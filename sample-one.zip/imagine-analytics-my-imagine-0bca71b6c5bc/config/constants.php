<?php

return [
    // ================== USER TYPES ==============================
    'user_types' => [
        'staff' => 'staff',
        'student'=> 'student',
        'agent'=> 'agent'
    ],
    // ======================== SYSTEM ROLES ============================
    'system_roles' => [
      'superadmin'=>'superadmin',
      'staff' => 'staff',
      'student' => 'student',
      'agent' => 'agent'
    ],
    // ======================== INSURANCE TYPES ============================
    'insurance_types' => [
        'single'=>'single',
        'couple'=>'couple',
        'family'=>'family'
    ],

    // ======================== Taxes ============================
    'taxes' => [
        'gst'=> [
            'label' => 'GST',
            'rate'=>0.1
        ]
    ],

    // ======================== PAYMENT METHOD TYPES ============================
    'payment_methods' => [
        'percentage'=> [
              'key'=> 'percentage',
              'label' => 'Percentage'
         ],
        'flat_fee'=>[
              'key'=> 'flat_fee',
              'label' => 'Flat Fee'
         ]
    ],

    // ======================== PROGRAM SERVICE TYPE ============================
    'program_service_types' => [
        'application'=> [
            'key'=> 'application',
            'label' => 'Per application'
        ],
        'course'=> [
            'key'=> 'course',
            'label' => 'Per course'
        ],
        'unit'=> [
            'key'=> 'unit',
            'label' => 'Per study unit'
        ],
    ],

    // ======================== ACCOMMODATION SERVICE TYPE ============================
    'accommodation_service_types' => [
        'application'=> [
            'key'=> 'application',
            'label' => 'Per application'
        ],
        'product'=> [
            'key'=> 'product',
            'label' => 'Per accommodation product'
        ],
        'unit'=> [
            'key'=> 'unit',
            'label' => 'Per accommodation unit'
        ],
    ],

    // =========================   EBECAS PRODUCT TYPES =====================================
    'ebecas_product_types'=>[
        'course'=>'course',
        'accommodation'=>'accommodation',
        'accommodation_arrangement'=>'arrangement',
        'insurance'=>'insurance',
        'airport'=>'airport',
        'other'=>'other',

    ],
    // =========================   IMAGINE PRODUCT TYPES =====================================
    'imagine_product_types'=>[
        'insurance'=>'Insurance',
        'accommodation'=>'Accommodation',
        'accommodation_service'=>'AccommodationService',
        'accommodation_addon'=>'AccommodationAddon',
        'program'=>'Program',
        'program_service'=>'ProgramService',
        'packaged_program'=>'PackagedProgram',
        'transportation' => 'Transportation',
        'transportation_service' => 'TransportationService',
        'transportation_addon' => 'TransportationAddon',
        'payment_method' => 'PaymentMethod'

    ],
    // =========================   SPECIAL OFFER SERVICE OFF TYPES =====================================
    'special_offer_service_off_types'=>[
        'percentage'=>'percentage',
        'value'=>'value',
        'override'=>'override',
    ],
    // ============================== APPLICATION FORM ================================
    'application_form' => [
        'status'=>[
            'draft'=>[
                'label'=>'Draft',
                'description'=>''
            ],
            'submitted'=>[
                'label'=>'Submitted',
                'description'=>''
            ],
            'application'=>[
                'label'=>'Application',
                'description'=>''
            ],
            'on_hold'=>[
                'label'=>'On-hold',
                'description'=>''
            ],
            'offer'=>[
                'label'=>'Offer Issued',
                'description'=>''
            ],
            'enrolled'=>[
                'label'=>'Enrolled',
                'description'=>''
            ],
            'cancelled'=>[
                'label'=>'Cancelled',
                'description'=>''
            ],
            'expired'=>[
                'label'=>'Expired',
                'description'=>''
            ],
        ],
        'documents'=>[
            'passport'=>[
                'label'=>'Passport / Photo ID',
                'description'
            ],
            'english_test'=>[
                'label'=>'English Test Results',
                'description'=>''
            ],
            'academic_results'=>[
                'label'=>'Academic Results',
                'description'=>''
            ],
            'other_results'=>[
                'label'=>'Other studies or employment',
                'description'=>''
            ],
            'financial_evidence' => [
                'label'=>'Financial Evidence',
                'description'=>''
            ]
        ]
    ],

    // ============================== LETTER OF OFFER ================================
    'section_type'=>[
        'section'=>'section',
        'page_break'=>'page break'
    ],

    // ============================== TinyCME ================================
    'tiny_api_key'=> env('TINY_MCE_KEY','f0hx8wcqw1qdj524jumsf9d6y20h5akb34hsjsjnn3wiab3a')
];
