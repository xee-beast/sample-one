<?php

namespace App\Policies;

use App\Models\Application;
use App\Models\User;
use Illuminate\Auth\Access\HandlesAuthorization;

class ApplicationPolicy
{
    use HandlesAuthorization;

    /**
     * @param User $user
     * @return bool
     */
    public function viewAny(User $user): bool{
        return !$user->isStaff() or $user->can('view-applications');
    }

    /**
     * @param User $user
     * @param Application $application
     * @return bool
     */
    public function view(User $user, Application $application): bool{
        if($user->isStaff())
            return $user->can('view-applications');

        return $application->owner == $user->id;
    }

    /**
     * @param User $user
     * @return bool
     */
    public function create(User $user): bool
    {
        if($user->isStaff())
            return $user->can('create-applications');

        return true;
    }

    /**
     * @param User $user
     * @param Application $application
     * @return bool
     */
    public function update(User $user, Application $application): bool
    {
        //If the application does not exist, the request if to 'create application
        if(!$application->exists)
            return $this->create($user);

        if($application->owner === $user->id)
            return true;

        if($user->isStaff())
            return $user->can('edit-applications');

        return  false;

    }

    /**
     * @param User $user
     * @param Application $application
     * @return bool
     */
    public function destroy(User $user, Application $application): bool{
       return false;
    }

    /**
     * @param User $user
     * @param Application $application
     * @return bool
     */
    public function updateProperties(User $user, Application $application): bool{
        return $user->isStaff() and $user->can('edit-application-properties');
    }


}
