<?php

namespace App\Policies;

use App\Models\CalendarCategory;
use App\Models\User;
use Illuminate\Auth\Access\HandlesAuthorization;

class CalendarCategoryPolicy
{
    use HandlesAuthorization;


    public function viewAny(User $user): bool
    {
        return $user->can('view-calendars');
    }

    public function view(User $user, CalendarCategory $calendarCategory): bool
    {
        return $user->can('view-calendars');
    }

    public function create(User $user): bool
    {
        return $user->can('create-calendars');
    }

    public function update(User $user, CalendarCategory $calendarCategory): bool
    {
        return $user->can('edit-calendars');
    }

    public function delete(User $user, CalendarCategory $calendarCategory): bool
    {
        return $user->can('edit-calendars');
    }

}
