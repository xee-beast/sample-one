<?php

namespace App\Policies;

use App\Models\Accommodation;
use App\Models\User;
use Illuminate\Auth\Access\HandlesAuthorization;

class AccommodationPolicy
{
    use HandlesAuthorization;

    /**
     * @param User $user
     * @return bool
     */
    public function viewAny(User $user): bool
    {
        return $user->can('view-accommodation');
    }

    /**
     * @param User $user
     * @param Accommodation $accommodation
     * @return bool
     */
    public function view(User $user, Accommodation $accommodation): bool
    {
        return $user->can('view-accommodation');
    }

    /**
     * @param User $user
     * @return bool
     */
    public function create(User $user): bool
    {
        return $user->can('create-accommodation');
    }

    /**
     * @param User $user
     * @param Accommodation $accommodation
     * @return bool
     */
    public function update(User $user, Accommodation $accommodation): bool
    {
        return $user->can('edit-accommodation');
    }

    /**
     * @param User $user
     * @param Accommodation $accommodation
     * @return bool
     */
    public function delete(User $user, Accommodation $accommodation): bool
    {
        return $user->can('edit-accommodation');
    }

}
