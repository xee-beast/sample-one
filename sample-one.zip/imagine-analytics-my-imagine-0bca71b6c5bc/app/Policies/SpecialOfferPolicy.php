<?php

namespace App\Policies;

use App\Models\SpecialOffer;
use App\Models\User;
use Illuminate\Auth\Access\HandlesAuthorization;

class SpecialOfferPolicy
{
    use HandlesAuthorization;

    public function viewAny(User $user): bool
    {
        return $user->can('view-special-offers');
    }

    public function view(User $user, SpecialOffer $specialOffer): bool
    {
        return $user->can('view-special-offers');
    }

    public function create(User $user): bool
    {
        return $user->can('create-special-offers');
    }

    public function update(User $user, SpecialOffer $specialOffer): bool
    {
        return $user->can('edit-special-offers');
    }

    public function delete(User $user, SpecialOffer $specialOffer): bool
    {
        return $user->can('edit-special-offers');
    }

}
