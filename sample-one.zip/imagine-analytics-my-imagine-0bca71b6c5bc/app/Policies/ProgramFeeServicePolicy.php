<?php

namespace App\Policies;

use App\Models\ProgramPriceBook;
use App\Models\ProgramFeeService;
use App\Models\User;
use Illuminate\Auth\Access\HandlesAuthorization;

class ProgramFeeServicePolicy
{
    use HandlesAuthorization;

    public function viewAny(User $user): bool
    {
        return $user->can('view-programs-fee-services');
    }

    public function view(User $user, ProgramFeeService $programService): bool
    {
        return $user->can('view-programs-fee-services');
    }

    public function create(User $user): bool
    {
        return $user->can('create-programs-fee-services');
    }

    public function update(User $user, ProgramFeeService $programService): bool
    {
        return $user->can('edit-programs-fee-services');
    }

    public function destroy(User $user, ProgramFeeService $programService): bool
    {
        return $user->can('edit-programs-fee-services');
    }

}
