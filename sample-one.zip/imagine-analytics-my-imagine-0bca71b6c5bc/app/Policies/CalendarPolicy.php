<?php

namespace App\Policies;

use App\Models\Calendar;
use App\Models\User;
use Illuminate\Auth\Access\HandlesAuthorization;

class CalendarPolicy
{
    use HandlesAuthorization;


    /**
     * @param User $user
     * @return bool
     */
    public function viewAny(User $user): bool
    {
        return $user->can('view-calendars');
    }

    /**
     * @param User $user
     * @param Calendar $calendar
     * @return bool
     */
    public function view(User $user, Calendar $calendar): bool
    {
        return $user->can('view-calendars');
    }

    /**
     * @param User $user
     * @return bool
     */
    public function create(User $user): bool
    {
        return $user->can('create-calendars');
    }

    /**
     * @param User $user
     * @param Calendar $calendar
     * @return bool
     */
    public function update(User $user, Calendar $calendar): bool
    {
        return $user->can('edit-calendars');
    }

    /**
     * @param User $user
     * @param Calendar $calendar
     * @return bool
     */
    public function delete(User $user, Calendar $calendar): bool
    {
        return $user->can('edit-calendars');
    }

}
