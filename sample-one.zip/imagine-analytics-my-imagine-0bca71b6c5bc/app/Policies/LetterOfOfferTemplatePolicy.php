<?php

namespace App\Policies;

use App\Models\LetterOfOfferTemplate;
use App\Models\User;
use Illuminate\Auth\Access\HandlesAuthorization;

class LetterOfOfferTemplatePolicy
{
    use HandlesAuthorization;


    public function viewAny(User $user): bool
    {
        return $user->can('view-letter-of-offer-templates');
    }

    public function view(User $user, LetterOfOfferTemplate $template): bool
    {
        return $user->can('view-letter-of-offer-templates');
    }

    public function create(User $user): bool
    {
        return $user->can('create-letter-of-offer-templates');
    }

    public function update(User $user, LetterOfOfferTemplate $template): bool
    {
        return $user->can('edit-letter-of-offer-templates');
    }

    public function delete(User $user, LetterOfOfferTemplate $template): bool
    {
        return $user->can('edit-letter-of-offer-templates');
    }


}
