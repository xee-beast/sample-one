<?php

namespace App\Policies;

use App\Models\PaymentMethod;
use App\Models\User;
use Illuminate\Auth\Access\HandlesAuthorization;

class PaymentMethodPolicy
{
    use HandlesAuthorization;


    public function viewAny(User $user): bool
    {
        return $user->can('view-payment-methods');
    }

    public function view(User $user, PaymentMethod $paymentMethod): bool
    {
        return $user->can('view-payment-methods');
    }

    public function create(User $user): bool
    {
        return $user->can('create-payment-methods');
    }

    public function update(User $user, PaymentMethod $paymentMethod): bool
    {
        return $user->can('edit-payment-methods');
    }

    public function destroy(User $user, PaymentMethod $paymentMethod): bool
    {
        return $user->can('edit-payment-methods');
    }



}
