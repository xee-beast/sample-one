<?php

namespace App\Policies;

use App\Models\Insurance;
use App\Models\User;
use Illuminate\Auth\Access\HandlesAuthorization;

class InsurancePolicy
{
    use HandlesAuthorization;


    public function viewAll(User $user): bool
    {
        return $user->can('edit-insurance');
    }


    public function update(User $user, Insurance $insurance): bool
    {
        return $user->can('edit-insurance');
    }

}
