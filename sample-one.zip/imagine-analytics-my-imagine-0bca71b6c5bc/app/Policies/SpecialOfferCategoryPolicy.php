<?php

namespace App\Policies;

use App\Models\SpecialOfferCategory;
use App\Models\User;
use Illuminate\Auth\Access\HandlesAuthorization;

class SpecialOfferCategoryPolicy
{
    use HandlesAuthorization;

    public function viewAny(User $user): bool
    {
        return $user->can('view-special-offer-categories');
    }

    public function view(User $user, SpecialOfferCategory $specialOfferCategory): bool
    {
        return $user->can('view-special-offer-categories');
    }

    public function create(User $user): bool
    {
        return $user->can('create-special-offer-categories');
    }

    public function update(User $user, SpecialOfferCategory $specialOfferCategory): bool
    {
        return $user->can('edit-special-offer-categories');
    }

    public function delete(User $user, SpecialOfferCategory $specialOfferCategory): bool
    {
        return $user->can('edit-special-offer-categories');
    }

}
