<?php

namespace App\Policies;

use App\Models\User;
use App\Models\Visa;
use Illuminate\Auth\Access\HandlesAuthorization;

class VisaPolicy
{
    use HandlesAuthorization;


    public function viewAny(User $user): bool
    {
        return $user->can('view-visas');
    }

    public function view(User $user, Visa $visa): bool
    {
        return $user->can('view-visas');
    }

    public function create(User $user): bool
    {
        return $user->can('create-visas');
    }

    public function update(User $user, Visa $visa): bool
    {
        return $user->can('edit-visas');
    }

    public function delete(User $user, Visa $visa): bool
    {
        return $user->hasRole(config('constants.system_roles.superadmin'));
    }

}
