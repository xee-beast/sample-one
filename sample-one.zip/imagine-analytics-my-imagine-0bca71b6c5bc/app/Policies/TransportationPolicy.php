<?php

namespace App\Policies;

use App\Models\Transportation;
use App\Models\User;
use Illuminate\Auth\Access\HandlesAuthorization;

class TransportationPolicy
{
    use HandlesAuthorization;

    /**
     * @param User $user
     * @return bool
     */
    public function viewAny(User $user): bool
    {
        return $user->can('view-transportation');
    }

    /**
     * @param User $user
     * @param Transportation $transportation
     * @return bool
     */
    public function view(User $user, Transportation $transportation): bool
    {
        return $user->can('view-transportation');
    }

    /**
     * @param User $user
     * @return bool
     */
    public function create(User $user): bool
    {
        return $user->can('create-transportation');
    }

    /**
     * @param User $user
     * @param Transportation $transportation
     * @return bool
     */
    public function update(User $user, Transportation $transportation): bool
    {
        return $user->can('edit-transportation');
    }

    /**
     * @param User $user
     * @param Transportation $transportation
     * @return bool
     */
    public function delete(User $user, Transportation $transportation): bool
    {
        return $user->can('edit-transportation');
    }

}
