<?php

namespace App\Policies;

use App\Models\ProgramPriceBook;
use App\Models\User;
use Illuminate\Auth\Access\HandlesAuthorization;

class ProgramPriceBookPolicy
{
    use HandlesAuthorization;

    public function viewAny(User $user): bool
    {
        return $user->can('view-programs-pricebooks');
    }

    public function view(User $user, ProgramPriceBook $programPriceBook): bool
    {
        return $user->can('view-programs-pricebooks');
    }

    public function create(User $user): bool
    {
        return $user->can('create-programs-pricebooks');
    }

    public function update(User $user, ProgramPriceBook $programPriceBook): bool
    {
        return $user->can('edit-programs-pricebooks');
    }

    public function delete(User $user, ProgramPriceBook $programPriceBook): bool
    {
        return $user->can('edit-programs-pricebooks');
    }

}
