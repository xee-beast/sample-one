<?php

namespace App\Policies;

use App\Models\Faculty;
use App\Models\User;
use Illuminate\Auth\Access\HandlesAuthorization;

class FacultyPolicy
{
    use HandlesAuthorization;

    /**
     * @param User $user
     * @return bool
     */
    public function viewAll(User $user): bool
    {
        return $user->can('view-faculties');
    }

    /**
     * @param User $user
     * @param Faculty $faculty
     * @return bool
     */
    public function view(User $user, Faculty $faculty): bool
    {
        return $user->can('view-faculties');
    }

    /**
     * @param User $user
     * @return bool
     */
    public function create(User $user): bool
    {
        return $user->can('create-faculties');
    }

    /**
     * @param User $user
     * @param Faculty $faculty
     * @return bool
     */
    public function update(User $user, Faculty $faculty): bool
    {
        return $user->can('edit-faculties');
    }

    /**
     * @param User $user
     * @param Faculty $faculty
     * @return bool
     */
    public function delete(User $user, Faculty $faculty): bool
    {
        return $user->can('edit-faculties');
    }

}
