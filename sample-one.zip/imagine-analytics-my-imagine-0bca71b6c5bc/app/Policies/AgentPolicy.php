<?php

namespace App\Policies;

use App\Models\Agent;
use App\Models\User;
use Illuminate\Auth\Access\HandlesAuthorization;

class AgentPolicy
{
    use HandlesAuthorization;


    public function viewAny(User $user): bool
    {
        return $user->can('view-agents');
    }

    public function view(User $user, Agent $agent): bool
    {
        return $user->can('view-agents');
    }

    public function create(User $user): bool
    {
        return $user->can('create-agents');
    }

    public function update(User $user, Agent $agent): bool
    {
        return $user->can('edit-agents');
    }


}
