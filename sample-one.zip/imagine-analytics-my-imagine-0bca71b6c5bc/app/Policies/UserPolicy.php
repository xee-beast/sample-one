<?php

namespace App\Policies;

use App\Models\User;
use Illuminate\Auth\Access\HandlesAuthorization;

class UserPolicy
{
    use HandlesAuthorization;


    public function viewAny(User $user): bool
    {
        return
                $user->can('view-staff-users')
                or $user->can('view-student-users')
                or $user->can('view-agent-users');
    }

    public function view(User $user, User $model): bool
    {
        if($model->hasRole(config('constants.system_roles.superadmin')) and !$user->hasRole(config('constants.system_roles.superadmin'))){
            return false;
        }

        if ($model->user_type === config('constants.system_roles.staff') and  $user->can('view-staff-users'))
            return true;
        if ($model->user_type === config('constants.system_roles.agent') and  $user->can('view-agent-users'))
            return true;
        if ($model->user_type === config('constants.system_roles.student') and  $user->can('view-student-users'))
            return true;

        return false;
    }

    public function create(User $user): bool
    {
        return
            $user->can('create-staff-users')
            or $user->can('create-student-users')
            or $user->can('create-agent-users');
    }

    public function update(User $user, User $model): bool
    {
        if($model->hasRole(config('constants.system_roles.superadmin')) and !$user->hasRole(config('constants.system_roles.superadmin'))){
            return false;
        }

        return
            $user->can('edit-staff-users')
            or $user->can('edit-student-users')
            or $user->can('edit-agent-users');
    }

    public function delete(User $user, User $model): bool
    {
        return false;
    }
}
