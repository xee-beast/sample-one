<?php

namespace App\Policies;

use App\Models\Agent;
use App\Models\LetterOfOfferSection;
use App\Models\User;
use Illuminate\Auth\Access\HandlesAuthorization;

class LetterOfOfferSectionPolicy
{
    use HandlesAuthorization;


    public function viewAny(User $user): bool
    {
        return $user->can('view-letter-of-offer-sections');
    }

    public function view(User $user, LetterOfOfferSection $section): bool
    {
        return $user->can('view-letter-of-offer-sections');
    }

    public function create(User $user): bool
    {
        return $user->can('create-letter-of-offer-sections');
    }

    public function update(User $user, LetterOfOfferSection $section): bool
    {
        return $user->can('edit-letter-of-offer-sections');
    }

    public function delete(User $user, LetterOfOfferSection $section): bool
    {
        return $user->can('edit-letter-of-offer-sections');
    }


}
