<?php

namespace App\Policies;

use App\Models\AccommodationPriceBookCategory;
use App\Models\User;
use Illuminate\Auth\Access\HandlesAuthorization;

class AccommodationPriceBookCategoryPolicy
{
    use HandlesAuthorization;

    public function viewAny(User $user): bool
    {
        return $user->can('view-accommodation-pricebooks');
    }

    public function view(User $user, AccommodationPriceBookCategory $accommodationPriceBookCategory): bool
    {
        return $user->can('view-accommodation-pricebooks');
    }

    public function create(User $user): bool
    {
        return $user->can('create-accommodation-pricebooks');
    }

    public function update(User $user, AccommodationPriceBookCategory $accommodationPriceBookCategory): bool
    {
        return $user->can('edit-accommodation-pricebooks');
    }

    public function delete(User $user, AccommodationPriceBookCategory $accommodationPriceBookCategory): bool
    {
        return $user->can('edit-accommodation-pricebooks');
    }

}
