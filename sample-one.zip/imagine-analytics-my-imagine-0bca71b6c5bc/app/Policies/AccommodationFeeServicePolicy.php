<?php

namespace App\Policies;

use App\Models\AccommodationFeeService;
use App\Models\User;
use Illuminate\Auth\Access\HandlesAuthorization;

class AccommodationFeeServicePolicy
{
    use HandlesAuthorization;

    /**
     * @param User $user
     * @return bool
     */
    public function viewAny(User $user): bool
    {
        return $user->can('view-accommodation-fee-services');
    }

    /**
     * @param User $user
     * @param AccommodationFeeService $accommodationFeeService
     * @return bool
     */
    public function view(User $user, AccommodationFeeService $accommodationFeeService): bool
    {
        return $user->can('view-accommodation-fee-services');
    }

    /**
     * @param User $user
     * @return bool
     */
    public function create(User $user): bool
    {
        return $user->can('create-accommodation-fee-services');
    }

    /**
     * @param User $user
     * @param AccommodationFeeService $accommodationFeeService
     * @return bool
     */
    public function update(User $user, AccommodationFeeService $accommodationFeeService): bool
    {
        return $user->can('edit-accommodation-fee-services');
    }

    /**
     * @param User $user
     * @param AccommodationFeeService $accommodationFeeService
     * @return bool
     */
    public function delete(User $user, AccommodationFeeService $accommodationFeeService): bool
    {
        return $user->can('edit-accommodation-fee-services');
    }

}
