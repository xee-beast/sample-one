<?php

namespace App\Policies;

use App\Models\TransportationFeeAddon;
use App\Models\User;
use Illuminate\Auth\Access\HandlesAuthorization;

class TransportationFeeAddonPolicy
{
    use HandlesAuthorization;

    /**
     * @param User $user
     * @return bool
     */
    public function viewAny(User $user): bool
    {
        return $user->can('view-transportation-fee-addons');
    }

    /**
     * @param User $user
     * @param TransportationFeeAddon $transportationFeeAddon
     * @return bool
     */
    public function view(User $user, TransportationFeeAddon $transportationFeeAddon): bool
    {
        return $user->can('view-transportation-fee-addons');
    }

    /**
     * @param User $user
     * @return bool
     */
    public function create(User $user): bool
    {
        return $user->can('create-transportation-fee-addons');
    }

    /**
     * @param User $user
     * @param TransportationFeeAddon $transportationFeeAddon
     * @return bool
     */
    public function update(User $user, TransportationFeeAddon $transportationFeeAddon): bool
    {
        return $user->can('edit-transportation-fee-addons');
    }

    /**
     * @param User $user
     * @param TransportationFeeAddon $transportationFeeAddon
     * @return bool
     */
    public function delete(User $user, TransportationFeeAddon $transportationFeeAddon): bool
    {
        return $user->can('edit-transportation-fee-addons');
    }

}
