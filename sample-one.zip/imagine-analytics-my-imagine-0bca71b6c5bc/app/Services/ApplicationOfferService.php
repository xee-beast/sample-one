<?php


namespace App\Services;

use App\Events\ApplicationTimeLine;
use App\Models\Application;
use App\Models\Program;
use Carbon\Carbon;
use Illuminate\Support\Facades\App;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use function Symfony\Component\Translation\t;

class ApplicationOfferService extends ApplicationService
{

    protected $programGroupId;
    protected bool $errors = false;

    /**
     *
     * @param int $offer_id
     * @return array
     */
    public function getOfferFromEbecas(int $offer_id): array{

        return $this->ebecasOfferService->getOffer($offer_id);
    }


    public function createOfferInEbecas(Application $application): array{

        $offerData = $this->generateDataObjectForOffer($application);

        if ($this->errors){
            $result['success'] = false;
            $result['message'] = 'Unable to create offer. At least one item does not have an ebecas_id. Check the logs for more details.';
            return $result;
        }

        if(count($offerData) == 0){
            $result['success'] = false;
            $result['message'] = 'The application does not have any data to create an offer in Ebecas or there is not an Ebecas student associated with the application';
            return $result;
        }
        return  $this->ebecasOfferService->createOffer($offerData);
    }

    /**
     * @param Application $application
     * @return array
     */
    public function generateDataObjectForOffer(Application $application): array{

        $offerArr = $this->getOfferBaseDetails($application);

        if(!count($offerArr))
            return [];

        $offerArr['OfferItems'] = $this->getOfferItems($application);

        return $offerArr;
    }

    /**
     * @param Application $application
     * @return array
     */
    public function getOfferBaseDetails(Application $application): array
    {

        if (!$application->student_id){
            return [];
        }

        $agentId = 0;
        if ($application->applicationOwner->isAgent() && !is_null($application->applicationOwner->agent_id)){
            $agentId = $application->applicationOwner->agent->ebecas_id;
        }

        return [
            'AgentId'   => $agentId,
            'StudentId' => $application->student_id,
            'OfferDate' => Carbon::now()->format('Y-m-d'),
            'OfferTypeId'=> 15, //15=Conditional, 16=full, 17=extension, 60=Change of course, 74=variance
            'VisaTypeId'=>$application->detail->visaApplyingFor->ebecas_id,
            'Notes'     => "$application->comments\n\n*Offer created by myImagine. Application #$application->id."

        ];
    }

    /**
     * @param Application $application
     * @return array
     */
    public function getOfferItems(Application $application): array
    {
        $this->programGroupId = null;

        $offerArr = [];
        // programs
        $programArr = $this->generateProgramData($application);
        $offerArr = array_merge($offerArr, $programArr);

        $programServiceArr = $this->generateProgramServiceData($application, $programArr);
        if ( !empty($programServiceArr) ){
            $offerArr = array_merge($offerArr,$programServiceArr);
        }

        // accommodations
        $accommodationArr = $this->generateAccommodationData($application);
        if ( !empty($accommodationArr) ){
            $offerArr = array_merge($offerArr,$accommodationArr);
        }


        $accommodationServiceArr = $this->generateAccommodationServiceData($application);
        if ( !empty($accommodationServiceArr) ){
            $offerArr = array_merge($offerArr,$accommodationServiceArr);
        }

        $accommodationAddonArr = $this->generateAccommodationAddonData($application);
        if ( !empty($accommodationAddonArr) ){
            $offerArr = array_merge($offerArr,$accommodationAddonArr);
        }

        // transportations
        $transportationArr = $this->generateTransportationData($application);
        if ( !empty($transportationArr) ){
            $offerArr = array_merge($offerArr,$transportationArr);
        }

        $transportationServiceArr = $this->generateTransportationServiceData($application);
        if ( !empty($transportationServiceArr) ){
            $offerArr = array_merge($offerArr,$transportationServiceArr);
        }

        $transportationAddonArr = $this->generateTransportationAddonData($application);
        if ( !empty($transportationAddonArr) ){
            $offerArr = array_merge($offerArr,$transportationAddonArr);
        }

        // insurance
        $insuranceArr = $this->generateInsuranceData($application);
        if ( !empty($insuranceArr) ){
            $offerArr = array_merge($offerArr,$insuranceArr);
        }

        // payment method
        $paymentArr = $this->generatePaymentData($application);
        if(count($paymentArr))
            $offerArr = array_merge($offerArr,[$paymentArr]);

        return $offerArr;
    }

    /**
     * @param Application $application
     * @return array
     */
    public function generateProgramData(Application $application): array
    {
        $programs = $this->getApplicationProgramsData($application, true);

        $programArr = [];
        $groupCount = 1;
        foreach ($programs as $program){
            $facultyId = $program['faculty_id'];
            $programId = $program['program_id'];
            $this->programGroupId[$programId] = $groupCount;

            $product = DB::table('faculty_program')->whereFacultyId($facultyId)->whereProgramId($programId)->first();

            if (!$product){
                $this->logProductIdError($application->id, $facultyId, 'Program', $programId);
            }

            $programArr[] = [
                'ProductId'         => $product?->ebecas_product_id,
                'FromDate'          => Carbon::parse($program['start_date'])->format('Y-m-d'),
                'PeriodWeeks'       => $program['length'],
                'Amount'            => 0,
                'CommissionAmount'  => 0,
                'TaxAmount'         => 0,
                'Notes'             => "",
                'GroupId'           => $groupCount,
                'AgentCommissionId' => $this->getAgentCommissionId($application, $programId)
            ];
            $groupCount++;
        }
        return $programArr;
    }

    /**
     * @param Application $application
     * @param array $programArr
     * @return array
     */
    public function generateProgramServiceData(Application $application, $programArr): array
    {
        $programServices = $this->getApplicationProgramServices($application, true);
        $programServiceArr = [];

        foreach ($programServices as $service){
            $facultyId = $service['faculty_id'];
            $serviceId = $service['service_id'];

            $product = DB::table('faculty_program_service')->whereFacultyId($facultyId)->whereProgramFeeServiceId($serviceId)->first();

            if (!$product){
                $this->logProductIdError($application->id, $facultyId, 'Program Service', $serviceId);
            }


            $resultantArr = array_filter($programArr, function($item, $itemKey) use ($service){
                return $item['FromDate'] === $service['program_start_date'];
            }, ARRAY_FILTER_USE_BOTH);

            if (sizeof($resultantArr)===0){
                $this->logProductIdError($application->id, $facultyId, 'Program Service', $serviceId);
            }

            $programServiceArr[] = [
                'ProductId'         => $product?->ebecas_product_id,
                'Amount'            => 0,
                'CommissionAmount'  => 0,
                'TaxAmount'         => 0,
                'Notes'             => "",
                // if service is type application then use '1' else program group id
                'GroupId'           => $service['type'] === 'application' ? 1 : reset($resultantArr)['GroupId']
            ];
        }

        return $programServiceArr;
    }

    /**
     * @param Application $application
     * @return array
     */
    public function generateAccommodationData(Application $application): array
    {
        $accommodations = $this->getApplicationAccommodationsData($application);
        $accommodationArr = [];
        foreach ($accommodations as $accommodation){
            $facultyId = $accommodation['faculty_id'];
            $accommodationId = $accommodation['accommodation_id'];

            $product = DB::table('faculty_accommodation')->whereFacultyId($facultyId)->whereAccommodationId($accommodationId)->first();

            if (!$product){
                $this->logProductIdError($application->id, $facultyId, 'Accommodation', $accommodationId);
            }

            $accommodationArr[] = [
                'ProductId'         => $product?->ebecas_product_id,
                'FromDate'          => Carbon::parse($accommodation['start_date'])->format('Y-m-d'),
                'ToDate'            => Carbon::parse($accommodation['end_date'])->format('Y-m-d'),
                'PeriodWeeks'       => $accommodation['weeks'],
                'PeriodDays'        => $accommodation['days'],
                'Amount'            => 0,
                'CommissionAmount'  => 0,
                'TaxAmount'         => 0,
                'Notes'             => "",
                'GroupId'           => 1,
            ];
        }
        return $accommodationArr;
    }

    /**
     * @param Application $application
     * @return array
     */
    public function generateAccommodationServiceData(Application $application): array
    {
        $accommodationServices = $this->getApplicationAccommodationServices($application, true);
        $accommodationServiceArr = [];

        foreach ($accommodationServices as $service){
            $facultyId = $service['faculty_id'];
            $serviceId = $service['service_id'];

            $product = DB::table('faculty_accommodation_service')->whereFacultyId($facultyId)->whereFeeServiceId($serviceId)->first();

            if (!$product){
                $this->logProductIdError($application->id, $facultyId, 'Accommodation Service', $serviceId);
            }

            $accommodationServiceArr[] = [
                'ProductId'         => $product?->ebecas_product_id,
                'Amount'            => 0,
                'CommissionAmount'  => 0,
                'TaxAmount'         => 0,
                'Notes'             => "",
                'GroupId'           => 1,
            ];
        }

        return $accommodationServiceArr;
    }

    /**
     * @param Application $application
     * @return array
     */
    public function generateAccommodationAddonData(Application $application): array
    {
        $accommodationAddons = $this->getApplicationAccommodationAddons($application, true);
        $accommodationAddonArr = [];

        foreach ($accommodationAddons as $service){
            $facultyId = $service['faculty_id'];
            $serviceId = $service['addon_id'];

            $product = DB::table('faculty_accommodation_addon')->whereFacultyId($facultyId)->whereAddonId($serviceId)->first();

            if (!$product){
                $this->logProductIdError($application->id, $facultyId, 'Accommodation Addon', $serviceId);
            }

            $accommodationAddonArr[] = [
                'ProductId'         => $product?->ebecas_product_id,
                'Amount'            => 0,
                'CommissionAmount'  => 0,
                'TaxAmount'         => 0,
                'Notes'             => "",
                'GroupId'           => 1,
            ];
        }

        return $accommodationAddonArr;
    }

    /**
     * @param Application $application
     * @return array
     */
    public function generateTransportationData(Application $application): array
    {
        $transportations = $this->getApplicationTransportationData($application);
        $transportationArr = [];
        foreach ($transportations as $transportation){
            $facultyId = $transportation['faculty_id'];
            $transportationId = $transportation['transportation_id'];

            $product = DB::table('faculty_transportation')->whereFacultyId($facultyId)->whereTransportationId($transportationId)->first();

            if (!$product){
                $this->logProductIdError($application->id, $facultyId, 'Transportation', $transportationId);
            }

            $transportationArr[] = [
                'ProductId'         => $product?->ebecas_product_id,
                'Amount'            => 0,
                'CommissionAmount'  => 0,
                'TaxAmount'         => 0,
                'Notes'             => "",
                'GroupId'           => 1,
            ];
        }
        return $transportationArr;
    }

    /**
     * @param Application $application
     * @return array
     */
    public function generateTransportationServiceData(Application $application): array
    {
        $transportationServices = $this->getApplicationTransportationServices($application, true);
        $transportationServiceArr = [];

        foreach ($transportationServices as $service){
            $facultyId = $service['faculty_id'];
            $serviceId = $service['service_id'];

            $product = DB::table('faculty_transportation_service')->whereFacultyId($facultyId)->whereFeeServiceId($serviceId)->first();

            if (!$product){
                $this->logProductIdError($application->id, $facultyId, 'Transportation Service', $serviceId);
            }

            $transportationServiceArr[] = [
                'ProductId'         => $product?->ebecas_product_id,
                'Amount'            => 0,
                'CommissionAmount'  => 0,
                'TaxAmount'         => 0,
                'Notes'             => "",
                'GroupId'           => 1,
            ];
        }

        return $transportationServiceArr;
    }

    /**
     * @param Application $application
     * @return array
     */
    public function generateTransportationAddonData(Application $application): array
    {
        $transportationAddons = $this->getApplicationTransportationAddons($application, true);
        $transportationAddonArr = [];

        foreach ($transportationAddons as $service){
            $facultyId = $service['faculty_id'];
            $serviceId = $service['addon_id'];

            $product = DB::table('faculty_transportation_addon')->whereFacultyId($facultyId)->whereAddonId($serviceId)->first();

            if (!$product){
                $this->logProductIdError($application->id, $facultyId, 'Transportation Addon', $serviceId);
            }

            $transportationAddonArr[] = [
                'ProductId'         => $product?->ebecas_product_id,
                'Amount'            => 0,
                'CommissionAmount'  => 0,
                'TaxAmount'         => 0,
                'Notes'             => "",
                'GroupId'           => 1,
            ];
        }

        return $transportationAddonArr;
    }

    /**
     * @param Application $application
     * @return array
     */
    public function generateInsuranceData(Application $application): array
    {
        $insurances = $this->getApplicationInsurancesData($application);
        $insuranceArr = [];

        foreach ($insurances as $service){
            $facultyId = $service['faculty_id'];
            $insuranceId = $service['insurance_id'];
            $duration = $service['duration'];

            $product = DB::table('insurance_fees')->select('faculty_insurance.ebecas_product_id', 'insurance_fees.duration')
                ->leftJoin('faculty_insurance', 'faculty_insurance.insurance_fee_id', '=', 'insurance_fees.id')
                ->where('insurance_fees.insurance_id', $insuranceId)->where('insurance_fees.duration', $duration)
                ->where('faculty_insurance.faculty_id', $facultyId)->first();

            if (!$product){
                $this->logProductIdError($application->id, $facultyId, 'Insurance', $insuranceId);
            }

            $insuranceArr[] = [
                'ProductId'         => $product?->ebecas_product_id,
                'PeriodMonths'      => $product?->duration,
                'FromDate'          => Carbon::createFromFormat('d/m/Y', $service['start_date'])->format('Y-m-d'),
                'ToDate'            => Carbon::createFromFormat('d/m/Y', $service['end_date'])->format('Y-m-d'),
                'Amount'            => 0,
                'CommissionAmount'  => 0,
                'TaxAmount'         => 0,
                'Notes'             => "",
                'GroupId'           => 1,
            ];
        }

        return $insuranceArr;
    }

    /**
     * @param Application $application
     * @return array
     */
    public function generatePaymentData(Application $application): array
    {
        $paymentMethod = $application->payment->toArray();

        $facultyId = $paymentMethod['faculty_id'];
        $paymentId = $paymentMethod['payment_method_id'];

        $product_id = DB::table('faculty_payment_method')->whereFacultyId($facultyId)->wherePaymentMethodId($paymentId)->first()->ebecas_product_id;

        if(!$product_id)
            return [];

        return [
            'ProductId'         => $product_id,
            'Amount'            => 0,
            'CommissionAmount'  => 0,
            'TaxAmount'         => 0,
            'Notes'             => "",
            'GroupId'           => 1,
        ];
    }

    /**
     * sync the application status from offer details from Ebecas.
     * @param Application $application
     * @return array
     */
    public function syncOffer(Application $application): array
    {

        $response = $this->getOfferFromEbecas($application->offer_id);
        if(!$response['success']){
            return [
                'success' => false,
                'offerData' => $response
            ];
        }
        $offerData = $response['data'];
        $oldStatus = $application->status;
        if ($oldStatus !== strtolower($offerData['OfferStatus'])){
            ApplicationTimeLine::dispatch([
                'application' => $application,
                'user' => auth()->check() ? auth()->user():getBotUser(),
                'event_type' => 'offer_status'
            ]);

            $application->status = strtolower($offerData['OfferStatus']);
            $application->save();

            $application->refresh();
            ApplicationTimeLine::dispatch([
                'application' => $application,
                'user' => auth()->check() ? auth()->user():getBotUser(),
                'old_status'=>$oldStatus,
                'new_status'=>$application->status,
                'event_type' => 'status_changed'
            ]);
        }
        return [
            'success' => true,
            'offerData' =>$offerData
        ];
    }

    /**
     * @param Application $application
     * @param $programId
     * @return mixed
     */
    public function getAgentCommissionId(Application $application, $programId){

        if (!$application->applicationOwner->agent){
            return null;
        }

        $value = null;
        $commissionError = false;
        $program = Program::find($programId);
        if ($program->is_language){
            if (!$application->applicationOwner->agent->language_commission_id){
                $commissionError = true;
            }
            $value = $application->applicationOwner->agent->language_commission_id;
        }else{
            if (!$application->applicationOwner->agent->vet_commission_id){
                $commissionError = true;
            }
            $value = $application->applicationOwner->agent->vet_commission_id;
        }

        if ($commissionError){
            Log::critical( "Application # ". $application->id .": Agent with ID: ". $application->applicationOwner->agent->id . " does not have commission set.  An offer might have been created without the commission.");
        }

        return $value;
    }

    /*
     * @param $facultyId
     * @param $entity
     * @param $entityId
     * @return void
     */
    public function logProductIdError($applicationId, $facultyId, $entity, $entityId): void
    {
        $this->errors = true;
        Log::critical("Unable to create offer in Ebecas for Application Id : $applicationId \r\n -> Ebecas product id not found for : faculty => $facultyId and $entity => $entityId");
    }
}
