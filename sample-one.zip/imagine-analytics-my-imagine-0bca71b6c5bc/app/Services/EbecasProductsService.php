<?php

namespace App\Services;

use App\Classes\Settings\EbecasSettings;
use Exception;
use Illuminate\Support\Facades\Http;

class EbecasProductsService extends EbecasService
{

    /**
     * Get the products by its id
     * @param int $productId Id of the product
     * @return array
     */
    public function getProduct(int $productId){

        $result = ['success'=>true, 'message'=>null, 'data'=>null];

        $keysToKeep =['ProductId', 'Code', 'Name', 'FacultyId'];

        $response =  $this->sendRequest(
            "/api/product/$productId",
            'get',
            []
        );

        if(!$response['ProductId']){
            return $result;
        }

        $result['data'] = array_intersect_key($response, array_flip($keysToKeep));

        return $result;

    }

    /**
     * Get the products for a faculty
     * @param int $facultyId Faculty to filter the products by.
     * @param array $products Each product should include the key 'FacultyId' with the id
     * of the faculty for the product.
     * @return array Array with the list of the products for the given faculty only.
     */
    public function filterProductsByFaculty(int $facultyId, array $products){

        $data = [];

        foreach ($products as $product){
            if($product['FacultyId'] == $facultyId){
                $data[] = $product;
            }
        }

        return $data;
    }

    /**
     * Get the products. If a faculty is provided, only the programs for that faculty will be included in the
     * response. If a productType is provided, only the products of that type will be included.
     * @param ?int $facultyId Faculty to filter the products by
     * @param ?string $productType Type of the product
     * @return array
     */
    public function getProducts(?int $facultyId = null, ?string $productType = null): array{

        $result = ['success'=>true, 'message'=>null,'count'=> null, 'data'=>[]];

        $keysToKeep =['ProductId', 'Code', 'Name', 'FacultyId'];

        $response =  $this->sendRequest(
            "/api/product/$productType",
            'get',
            ['PageSize'=>10000]
        );


        if(!isset($response['Products'])){
            $result['success'] = false;
            $result['message'] = 'Payload missing on response';
            return $result;
        }
        $products = $response['Products'];

        if($facultyId){
            $response = $this->filterProductsByFaculty(facultyId: $facultyId, products: $products);
            $products = $response;
        }

        $result['count'] = count($products);

        if(count($products)){
            foreach ($products as $key=>$value){
                $result['data'][] = array_intersect_key($value, array_flip($keysToKeep));
            }
        }

        return $result;
    }

}
