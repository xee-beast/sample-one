<?php

namespace App\Services;

use App\Classes\Settings\EbecasSettings;
use Exception;
use Illuminate\Support\Facades\Http;

class EbecasService
{
    /**
     * The HTTP Client instance.
     */
    protected Http $httpClient;
    protected EbecasSettings $ebecasSettings;

    function __construct(EbecasSettings $ebecasSettings){
        $this->ebecasSettings = $ebecasSettings;
    }

    /**
     * Get an instance of the HTTP client.
     *
     * @return Http
     */
    protected function httpClient($body)
    {
        $headers = [
            'Content-Type' => 'application/json',
            'COLLEGECODE' => $this->ebecasSettings->college_code,
            'USERNAME' => $this->ebecasSettings->api_username,
            'Authorization' => $this->getAuthorization()
        ];

        $client = Http::withHeaders($headers);

        if(!empty($body)){
            $client = $client->withBody(json_encode($body),'application/json');
        }
//        return Http::dd()->withHeaders($headers)->baseUrl($this->ebecasSettings->api_url);
        return $client->baseUrl($this->ebecasSettings->api_url);
    }

    /**
     * Get authorization for request.
     *
     * @return string
     */
    protected function getAuthorization(): string
    {
        return 'Basic '.base64_encode($this->ebecasSettings->api_key.':'.$this->ebecasSettings->api_secret);
    }

    /**
     * Send the request to the Equator Service
     * @param string $endpoint
     * @return array
     */
    protected function sendRequest(string $endpoint, string $method='get', array $params=[], array $body=[]): array
    {
        try{

            $response = match ($method) {
                'post' => $this->httpClient($body)->post($endpoint, $params),
                'patch'=> $this->httpClient($body)->patch($endpoint, $params),
                'delete'=> $this->httpClient($body)->delete($endpoint, $params),
                default => $this->httpClient($body)->get($endpoint, $params)
            };

            if($response->successful()){
                return json_decode($response->body(),true);
            }

            if(!$response->ok() and $response->body()){
                    return json_decode($response->body(),true);
            }


            $response->onError(function() use ($response){
                $response->throw();
            });
        }catch(Exception $exp){

            $response = [
                'success' => false,
                'message' => $exp->getMessage()
            ];
        }
        return $response;
    }

    /**
     * Test the connection
     * @return boolean True: Connection successful. False: Connection Unsuccessful.
     */
    public function testConnection(){
        $response = $this->getAllLocations();
        return $response['success'];
    }


    /**
     * Get the list of all the agents
     * @return array
     */
    public function getAllAgents(){

        $result = ['success'=>true, 'message'=>null,'count'=> null, 'data'=>null];

        $response =  $this->sendRequest(
            "/api/report/AGENTLISTING",
            'get',
            ['PageSize'=>10000]
        );

        if(!isset($response['ReportRecords'])){
            $result['success'] = false;
            $result['message'] = 'Payload missing on response';
            return $result;
        }
        $result['count'] = $response['RecordCount'];
        $result['data'] = $response['ReportRecords'];

        return $result;
    }

    /**
     * Get the details for an agent
     * @param int $agent_id Id of the agent to get the details for.
     * @return array
     */
    public function getAgentById(int $agent_id){

        $result = ['success'=>true, 'message'=>null, 'data'=>null];

        $response =  $this->sendRequest(
            "/api/agent/$agent_id",
            'get',
            []
        );

        $result['data'] = $response;

        return $result;
    }

    /**
     * Get the commission rates for an agent
     * @param int $agent_id ID of the agent to get the details for.
     * @return array
     */
    public function getAgentCommissions(int $agent_id){

        $result = ['success'=>true, 'message'=>null, 'data'=>null];

        $response =  $this->sendRequest(
            "/api/agent/$agent_id/commission",
            'get',
            []
        );

        $result['data'] = $response['CommissionItems'] ?? [] ;

        return $result;
    }


    /**
     * Get all the locations
     * @return array
     */
    public function getAllLocations(){

        $result = ['success'=>true, 'message'=>null,'count'=> null, 'data'=>null];

        $response =  $this->sendRequest(
            "/api/location",
            'get',
            []
        );

        if(!isset($response['Locations'])){
            $result['success'] = false;
            $result['message'] = 'Payload missing on response';
            return $result;
        }
        $result['count'] = count($response['Locations']);
        $result['data'] = $response['Locations'];

        return $result;
    }


    /**
     * Get all the faculties for a given location
     * @param int $locationId Location to get the faculties for
     * @return array
     */
    public function getFacultiesByLocation(int $locationId){

        $result = ['success'=>true, 'message'=>null,'count'=> null, 'data'=>null];

        $response =  $this->sendRequest(
            "/api/location/$locationId/faculty",
            'get',
            []
        );

        if(!isset($response['Faculties'])){
            $result['success'] = false;
            $result['message'] = 'Payload missing on response';
            return $result;
        }
        $result['count'] = count($response['Faculties']);
        $result['data'] = $response['Faculties'];

        return $result;
    }


    /***
     * Calculate the end date for a program in a faculty provided given the start date and the length.
     * The holidays for the faculty are considered in the calculation.
     * @param int $facultyId
     * @param string $startDate (YYYY-MM-DD)
     * @param int $length Number of weeks
     * @return array
     */
    public function getFacultyEndDate(int $facultyId, string $startDate, int $length): array{
        $result = ['success'=>true, 'message'=>null,'count'=> null, 'data'=>null];

        return $this->sendRequest(
            "/api/faculty/$facultyId/enddate",
            'get',
            ["StartDate"=>$startDate, 'Weeks'=>$length]
        );


    }

    /***
     * Get language list from ebecas for language dropdown.
     * @return array
     */
    public function getAllLanguages(): array{
        return $this->sendRequest(
            "/api/lookup/language",
            'get',
            []
        );
    }


   /***
     * Get countries list from ebecas to be used for dropdown.
     * @return array
     */
    public function getAllCountries(): array{
        return $this->sendRequest(
            "/api/lookup/country",
            'get',
            []
        );
    }


    /***
     * Get the visa types for student
     * @return array Each item is an array representing a visa type with the following keys:
     *  id: Id of the visa
     *  name: Name of the visa
     */
    public function getVisaTypes(): array{
        $visas=$this->sendRequest(
            "/api/lookup/visa_type/code",
            'get',
            []
        );
        if(!isset($visas["LookupList"]))
            return [];

        $visa_types = [];
        $visas = $visas["LookupList"];
        foreach ($visas as $visa){
            $temp = [];
            $temp['id'] = $visa["LookupId"];
            $temp['name']= $visa["LookupName"];

            $visa_types[] = $temp;
        }

        return $visa_types;

    }




}
