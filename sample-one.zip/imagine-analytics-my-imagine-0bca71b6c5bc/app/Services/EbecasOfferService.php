<?php

namespace App\Services;

use App\Classes\Settings\EbecasSettings;
use Exception;
use Illuminate\Support\Facades\Http;

class EbecasOfferService extends EbecasService
{

    public function createOffer(array $data): array{

        $response =  $this->sendRequest(
            "/api/offer",
            'post',
            [],
            $data
        );

        $result['success'] = $response['Success'];
        $result['message'] = $response['ValidationMessage'];
        $result['data'] = $response['OfferId'] ?? null;

        return $result;
    }


    public function getOffer(int $offer_id): array{
        $response =  $this->sendRequest(
            "/api/offer/$offer_id",
            'get',
            []
        );

        if(!isset($response['OfferId']) or $response['OfferId'] == 0){
            $result['success'] = false;
            $result['message'] = "Offer does not exist";
            $result['data']=[];
            return $result;
        }

        $result['success'] = true;
        $result['message'] = "";
        $result['data']=$response;

        return $result;
    }


}
