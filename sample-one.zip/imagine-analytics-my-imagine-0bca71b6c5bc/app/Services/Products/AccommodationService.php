<?php

namespace App\Services\Products;

use App\Models\Accommodation;
use App\Models\AccommodationFeeAddon;
use App\Models\AccommodationFeeService;
use Exception;
use Illuminate\Support\Facades\Log;

class AccommodationService
{
    /** calculates the fee of Accommodation type product based upon the weeks and days selected from the price book
     * set for the accommodation
     * @param array $data
     * @param int $application_id
     * @return float
     */
    public function calculateAccommodationFee(array $data, $application_id) {
        $amount = 0;
        try {

            $accommodation = Accommodation::findOrFail($data['accommodation_id']);
            $priceBook = $accommodation->priceBook;
            $weeks = $data['weeks'];
            $days = $data['days'];
            $rate = $priceBook->rates()->where('min', '<=', $weeks)->where('max','>=', $weeks)->first();
            if(isset($rate)){
                $weeklyFee = $weeks * $rate->weekly_fee;
                $dailyFee = $days * $rate->daily_fee;
                $amount = $weeklyFee + $dailyFee;
            }
            return $amount;

        } catch(Exception $e){
            $accommodationId = $data['accommodation_id'];
            $logMessage = $e->getMessage();
            Log::critical("Error in calculating Accommodation price for Application ID: $application_id \r\n Accommodation: $accommodationId \r\n Error: $logMessage");
            return $amount;
        }

    }


    /** calculates the fee of Accommodation service type product based upon the weeks and days selected from the weekly
     * and daily prices set for this service
     * @param array $data
     * @param int $application_id
     * @return float
     */
    public function calculateAccommodationServiceFee(array $data, $application_id){
        $amount = 0;
        try {
            $service = AccommodationFeeService::findOrFail($data['service_id']);
            if($service->type===config('constants.accommodation_service_types.application.key')){
                $amount = $service->fee;
            } elseif($service->type===config('constants.accommodation_service_types.product.key')){
                $amount = $service->fee;
            } else {
                $weeks = $data['weeks'];
                $days = $data['days'];
                $amount = ($service->fee * $weeks) + ($service->daily_fee * $days);
            }
            return $amount;

        } catch(Exception $e){
            $accommodationServiceId = $data['service_id'];
            $logMessage = $e->getMessage();
            Log::critical("Error in calculating Accommodation Service price for Application ID: $application_id \r\n Accommodation Service: $accommodationServiceId \r\n Error: $logMessage");
            return $amount;
        }

    }

     /** calculates the tax of Accommodation service type product amount based
     * @param float $value
     * @param int $service_id
     * @param int $application_id
     * @return float
     */
    public function calculateAccommodationServiceTax(float $value, $service_id, $application_id){
        $amount = 0;
        try {
            $service = AccommodationFeeService::findOrFail($service_id);
            return $service->taxable ? calculateTax($value, true) : 0;

        } catch(Exception $e){
            $logMessage = $e->getMessage();
            Log::critical("Error in calculating Accommodation Service Tax for Application ID: $application_id \r\n Accommodation Service: $service_id \r\n Error: $logMessage");
            return $amount;
        }

    }


    /** calculates the fee of Accommodation addon type product based upon the weeks and days selected from the weekly
     * and daily prices set for this addon
     * @param array $data
     * @param int $application_id
     * @return float
     */
    public function calculateAccommodationAddonFee(array $data, $application_id){
        $amount = 0;
        try {
            $addon = AccommodationFeeAddon::findOrFail($data['addon_id']);
            $weeks = $data['weeks'];
            $days = $data['days'];
            $amount = ($addon->weekly_fee * $weeks) + ($addon->daily_fee * $days);
            return $amount;

        } catch(Exception $e){
            $accommodationAddonId = $data['addon_id'];
            $logMessage = $e->getMessage();
            Log::critical("Error in calculating Accommodation Addon price for Application ID: $application_id \r\n Accommodation Addon: $accommodationAddonId \r\n Error: $logMessage");
            return $amount;
        }

    }

    /** calculates the tax of Accommodation addon type product amount based
     * @param float $value
     * @param int $addon_id
     * @param int $application_id
     * @return float
     */
    public function calculateAccommodationAddonTax(float $value, $addon_id, $application_id){
        $amount = 0;
        try {
            $addon = AccommodationFeeAddon::findOrFail($addon_id);
            return $addon->taxable ? calculateTax($value, true) : 0;

        } catch(Exception $e){
            $logMessage = $e->getMessage();
            Log::critical("Error in calculating Accommodation Addon tax for Application ID: $application_id \r\n Accommodation Addon: $addon_id \r\n Error: $logMessage");
            return $amount;
        }
    }

}
