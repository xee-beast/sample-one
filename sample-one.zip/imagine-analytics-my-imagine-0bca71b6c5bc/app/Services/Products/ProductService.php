<?php

namespace App\Services;

use App\Services\Products\AccommodationService;
use App\Services\Products\InsuranceService;
use App\Services\Products\PaymentMethodService;
use App\Services\Products\ProgramService;
use App\Services\Products\TransportationService;
use Exception;
use Illuminate\Support\Facades\Http;

class ProductService
{
    private $insuranceService;
    private $accommodationService;
    private $programService;
    private $transportationService;
    private $paymentMethodService;

    function __construct(InsuranceService $insuranceService,
                        AccommodationService $accommodationService,
                        TransportationService $transportationService,
                        ProgramService $programService,
                        PaymentMethodService $paymentMethodService)
    {
        $this->insuranceService = $insuranceService;
        $this->accommodationService = $accommodationService;
        $this->programService = $programService;
        $this->transportationService = $transportationService;
        $this->paymentMethodService = $paymentMethodService;
    }


    /** Calculates the fee of the product in each product's respective service
     * @param array $data
     * @param string $productType
     * @param int $applicationId
     * @return float
     */
    public function calculateFee($data, $productType, $applicationId): float {
        return match($productType){
            config('constants.imagine_product_types.insurance') => $this->insuranceService->calculateFee($data, $applicationId),
            config('constants.imagine_product_types.accommodation') => $this->accommodationService->calculateAccommodationFee($data, $applicationId),
            config('constants.imagine_product_types.accommodation_service') => $this->accommodationService->calculateAccommodationServiceFee($data, $applicationId),
            config('constants.imagine_product_types.accommodation_addon') => $this->accommodationService->calculateAccommodationAddonFee($data, $applicationId),
            config('constants.imagine_product_types.program') => $this->programService->calculateProgramFee($data, $applicationId),
            config('constants.imagine_product_types.program_service') => $this->programService->calculateProgramServiceFee($data, $applicationId),
            config('constants.imagine_product_types.packaged_program') => $this->programService->calculatePackagedProgramFee($data, $applicationId),
            config('constants.imagine_product_types.transportation') => $this->transportationService->calculateTransportationFee($data, $applicationId),
            config('constants.imagine_product_types.transportation_service') => $this->transportationService->calculateTransportationServiceFee($data, $applicationId),
            config('constants.imagine_product_types.transportation_addon') => $this->transportationService->calculateTransportationAddonFee($data, $applicationId),
            config('constants.imagine_product_types.payment_method') => $this->paymentMethodService->calculateFee($data, $applicationId),
            'default' => 0
        };
    }

    /** Calculates the tax of the product fee calculated
     * @param float $value
     * @param int $product_id
     * @param string $productType
     * @param int $applicationId
     * @return float
     */
    public function calculateTax($value, $product_id, $productType, $applicationId): float {
        return match($productType){
            config('constants.imagine_product_types.insurance') => $this->insuranceService->calculateTax($value, $product_id, $applicationId),
            config('constants.imagine_product_types.accommodation_service') => $this->accommodationService->calculateAccommodationServiceTax($value, $product_id, $applicationId),
            config('constants.imagine_product_types.accommodation_addon') => $this->accommodationService->calculateAccommodationAddonTax($value, $product_id, $applicationId),
            config('constants.imagine_product_types.program_service') => $this->programService->calculateProgramServiceTax($value, $product_id, $applicationId),
            config('constants.imagine_product_types.transportation') => $this->transportationService->calculateTransportationTax($value, $product_id, $applicationId),
            config('constants.imagine_product_types.transportation_service') => $this->transportationService->calculateServiceTax($value, $product_id, $applicationId),
            config('constants.imagine_product_types.transportation_addon') => $this->transportationService->calculateAddonTax($value, $product_id, $applicationId),
            config('constants.imagine_product_types.payment_method') => $this->paymentMethodService->calculateTax($value, $product_id, $applicationId),
            'default' => 0
        };
    }
}
