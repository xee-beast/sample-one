<?php

namespace App\Services\Products;

use App\Models\Application;
use App\Models\PaymentMethod;
use Exception;
use Illuminate\Support\Facades\Log;

class PaymentMethodService
{

    /** calculates the fee of payment method type product based upon the payment selected
     * @param array $data
     * @param int $application_id
     * @return float
     */
    public function calculateFee(array $data, $application_id) {
        $amount = 0;
        try {
            $paymentMethod = PaymentMethod::find($data['payment_method_id']);
            if ($paymentMethod->surcharge_type === config('constants.payment_methods.flat_fee.key')){
                $amount = $paymentMethod->value;
            }
            elseif($paymentMethod->surcharge_type === config('constants.payment_methods.percentage.key')){
                $value = $paymentMethod->value;
                $amount = $data['app_amounts']['total_amount'] * ($value);
            }
            return $amount;
        } catch(Exception $e){
            $paymentMethodId = $data['payment_method_id'];
            $logMessage = $e->getMessage();
            Log::critical("Error in calculating payment method price for Application ID: $application_id \r\n Payment Method: $paymentMethodId \r\n Error: $logMessage");
            return $amount;
        }

    }

    /** calculates the tax of payment method type product based upon the price
     * @param float $value
     * @param int $payment_method_id
     * @param int $application_id
     * @return float
     */
    public function calculateTax(float $value, $payment_method_id, $application_id) {
        $amount = 0;
        try {
            $paymentMethod = PaymentMethod::find($payment_method_id);
            return $paymentMethod->taxable ? calculateTax($value, true): 0;

        } catch(Exception $e){
            $logMessage = $e->getMessage();
            Log::critical("Error in calculating payment method tax for Application ID: $application_id \r\n Insurance: $payment_method_id \r\n Error: $logMessage");
            return $amount;
        }

    }
}
