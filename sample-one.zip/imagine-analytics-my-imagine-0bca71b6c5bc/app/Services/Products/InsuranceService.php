<?php

namespace App\Services\Products;

use App\Models\Insurance;
use Exception;
use Illuminate\Support\Facades\Log;

class InsuranceService
{

    /** calculates the fee of Insurance type product based upon the duration selected from the fee which has been
     * set against that insurance type and duration
     * @param array $data
     * @param int $application_id
     * @return float
     */
    public function calculateFee(array $data, $application_id) {
        $amount = 0;
        try {
            $insurance = Insurance::findOrFail($data['insurance_id']);
            $duration = $data['duration'];
            $feeRow = $insurance->fees()->where('duration',$duration)->first();
            return $feeRow->fee;
        } catch(Exception $e){
            $insuranceId = $data['insurance_id'];
            $logMessage = $e->getMessage();
            Log::critical("Error in calculating OSHC price for Application ID: $application_id \r\n Insurance: $insuranceId \r\n Error: $logMessage");
            return $amount;
        }

    }

    /** calculates the tax of Insurance type product based upon the price
     * @param float $value
     * @param int $insurance_id
     * @param int $application_id
     * @return float
     */
    public function calculateTax(float $value, $insurance_id, $application_id) {
        $amount = 0;
        try {
            $insurance = Insurance::findOrFail($insurance_id);
            return $insurance->taxable ? calculateTax($value, true): 0;

        } catch(Exception $e){
            $logMessage = $e->getMessage();
            Log::critical("Error in calculating OSHC tax for Application ID: $application_id \r\n Insurance: $insurance_id \r\n Error: $logMessage");
            return $amount;
        }

    }
}
