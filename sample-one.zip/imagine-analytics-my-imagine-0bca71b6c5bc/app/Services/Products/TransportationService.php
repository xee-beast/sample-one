<?php

namespace App\Services\Products;

use App\Models\Transportation;
use App\Models\TransportationFeeAddon;
use App\Models\TransportationFeeService;
use Exception;
use Illuminate\Support\Facades\Log;

class TransportationService
{
    /** calculates the fee of Transportation type product assigned to it
     * @param array $data
     * @param $application_id
     * @return float
     */
    public function calculateTransportationFee(array $data, $application_id) {
        $amount = 0;
        try {
            $transportation = Transportation::findOrFail($data['transportation_id']);
            $amount = $transportation->fee;
            return $amount;

        } catch(Exception $e){
            $transportationId = $data['transportation_id'];
            $logMessage = $e->getMessage();
            Log::critical("Error in calculating Transportation price for Application ID: $application_id \r\n Accommodation: $transportationId \r\n Error: $logMessage");
            return $amount;
        }
        
    }

    /** calculates the tax of Transportation type product
     * @param float $value
     * @param int $transportation_id
     * @param $application_id
     * @return float
     */
    public function calculateTransportationTax(float $value, $transportation_id, $application_id){
        $amount = 0;
        try {
            $transportation = Transportation::findOrFail($transportation_id);
            return $transportation->taxable ? calculateTax($value, true) : 0;  
        } catch(Exception $e){
            $logMessage = $e->getMessage();
            Log::critical("Error in calculating Transportation tax for Application ID: $application_id \r\nTransportation: $transportation_id \r\n Error: $logMessage");
            return $amount;
        }
          
    }

    /** calculates the fee of Transportation service type product
     * @param array $data
     * @param $application_id
     * @return float
     */
    public function calculateTransportationServiceFee(array $data, $application_id) {
        $amount = 0;
        try {
            $service = TransportationFeeService::findOrFail($data['service_id']);
            $amount = $service->fee;
            return $amount;

        } catch(Exception $e){
            $transportationServiceId = $data['service_id'];
            $logMessage = $e->getMessage();
            Log::critical("Error in calculating Transportation Service price for Application ID: $application_id \r\n Transportation Service: $transportationServiceId \r\n Error: $logMessage");
            return $amount;
        }
        
    }
     /** calculates the tax of Transportation service type product amount based
     * @param float $value
     * @param int $service_id
     * @param $application_id
     * @return float
     */
    public function calculateServiceTax(float $value, $service_id, $application_id){
        $amount = 0;
        try {
            $service = TransportationFeeService::findOrFail($service_id);
            return $service->taxable ? calculateTax($value, true) : 0; 
        } catch(Exception $e){
            $logMessage = $e->getMessage();
            Log::critical("Error in calculating Transportation Service tax for Application ID: $application_id \r\n Transportation Service: $service_id \r\n Error: $logMessage");
            return $amount;
        }
           
    }

    /** calculates the fee of Transportation addon type product
     * and daily prices set for this addon
     * @param array $data
     * @param $application_id
     * @return float
     */
    public function calculateTransportationAddonFee(array $data, $application_id){
        $amount = 0;
        try {
            $addon = TransportationFeeAddon::findOrFail($data['addon_id']);
            return $addon->fee;

        } catch(Exception $e){
            $transportationAddonId = $data['addon_id'];
            $logMessage = $e->getMessage();
            Log::critical("Error in calculating Transportation Addon price for Application ID: $application_id \r\n Transportation Addon: $transportationAddonId \r\n Error: $logMessage");
            return $amount;
        }
        
    }
    /** calculates the tax of Transportation addon type product amount based
     * @param float $value
     * @param int $addon_id
     * @param $application_id
     * @return float
     */
    public function calculateAddonTax(float $value, $addon_id, $application_id){
        $amount = 0;
        try {
            $addon = TransportationFeeAddon::findOrFail($addon_id);
            return $addon->taxable ? calculateTax($value, true)  : 0; 

        } catch(Exception $e){
            $logMessage = $e->getMessage();
            Log::critical("Error in calculating Transportation Addon tax for Application ID: $application_id \r\n Transportation Addon: $addon_id \r\n Error: $logMessage");
            return $amount;
        }
           
    }
}
