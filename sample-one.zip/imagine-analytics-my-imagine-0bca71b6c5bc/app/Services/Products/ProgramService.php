<?php

namespace App\Services\Products;

use App\Models\PackagedProgram;
use App\Models\Program;
use App\Models\ProgramFeeService;
use App\Models\ProgramPriceBook;
use Exception;
use Illuminate\Support\Facades\Log;

class ProgramService
{

    /** calculates the fee of Program type product based upon the weeks selected from the price book
     * set for the program
     * @param array $data
     * @param int $application_id
     * @return float
     */
    public function calculateProgramFee(array $data, $application_id) {
        $amount = 0;
        try {
            $program = Program::findOrFail($data['program_id']);
            $priceBook = $program->priceBook;
            $length = $data['length'];
            $amount = $this->getFeeFromPricebook($priceBook, $length, $program->id);
            return $amount;
        } catch(Exception $e){
            $programId = $data['program_id'];
            $logMessage = $e->getMessage();
            Log::critical("Error in calculating Program price for Application ID: $application_id \r\n Program: $programId \r\n Error: $logMessage");
            return $amount;
        }

    }

    /** calculates the fee of Packaged Program type product from the price book
     * set for the program
     * @param array $data
     * @param int $application_id
     * @return float
     */
    public function calculatePackagedProgramFee(array $data, $application_id){
        $amount = 0;
        try {
            $program = Program::findOrFail($data['program_id']);
            $priceBook = $program->priceBook;
            $length = $data['length'];
            $amount = $this->getFeeFromPricebook($priceBook, $length, $program->id);
            $package = PackagedProgram::findOrFail($data['package']['id']);
            $programInPackage = $package->programs()->where('faculty_id',$data['faculty_id'])->where('program_id',$data['program_id'])->first();
            $discount = floatval($programInPackage->pivot->discount);
            if($discount>0){
                $amount = $amount*(1-$discount);
            }
            return $amount;
        } catch(Exception $e){
            $programId = $data['program_id'];
            $logMessage = $e->getMessage();
            Log::critical("Error in calculating Packaged Program price for Application ID: $application_id \r\n Program: $programId \r\n Error: $logMessage");
            return $amount;
        }

    }

    /** Get the rate as per given length and pricebook
     * @param ProgramPriceBook $pricebook
     * @param int $length
     * @param int $program_id
     * @return float
     */
    public function getFeeFromPricebook(ProgramPriceBook $pricebook, int $length, $program_id){
        $program = Program::find($program_id);
        //Language Program
        if($program->is_language){
            $rate = $pricebook->rates()->where('min', '<=', $length)->where('max','>=', $length)->first();
            if(!$rate) {
                throw new Exception("Error in calculating Program price for English Program: $program_id \r\n Error: Pricebook does not have value for length: $length");
            }
            return $length * $rate->price;
        }

        //Not Language program
        $rate = $pricebook->rates()->first();
        if(!$rate) {
            throw new Exception("Error in calculating Program price for Non-English Program: $program_id \r\n Error: Pricebook could not be found.");
        }
        return $rate->price;

    }


    /** calculates the fee of Program service type product based upon the weeks selected from the weekly
     * prices set for this service
     * @param array $data
     * @param int $application_id
     * @return float
     */
    public function calculateProgramServiceFee(array $data, $application_id){
        $amount = 0;
        try {
            $service = ProgramFeeService::findOrFail($data['service_id']);
            if($service->type===config('constants.program_service_types.application.key')){
                $amount = $service->fee;
            } elseif($service->type===config('constants.program_service_types.course.key')){
                $amount = $service->fee;
            } else {
                $amount = ($service->fee * $data['length']);
            }
            return $amount;
        } catch(Exception $e){
            $programServiceId = $data['service_id'];
            $logMessage = $e->getMessage();
            Log::critical("Error in calculating Program Service price for Application ID: $application_id \r\n Program Service: $programServiceId \r\n Error: $logMessage");
            return $amount;
        }

    }

     /** calculates the tax of Program service type product amount based
     * @param float $value
     * @param int $service_id
     * @param int $application_id
     * @return float
     */
    public function calculateProgramServiceTax(float $value, $service_id, $application_id){
        $amount = 0;
        try {
            $service = ProgramFeeService::findOrFail($service_id);
            return $service->taxable ? calculateTax($value, true) : 0;
        } catch(Exception $e){
            $logMessage = $e->getMessage();
            Log::critical("Error in calculating Program Service Tax for Application ID: $application_id \r\n Program Service: $service_id \r\n Error: $logMessage");
            return $amount;
        }

    }

}
