<?php

namespace App\Services;

use App\Classes\Settings\EbecasSettings;
use Exception;
use Illuminate\Support\Facades\Http;

class EbecasStudentService extends EbecasService
{

    /**
     * Get the student details for a student by the student code (Student id - frontend id)
     * @param string $studentCode
     * @return array
     */
    public function getStudentByCode(string $studentCode): array{

        $result = ['success'=>true, 'message'=>null, 'data'=>null];

        $response =  $this->sendRequest(
            "/api/student/code/$studentCode",
            'get',
            []
        );

        if(!$response['StudentNo']){
            return $result;
        }

        $result['data'] = $response;

        return $result;
    }

    /**
     * Get the student details for a student by the student  (internal id)
     * @param int $studentId
     * @return array
     */
    public function getStudentById(int $studentId): array{

        $result = ['success'=>true, 'message'=>null, 'data'=>null];

        $response =  $this->sendRequest(
            "/api/student/$studentId",
            'get',
            []
        );


        if(!$response['StudentNo']){
            return $result;
        }

        $result['data'] = $response;

        return $result;
    }

    /**
     * Create a student in eBECAS. If the student already exists in eBECAS, a new one will not be created.
     * The @data on the response will have the student id for the existing student.
     * @param array $data
     * @return array with the items:
     *      @success
     *      @message
     *      @data: student_id
     */
    public function createStudent(array $data): array{

        // Required Fields
        $student_data = [
            "FirstName" => $data['first_name'],
            "LastName" => $data['last_name'],
            "Gender" => $data['gender'], //M, F, X
            "DateOfBirth" => $data['dob'],
            "EmailAddress"=> $data['email'],
            "LEmail" => $data['email'],
            "PassportNo" => $data['passport_number'],
            "OverSeas" => !(strtolower($data['nationality']['name']) == 'australia') ?? false,
            "Notes" => 'Created by myImagine. Application #'.$data['application_id'],
            "EContactName"=>$data['next_of_kin_full_name'],
            "EContactEmail"=>$data['next_of_kin_email'],
            "EContactInfo"=>$data['next_of_kin_relationship'],
            "EContactPhone1"=>$data['next_of_kin_phone'],
            "StudentLocationId" => $data['living_in_australia'] ? 7742 : 7743, //7742=onshore, 7743=offshore
        ];

        if(isset($data['title']))  $student_data["Title"] = $data['title'];
        if(isset($data['middle_name']))  $student_data["MiddleName"] = $data['middle_name'];
        if(isset($data['mobile']))  $student_data["LocalMobile"] = $data['mobile'];

        if(isset($data['country_id']) and $data['country_id'])  $student_data["CountryId"] = $data['country_id'];
        if(isset($data['language_id']) and $data['language_id'])  $student_data["LanguageId"] = $data['language_id'];
        if(isset($data['citizenship_id']) and $data['citizenship_id'])  $student_data["CitizenshipCountryId"] = $data['citizenship_id'];


        if($data['living_in_australia']){
            if(isset($data['current_residence_address_line_1'])) $student_data["LocalAddressLine1"]=$data['current_residence_address_line_1'];
            if(isset($data['current_residence_address_line_2'])) $student_data["LocalAddressLine2"]=$data['current_residence_address_line_2'];
            if(isset($data['current_residence_address_line_2'])) $student_data["LocalAddressLine3"]=$data['current_residence_address_line_2'];
            if(isset($data['current_residence_address_city'])) $student_data["LocalSuburbName"]=$data['current_residence_address_city'];
            if(isset($data['current_residence_address_state'])) $student_data["LocalState"]=$data['current_residence_address_state'];
            if(isset($data['current_residence_address_postcode'])) $student_data["LocalPostCode"]=$data['current_residence_address_postcode'];
        }else{
            if(isset($data['current_residence_address_line_1'])) $student_data["OSAddressLine1"]=$data['current_residence_address_line_1'];
            if(isset($data['current_residence_address_line_2'])) $student_data["OSAddressLine2"]=$data['current_residence_address_line_2'];
            if(isset($data['current_residence_address_line_3'])) $student_data["OSAddressLine3"]=$data['current_residence_address_line_3'];
            if(isset($data['current_residence_address_city'])) $student_data["OSSuburbName"]=$data['current_residence_address_city'];
            if(isset($data['current_residence_address_state'])) $student_data["OSState"]=$data['current_residence_address_state'];
            if(isset($data['current_residence_address_postcode'])) $student_data["OSPostCode"]=$data['current_residence_address_postcode'];
        }

        $response =  $this->sendRequest(
            "/api/student",
            'post',
            $student_data
        );

        $result['success'] = $response['Success'] ?? $response['success'];
        $result['message'] = $response['ValidationMessage'] ?? $response['message'];
        $result['data'] = $response['StudentId'] ?? null;

        return $result;
    }
}
