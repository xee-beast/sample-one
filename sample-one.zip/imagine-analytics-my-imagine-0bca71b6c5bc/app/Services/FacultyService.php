<?php


namespace App\Services;


use App\Models\Faculty;
use App\Models\PackagedProgram;

class FacultyService
{

    protected EbecasService $ebecasService;
    public EbecasProductsService $ebecasProductsService;

    function __construct(EbecasService $ebecasService, EbecasProductsService $ebecasProductsService){
        $this->ebecasService = $ebecasService;
        $this->ebecasProductsService = $ebecasProductsService;
    }

    /**
     * @param $programs
     * @return array
     */
    public function getProgramsArray($programs): array
    {
        $selectedProgramsArray = [];
        foreach($programs as $program){
            $selectedProgramsArray[] = [
                'program_id' => $program->id,
                'calendar_id' => $program->pivot->calendar_id,
                'faculty_id' => $program->pivot->faculty_id,
                'ebecas_product_id' => $program->pivot->ebecas_product_id,
            ];
        }

        return $selectedProgramsArray;
    }

    /**
     * @param $accommodations
     * @return array
     */
    public function getAccommodationsArray($accommodations): array
    {
        $selectedArray = [];
        foreach($accommodations as $accommodation){
            $selectedArray[] = [
                'accommodation_id' => $accommodation->id,
                'calendar_id' => $accommodation->pivot->calendar_id,
                'faculty_id' => $accommodation->pivot->faculty_id,
                'ebecas_product_id' => $accommodation->pivot->ebecas_product_id,
            ];
        }

        return $selectedArray;
    }

    /**
     * @param $services
     * @return array
     */
    public function getAccommodationServicesArray($services): array
    {
        $selectedArray = [];
        foreach($services as $service){
            $selectedArray[] = [
                'fee_service_id' => $service->id,
                'fee' => $service->pivot->fee,
                'faculty_id' => $service->pivot->faculty_id,
                'ebecas_product_id' => $service->pivot->ebecas_product_id,
            ];
        }

        return $selectedArray;
    }


    /**
     * @param $addons
     * @return array
     */
    public function getAccommodationAddonsArray($addons): array
    {
        $selectedArray = [];
        foreach($addons as $addon){
            $selectedArray[] = [
                'addon_id' => $addon->id,
                'faculty_id' => $addon->pivot->faculty_id,
                'ebecas_product_id' => $addon->pivot->ebecas_product_id,
            ];
        }

        return $selectedArray;
    }

    /**
     * @param $services
     * @return array
     */
    public function getServicesArray($services): array
    {
        $selectedServicesArray = [];
        foreach($services as $service){
            $selectedServicesArray[] = [
                'program_fee_service_id' => $service->id,
                'fee' => $service->pivot->fee,
                'faculty_id' => $service->pivot->faculty_id,
                'ebecas_product_id' => $service->pivot->ebecas_product_id,
            ];
        }

        return $selectedServicesArray;
    }

    /**
     * @param $transportations
     * @return array
     */
    public function getTransportationsArray($transportations): array
    {
        $selectedArray = [];
        foreach($transportations as $transportation){
            $selectedArray[] = [
                'transportation_id' => $transportation->id,
                'calendar_id' => $transportation->pivot->calendar_id,
                'faculty_id' => $transportation->pivot->faculty_id,
                'ebecas_product_id' => $transportation->pivot->ebecas_product_id,
            ];
        }

        return $selectedArray;
    }

     /**
     * @param $services
     * @return array
     */
    public function getTransportationServicesArray($services): array
    {
        $selectedArray = [];
        foreach($services as $service){
            $selectedArray[] = [
                'fee_service_id' => $service->id,
                'fee' => $service->pivot->fee,
                'faculty_id' => $service->pivot->faculty_id,
                'ebecas_product_id' => $service->pivot->ebecas_product_id,
            ];
        }

        return $selectedArray;
    }


     /**
     * @param $addons
     * @return array
     */
    public function getTransportationAddonsArray($addons): array
    {
        $selectedArray = [];
        foreach($addons as $addon){
            $selectedArray[] = [
                'addon_id' => $addon->id,
                'fee' => $addon->pivot->fee,
                'faculty_id' => $addon->pivot->faculty_id,
                'ebecas_product_id' => $addon->pivot->ebecas_product_id,
            ];
        }

        return $selectedArray;
    }

    /**
     * @param $insurances
     * @return array
     */
    public function getInsuranceArray($insurances): array
    {
        $selectedInsurances = [];
        foreach($insurances as $insurance){
            $selectedInsurances[] = [
                'insurance_id' => $insurance->pivot->insurance_id,
                'insurance_fee_id' => $insurance->pivot->insurance_fee_id,
                'faculty_id' => $insurance->pivot->faculty_id,
                'ebecas_product_id' => $insurance->pivot->ebecas_product_id,
            ];
        }
        return $selectedInsurances;
    }

    /**
     * @param $paymentMethods
     * @return array
     */
    public function getPaymentMethodArray($paymentMethods): array
    {
        $selectedPaymentMethods = [];
        foreach($paymentMethods as $paymentMethod){
            $selectedPaymentMethods[] = [
                'payment_method_id' => $paymentMethod->id,
                'faculty_id' => $paymentMethod->pivot->faculty_id,
                'ebecas_product_id' => $paymentMethod->pivot->ebecas_product_id,
            ];
        }
        return $selectedPaymentMethods;
    }

    /**
     * @param $faculty
     * @return array
     */
    public function getSortedEbecasProductsByFacultyAndType($faculty, $type):array
    {
        $products = [];
        if ( $faculty->id ) {
            $products = $this->ebecasProductsService->getProducts(
                facultyId: $faculty->ebecas_id,
                productType: $type
            )['data'];
            usort($products, function ($a, $b) {
                return strcmp($a["Name"], $b["Name"]);
            });
        }
        return $products;
    }

    /**
     * @param $programs
     * @return array
     */
    public function getProgramSyncArray($programs): array
    {
        $programArr = [];
        foreach($programs as $program){
            $programArr[$program['program_id']] = [
                'calendar_id' => $program['calendar_id'],
                'ebecas_product_id' => $program['ebecas_product_id'],
            ];
        }

        return $programArr;
    }

    /**
     * @param $services
     * @return array
     */
    public function getServiceSyncArray($services): array
    {
        $serviceArr = [];
        foreach($services as $service){
            $serviceArr[$service['program_fee_service_id']] = [
                'fee' => $service['fee'],
                'ebecas_product_id' => $service['ebecas_product_id'],
            ];
        }

        return $serviceArr;
    }

    /**
     * @param $accommodations
     * @return array
     */
    public function getAccommodationSyncArray($accommodations): array
    {
        $accommodationArr = [];
        foreach($accommodations as $accommodation){
            $accommodationArr[$accommodation['accommodation_id']] = [
                'ebecas_product_id' => $accommodation['ebecas_product_id'],
            ];
        }

        return $accommodationArr;
    }

    /**
     * @param $services
     * @return array
     */
    public function getAccommodationServiceSyncArray($services): array
    {
        $serviceArr = [];
        foreach($services as $service){
            $serviceArr[$service['fee_service_id']] = [
                'ebecas_product_id' => $service['ebecas_product_id'],
            ];
        }

        return $serviceArr;
    }


    /**
     * @param $addons
     * @return array
     */
    public function getAccommodationAddonsSyncArray($addons): array
    {
        $result = [];
        foreach($addons as $addon){
            $result[$addon['addon_id']] = [
                'ebecas_product_id' => $addon['ebecas_product_id'],
            ];
        }

        return $result;
    }


    /**
     * @param $transportations
     * @return array
     */
    public function getTransportationSyncArray($transportations): array
    {
        $transportationArr = [];
        foreach($transportations as $transportation){
            $transportationArr[$transportation['transportation_id']] = [
                'ebecas_product_id' => $transportation['ebecas_product_id'],
            ];
        }

        return $transportationArr;
    }

    /**
     * @param $services
     * @return array
     */
    public function getTransportationServiceSyncArray($services): array
    {
        $serviceArr = [];
        foreach($services as $service){
            $serviceArr[$service['fee_service_id']] = [
                'fee' => $service['fee'],
                'ebecas_product_id' => $service['ebecas_product_id'],
            ];
        }

        return $serviceArr;
    }


    /**
     * @param $addons
     * @return array
     */
    public function getTransportationAddonsSyncArray($addons): array
    {
        $result = [];
        foreach($addons as $addon){
            $result[$addon['addon_id']] = [
                'fee' => $addon['fee'],
                'ebecas_product_id' => $addon['ebecas_product_id'],
            ];
        }

        return $result;
    }

    /**
     * @param $data
     * @param Faculty $faculty
     * @return array
     */
    public function getInsuranceSyncArray($data, Faculty $faculty): array
    {
        $insuranceArray = [];
        foreach($data['insurances'] as $service){
            $list = [
                'insurance_id' => $data['insurance_id'],
                'faculty_id' => $faculty->id,
                'ebecas_product_id' => $service['ebecas_product_id'],
            ];
            $faculty->insurances()->attach( $service['insurance_fee_id'], $list);
        }
        return $insuranceArray;
    }

    /**
     * @param $paymentMethods
     * @return array
     */
    public function getPaymentMethodsSyncArray($paymentMethods): array
    {
        $paymentMethodArray = [];
        foreach($paymentMethods as $method){
            $paymentMethodArray[$method['payment_method_id']] = [
                'ebecas_product_id' => $method['ebecas_product_id'],
            ];
        }
        return $paymentMethodArray;
    }

    /**
     * @param $faculty
     * @return void
     */
    public function detachProductPrograms($faculty): void
    {
        $packagePrograms = PackagedProgram::all();
        $facultyProgramIds = $faculty->programs()->pluck('id')->toArray();
        foreach ($packagePrograms as $packageProgram){
            $facultyPrograms = $packageProgram->programs()->get();
            foreach ( $facultyPrograms as $program ){
                if ( ! in_array($program->id, $facultyProgramIds )){
                    $packageProgram->programs()->detach($program);
                }
            }
        }

    }


}
