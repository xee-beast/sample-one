<?php


namespace App\Services;


use App\Models\Accommodation;
use App\Models\Application;
use App\Models\Faculty;
use App\Models\PackagedProgram;
use App\Models\PaymentMethod;
use App\Models\Program;
use App\Models\Transportation;
use App\Models\User;
use App\Services\Products\PaymentMethodService;
use Carbon\Carbon;
use Illuminate\Support\Facades\DB;

class ApplicationService
{

    protected EbecasStudentService $ebecasStudentService;
    public EbecasOfferService $ebecasOfferService;
    protected PaymentMethodService $paymentMethodService;
    /**
     * Instantiate a new UserController instance.
     */
    public function __construct(EbecasStudentService $ebecasStudentService,
                                EbecasOfferService $ebecasOfferService,
                                PaymentMethodService $paymentMethodService)
    {
        $this->ebecasStudentService = $ebecasStudentService;
        $this->ebecasOfferService = $ebecasOfferService;
        $this->paymentMethodService = $paymentMethodService;
    }

    /**
     * @param $facultyId
     * @return mixed
     */
    public function paymentPlanByFaculty($facultyId): mixed
    {
        return Faculty::whereHas( 'paymentMethods', function($paymentMethod) {
            $paymentMethod->whereIsPaymentPlan(true)->whereEnabled(true);
        })->find($facultyId);
    }

    /**
     * @param $facultyId
     * @return mixed
     */
    public function paymentMethodsByFaculty($facultyId): mixed
    {
        return Faculty::find($facultyId)->paymentMethods()->whereEnabled(true)->get();
    }


    /**
     * Create a student in ebecas with the details in a provided application form.
     * @param int $applicationId Id of the application to get the student details from.
     * @return array
     *      @ success (bool)
     *      @ message (string)
     *      @ data (string|int) student_id
     */
    public function createStudentInEbecas(int $applicationId): array{

        $application = Application::find($applicationId);
        if(!$application){
            $result['success'] = false;
            $result['message'] = 'Application does not exist';
            return $result;
        }
        $details = $application->detail->load(['nationality','birthCountry','firstLanguage']);
        $details = $details->toArray();

        $details['application_id'] = $applicationId;
        //Update the data as the Ebecas service needs it
        $details['title'] = $details['salutation'];
        $details['citizenship_id'] = $details['nationality']['ebecas_id'] ?? null;
        $details['country_id'] = $details['birth_country']['ebecas_id'] ?? null;
        $details['language_id'] = $details['first_language']['ebecas_id'] ?? null;


        return $this->ebecasStudentService->createStudent(data: $details);

    }

    /**
     * @param $studentId
     * @return array
     */
    public function getStudentNumberFromEbecas($studentId): array
    {
        return $this->ebecasStudentService->getStudentById((int)$studentId);
    }

    /**
     * @param Application $application
     * @return void
     */
    public function setApplicationSummaryData(Application $application): void
    {
        // setting programs
        $programs = $this->getApplicationProgramsData($application, false);
        $programServices = $this->getApplicationProgramServices($application, true);
        $application['application_programs'] = $programs;
        $application['application_program_services'] = $programServices;

        // packaged programs
        $packagedPrograms = $this->getApplicationPackagedProgramsData($application);
        $application['application_packaged_programs'] = $packagedPrograms;

        // sort programs on start date
        $packagedProgramArray = $application['application_packaged_programs'];
        foreach ($packagedProgramArray as $key => $packagedProgram) {
            $packagedProgramArray[$key]['start_date'] = $packagedProgram['programs'][0]['start_date'];
            $packagedProgramArray[$key]['end_date'] = end($packagedProgram['programs'])['end_date'];
        }
        $allProgramsArr = array_merge($packagedProgramArray, $application['application_programs']);
        arraySortByColumn($allProgramsArr, 'start_date');
        $application['sorted_programs'] = $allProgramsArr;

        // setting accommodations
        $accommodation = $this->getApplicationAccommodationsData($application);
        $accommodationServices = $this->getApplicationAccommodationServices($application, true);
        $accommodationAddons = $this->getApplicationAccommodationAddons($application, true);
        $application['application_accommodations'] = $accommodation;
        $application['application_accommodation_services'] = $accommodationServices;
        $application['application_accommodation_addons'] = $accommodationAddons;


        // setting transportations
        $transportation = $this->getApplicationTransportationData($application);
        $transportationServices = $this->getApplicationTransportationServices($application, true);
        $transportationAddons = $this->getApplicationTransportationAddons($application, true);
        $application['application_transportations'] = $transportation;
        $application['application_transportation_services'] = $transportationServices;
        $application['application_transportation_addons'] = $transportationAddons;

        $insurances = $this->getApplicationInsurancesData($application);
        $application['application_insurances'] = $insurances;

        $documentConstants = config('constants.application_form.documents');
        foreach ($application->documents as $key => $document){
            $document['created_by_name'] = $document->createdBy->full_name;
            $document['document_name'] = $documentConstants[$document->type]['label'];
            $document['download_route'] = route("application.document.single.get", [$document]);
            $application->documents[$key] = $document;
        }
    }


    /** get programs list saved against application formatted in required data
     * @param application $application
     * @return array
     */
    public function getApplicationProgramsData($application, $getPackagedPrograms = false): array
    {
        $programs = $application->programs;
        $list = [];
        foreach($programs as $program) {
            $package = false;
            if ($getPackagedPrograms || !$program->pivot->packaged_program_id) {
                if ($program->pivot->packaged_program_id) {
                    $package = PackagedProgram::find($program->pivot->packaged_program_id);
                }
                $faculty = Faculty::find($program->pivot->faculty_id);
                $list[] = [
                    'program' => $program->name,
                    'program_id' => $program->id,
                    'location' => $faculty->location->name,
                    'faculty_id' => $program->pivot->faculty_id,
                    'faculty' => $faculty->name,
                    'start_date' => $program->pivot->start_date,
                    'end_date' => $program->pivot->end_date,
                    'length' => $program->pivot->length,
                    'package' => $package
                ];
            }
        }
        return $list;
    }

    /**
     * @param $application
     * @return array
     */
    public function getApplicationPackagedProgramsData($application): array
    {
        $programs = $application->programs()->whereNotNull('packaged_program_id')->get();
        $list = [];
        foreach($programs as $key => $program){
            $package = PackagedProgram::find($program->pivot->packaged_program_id);
            $faculty = Faculty::find($program->pivot->faculty_id);
            $list[$program->pivot->packaged_program_id]['package'] = [
                'id' => $package->id,
                'name' => $package->name,
            ];
            $list[$program->pivot->packaged_program_id]['programs'][] = [
                'program' => $program->name,
                'program_id' => $program->id,
                'location' => $faculty->location->name,
                'faculty_id' => $program->pivot->faculty_id,
                'faculty' => $faculty->name,
                'start_date' => $program->pivot->start_date,
                'end_date' => $program->pivot->end_date,
                'length' => $program->pivot->length
            ];
        }

        return array_values($list);
    }

    /** get programs list saved against application insurances in required data
     * @param application $application
     * @return array
     */
    public function getApplicationInsurancesData($application): array
    {
        $insurances = $application->insurances;
        $list = [];
        foreach($insurances as $insurance){
            $faculty = Faculty::find( $insurance->pivot->faculty_id);
            $list[] = [
                'insurance_id' => $insurance->id,
                'faculty_id' => $faculty->id,
                'faculty_name' => $faculty->name,
                'insurance_name' => $insurance->type,
                'start_date' => Carbon::parse($insurance->pivot->start_date)->format('d/m/Y'),
                'end_date' => Carbon::parse($insurance->pivot->end_date)->format('d/m/Y'),
                'duration' => $insurance->pivot->duration,
            ];
        }
        return $list;
    }


    /** get programs list saved against application formatted in required data
     * @param application $application
     * @return array
     */

    public function getApplicationAccommodationsData($application): array
    {
        $accommodations = $application->accommodations;
        $list = [];
        foreach($accommodations as $accommodation){
            $faculty = Faculty::find( $accommodation->pivot->faculty_id);
            $list[] = [
                'accommodation' => $accommodation->name,
                'accommodation_id' => $accommodation->id,
                'accommodation_category' =>$accommodation->category->name,
                'faculty_id' => $accommodation->pivot->faculty_id,
                'faculty' => $faculty->name,
                'start_date' => $accommodation->pivot->start_date,
                'end_date' => $accommodation->pivot->end_date,
                'weeks' => $accommodation->pivot->weeks,
                'days' => $accommodation->pivot->days,
            ];
        }
        return $list;
    }


    /** get services list saved against application formatted in required data
     * @param application $application
     * @return array
     */
    public function getApplicationProgramServices($application, $withMandatory = false): array
    {
        $services = $application->programServices;
        $list = [];
        foreach($services as $service){
            if($withMandatory || $service->pivot->mandatory==0) {
                $program = Program::find($service->pivot->program_id);
                $list[] = [
                    'service_id' => $service->id,
                    'name' => $service->name,
                    'program' => $program->name,
                    'type' => $service->type,
                    'program_id' => $service->pivot->program_id,
                    'faculty_id' => $service->pivot->faculty_id,
                    'mandatory' => $service->pivot->mandatory,
                    'program_start_date' => $service->pivot->program_start_date,
                ];
            }
        }
        return $list;
    }

    /** get services list saved against application accommodation formatted in required data
     * @param application $application
     * @return array
     */
    public function getApplicationAccommodationServices($application, $withMandatory = false): array
    {
        $services = $application->accommodationServices;
        $list = [];
        foreach($services as $service){
            if($withMandatory ||  $service->pivot->mandatory==0) {
                $accommodation = Accommodation::find($service->pivot->accommodation_id);
                $list[] = [
                    'service_id' => $service->id,
                    'name' => $service->name,
                    'accommodation' => $accommodation->name,
                    'type' => $service->type,
                    'accommodation_id' => $service->pivot->accommodation_id,
                    'mandatory' => $service->pivot->mandatory,
                    'faculty_id' => $service->pivot->faculty_id,
                    'accommodation_start_date' => $service->pivot->accommodation_start_date,
                ];
            }
        }
        return $list;
    }

    /** get services list saved against application accommodation formatted in required data
     * @param application $application
     * @return array
     */

    public function getApplicationAccommodationAddons($application, $withMandatory = false): array
    {
        $addons = $application->accommodationAddons;
        $list = [];
        foreach($addons as $addon){
            if($withMandatory || $addon->pivot->mandatory==0) {
                $accommodation = Accommodation::find($addon->pivot->accommodation_id);
                $list[] = [
                    'addon_id' => $addon->id,
                    'name' => $addon->name,
                    'accommodation' => $accommodation->name,
                    'type' => $addon->type,
                    'accommodation_id' => $addon->pivot->accommodation_id,
                    'mandatory' => $addon->pivot->mandatory,
                    'faculty_id' => $addon->pivot->faculty_id,
                    'accommodation_start_date' => $addon->pivot->accommodation_start_date,
                ];
            }
        }
        return $list;
    }

    /** get transportation list saved against application formatted in required data
     * @param application $application
     * @return array
     */

    public function getApplicationTransportationData($application): array
    {
        $transportationArray = $application->transportations;
        $list = [];
        foreach($transportationArray as $transportation){
            $list[] = [
                'transportation' => $transportation->name,
                'transportation_id' => $transportation->id,
                'return' => $transportation->return,
                'faculty_id' => $transportation->pivot->faculty_id
            ];
        }
        return $list;
    }

    /** get transportation services list saved against application formatted in required data
     * @param application $application
     * @return array
     */
    public function getApplicationTransportationServices($application, $withMandatory = false): array
    {
        $services = $application->transportationServices;
        $list = [];
        foreach($services as $service){
            if($withMandatory || $service->pivot->mandatory==0) {
                $list[] = [
                    'faculty_id' => $service->pivot->faculty_id,
                    'name' => $service->name,
                    'service_id' => $service->id,
                    'transportation_id' => $service->pivot->transportation_id,
                    'mandatory' => $service->pivot->mandatory,
                ];
            }
        }
        return $list;
    }

    /** get transportation services list saved against application formatted in required data
     * @param application $application
     * @return array
     */
    public function getApplicationTransportationAddons($application, $withMandatory = false): array
    {
        $addons = $application->transportationAddons;
        $list = [];
        foreach($addons as $addon){
            if($withMandatory || $addon->pivot->mandatory==0) {
                $list[] = [
                    'faculty_id' => $addon->pivot->faculty_id,
                    'name' => $addon->name,
                    'addon_id' => $addon->id,
                    'transportation_id' => $addon->pivot->transportation_id,
                    'mandatory' => $addon->pivot->mandatory,
                ];
            }
        }
        return $list;
    }

    /** Check if request has passport type document and also validate application  documents include passport type document.
     * @param application $application
     * @param  $request
     * @return boolean
     */
    public function hasPassportType($request,$application)
    {

        $hasPassport = false;
        if ($request->has('document')) {
            $data = $request->get('document');
            for ($i = 0; $i < count($data); $i++) {
                $item = $data[$i];
                if ($item['type'] === 'passport') {
                    $hasPassport = true;
                }
            }
        }
        $passport = $application->documents()->where('type', 'passport')->first();
        if ($hasPassport === false && $passport === null) {
            return false;
        }
        return true;
    }

    /**
     * @param $applicationId
     * @param $paymentMethodId
     * @return void
     */
    public function updateApplicationPaymentMethodFee($applicationId, $paymentMethodId): void
    {
        $application = Application::find($applicationId);
        $data = array('payment_method_id'=>$paymentMethodId, 'app_amounts'=>$this->getApplicationAmountWithTax($applicationId));
        $amount = $this->paymentMethodService->calculateFee($data, $applicationId);
        $tax = $this->paymentMethodService->calculateTax($amount, $paymentMethodId, $applicationId);
        $applicationPaymentMethod = $application->payment;
        $applicationPaymentMethod->update(['default_amount'=>$amount, 'default_tax'=>$tax,'amount'=>$amount,'tax'=>$tax]);
    }

    /**
     * Get total amount of fee in an application with tax
     * @param $applicationId
     * @return array
     */
    public function getApplicationAmountWithTax($applicationId): array
    {
        $defaultAmount = $amount = $defaultTax = $tax = 0;
        $application = Application::find($applicationId);

        // application programs
        foreach ($application->programs as $program){
            $defaultAmount+= $program->pivot->default_amount;
            $amount+= $program->pivot->amount;
            $defaultTax+= $program->pivot->default_tax;
            $tax+= $program->pivot->tax;
        }
        foreach ($application->programServices as $services){
            $defaultAmount+= $services->pivot->default_amount;
            $amount+= $services->pivot->amount;
            $defaultTax+= $services->pivot->default_tax;
            $tax+= $services->pivot->tax;
        }

        // application accommodations
        foreach ($application->accommodations as $accommodation){
            $defaultAmount+= $accommodation->pivot->default_amount;
            $amount+= $accommodation->pivot->amount;
            $defaultTax+= $accommodation->pivot->default_tax;
            $tax+= $accommodation->pivot->tax;
        }
        foreach ($application->accommodationServices as $services){
            $defaultAmount+= $services->pivot->default_amount;
            $amount+= $services->pivot->amount;
            $defaultTax+= $services->pivot->default_tax;
            $tax+= $services->pivot->tax;
        }
        foreach ($application->accommodationAddons as $addon){
            $defaultAmount+= $addon->pivot->default_amount;
            $amount+= $addon->pivot->amount;
            $defaultTax+= $addon->pivot->default_tax;
            $tax+= $addon->pivot->tax;
        }

        // application transportations
        foreach ($application->transportations as $transport){
            $defaultAmount+= $transport->pivot->default_amount;
            $amount+= $transport->pivot->amount;
            $defaultTax+= $transport->pivot->default_tax;
            $tax+= $transport->pivot->tax;
        }
        foreach ($application->transportationServices as $services){
            $defaultAmount+= $services->pivot->default_amount;
            $amount+= $services->pivot->amount;
            $defaultTax+= $services->pivot->default_tax;
            $tax+= $services->pivot->tax;
        }
        foreach ($application->transportationAddons as $addon){
            $defaultAmount+= $addon->pivot->default_amount;
            $amount+= $addon->pivot->amount;
            $defaultTax+= $addon->pivot->default_tax;
            $tax+= $addon->pivot->tax;
        }

        // application insurances
        foreach ($application->insurances as $transport){
            $defaultAmount+= $transport->pivot->default_amount;
            $amount+= $transport->pivot->amount;
            $defaultTax+= $transport->pivot->default_tax;
            $tax+= $transport->pivot->tax;
        }

        return  [
            'total_default_amount' => $defaultAmount,
            'total_default_tax' => $defaultTax,
            'total_amount' => $amount,
            'total_tax' => $tax,
        ];
        
    }
}
