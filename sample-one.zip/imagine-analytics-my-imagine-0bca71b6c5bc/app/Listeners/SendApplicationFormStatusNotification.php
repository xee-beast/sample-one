<?php

namespace App\Listeners;

use App\Events\ApplicationFormStatusChanged;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Queue\InteractsWithQueue;

class SendApplicationFormStatusNotification
{
    /**
     * Create the event listener.
     *
     * @return void
     */
    public function __construct()
    {
        //
    }

    /**
     * Handle the event.
     *
     * @param ApplicationFormStatusChanged $event
     * @return void
     */
    public function handle(ApplicationFormStatusChanged $event)
    {
        // handles the event to status change here
    }
}
