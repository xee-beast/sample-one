<?php

namespace App\Listeners;

use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Support\Facades\Log;

class RecordApplicationTimeLine
{
    private $data;
    /**
     * Create the event listener.
     *
     * @return void
     */
    public function __construct()
    {
    }

    /**
     * Handle the event.
     *
     * @param  object  $event
     * @return void
     */
    public function handle($event): void
    {
        $eventType = $event->eventData['event_type'];
        switch($eventType){
            case 'status_changed':
                $this->recordStatusChanged($event->eventData);
                break;
            case 'application_created':
                $this->recordApplicationCreatedEvent($event->eventData);
                break;
            case 'document_created':
                $this->recordApplicationDocumentCreatedEvent($event->eventData);
                break;
            case 'document_removed':
                $this->recordApplicationDocumentRemovedEvent($event->eventData);
                break;
            case 'application_submitted':
                $this->recordApplicationSubmittedEvent($event->eventData);
                break;
            case 'student_created':
                $this->recordApplicationStudentCreatedEvent($event->eventData);
                break;
            case 'student_removed':
                $this->recordApplicationStudentRemovedEvent($event->eventData);
                break;
            case 'offer_created':
                $this->recordApplicationOfferCreatedEvent($event->eventData);
                break;
            case 'offer_removed':
                $this->recordApplicationOfferRemovedEvent($event->eventData);
                break;
            case 'owner_updated':
                $this->recordApplicationOwnerChangeEvent($event->eventData);
                break;
            case 'offer_status':
                $this->recordApplicationOfferStatusChangeEvent($event->eventData);
                break;
            case 'application_details_updated':
                $this->recordApplicationDetailUpdateEvent($event->eventData);
                break;


        }

    }

    /**
     * @param $data
     * @return void
     */
    private function recordApplicationOfferStatusChangeEvent($data): void
    {
        $user = $data['user'];
        $application = $data['application'];
        $application->activities()->create([
            'user_id' => $user->id,
            'event' => 'Offer sync’d from Ebecas: '. $application->offer_id
        ]);
    }

    /**
     * @param $data
     * @return void
     */
    private function recordApplicationOwnerChangeEvent($data): void
    {
        $user = $data['user'];
        $application = $data['application'];
        $oldOwner = $data['old_owner'];
        $oldOwnerRoute = route('staff.users.show',$oldOwner->id);
        $newOwnerRoute = route('staff.users.show',$application->applicationOwner->id);
        $userTypeConstants = config('constants.user_types');

        $application->activities()->create([
            'user_id' => $user->id,
            'event' => 'Application re-assigned: <a href="'.$oldOwnerRoute.'">'.$oldOwner->fullName.'</a>' .' ('. $userTypeConstants[$oldOwner->user_type].') => <a href="'.$newOwnerRoute.'">'.$application->applicationOwner->fullName.'</a>' .' ('. $userTypeConstants[$application->applicationOwner->user_type].')'
        ]);
    }

    /**
     * @param $data
     * @return void
     */
    private function recordStatusChanged($data): void
    {
        $user = $data['user'];
        $application = $data['application'];
        $applicationStatusConstants = config('constants.application_form.status');
        $application->activities()->create([
            'user_id' => $user->id,
            'event' => 'Application status changed:  '.$applicationStatusConstants[$data['old_status']]['label'].'  =>  '.$applicationStatusConstants[$data['new_status']]['label'],
        ]);
    }

    /**
     * @param $data
     * @return void
     */
    private function recordApplicationCreatedEvent($data): void
    {
        $user = $data['user'];
        $application = $data['application'];
        $application->activities()->create([
            'user_id' => $user->id,
            'event' => "Application created"
        ]);
    }

    /**
     * @param $data
     * @return void
     */
    private function recordApplicationDocumentCreatedEvent($data): void
    {
        $user = $data['user'];
        $document = $data['document'];
        $application = $data['application'];
        $route = route('application.document.single.get',$document->id);
        $documentConstants = config('constants.application_form.documents');
        $application->activities()->create([
            'user_id' => $user->id,
            'event' => 'Document uploaded :  '.$documentConstants[$document->type]['label'].' : <a href="'.$route.'">'.$document->name.'</a>'
        ]);
    }

    /**
     * @param $data
     * @return void
     */
    private function recordApplicationDocumentRemovedEvent($data): void
    {
        $user = $data['user'];
        $document = $data['document'];
        $application = $data['application'];
        $documentConstants = config('constants.application_form.documents');
        $application->activities()->create([
            'user_id' => $user->id,
            'event' => 'Document removed:  '.$documentConstants[$document['type']]['label'].' : '.$document['name']
        ]);
    }

    /**
     * @param $data
     * @return void
     */
    private function recordApplicationSubmittedEvent($data): void
    {
        $user = $data['user'];
        $application = $data['application'];
        $application->activities()->create([
            'user_id' => $user->id,
            'event' => "Application Submitted"
        ]);
    }

    /**
     * @param $data
     * @return void
     */
    private function recordApplicationStudentCreatedEvent($data): void
    {
        $user = $data['user'];
        $application = $data['application'];
        $application->activities()->create([
            'user_id' => $user->id,
            'event' => "Student created/linked in Ebecas: $application->student_number"
        ]);
    }

    /**
     * @param $data
     * @return void
     */
    private function recordApplicationStudentRemovedEvent($data): void
    {
        $user = $data['user'];
        $application = $data['application'];
        $oldStudentId = $data['old_student_id'];
        $application->activities()->create([
            'user_id' => $user->id,
            'event' => "Ebecas student removed from application: $oldStudentId"
        ]);
    }

    /**
     * @param $data
     * @return void
     */
    private function recordApplicationOfferCreatedEvent($data): void
    {
        $user = $data['user'];
        $application = $data['application'];
        $application->activities()->create([
            'user_id' => $user->id,
            'event' => "Offer created in Ebecas: $application->offer_id"
        ]);
    }

    /**
     * @param $data
     * @return void
     */
    private function recordApplicationOfferRemovedEvent($data): void
    {
        $user = $data['user'];
        $application = $data['application'];
        $offer_id = $data['offer_id'];
        $application->activities()->create([
            'user_id' => $user->id,
            'event' => "Offer unlinked from application: $offer_id"
        ]);
    }

    /**
     * @param $data
     * @return void
     */
    private function recordApplicationDetailUpdateEvent($data): void
    {
        $user = $data['user'];
        $application = $data['application'];
        $application->activities()->create([
            'user_id' => $user->id,
            'event' => "Application saved (re-submitted)"
        ]);
    }
}
