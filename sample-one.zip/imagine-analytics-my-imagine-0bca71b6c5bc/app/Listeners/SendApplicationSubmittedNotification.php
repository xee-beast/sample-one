<?php

namespace App\Listeners;

use App\Events\ApplicationSubmitted;
use App\Models\User;
use App\Notifications\ApplicationSubmittedNotification;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Support\Facades\Notification;

class SendApplicationSubmittedNotification
{
    /**
     * Create the event listener.
     *
     * @return void
     */
    public function __construct()
    {
        //
    }

    /**
     * Handle the event.
     *
     * @param ApplicationSubmitted $event
     * @return void
     */
    public function handle(ApplicationSubmitted $event)
    {

        if($event->oldStatus != 'draft'){
            return;
        }
        $generalSettings = app()->make('App\Classes\Settings\GeneralSettings');
        $notifiersIds = $generalSettings->notifiers_on_app_form_submission;
        $notifiers = User::whereIn('id', $notifiersIds)->get();
        Notification::sendNow($notifiers, new ApplicationSubmittedNotification($event->application));
    }
}
