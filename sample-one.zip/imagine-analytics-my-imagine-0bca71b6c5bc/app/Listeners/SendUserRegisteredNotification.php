<?php

namespace App\Listeners;

use App\Events\UserSelfRegistered;
use App\Models\User;
use App\Notifications\UserRegisteredNotification;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Support\Facades\Notification;

class SendUserRegisteredNotification
{
    /**
     * Create the event listener.
     *
     * @return void
     */
    public function __construct()
    {
        //
    }

    /**
     * Handle the event.
     *
     * @param UserSelfRegistered $event
     * @return void
     */
    public function handle(UserSelfRegistered $event)
    {
        if(!$event->user->isAgent()){
            return;
        }

        $generalSettings = app()->make('App\Classes\Settings\GeneralSettings');
        $notifiersIds = $generalSettings->notifiers_on_agent_registration;
        $notifiers = User::whereIn('id', $notifiersIds)->get();
        Notification::sendNow($notifiers, new UserRegisteredNotification($event->user));
    }
}
