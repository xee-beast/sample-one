<?php

namespace App\Classes\Settings;

use Spatie\LaravelSettings\Settings;

class EbecasSettings extends Settings
{
    public string|null $college_code;
    public string|null $api_url;
    public string|null $api_key;
    public string|null $api_secret;
    public string|null $api_username;

    public static function group(): string
    {
        return 'ebecas';
    }
}
