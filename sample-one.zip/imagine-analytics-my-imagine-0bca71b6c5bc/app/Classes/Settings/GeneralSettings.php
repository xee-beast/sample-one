<?php

namespace App\Classes\Settings;

use Spatie\LaravelSettings\Settings;

class GeneralSettings extends Settings
{
    public array|null $notifiers_on_agent_registration;
    public array|null $notifiers_on_app_form_submission;

    public static function group(): string
    {
        return 'general';
    }
}
