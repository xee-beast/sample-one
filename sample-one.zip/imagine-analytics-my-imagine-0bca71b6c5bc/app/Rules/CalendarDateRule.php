<?php

namespace App\Rules;

use Carbon\Carbon;
use Illuminate\Contracts\Validation\Rule;

class CalendarDateRule implements Rule
{
    public string $message = "";
    /**
     * Create a new rule instance.
     *
     * @return void
     */
    public function __construct()
    {
        //
    }

    /**
     * Determine if the validation rule passes.
     *
     * @param  string  $attribute
     * @param  mixed  $value
     * @return bool
     */
    public function passes($attribute, $value): bool
    {
        foreach ($value as $index => $date){

            // if weeks are provided then end date is required
            if ($date['weeks'] && ! $date['end_date']){
                $this->message = "End date is required with weeks at row " . $index+1;
                return false;
            }

            // end date cannot be less then the start date
            if ($date['end_date']){
                if ( Carbon::parse($date['end_date'])->lt(Carbon::parse($date['start_date'])) ){
                    $this->message = "End date cannot be less then the start date at date row " . $index+1;
                    return false;
                }
            }
        }

        return true;
    }

    /**
     * Get the validation error message.
     *
     * @return string
     */
    public function message()
    {
        return $this->message;
    }
}
