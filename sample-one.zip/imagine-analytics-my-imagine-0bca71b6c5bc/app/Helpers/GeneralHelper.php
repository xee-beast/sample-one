<?php
    /**
     * Returns side bar json with respect to logged in user's type .
     *
     * @param  array  $sidebarContent | Optional
     * @return array
     */

use App\Models\User;

if(!function_exists('sidebarContent')){
    function sidebarContent( $sidebarArray = []): array{
        $user = auth()->user();
        if(count($sidebarArray) == 0){
            $fileName = match ($user->user_type){
                config('constants.user_types.staff') => "/json/sidebars/staff/sidebar.json",
                config('constants.user_types.student') => "/json/sidebars/student/sidebar.json",
                config('constants.user_types.agent') => "/json/sidebars/agent/sidebar.json",
                default => ""
            };

            if($fileName){
                $content = resource_path($fileName);
                $sidebarArray =  json_decode(file_get_contents($content));
            }
        }

        $sidebarJson=  [];
        for($i=0; $i < count($sidebarArray); $i++){
            $item = $sidebarArray[$i];
            $permissions = isset($item->permissions) && ($item->permissions != '' && $item->permissions != '*')  ? explode('|',$item->permissions) : '';

            //Convert permissions string to array and check if user has any of given permission
            $authorize = false;
            if( is_array($permissions)){
                for( $j = 0; $j < count($permissions); $j++){
                    if(auth()->user()->can($permissions[$j]))
                        $authorize = true;
                }
                if(!auth()->user()->hasRole(config('constants.system_roles.superadmin')) && $authorize == false)
                    continue;
            }
            // setup routes  and add active class on current page route in sidebar
            if(isset($item->route)){
                $route = $item->route;
                $currentRoute = null;
                $isRoute = request()->route();
                if(isset($isRoute)){
                    $currentRoute = str_replace(['.index','.show','.create','.edit'],'',request()->route()->getName());
                }
                if(str_contains($route, $currentRoute)){
                    $item->class = "active";
                }
                $item->route = route($route);
            }

            if(isset($item->children)){
                $item->children = sidebarContent($item->children);
                // Skip menu group if its empty
                if(!isset($item->route) &&  count($item->children) == 0 )
                    continue;
            }
            $sidebarJson[] = $item;
        }
        return $sidebarJson;

    }
 }

if(!function_exists('percentageFormatter')) {
    function percentageFormatter($value): float|int
    {
        return ($value * 100);
    }
}

if(!function_exists('currencyFormat')) {
    function currencyFormatter($value): string
    {
        return '$'.number_format($value,2,".","," );
    }
}

if(!function_exists('getBotUser')) {
    function getBotUser(): User
    {
        return User::where('id',1)->where('user_type','staff')->first();
    }
}

/**
  * * Returns tax from given amount
  * @param  float  $amount
  * @param  bool  tax_included
  * @return float
**/
if(!function_exists('calculateTax')) {
    function calculateTax ($amount, $tax_included=true) {
        return $tax_included ? $amount/11 : $amount*0.11;
    }
}


if(!function_exists('arraySortByColumn')) {
    function arraySortByColumn(&$array, $column, $direction = SORT_ASC): void
    {
        $reference_array = array();

        foreach($array as $key => $row) {
            $reference_array[$key] = $row[$column];
        }

        array_multisort($reference_array, $direction, $array);
    }
}

