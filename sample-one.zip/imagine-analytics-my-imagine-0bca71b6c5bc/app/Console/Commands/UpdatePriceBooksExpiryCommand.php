<?php

namespace App\Console\Commands;

use App\Models\AccommodationPriceBook;
use App\Models\ProgramPriceBook;
use Carbon\Carbon;
use Illuminate\Console\Command;

class UpdatePriceBooksExpiryCommand extends Command
{

    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'application:update-pricebook-expiry';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Update Programs and Accommodation pricebook expiry status';


    /**
     * Execute the console command.
     *
     * @return int
     */
    public function handle()
    {
        $programPricebooks = ProgramPriceBook::where('expired',0)->get();
        foreach ($programPricebooks as $pricebook){
            if (Carbon::today()->gt(Carbon::parse($pricebook->expiry_date))){
                $pricebook->expired = true;
                $pricebook->save();
            }
        }

        $accommodationPricebooks = AccommodationPriceBook::where('expired',0)->get();
        foreach ($accommodationPricebooks as $pricebook){
            if (Carbon::today()->gt(Carbon::parse($pricebook->expiry_date))){
                $pricebook->expired = true;
                $pricebook->save();
            }
        }
    }
}
