<?php

namespace App\Console\Commands;

use App\Events\ApplicationTimeLine;
use App\Models\Application;
use App\Services\ApplicationOfferService;
use Illuminate\Console\Command;
use Illuminate\Support\Facades\App;
use Illuminate\Support\Facades\Log;

class SyncApplicationOffersCommand extends Command
{

    protected ApplicationOfferService $applicationOfferService;

    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'application:sync-offers';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Sync applications offers with Ebecas';


    /**
     * Execute the console command.
     *
     * @return int
     */
    public function handle()
    {
        $applications = Application::whereNotNull('offer_id')->whereIn('status',['application','offer'])->get();
        foreach($applications as $application){
            $applicationService = app(ApplicationOfferService::class);
            $response = $applicationService->syncOffer($application);
            if(!$response['success']){
                Log::critical("There was an error sync'ing application $application->id from command");
            }
        }
    }
}
