<?php

namespace App\Models;

use Exception;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsToMany;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Http\JsonResponse;
use Yajra\DataTables\DataTables;

class Insurance extends Model
{
    use HasFactory;
    protected $guarded = [];

    public function fees(): HasMany
    {
        return $this->hasMany(InsuranceFee::class,'insurance_id');
    }

    /**
     * @return BelongsToMany
     */
    public function faculties(): BelongsToMany{
        return $this->belongsToMany(Faculty::class, 'faculty_insurance', 'insurance_id', 'faculty_id')->withPivot(['fee','ebecas_product_id']);
    }

}
