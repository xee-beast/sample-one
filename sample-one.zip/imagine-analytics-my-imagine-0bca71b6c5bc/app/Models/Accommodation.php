<?php

namespace App\Models;

use Exception;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\BelongsToMany;
use Yajra\DataTables\DataTables;

class Accommodation extends Model
{
    use HasFactory;

    protected $fillable = [
        'name',
        'description',
        'enabled',
        'accommodation_price_book_id',
        'accommodation_category_id',
        'min_length',
        'max_length',
        'length_restriction_enabled'
    ];

    /**
     * @return BelongsTo
     */
    public function priceBook():BelongsTo {
        return $this->belongsTo(AccommodationPriceBook::class,'accommodation_price_book_id');
    }

    /**
     * @return BelongsTo
     */
    public function category():BelongsTo {
        return $this->belongsTo(AccommodationCategory::class,'accommodation_category_id');
    }

    public function services(): BelongsToMany{
        return $this->belongsToMany(AccommodationFeeService::class, 'accommodation_service', 'accommodation_id', 'accommodation_fee_service_id')->withPivot('mandatory');
    }

    /**
     * @return BelongsToMany
     */
    public function faculties(): BelongsToMany{
        return $this->belongsToMany(Faculty::class, 'faculty_accommodation','accommodation_id','faculty_id')->withPivot(['calendar_id','ebecas_product_id']);
    }

    public function addons(): BelongsToMany{
        return $this->belongsToMany(AccommodationFeeAddon::class, 'accommodation_addon', 'accommodation_id', 'addon_id')->withPivot('mandatory');
    }

    /**
     * @return BelongsToMany
     */
    public function applications(): BelongsToMany
    {
        return $this->belongsToMany(Accommodation::class,'application_accommodation','accommodation_id','application_id')->withPivot(['faculty_id','start_date','end_date','weeks','days']);
    }

    public function optionalServices(){
        return $this->services()->where('enabled',1)->wherePivot('mandatory',0);
    }

    public function mandatoryServices(){
        return $this->services()->where('enabled',1)->wherePivot('mandatory',1);
    }
    
    public function mandatoryAddons(){
        return $this->addons()->where('enabled',1)->wherePivot('mandatory',1);
    }

    public function optionalAddons(){
        return $this->addons()->where('enabled',1)->wherePivot('mandatory',0);
    }

     /**
     * Gives count of connected relations
     * @return bool
     */
    public function hasResources(){
        $applicationCount = $this->applications()->count();
        $facultyCount = $this->faculties()->count();
        if($applicationCount > 0 || $facultyCount > 0)
            return true;
        return false;
    }


    /**
     * @return mixed
     * @throws Exception
     */
    public static function getDataTable(){
        $query = self::query();

        return DataTables::of($query)
            ->editColumn('name', function ($accommodation) {
                return '<a href="'. route('staff.settings.products.accommodation.show',$accommodation) .'" class="text-decoration-none">'.$accommodation->name.'</a>';
            })
            ->editColumn('category', function ($accommodation) {
                return '<a href="'. route('staff.settings.products.accommodation-categories.show',$accommodation->category) .'" class="text-decoration-none">'.$accommodation->category->name.'</a>';
            })
            ->addColumn('price_book', function ($accommodation) {
                $priceBook = $accommodation->priceBook ? $accommodation->priceBook->name : '';
                if($priceBook){
                    return '<a href="'. route('staff.settings.fees.accommodation.pricebooks.show',$accommodation->priceBook) .'" class="text-decoration-none">'.$priceBook.'</a>';
                }
                return '';
            })
            ->editColumn('enabled', function ($accommodation) {
                return $accommodation->enabled ? 'Active' : "Inactive";
            })

            ->filter(function ($query) {
                if (!empty(request('search')['value'])) {
                    $search = request('search')['value'];
                    $query->where(function ($query)  use($search){
                        $query->orWhere('accommodations.name', 'like', '%' . $search . '%');
                        $query->orWhere('accommodations.description', 'like', '%' . $search . '%');
                        $query->orWhereHas('priceBook', function($query) use ($search) {
                            $query->where('accommodation_price_books.name', 'like', '%' . $search . '%');
                        });
                        $query->orWhereHas('category', function($query) use ($search) {
                            $query->where('accommodation_categories.name', 'like', '%' . $search . '%');
                        });
                    });
                }
            })
            ->orderColumn('name', function ($query, $order) {
                $query->orderBy('name', $order);
            })
            ->rawColumns(['name','price_book', 'category'])
            ->make(true);
    }
}
