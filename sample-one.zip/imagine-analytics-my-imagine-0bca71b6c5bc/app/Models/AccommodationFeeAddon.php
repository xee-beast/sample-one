<?php

namespace App\Models;

use Exception;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsToMany;
use Illuminate\Http\JsonResponse;
use Yajra\DataTables\DataTables;

class AccommodationFeeAddon extends Model
{
    use HasFactory;
    protected $guarded = [];

    /**
     * @return BelongsToMany
     */
    public function accommodation() : BelongsToMany{
        return $this->belongsToMany(Accommodation::class, 'accommodation_addon', 'addon_id','accommodation_id')->withPivot(['mandatory']);
    }

    /**
     * @return BelongsToMany
     */
    public function faculties(): BelongsToMany{
        return $this->belongsToMany(Faculty::class, 'faculty_accommodation_addon',  'addon_id', 'faculty_id')->withPivot(['fee','ebecas_product_id']);
    }

    /**
     * @return BelongsToMany
     */
    public function applications(): BelongsToMany{
        return $this->belongsToMany(Application::class, 'application_accommodation_addon', 'addon_id', 'application_id');
    }

     /**
     * Gives count of connected relations
     * @return bool
     */
    public function hasResources(){
        $accommodationCount = $this->accommodation()->count();
        $facultyCount = $this->faculties()->count();
        $applicationCount = $this->applications()->count();
        if($accommodationCount > 0 || $applicationCount > 0 || $facultyCount > 0)
            return true;
        return false;
    }

    /**
     * @return JsonResponse
     * @throws Exception
     */
    public static function  getDataTable(): JsonResponse
    {
        $query = self::query();

        return DataTables::of($query)
            ->editColumn('name', function ($addon) {
                return '<a href="'. route('staff.settings.fees.accommodation.fee-addons.show',$addon) .'" class="text-decoration-none">'.$addon->name.'</a>';
            })
            ->editColumn('enabled', function ($addon) {
                return $addon->enabled ? 'Active' : "Inactive";
            })
            ->editColumn('taxable', function ($addon) {
                return $addon->taxable ? 'Yes' : "No";
            })
            ->editColumn('weekly_fee', function ($addon) {
                return currencyFormatter($addon->weekly_fee);
            })
            ->filter(function ($query) {
                if (!empty(request('search')['value'])) {
                    $search = request('search')['value'];
                    $query->where(function ($query)  use($search){
                        $query->orWhere('name', 'like', '%' . $search . '%');
                        $query->orWhere('weekly_fee', 'like', '%' . $search . '%');
                    });
                }
            })
            ->rawColumns(['name'])
            ->make(true);
    }
}
