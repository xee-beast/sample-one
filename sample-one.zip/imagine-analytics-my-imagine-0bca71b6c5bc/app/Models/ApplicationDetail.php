<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Casts\Attribute;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class ApplicationDetail extends Model
{
    use HasFactory;
    protected $guarded = [];
    protected $appends = ['full_name'];

    /**
     * @return BelongsTo
     */
    public function application(): BelongsTo
    {
        return $this->belongsTo(Application::class);
    }



    /**
     * Get the user's full name.
     *
     * @return string
     */
    public function getFullNameAttribute()
    {
        return $this->first_name .' '.$this->last_name;
    }

    /**
     * @return BelongsTo
     */
    public function nationality(): BelongsTo
    {
        return $this->belongsTo(Country::class,'country');
    }

    /**
     * @return BelongsTo
     */
    public function birthCountry(): BelongsTo
    {
        return $this->belongsTo(Country::class,'country_of_birth');
    }

    /**
     * @return BelongsTo
     */
    public function visaApplyingFor(): BelongsTo
    {
        return $this->belongsTo(Visa::class,'visa_applying_for');
    }

    /**
     * @return BelongsTo
     */
    public function visaType(): BelongsTo
    {
        return $this->belongsTo(Visa::class,'current_visa_type');
    }

    /**
     * @return BelongsTo
     */
    public function firstLanguage(): BelongsTo
    {
        return $this->belongsTo(Language::class,'language');
    }

    /**
     * @return BelongsTo
     */
    public function visaApplicationLocation(): BelongsTo
    {
        return $this->belongsTo(Country::class,'visa_application_location');
    }

    /**
     * @return BelongsTo
     */
    public function currentResidenceCountry(): BelongsTo
    {
        return $this->belongsTo(Country::class,'current_residence_address_country');
    }
}
