<?php

namespace App\Models;

use Exception;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Http\JsonResponse;
use Yajra\DataTables\DataTables;

class Location extends Model
{
    protected $guarded = [];

    /**
     * @return JsonResponse
     * @throws Exception
     */
    public static function  getDataTable(): JsonResponse
    {
        $query = self::query();

        return DataTables::of($query)
            ->editColumn('name', function ($location) {
                return '<a href="'. route('staff.settings.locations.show',$location) .'" class="text-decoration-none">'.$location->name.'</a>';
            })
            ->editColumn('enabled', function ($location) {
                return $location->enabled ? 'Active' : "Inactive";
            })
            ->filter(function ($query) {
                if (!empty(request('search')['value'])) {
                    $search = request('search')['value'];
                    $query->where(function ($query)  use($search){
                        $query->orWhere('name', 'like', '%' . $search . '%');
                    });
                }
            })
            ->rawColumns(['name'])
            ->make(true);
    }

    /**
     * @return HasMany
     */
    public function faculties(): HasMany {
        return $this->hasMany(Faculty::class);
    }

     /**
     * @return HasMany
     */
    public function transportsAsOrigin(): HasMany {
        return $this->hasMany(Transportation::class, 'origin');
    }

     /**
     * @return HasMany
     */
    public function transportsAsDestination(): HasMany {
        return $this->hasMany(Transportation::class, 'destination');
    }

    /**
     * Gives count of connected relations
     * @return bool
     */
    public function hasResources(){
        $facultyCount = $this->faculties()->count();
        $originCount = $this->transportsAsOrigin()->count();
        $destinationCount = $this->transportsAsDestination()->count();
        if($facultyCount > 0 || $destinationCount > 0 || $originCount > 0)
            return true;
        return false;
    }

}
