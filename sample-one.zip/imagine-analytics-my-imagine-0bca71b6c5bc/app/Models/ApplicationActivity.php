<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class ApplicationActivity extends Model
{
    use HasFactory;

    protected $fillable = [
        'user_id',
        'application_id',
        'event',
        'url',
    ];

    /**
     * @return BelongsToMany
     */
    public function user():BelongsTo
    {
        return $this->belongsTo(User::class,'user_id');
    }

    /**
     * @return BelongsToMany
     */
    public function application():BelongsTo
    {
        return $this->belongsTo(Application::class,'application_id');
    }
}
