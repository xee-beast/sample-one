<?php

namespace App\Models;

use Exception;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Http\JsonResponse;
use Yajra\DataTables\DataTables;

class AccommodationCategory extends Model
{
    use HasFactory;

    protected $guarded = [];

    /**
     * @return JsonResponse
     * @throws Exception
     */
    public static function  getDataTable(): JsonResponse
    {
        $query = self::query();

        return DataTables::of($query)
            ->editColumn('name', function ($cat) {
                return '<a href="'. route('staff.settings.products.accommodation-categories.show',$cat) .'" class="text-decoration-none">'.$cat->name.'</a>';
            })
            ->editColumn('enabled', function ($cat) {
                return $cat->enabled ? 'Active' : "Inactive";
            })
            ->editColumn('age_restricted', function ($cat) {
                return $cat->age_restricted ? 'Yes' : "No";
            })
            ->filter(function ($query) {
                if (!empty(request('search')['value'])) {
                    $search = request('search')['value'];
                    $query->where(function ($query)  use($search){
                        $query->orWhere('name', 'like', '%' . $search . '%');
                        $query->orWhere('description', 'like', '%' . $search . '%');
                    });
                }
            })
            ->orderColumn('name', function ($query, $order) {
                $query->orderBy('name', $order);
            })
            ->rawColumns(['name'])
            ->make(true);
    }


    public function accommodations(){
        return $this->hasMany(Accommodation::class);
    }

     /**
     * Gives count of connected relations
     * @return bool
     */
    public function hasResources(){
        $accommodationCount = $this->accommodations()->count();
        if($accommodationCount > 0)
            return true;
        return false;
    }
}
