<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsToMany;
use Illuminate\Http\JsonResponse;
use Yajra\DataTables\DataTables;

class AccommodationFeeService extends Model
{
    use HasFactory;

    protected $guarded = [];
    
    public static function  getDataTable(): JsonResponse
    {
        $query = self::query();

        return DataTables::of($query)
            ->editColumn('name', function ($service) {
                return '<a href="' . route('staff.settings.fees.accommodation.fee-services.show', $service) . '" class="text-decoration-none">' . $service->name . '</a>';
            })
            ->editColumn('enabled', function ($service) {
                return $service->enabled ? 'Active' : "Inactive";
            })
            ->editColumn('taxable', function ($service) {
                return $service->taxable ? 'Yes' : "No";
            })
            ->editColumn('fee', function ($service) {
                return currencyFormatter($service->fee);
            })
            ->editColumn('type', function ($service) {
                return config('constants.accommodation_service_types.' . $service->type)['label'];
            })
            ->filter(function ($query) {
                if (!empty(request('search')['value'])) {
                    $search = request('search')['value'];
                    $query->where(function ($query) use ($search) {
                        $query->orWhere('name', 'like', '%' . $search . '%');
                    });
                }
            })
            ->rawColumns(['name'])
            ->make(true);
    }

    /**
     * @return BelongsToMany
     */
    public function faculties(): BelongsToMany{
        return $this->belongsToMany(Faculty::class, 'faculty_accommodation_service', 'fee_service_id','faculty_id')->withPivot(['fee','ebecas_product_id']);
    }

    /**
     * @return BelongsToMany
     */
    public function accommodations(): BelongsToMany{
        return $this->belongsToMany(Accommodation::class, 'accommodation_service', 'accommodation_fee_service_id', 'accommodation_id')->withPivot('mandatory');
    }

    /**
     * @return BelongsToMany
     */
    public function applications(): BelongsToMany{
        return $this->belongsToMany(Application::class, 'application_accommodation_service', 'service_id', 'application_id');
    }

    /**
     * Gives count of connected relations
     * @return bool
     */
    public function hasResources(){
        $applicationCount = $this->applications()->count();
        $accommodationCount = $this->accommodations()->count();
        $facultyCount = $this->faculties()->count();
        if($applicationCount > 0 || $accommodationCount > 0 || $facultyCount > 0)
            return true;
        return false;
    }
}
