<?php

namespace App\Models;

use Carbon\Carbon;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Yajra\DataTables\DataTables;
use Illuminate\Http\JsonResponse;

class AccommodationPriceBook extends Model
{
    use HasFactory;


    protected $fillable = [
        'name',
        'description',
        'expiry_date',
        'expired',
        'enabled',
        'price_book_category_id'
    ];

    /**
     * @return BelongsTo
     */
    public function category(): BelongsTo
    {
        return $this->belongsTo(AccommodationPriceBookCategory::class,'price_book_category_id');
    }

    /**
     * @return HasMany
     */
    public function rates(): HasMany
    {
        return $this->hasMany(AccommodationPriceBookFee::class,'price_book_id');
    }

    /**
     * @return HasMany
     */
    public function accommodations(): HasMany
    {
        return $this->hasMany(Accommodation::class,'accommodation_price_book_id');
    }


    /**
     * Gives count of connected relations
     * @return bool
     */
    public function hasResources(){
        $accommodationCount = $this->accommodations()->count();
        if($accommodationCount > 0)
            return true;
        return false;
    }

    /**
     * @return void
     */
    public function replicateRow(): void
    {
        $cloned = $this->replicate();
        $cloned->name = $cloned->name . "-copy";
        $cloned->created_at = Carbon::now();
        $cloned->updated_at = Carbon::now();
        $cloned->push();

        foreach($this->rates as $rate)
        {
            $arr = $rate->toArray();
            unset($arr['id']);
            $cloned->rates()->create($rate->toArray());
        }

        $cloned->save();
    }

    public static function  getDataTable(): JsonResponse
    {
        $query = self::query();

        return DataTables::of($query)
            ->editColumn('name', function ($priceBook) {
                return '<a href="'. route('staff.settings.fees.accommodation.pricebooks.show',$priceBook) .'" class="text-decoration-none">'.$priceBook->name.'</a>';
            })
            ->editColumn('category', function ($priceBook) {
                return '<a href="'. route('staff.settings.fees.accommodation.pricebook-categories.show',$priceBook) .'" class="text-decoration-none">'.$priceBook->category->name.'</a>';
            })
            ->editColumn('enabled', function ($priceBook) {
                return $priceBook->enabled ? 'Active' : "Inactive";
            })
            ->editColumn('expiry_date', function ($priceBook) {
                return $priceBook->expiry_date ? Carbon::parse($priceBook->expiry_date)->format('d/m/Y') : "";
            })
            ->addColumn('expired', function ($priceBook) {
                return $priceBook->expiry_date && Carbon::parse($priceBook->expiry_date)->isPast() ? 'Yes' : 'No';
            })
            ->filter(function ($query) {
                if (!empty(request('search')['value'])) {
                    $search = request('search')['value'];
                    $query->where(function ($query)  use($search){
                        $query->orWhere('name', 'like', '%' . $search . '%');
                        $query->orWhere('description', 'like', '%' . $search . '%');
                        $query->orWhereHas('category', function($query) use ($search) {
                            $query->where('accommodation_price_book_categories.name', 'like', '%' . $search . '%');
                        });
                    });
                }

                if ( !empty(request('category')) ){
                    $query->where('price_book_category_id', request('category'));
                }
                if ( request()->get('enabled') != null){
                    $query->where('enabled',(int)request('enabled'));
                }
                if ( request()->get('expired') != null){
                    $query->where('expired',(int)request('expired'));
                }
            })
            ->orderColumn('category', function ($query, $order) {
                $query->orderBy('name', $order);
            })
            ->rawColumns(['name', 'category'])
            ->make(true);
    }
}
