<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use \Spatie\Permission\Models\Permission as SpatiePermission;

class Permission extends SpatiePermission
{
    use HasFactory;

    protected $fillable = [
        'name',
        'guard_name',
        'label',
        'description',
        'group_id'
    ];

    /**
     * The accessors to append to the model's array form.
     *
     * @var array
     */
    protected $appends = ['key','parent_item','hasItems'];



    public function group(): BelongsTo
    {
        return $this->belongsTo(PermissionsGroup::class,'group_id');
    }

    /**
     * Always returns true for permission tree list to determine if this item contains any children nodes.
     * @return Boolean
     */
    public function getHasItemsAttribute(){
        return false;
    }

    /**
     * Returns id with permission prefix to determine that the selected item is permission in tree list.
     * @return String
     */
    public function getKeyAttribute(){
        return 'permission_'.$this->id;
    }
    /**
     * Returns groups id with group prefix to set permission under parent group.
     * @return String
     */
    public function getParentItemAttribute(){
        return 'group_'.$this->group_id;
    }
}
