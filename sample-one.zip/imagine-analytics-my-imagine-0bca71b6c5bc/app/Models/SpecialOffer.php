<?php

namespace App\Models;

use Exception;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\BelongsToMany;
use Illuminate\Http\JsonResponse;
use Yajra\DataTables\DataTables;

class SpecialOffer extends Model
{
    use HasFactory;

    protected $guarded = [];

    /**
     * @return BelongsTo
     */
    public function category(): BelongsTo
    {
        return $this->belongsTo(SpecialOfferCategory::class,'category_id');
    }

    /**
     * @return BelongsTo
     */
    public function region(): BelongsTo
    {
        return $this->belongsTo(Region::class,'region_id');
    }

    /**
     * @return BelongsToMany
     */
    public function locations(): BelongsToMany{
        return $this->belongsToMany(Location::class, 'special_offer_location', 'special_offer_id', 'location_id');
    }

    /**
     * @return BelongsToMany
     */
    public function pricebooks(): BelongsToMany{
        return $this->belongsToMany(ProgramPriceBook::class, 'special_offer_price_book', 'special_offer_id', 'price_book_id')->withPivot('program_id');
    }

    /**
     * @return BelongsToMany
     */
    public function services(): BelongsToMany{
        return $this->belongsToMany(ProgramFeeService::class, 'special_offer_service', 'special_offer_id', 'service_id')->withPivot(['off_type', 'value', 'override_duration', 'duration_length_start', 'duration_length_end'] );
    }

    /**
     * @return JsonResponse
     * @throws Exception
     */
    public static function  getDataTable(): JsonResponse
    {
        $query = self::query();

        return DataTables::of($query)
            ->editColumn('name', function ($offer) {
                return '<a href="'. route('staff.settings.special-offers.show',$offer) .'" class="text-decoration-none">'.$offer->name.'</a>';
            })
            ->editColumn('category', function ($offer) {
                return '<a href="'. route('staff.settings.special-offer-categories.show',$offer->category) .'" class="text-decoration-none">'.$offer->category->name.'</a>';
            })
            ->editColumn('region', function ($offer) {
                return '<a href="'. route('staff.settings.regions.show',$offer->region) .'" class="text-decoration-none">'.$offer->region->name.'</a>';
            })
            ->editColumn('enabled', function ($offer) {
                return $offer->enabled ? 'Active' : "Inactive";
            })
            ->filter(function ($query) {
                if (!empty(request('search')['value'])) {
                    $search = request('search')['value'];
                    $query->where(function ($query)  use($search){
                        $query->orWhere('name', 'like', '%' . $search . '%');
                        $query->orWhere('description', 'like', '%' . $search . '%');
                    });
                }

                if ( request()->get('enabled') != null){
                    $query->where('enabled',(int)request('enabled'));
                }
                if ( request()->get('category') != null){
                    $query->where('category_id', (int)request('category'));
                }
                if ( request()->get('region') != null){
                    $query->where('region_id', (int)request('region'));
                }

            })
            ->rawColumns(['name', 'category', 'region'])
            ->make(true);
    }
}
