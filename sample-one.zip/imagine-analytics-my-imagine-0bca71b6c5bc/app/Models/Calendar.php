<?php

namespace App\Models;

use Carbon\Carbon;
use Exception;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\BelongsToMany;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Http\JsonResponse;
use Yajra\DataTables\DataTables;

class Calendar extends Model
{
    use HasFactory;

    protected $guarded = [];

    /**
     * @return BelongsTo
     */
    public function category(): BelongsTo
    {
        return $this->belongsTo(CalendarCategory::class,'calendar_category_id');
    }

    /**
     * @return HasMany
     */
    public function dates(): HasMany
    {
        return $this->hasMany(CalendarDate::class);
    }

    /**
     * @param $dates
     * @return void
     */
    public function replicateRow($dates): void
    {
        $cloned = $this->replicate();
        $cloned->name = $cloned->name . "-copy";
        $cloned->created_at = Carbon::now();
        $cloned->updated_at = Carbon::now();
        $cloned->enabled = false;
        $cloned->push();

        foreach($dates as $date)
        {
            $arr = $date->toArray();
            unset($arr['id']);
            $cloned->dates()->create($arr);
        }

        $cloned->save();
    }

    /**
     * @return BelongsToMany
     */
    public function programs(): BelongsToMany{
        return $this->belongsToMany(Program::class, 'faculty_program', 'calendar_id','program_id');
    }

     /**
     * Gives count of connected relations
     * @return bool
     */
    public function hasResources(){
        $programCount = $this->programs()->count();
        if($programCount > 0)
            return true;
        return false;
    }

    /**
     * @return JsonResponse
     * @throws Exception
     */
    public static function  getDataTable(): JsonResponse
    {
        $query = self::query()->orderBy('name', 'asc');

        return DataTables::of($query)
            ->addColumn('name', function ($cal) {
                return '<a href="'. route('staff.settings.dates.calendars.show',$cal) .'" class="text-decoration-none">'.$cal->name.'</a>';
            })
            ->addColumn('category', function ($cal) {
                return '<a href="'. route('staff.settings.dates.categories.show',$cal->category) .'" class="text-decoration-none">'.$cal->category->name.'</a>';
            })
            ->editColumn('enabled', function ($cal) {
                return $cal->enabled ? 'Active' : "Inactive";
            })
            ->filter(function ($query) {
                if (!empty(request('search')['value'])) {
                    $search = request('search')['value'];
                    $query->where(function ($query)  use($search){
                        $query->orWhere('calendars.name', 'like', '%' . $search . '%');
                    });
                }
            })
            ->rawColumns(['name', 'category'])
            ->make(true);
    }
}
