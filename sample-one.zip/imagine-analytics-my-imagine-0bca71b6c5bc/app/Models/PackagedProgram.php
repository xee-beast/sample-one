<?php

namespace App\Models;

use Exception;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsToMany;
use Illuminate\Http\JsonResponse;
use Yajra\DataTables\DataTables;

class PackagedProgram extends Model
{
    use HasFactory;
    protected $guarded = [];

    /**
     * @return BelongsToMany
     */
    public function programs(): BelongsToMany{
        return $this->belongsToMany(Program::class, 'packaged_faculty_program', 'package_id', 'program_id')->withPivot(['faculty_id','discount']);
    }

    /**
     * @return JsonResponse
     * @throws Exception
     */
    public static function  getDataTable(): JsonResponse
    {
        $query = self::query();

        return DataTables::of($query)
            ->editColumn('name', function ($package) {
                return '<a href="'. route('staff.settings.products.packaged-programs.show',$package) .'" class="text-decoration-none">'.$package->name.'</a>';
            })
            ->editColumn('enabled', function ($package) {
                return $package->enabled ? 'Active' : "Inactive";
            })
            ->addColumn('programs', function ($package) {
                $programRowHtml = '<ol class="ps-4">';
                foreach ( $package->programs as  $program ){
                    $programRowHtml .= '<li><a href="'. route('staff.settings.products.programs.show', $program) .'" class="text-decoration-none">'. $program->name.'</a></li>';
                }
                $programRowHtml .= '</ol>';
                return $programRowHtml;
            })
            ->filter(function ($query) {
                if (!empty(request('search')['value'])) {
                    $search = request('search')['value'];
                    $query->where(function ($query)  use($search){
                        $query->orWhere('name', 'like', '%' . $search . '%');
                    });
                }

                if ( request()->get('enabled') != null){
                    $query->where('enabled',(int)request('enabled'));
                }
            })
            ->orderColumn('name', function ($query, $order) {
                $query->orderBy('name', $order);
            })
            ->rawColumns(['name','programs'])
            ->make(true);
    }
}
