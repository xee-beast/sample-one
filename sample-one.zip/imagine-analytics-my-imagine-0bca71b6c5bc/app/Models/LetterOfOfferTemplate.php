<?php

namespace App\Models;

use Exception;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\BelongsToMany;
use Yajra\DataTables\DataTables;

class LetterOfOfferTemplate extends Model
{
    use HasFactory;

    protected $guarded = [];

    /**
     * @return BelongsTo
     */
    public function faculty(): BelongsTo
    {
        return $this->belongsTo(Faculty::class,'faculty_id');
    }

    /**
     * @return BelongsToMany
     */
    public function sections(): BelongsToMany{
        return $this->belongsToMany(LetterOfOfferSection::class, 'letter_of_offer_template_sections', 'template_id', 'type')->withPivot(['section_name','section_id', 'order']);
    }


    /**
     * @return mixed
     * @throws Exception
     */
    public static function getDataTable(){
        $query = self::query();

        return DataTables::of($query)
            ->editColumn('name', function ($template) {
                return '<a href="'. route('staff.settings.offer-letters.templates.show',$template) .'" class="text-decoration-none">'.$template->name.'</a>';
            })
            ->editColumn('enabled', function ($template) {
                return $template->enabled ? 'Active' : "Inactive";
            })
            ->editColumn('faculty', function ($template) {
                return '<a href="'. route('staff.settings.faculties.details',$template->faculty) .'" class="text-decoration-none">'.$template->faculty->name.'</a>';
            })
            ->filter(function ($query) {
                if (!empty(request('search')['value'])) {
                    $search = request('search')['value'];
                    $query->where(function ($query)  use($search){
                        $query->orWhere('letter_of_offer_templates.name', 'like', '%' . $search . '%');
                        $query->orWhere('letter_of_offer_templates.description', 'like', '%' . $search . '%');
                    });
                }
            })
            ->orderColumn('name', function ($query, $order) {
                $query->orderBy('name', $order);
            })
            ->rawColumns(['name', 'faculty'])
            ->make(true);
    }
}
