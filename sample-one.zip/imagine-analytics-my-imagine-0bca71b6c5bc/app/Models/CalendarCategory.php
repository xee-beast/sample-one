<?php

namespace App\Models;

use Exception;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Http\JsonResponse;
use Yajra\DataTables\DataTables;

class CalendarCategory extends Model
{
    use HasFactory;

    protected $guarded = [];

    /**
     * @return HasMany
     */
    public function calendars(): HasMany
    {
        return $this->hasMany(Calendar::class,'calendar_category_id');
    }

     /**
     * Gives count of connected relations
     * @return bool
     */
    public function hasResources(){
        $calendarCount = $this->calendars()->count();
        if($calendarCount > 0 )
            return true;
        return false;
    }

    /**
     * @return JsonResponse
     * @throws Exception
     */
    public static function  getDataTable(): JsonResponse
    {
        $query = self::query()->orderBy('name', 'asc');

        return DataTables::of($query)
            ->addColumn('name', function ($cal) {
                return '<a href="'. route('staff.settings.dates.categories.show',$cal) .'" class="text-decoration-none">'.$cal->name.'</a>';
            })
            ->editColumn('enabled', function ($cal) {
                return $cal->enabled ? 'Active' : "Inactive";
            })
            ->filter(function ($query) {
                if (!empty(request('search')['value'])) {
                    $search = request('search')['value'];
                    $query->where(function ($query)  use($search){
                        $query->orWhere('calendar_categories.name', 'like', '%' . $search . '%');
                        $query->orWhere('calendar_categories.description', 'like', '%' . $search . '%');
                    });
                }
            })
            ->rawColumns(['name'])
            ->make(true);
    }
}
