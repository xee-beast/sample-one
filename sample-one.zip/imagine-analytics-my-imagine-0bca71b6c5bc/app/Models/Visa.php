<?php

namespace App\Models;

use Exception;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsToMany;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Http\JsonResponse;
use Yajra\DataTables\DataTables;

class Visa extends Model
{
    protected $guarded = [];

    /**
     * Scope a query to only include active visas.
     *
     * @param  \Illuminate\Database\Eloquent\Builder  $query
     * @return void
     */
    public function scopeEnabled($query)
    {
        $query->where('enabled', 1);
    }

    /**
     * @return BelongsToMany
     */
    public function programs() : BelongsToMany{
        return $this->belongsToMany(Program::class, 'program_visa', 'visa_id','program_id');
    }

    /**
     * @return HasMany
     */
    public function applications() : HasMany{
        return $this->hasMany(ApplicationDetail::class, 'visa_applying_for');
    }

    /**
     * Gives count of connected relations
     * @return bool
     */
    public function hasResources(){
        $applicationCount = $this->applications()->count();
        $programCount = $this->programs()->count();
        if($applicationCount > 0 || $programCount > 0)
            return true;
        return false;
    }

    /**
     * @return JsonResponse
     * @throws Exception
     */
    public static function  getDataTable(){
        $query = self::query();

        return DataTables::of($query)
            ->addColumn('name', function ($visa) {
                return '<a href="'. route('staff.settings.visas.show',$visa) .'" class="text-decoration-none">'.$visa->name.'</a>';
            })
            ->addColumn('enabled', function ($visa) {
                return $visa->enabled ? 'Active' : 'Inactive';
            })
            ->filter(function ($query) {
                if (!empty(request('search')['value'])) {
                    $search = request('search')['value'];
                    $query->where(function ($query)  use($search){
                        $query->orWhere('visas.name', 'like', '%' . $search . '%');
                        $query->orWhere('visas.max_weeks', 'like', '%' . $search . '%');
                    });
                }

            })
            ->orderColumn('name', function ($query, $order) {
                $query->orderBy('name', $order);
            })
            ->rawColumns(['name'])
            ->make(true);
    }
}
