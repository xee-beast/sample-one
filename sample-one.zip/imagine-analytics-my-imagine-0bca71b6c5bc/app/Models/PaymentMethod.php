<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Casts\Attribute;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsToMany;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Http\JsonResponse;
use Yajra\DataTables\DataTables;

class PaymentMethod extends Model
{
    use HasFactory;

    protected $guarded = [];

    /**
     * @return Attribute
     */
    protected function value(): Attribute
    {
        $paymentMethodPercentage = config('constants.payment_methods')['percentage']['key'];

        return Attribute::make(
            set: function ($value, $attributes) use($paymentMethodPercentage) {
                if ( count($attributes) && $attributes['surcharge_type'] == $paymentMethodPercentage  ){
                    return ($value / 100);
                }
                return $value;
            },
        );
    }

    /**
     * @return BelongsToMany
     */
    public function applications(): BelongsToMany
    {
        return $this->belongsToMany(PaymentMethod::class,'application_payments','application_id','payment_method_id');
    }

    /**
     * @return BelongsToMany
     */
    public function faculties(): BelongsToMany
    {
        return $this->belongsToMany(Faculty::class,'faculty_payment_method','faculty_id','payment_method_id');
    }

    /**
     * Gives count of connected relations
     * @return bool
     */
    public function hasResources(){
        $applicationCount = $this->applications()->count();
        $facultyCount = $this->faculties()->count();
        if($applicationCount > 0 || $facultyCount  > 0)
            return true;
        return false;
    }

    public static function  getDataTable(): JsonResponse
    {
        $query = self::query();

        return DataTables::of($query)
            ->editColumn('name', function ($method) {
                return '<a href="'. route('staff.settings.fees.payment-methods.show',$method) .'" class="text-decoration-none">'.$method->name.'</a>';
            })
            ->editColumn('enabled', function ($method) {
                return $method->enabled ? 'Active' : "Inactive";
            })
            ->editColumn('value', function ($method) {
                $surchargeType = $method->surcharge_type;
                $paymentMethods = config('constants.payment_methods');
                if ( $paymentMethods['percentage']['key'] === $surchargeType ){
                    return (number_format(percentageFormatter($method->value),2 )). '%';
                }
                return currencyFormatter($method->value);
            })
            ->editColumn('taxable', function ($method) {
                return $method->taxable ? 'Yes' : "No";
            })
            ->editColumn('is_payment_plan', function ($method) {
                return $method->is_payment_plan ? 'Yes' : "No";
            })
            ->editColumn('surcharge_type', function ($method) {
                return config('constants.payment_methods.'.$method->surcharge_type)['label'];
            })
            ->filter(function ($query) {
                if (!empty(request('search')['value'])) {
                    $search = request('search')['value'];
                    $query->where(function ($query)  use($search){
                        $query->orWhere('name', 'like', '%' . $search . '%');
                        $query->orWhere('description', 'like', '%' . $search . '%');
                    });
                }

                if ( request()->get('enabled') != null){
                    $query->where('enabled',(int)request('enabled'));
                }

                if ( request()->get('surcharge_type') != null){
                    $query->where('surcharge_type', request('surcharge_type'));
                }
            })
            ->rawColumns(['name', 'category'])
            ->make(true);
    }
}
