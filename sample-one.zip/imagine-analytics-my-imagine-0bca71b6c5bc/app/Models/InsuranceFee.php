<?php

namespace App\Models;

use Exception;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Http\JsonResponse;
use Yajra\DataTables\DataTables;

class InsuranceFee extends Model
{
    use HasFactory;
    protected $guarded = [];

    public function insuranceType(): BelongsTo
    {
        return $this->belongsTo(Insurance::class,'insurance_id');
    }

}
