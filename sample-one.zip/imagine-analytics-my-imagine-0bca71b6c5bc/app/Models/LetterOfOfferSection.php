<?php

namespace App\Models;

use Exception;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Yajra\DataTables\DataTables;

class LetterOfOfferSection extends Model
{
    use HasFactory;

    protected $guarded = [];


    /**
     * @return mixed
     * @throws Exception
     */
    public static function getDataTable(){
        $query = self::query();

        return DataTables::of($query)
            ->editColumn('name', function ($offerOfLetter) {
                return '<a href="'. route('staff.settings.offer-letters.sections.show',$offerOfLetter) .'" class="text-decoration-none">'.$offerOfLetter->name.'</a>';
            })
            ->editColumn('enabled', function ($offerOfLetter) {
                return $offerOfLetter->enabled ? 'Active' : "Inactive";
            })

            ->filter(function ($query) {
                if (!empty(request('search')['value'])) {
                    $search = request('search')['value'];
                    $query->where(function ($query)  use($search){
                        $query->orWhere('letter_of_offer_sections.name', 'like', '%' . $search . '%');
                        $query->orWhere('letter_of_offer_sections.description', 'like', '%' . $search . '%');
                    });
                }
            })
            ->orderColumn('name', function ($query, $order) {
                $query->orderBy('name', $order);
            })
            ->rawColumns(['name'])
            ->make(true);
    }
}
