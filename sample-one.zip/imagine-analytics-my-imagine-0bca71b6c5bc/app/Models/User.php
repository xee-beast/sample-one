<?php

namespace App\Models;

use Exception;
use Illuminate\Contracts\Auth\MustVerifyEmail;
use Illuminate\Database\Eloquent\Casts\Attribute;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Http\JsonResponse;
use Illuminate\Notifications\Notifiable;
use Laravel\Sanctum\HasApiTokens;
use phpDocumentor\Reflection\Types\This;
use Spatie\Permission\Traits\HasRoles;
use Yajra\DataTables\DataTables;

class User extends Authenticatable implements MustVerifyEmail
{
    use HasApiTokens, HasFactory, Notifiable, HasRoles;


    /**
     * The attributes that are mass assignable.
     *
     * @var array<int, string>
     */
    protected $fillable = [
        'first_name',
        'last_name',
        'email',
        'mobile',
        'password',
        'enabled',
        'country_id',
        'agent_id',
        'parent_user_id',
        'company',
        'email_verified_at',
        'verified_at'
    ];

    /**
     * The attributes that should be hidden for serialization.
     *
     * @var array<int, string>
     */
    protected $hidden = [
        'password',
        'remember_token',
    ];

    /**
     * The attributes that should be cast.
     *
     * @var array<string, string>
     */
    protected $casts = [
        'email_verified_at' => 'datetime',
    ];

    /**
     * Get the user's full name.
     *
     * @return Attribute
     */
    protected function fullName(): Attribute
    {
        return new Attribute(
            get: fn ($value,$attributes) => (
                $attributes['first_name']. ' '.$attributes['last_name']
            ),
        );
    }


    /**
     * Check if the Model is of Type Staff
     * @return bool
     */
    public function isStaff(): bool{
        return $this->user_type == config('constants.user_types.staff');
    }

    /**
     * Check if the Model is of Type Student
     * @return bool
     */
    public function isStudent(): bool{
        return $this->user_type == config('constants.user_types.student');
    }

    /**
     * Check if the Model is of Type Agent
     * @return bool
     */
    public function isAgent(): bool{
        return $this->user_type == config('constants.user_types.agent');
    }

    /**
     * Check if the Model is verified (verified user)
     * @return bool
     */
    public function isVerified(): bool{
        return $this->verified_at != null;
    }

    /**
     * Scope a query to only include enabled users
     * @param  \Illuminate\Database\Eloquent\Builder  $query
     * @return \Illuminate\Database\Eloquent\Builder
     */
    public function scopeEnabled($query)
    {
        return $query->where('enabled', true);
    }

    /**
     * Scope a query to only include enabled users
     * @param  \Illuminate\Database\Eloquent\Builder  $query
     * @return \Illuminate\Database\Eloquent\Builder
     */
    public function scopeStaff($query)
    {
        return $query->where('user_type', config('constants.user_types.staff'));
    }


    public function country(): BelongsTo{
        return $this->belongsTo(Country::class,'country_id');
    }

    public function children(): HasMany{
        return $this->hasMany(User::class,'parent_user_id');
    }

    public function parent(): BelongsTo{
        return $this->belongsTo(User::class,'parent_user_id');
    }

    public function agent(): BelongsTo{
        return $this->belongsTo(Agent::class,'agent_id');
    }

    /**
     * Validates if current user is a bot
     * @return bool
     */
    public function isBotUser(){
        return $this->id===1;
    }

    /**
     * @param $userTypes
     * @return JsonResponse
     * @throws Exception
     */
    public static function  getDataTable($userTypes): JsonResponse
    {
        $query = self::query();

        return DataTables::of($query)
            ->editColumn('first_name', function ($user) {
                return '<a href="'. route('staff.users.show',$user) .'" class="text-decoration-none">'.$user->first_name.'</a>';
            })
            ->editColumn('last_name', function ($user) {
                return '<a href="'. route('staff.users.show',$user) .'" class="text-decoration-none">'.$user->last_name.'</a>';
            })
            ->editColumn('email_ref', function ($user) {
                return '<a href="'. route('staff.users.show',$user) .'" class="text-decoration-none">'.$user->email.'</a>';
            })
            ->editColumn('user_type', function ($user) {
                return ucfirst($user->user_type);
            })
            ->filter(function ($query) use ($userTypes) {
                if (!empty(request('search')['value'])) {
                    $search = request('search')['value'];
                    $query->where(function ($query)  use($search){
                        $query->orWhere('users.first_name', 'like', '%' . $search . '%');
                        $query->orWhere('users.last_name', 'like', '%' . $search . '%');
                        $query->orWhere('users.email', 'like', '%' . $search . '%');
                    });
                }

                // superadmin role check
                // if the user does not have super admin role assigned then he will not be able to list superadmin users
                if ( ! auth()->user()->hasRole(config('constants.system_roles.superadmin')) ) {
                    $query->where(function($query2){
                        $query2->whereHas('roles', function ($query3) {
                            $query3->where('roles.name', '!=', config('constants.system_roles.superadmin'));
                        })->orWhereDoesntHave('roles');
                    });

                }
                $query->whereIn('user_type', $userTypes)->where('id','>',1);

                if ( request()->get('type') != null){
                    $query->where('user_type', request('type'));
                }
                if ( request()->get('enabled') != null){
                    $query->where('enabled',(int)request('enabled'));
                }

                if ( !empty(request('agent_id')) ){
                    $query->where('agent_id', request('agent_id'));
                }
            })
            ->rawColumns(['first_name','last_name', 'email_ref'])
            ->make(true);
    }



}
