<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use \Spatie\Permission\Models\Role as SpatieRole;
use Yajra\DataTables\DataTables;

class Role extends SpatieRole
{
    use HasFactory;

    /**
     * return Data Table listing for roles index
     *
     * @return DataTables
     */
    public static function  getDataTable(){
        $query = self::query();
        $query = $query->withCount('users')->orderBy('name', 'asc');

        return DataTables::of($query)
                ->addColumn('name', function ($role) {
                    return '<a href="'. route('staff.settings.roles.show',$role) .'" class="text-decoration-none">'.$role->name.'</a>';
                })
                ->filter(function ($query) {
                    if (!empty(request('search')['value'])) {
                        $search = request('search')['value'];
                        $query->where(function ($query)  use($search){
                                $query->orWhere('roles.name', 'like', '%' . $search . '%');
                                $query->orWhere('roles.description', 'like', '%' . $search . '%');
                        });
                    }
                })
                ->rawColumns(['name'])
                ->make(true);
    }

}
