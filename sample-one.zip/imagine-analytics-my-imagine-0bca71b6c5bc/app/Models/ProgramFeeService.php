<?php

namespace App\Models;

use Exception;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsToMany;
use Illuminate\Http\JsonResponse;
use Yajra\DataTables\DataTables;

class ProgramFeeService extends Model
{
    use HasFactory;

    protected $guarded = [];

    /**
     * @return JsonResponse
     * @throws Exception
     */
    public static function  getDataTable(): JsonResponse
    {
        $query = self::query();

        return DataTables::of($query)
            ->editColumn('name', function ($program) {
                return '<a href="'. route('staff.settings.fees.programs.fee-services.show',$program) .'" class="text-decoration-none">'.$program->name.'</a>';
            })
            ->editColumn('enabled', function ($program) {
                return $program->enabled ? 'Active' : "Inactive";
            })
            ->editColumn('taxable', function ($program) {
                return $program->taxable ? 'Yes' : "No";
            })
            ->editColumn('instalment_plan_enabled', function ($program) {
                return $program->instalment_plan_enabled ? 'Yes' : "No";
            })
            ->editColumn('fee', function ($program) {
                return currencyFormatter($program->fee);
            })
            ->editColumn('type', function ($program) {
                return config('constants.program_service_types.'.$program->type)['label'];
            })
            ->filter(function ($query) {
                if (!empty(request('search')['value'])) {
                    $search = request('search')['value'];
                    $query->where(function ($query)  use($search){
                        $query->orWhere('name', 'like', '%' . $search . '%');
                    });
                }
            })
            ->rawColumns(['name'])
            ->make(true);
    }

     /**
     * @return BelongsToMany
     */
    public function programs(): BelongsToMany{
        return $this->belongsToMany(Program::class, 'program_service', 'program_fee_service_id', 'program_id')->withPivot('mandatory');
    }

    /**
     * @return BelongsToMany
     */
    public function applications(): BelongsToMany{
        return $this->belongsToMany(Application::class, 'application_program_service', 'service_id', 'application_id');
    }

    /**
     * Gives count of connected relations
     * @return bool
     */
    public function hasResources(){
        $programCount = $this->programs()->count();
        $applicationCount = $this->applications()->count();
        if($programCount > 0 || $applicationCount > 0)
            return true;
        return false;
    }
}
