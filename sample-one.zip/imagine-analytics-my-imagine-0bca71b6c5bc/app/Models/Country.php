<?php

namespace App\Models;

use Exception;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Http\JsonResponse;
use Yajra\DataTables\DataTables;

class Country extends Model
{
    use HasFactory;

    protected $guarded = [];


    /**
     * Scope a query to only include active countries.
     *
     * @param  \Illuminate\Database\Eloquent\Builder  $query
     * @return void
     */
    public function scopeEnabled($query)
    {
        $query->where('enabled', 1);
    }

    /**
     * @return BelongsTo
     */
    public function region(): BelongsTo
    {
        return $this->belongsTo(Region::class);
    }

    /**
     * @return HasMany
     */
    public function applications(): HasMany
    {
        return $this->hasMany(ApplicationDetail::class,'country');
    }

    /**
     * Gives count of connected relations
     * @return bool
     */
    public function hasResources(){
        $applicationCount = $this->applications()->count();
        if($applicationCount > 0)
            return true;
        return false;
    }

    /**
     * @return JsonResponse
     * @throws Exception
     */
    public static function  getDataTable(){
        $query = self::query();

        return DataTables::of($query)
            ->addColumn('name', function ($country) {
                return '<a href="'. route('staff.settings.countries.show',$country) .'" class="text-decoration-none">'.$country->name.'</a>';
            })
            ->addColumn('region', function ($country) {
                if ($country->region) {
                    return '<a href="' . route('staff.settings.regions.show', $country->region) . '" class="text-decoration-none">' . $country->region->name . '</a>';
                }
                return '';
            })
            ->filter(function ($query) {
                if (!empty(request('search')['value'])) {
                    $search = request('search')['value'];
                    $query->where(function ($query)  use($search){
                        $query->orWhere('countries.name', 'like', '%' . $search . '%');
                        $query->orWhere('countries.code', 'like', '%' . $search . '%');
                    });
                }

                if ( !empty(request('region')) ){
                    $query->where('region_id', request('region'));
                }
            })
            ->orderColumn('name', function ($query, $order) {
                $query->orderBy('name', $order);
            })
            ->rawColumns(['name', 'region'])
            ->make(true);
    }
}
