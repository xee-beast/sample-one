<?php

namespace App\Models;

use Exception;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsToMany;
use Illuminate\Http\JsonResponse;
use Yajra\DataTables\DataTables;

class TransportationFeeAddon extends Model
{
    use HasFactory;
    protected $guarded = [];

    /**
     * @return BelongsToMany
     */
    public function transportations(): BelongsToMany
    {
        return $this->belongsToMany(Transportation::class,'transportation_addon','transportation_fee_addon_id','transportation_id')->withPivot(['mandatory']);
    }

    /**
     * @return BelongsToMany
     */
    public function applications(): BelongsToMany
    {
        return $this->belongsToMany(Application::class,'application_transportation_addon','addon_id','application_id');
    }

    /**
     * Gives count of connected relations
     * @return bool
     */
    public function hasResources(){
        $transportCount = $this->transportations()->count();
        $applicationCount = $this->applications()->count();
        if($transportCount > 0 || $applicationCount > 0)
            return true;
        return false;
    }

    /**
     * @return JsonResponse
     * @throws Exception
     */
    public static function  getDataTable(): JsonResponse
    {
        $query = self::query();

        return DataTables::of($query)
            ->editColumn('name', function ($addon) {
                return '<a href="'. route('staff.settings.fees.transportation.fee-addons.show',$addon) .'" class="text-decoration-none">'.$addon->name.'</a>';
            })
            ->editColumn('enabled', function ($addon) {
                return $addon->enabled ? 'Active' : "Inactive";
            })
            ->editColumn('taxable', function ($addon) {
                return $addon->taxable ? 'Yes' : "No";
            })
            ->editColumn('fee', function ($addon) {
                return currencyFormatter($addon->fee);
            })
            ->filter(function ($query) {
                if (!empty(request('search')['value'])) {
                    $search = request('search')['value'];
                    $query->where(function ($query)  use($search){
                        $query->orWhere('name', 'like', '%' . $search . '%');
                        $query->orWhere('fee', 'like', '%' . $search . '%');
                    });
                }
            })
            ->rawColumns(['name'])
            ->make(true);
    }
}
