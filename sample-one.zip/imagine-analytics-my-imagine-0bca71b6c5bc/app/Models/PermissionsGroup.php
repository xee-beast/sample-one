<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;

class PermissionsGroup extends Model
{
    use HasFactory;

     /**
     * The accessors to append to the model's array form.
     *
     * @var array
     */
    protected $appends = ['key','parent_item'];
    /**
     * The attributes that aren't mass assignable.
     *
     * @var array
     */
    protected $guarded = [];


    public function parent(): BelongsTo
    {
        return $this->belongsTo(PermissionsGroup::class,'parent_id');
    }

    //each category might have multiple children
    public function children(): HasMany
    {
        return $this->hasMany(PermissionsGroup::class,'parent_id');
    }

    public function permissions(): HasMany
    {
        return $this->hasMany(Permission::class,'group_id');
    }

    /**
     * Returns id with group prefix to determin that the selected item is group in tree list.
     * @return String
     */
    public function getKeyAttribute(){
        return 'group_'.$this->id;
    }

    /**
     * Returns parent id with group prefix to set group under parent group.
     * @return String
     */
    public function getParentItemAttribute(){
        if($this->parent_id){
            return 'group_'.$this->parent_id;
        }
        return '';
    }

}
