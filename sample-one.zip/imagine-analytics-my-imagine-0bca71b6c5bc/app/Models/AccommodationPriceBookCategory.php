<?php

namespace App\Models;

use Exception;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Http\JsonResponse;
use Yajra\DataTables\DataTables;

class AccommodationPriceBookCategory extends Model
{
    use HasFactory;

    protected $guarded = [];

     /**
     * @return HasMany
     */
    public function priceBooks():HasMany {
        return $this->hasMany(AccommodationPriceBook::class,'price_book_category_id');
    }

    /**
     * Gives count of connected relations
     * @return bool
     */
    public function hasResources(){
        $pricebookCount = $this->priceBooks()->count();
        if($pricebookCount > 0)
            return true;
        return false;
    }

    /**
     * @return JsonResponse
     * @throws Exception
     */
    public static function  getDataTable(): JsonResponse
    {
        $query = self::query();

        return DataTables::of($query)
            ->editColumn('name', function ($priceBook) {
                return '<a href="'. route('staff.settings.fees.accommodation.pricebook-categories.show',$priceBook) .'" class="text-decoration-none">'.$priceBook->name.'</a>';
            })
            ->editColumn('enabled', function ($priceBook) {
                return $priceBook->enabled ? 'Active' : "Inactive";
            })
            ->filter(function ($query) {
                if (!empty(request('search')['value'])) {
                    $search = request('search')['value'];
                    $query->where(function ($query)  use($search){
                        $query->orWhere('name', 'like', '%' . $search . '%');
                        $query->orWhere('description', 'like', '%' . $search . '%');
                    });
                }
            })
            ->rawColumns(['name'])
            ->make(true);
    }
}
