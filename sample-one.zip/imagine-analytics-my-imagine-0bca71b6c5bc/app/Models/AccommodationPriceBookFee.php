<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class AccommodationPriceBookFee extends Model
{
    use HasFactory;

    protected $fillable = [
        'min',
        'max',
        'weekly_fee',
        'daily_fee',
        'price_book_id'
    ];

    /**
     * @return BelongsTo
     */
    public function priceBook(): BelongsTo
    {
        return $this->belongsTo(AccommodationPriceBook::class,'price_book_id');
    }
}
