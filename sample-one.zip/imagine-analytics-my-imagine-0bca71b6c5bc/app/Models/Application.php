<?php

namespace App\Models;

use Carbon\Carbon;
use Database\Factories\ApplicationFactory;
use Exception;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\BelongsToMany;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\Relations\HasOne;
use Illuminate\Http\JsonResponse;
use Yajra\DataTables\DataTables;

class Application extends Model
{
    use HasFactory;
    protected $guarded = [];

    /**
     * Check if the application is in draft status
     * @return bool
     */
    public function isStatusDraft(): bool{
        return $this->status == 'draft';
    }

    /**
     * Check if the application is in draft status
     * @return bool
     */
    public function isStatusExpired(): bool{
        return $this->status == 'expired';
    }


    /**
     * @return HasOne
     */
    public function detail(): HasOne
    {
        return $this->hasOne(ApplicationDetail::class);
    }

    /**
     * @return HasOne
     */
    public function payment(): HasOne
    {
        return $this->hasOne(ApplicationPayment::class);
    }

    /**
     * @return BelongsTo
     */
    public function createdBy(): BelongsTo
    {
        return $this->belongsTo(User::class,'created_by');
    }

    /**
     * @return BelongsTo
     */
    public function submittedBy(): BelongsTo
    {
        return $this->belongsTo(User::class,'submitted_by');
    }

    /**
     * @return BelongsTo
     */
    public function applicationOwner(): BelongsTo
    {
        return $this->belongsTo(User::class,'owner');
    }


    /**
     * @return BelongsToMany
     */
    public function programs(): BelongsToMany
    {
        return $this->belongsToMany(Program::class,'application_program','application_id','program_id')->withPivot(['faculty_id','packaged_program_id','start_date','end_date','length', 'default_amount','tax','amount','default_tax']);
    }

    /**
     * @return BelongsToMany
     */
    public function programServices(): BelongsToMany
    {
        return $this->belongsToMany(ProgramFeeService::class,'application_program_service','application_id','service_id')->withPivot(['faculty_id','program_id','program_start_date', 'mandatory', 'default_amount','tax','amount','default_tax']);
    }

    /**
     * @return BelongsToMany
     */
    public function accommodations(): BelongsToMany
    {
        return $this->belongsToMany(Accommodation::class,'application_accommodation','application_id','accommodation_id')->withPivot(['faculty_id','start_date','end_date','weeks','days','default_amount','tax','amount','default_tax']);
    }


    /**
     * @return BelongsToMany
     */
    public function accommodationServices(): BelongsToMany
    {
        return $this->belongsToMany(AccommodationFeeService::class,'application_accommodation_service','application_id','service_id')->withPivot(['faculty_id','accommodation_id','accommodation_start_date','default_amount','amount','tax','mandatory','default_tax']);
    }


    /**
     * @return BelongsToMany
     */
    public function accommodationAddons(): BelongsToMany
    {
        return $this->belongsToMany(AccommodationFeeAddon::class,'application_accommodation_addon','application_id','addon_id')->withPivot(['faculty_id','accommodation_id','accommodation_start_date','default_amount','amount','tax','mandatory','default_tax']);
    }

    /**
     * @return BelongsToMany
     */
    public function transportations(): BelongsToMany
    {
        return $this->belongsToMany(Transportation::class,'application_transportation','application_id','transportation_id')->withPivot(['faculty_id','default_amount','amount','tax','default_tax']);
    }

    /**
     * @return BelongsToMany
     */
    public function transportationServices(): BelongsToMany
    {
        return $this->belongsToMany(TransportationFeeService::class,'application_transportation_service','application_id','service_id')->withPivot(['faculty_id','transportation_id', 'mandatory','default_amount','amount','tax','default_tax']);
    }


    public function documents():HasMany
    {
        return $this->hasMany(ApplicationDocument::class);
    }
    /**
     * @return BelongsToMany
     */
    public function transportationAddons(): BelongsToMany
    {
        return $this->belongsToMany(TransportationFeeAddon::class,'application_transportation_addon','application_id','addon_id')->withPivot(['faculty_id','transportation_id', 'mandatory','default_amount','amount','tax','default_tax']);
    }

    /**
     * @return BelongsToMany
     */
    public function insurances(): BelongsToMany
    {
        return $this->belongsToMany(Insurance::class, 'application_insurance', 'application_id', 'insurance_id')->withPivot(['faculty_id','start_date','end_date','duration','default_amount','tax','amount','default_tax']);
    }

     /**
     * @return HasMany
     */
    public function activities(): HasMany
    {
        return $this->hasMany(ApplicationActivity::class);
    }

    /**
     * @return JsonResponse
     * @throws Exception
     */
    public static function  getDataTable(): JsonResponse
    {
        $query = self::with('detail', 'applicationOwner')->select('applications.*');
        $status = config('constants.application_form.status');
        $userType = auth()->user()->user_type;

        if (auth()->user()->isStaff() and !auth()->user()->can('view-applications') ){
            return response()->json([]);
        }

        return DataTables::of($query)
            ->editColumn('id', function ($application) {
                return '<a href="'. route('applications.show',$application) .'" class="text-decoration-none">'.$application->id.'</a>';
            })
            ->addColumn('application_id', function ($application) {
                return $application->id;
            })
            ->editColumn('status', function ($application) use ($status) {
                return $status[$application->status]['label'];
            })
            ->editColumn('student', function ($application) use ($status) {
                return $application->detail->full_name;
            })
            ->editColumn('owner', function ($application) use ($status) {
                return $application->applicationOwner
                    ? '<a href="'. route('staff.users.show',$application->applicationOwner) .'" class="text-decoration-none">'.$application->applicationOwner->full_name.'</a>'
                    : null;
            })
            ->editColumn('user_type', function ($application) use ($status) {
                return $application->applicationOwner ? ucfirst($application->applicationOwner->user_type) : null;
            })
            ->editColumn('agent_name', function ($application) use ($status) {
                return $application->applicationOwner->isAgent() && isset($application->applicationOwner->agent)
                    ?  '<a href="'. route('staff.agents.show',$application->applicationOwner->agent->id) .'" class="text-decoration-none">' . $application->applicationOwner->agent->name . '</a>'
                    : '';
            })
            ->editColumn('submitted_on', function ($application) use ($status) {
                return $application->submitted_on ? Carbon::parse($application->submitted_on)->format("d/m/Y") : null;
            })
            ->filter(function ($query) use ($userType) {
                if (!empty(request('search')['value'])) {
                    $search = request('search')['value'];
                    $query->where(function ($query)  use($search){
                        $query
                            ->orWhere('applications.id', 'like', '%' . $search . '%')
                            ->orWhere('student_number','like',"%$search%");
                        $query->orWhereHas('applicationOwner', function ($query) use ($search) {
                            $query->where('users.first_name', 'like', '%' . $search . '%');
                            $query->orWhere('users.last_name', 'like', '%' . $search . '%');
                        });
                        $query->orWhereHas('detail', function ($query) use ($search) {
                            $query->whereRaw("concat(first_name,' ',last_name) like '%$search%'");
                        });
                    });
                }

                if ( request()->get('status') != null){
                    $query->whereIn('status', request('status'));
                }
                if ( request()->get('date') != null){
                    $query->whereBetween('submitted_on', [request()->get('date')[0], request()->get('date')[1]]);
                }
                if ( request()->get('user_type') != null ){
                    $query->whereHas('applicationOwner', function ($query2) {
                        $query2->whereIn('users.user_type', request()->get('user_type'));
                    });
                }

                if ( !auth()->user()->isStaff() ){
                    $query->where('owner', auth()->id());
                }

            })
            ->orderColumn('id', function ($query, $order) {
                $query->orderBy('id', $order);
            })
            ->rawColumns(['id', 'owner', 'agent_name'])
            ->make(true);
    }
}
