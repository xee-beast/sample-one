<?php

namespace App\Models;

use Exception;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\BelongsToMany;
use Illuminate\Http\JsonResponse;
use Yajra\DataTables\DataTables;

class Transportation extends Model
{
    use HasFactory;
    protected $guarded= [];

    /**
     * @return BelongsTo
     */
    public function originLocation(): BelongsTo
    {
        return $this->belongsTo(Location::class,'origin');
    }

    /**
     * @return BelongsTo
     */
    public function destinationLocation(): BelongsTo
    {
        return $this->belongsTo(Location::class,'destination');
    }

    /**
     * @return BelongsToMany
     */
    public function faculties(): BelongsToMany
    {
        return $this->belongsToMany(Faculty::class, 'faculty_transportation', 'transportation_id', 'faculty_id')->withPivot(['ebecas_product_id']);
    }


    public function services(): BelongsToMany{
        return $this->belongsToMany(TransportationFeeService::class, 'transportation_service', 'transportation_id', 'transportation_fee_service_id')->withPivot('mandatory');
    }


    public function addons(): BelongsToMany{
        return $this->belongsToMany(TransportationFeeAddon::class, 'transportation_addon', 'transportation_id', 'transportation_fee_addon_id')->withPivot('mandatory');
    }

    public function optionalServices(){
        return $this->services()->where('enabled',1)->wherePivot('mandatory',0);
    }

    public function mandatoryServices(){
        return $this->services()->where('enabled',1)->wherePivot('mandatory',1);
    }

    public function mandatoryAddons(){
        return $this->addons()->where('enabled',1)->wherePivot('mandatory',1);
    }

    public function optionalAddons(){
        return $this->addons()->where('enabled',1)->wherePivot('mandatory',0);
    }

    /**
     * @return BelongsToMany
     */
    public function applications(): BelongsToMany
    {
        return $this->belongsToMany(Application::class,'application_transportation','transportation_id','application_id')->withPivot(['faculty_id']);
    }

    /**
     * Gives count of connected relations
     * @return bool
     */
    public function hasResources(){
        $facultyCount = $this->faculties()->count();
        $applicationCount = $this->applications()->count();
        $servicesCount = $this->services()->count();
        $addonsCount = $this->addons()->count();
        if($facultyCount > 0 || $applicationCount > 0 || $servicesCount > 0 || $addonsCount > 0)
            return true;
        return false;
    }

    /**
     * @return JsonResponse
     * @throws Exception
     */
    public static function  getDataTable(): JsonResponse
    {
        $query = self::query();

        return DataTables::of($query)
            ->editColumn('name', function ($transport) {
                return '<a href="'. route('staff.settings.products.transportation.show',$transport) .'" class="text-decoration-none">'.$transport->name.'</a>';
            })
            ->editColumn('origin', function ($transport) {
                return '<a href="'. route('staff.settings.locations.show',$transport->originLocation->id) .'" class="text-decoration-none">'.$transport->originLocation->name.'</a>';
            })
            ->editColumn('destination', function ($transport) {
                return '<a href="'. route('staff.settings.locations.show',$transport->destinationLocation->id) .'" class="text-decoration-none">'.$transport->destinationLocation->name.'</a>';
            })
            ->editColumn('enabled', function ($transport) {
                return $transport->enabled ? 'Active' : "Inactive";
            })
            ->editColumn('return', function ($transport) {
                return $transport->return ? 'Yes' : "No";
            })
            ->editColumn('taxable', function ($transport) {
                return $transport->taxable ? 'Yes' : "No";
            })
            ->filter(function ($query) {
                if (!empty(request('search')['value'])) {
                    $search = request('search')['value'];
                    $query->where(function ($query)  use($search){
                        $query->orWhere('name', 'like', '%' . $search . '%');
                    });
                }

                if ( request()->get('enabled') != null){
                    $query->where('enabled',(int)request('enabled'));
                }
            })
            ->orderColumn('name', function ($query, $order) {
                $query->orderBy('name', $order);
            })
            ->rawColumns(['name', 'origin', 'destination'])
            ->make(true);
    }
}
