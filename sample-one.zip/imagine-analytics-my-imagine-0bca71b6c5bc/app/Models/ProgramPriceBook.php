<?php

namespace App\Models;

use Carbon\Carbon;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Http\JsonResponse;
use Yajra\DataTables\DataTables;

class ProgramPriceBook extends Model
{
    use HasFactory;

    protected $guarded = [];

    /**
     * @return BelongsTo
     */
    public function category(): BelongsTo
    {
        return $this->belongsTo(ProgramPriceBookCategory::class,'program_price_book_category_id');
    }

    /**
     * @return HasMany
     */
    public function programs(): HasMany
    {
        return $this->hasMany(Program::class,'program_price_book_id');
    }

    /**
     * @return HasMany
     */
    public function rates(): HasMany
    {
        return $this->hasMany(ProgramPriceBookFee::class);
    }

    /**
     * @return void
     */
    public function replicateRow(): void
    {
        $cloned = $this->replicate();
        $cloned->name = $cloned->name . "-copy";
        $cloned->created_at = Carbon::now();
        $cloned->updated_at = Carbon::now();
        $cloned->push();

        foreach($this->rates as $rate)
        {
            $arr = $rate->toArray();
            unset($arr['id']);
            $cloned->rates()->create($arr);
        }

        $cloned->save();
    }

    /**
     * Gives count of connected relations
     * @return bool
     */
    public function hasResources(){
        $programsCount = $this->programs()->count();
        if($programsCount > 0)
            return true;
        return false;
    }


    public static function  getDataTable(): JsonResponse
    {
        $query = self::query();

        return DataTables::of($query)
            ->editColumn('name', function ($priceBook) {
                return '<a href="'. route('staff.settings.fees.programs.pricebooks.show',$priceBook) .'" class="text-decoration-none">'.$priceBook->name.'</a>';
            })
            ->editColumn('category', function ($priceBook) {
                return '<a href="'. route('staff.settings.fees.programs.pricebook-categories.show',$priceBook) .'" class="text-decoration-none">'.$priceBook->category->name.'</a>';
            })
            ->editColumn('enabled', function ($priceBook) {
                return $priceBook->enabled ? 'Active' : "Inactive";
            })
            ->editColumn('expiry_date', function ($priceBook) {
                return $priceBook->expiry_date ? Carbon::parse($priceBook->expiry_date)->format('d/m/Y') : "";
            })
            ->editColumn('expired', function ($priceBook) {
                return $priceBook->expired ? 'Yes' : "No";
            })
            ->filter(function ($query) {
                if (!empty(request('search')['value'])) {
                    $search = request('search')['value'];
                    $query->where(function ($query)  use($search){
                        $query->orWhere('program_price_books.name', 'like', '%' . $search . '%');
                        $query->orWhere('program_price_books.description', 'like', '%' . $search . '%');
                        $query->orWhereHas('category', function($query) use ($search) {
                            $query->where('program_price_book_categories.name', 'like', '%' . $search . '%');
                        });
                    });
                }

                if ( request()->get('category') != null){
                    $query->where('program_price_book_category_id', (int)request('category'));
                }

                if ( request()->get('enabled') != null){
                    $query->where('enabled',(int)request('enabled'));
                }
                if ( request()->get('expired') != null){
                    $query->where('expired',(int)request('expired'));
                }
            })
            ->orderColumn('category', function ($query, $order) {
                $query->orderBy('name', $order);
            })
            ->rawColumns(['name', 'category'])
            ->make(true);
    }
}
