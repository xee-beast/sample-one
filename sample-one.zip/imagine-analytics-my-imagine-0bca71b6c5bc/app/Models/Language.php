<?php

namespace App\Models;

use Exception;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Http\JsonResponse;
use Yajra\DataTables\DataTables;

class Language extends Model
{
    use HasFactory;
    protected $guarded = [];

    /**
     * @return HasMany
     */
    public function applications(): HasMany
    {
        return $this->hasMany(ApplicationDetail::class,'language');
    }

    /**
     * Gives count of connected relations
     * @return bool
     */
    public function hasResources(){
        $applicationCount = $this->applications()->count();
        if($applicationCount > 0)
            return true;
        return false;
    }


    /**
     * @return JsonResponse
     * @throws Exception
     */
    public static function  getDataTable(): JsonResponse
    {
        $query = self::query();

        $query = $query->orderBy("name", 'ASC');
        return DataTables::of($query)
            ->addColumn('name', function ($language) {
                return '<a href="'. route('staff.settings.languages.show',$language) .'" class="text-decoration-none">'.$language->name.'</a>';
            })
            ->editColumn('enabled', function ($language) {
                return $language->enabled ? 'Active' : "Inactive";
            })
            ->filter(function ($query) {
                if (!empty(request('search')['value'])) {
                    $search = request('search')['value'];
                    $query->where(function ($query)  use($search){
                        $query->orWhere('name', 'like', '%' . $search . '%');
                    });
                }
                if ( request()->get('enabled') != null){
                    $query->where('enabled',(int)request('enabled'));
                }
            })
            ->rawColumns(['name'])
            ->make(true);
    }
}
