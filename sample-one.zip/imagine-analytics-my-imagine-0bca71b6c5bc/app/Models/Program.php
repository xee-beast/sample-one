<?php

namespace App\Models;

use Carbon\Carbon;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\BelongsToMany;
use Illuminate\Http\JsonResponse;
use Yajra\DataTables\DataTables;
class Program extends Model
{
    use HasFactory;

    protected $fillable = [
        'name',
        'description',
        'enabled',
        'is_language',
        'program_price_book_id',
        'length_restriction_enabled',
        'min_length',
        'max_length',
        'age_restriction_enabled',
        'min_age',
        'max_age',
        'visa_restriction_enabled'

    ];

    public static function getDataTable(){
        $query = self::query();

        return DataTables::of($query)
            ->editColumn('name', function ($program) {
                return '<a href="'. route('staff.settings.products.programs.show',$program) .'" class="text-decoration-none">'.$program->name.'</a>';
            })
            ->addColumn('price_book', function ($program) {
                $priceBook = $program->priceBook ? $program->priceBook->name : '';
                 if($priceBook){
                     return '<a href="'. route('staff.settings.fees.programs.pricebooks.show',$program->priceBook) .'" class="text-decoration-none">'.$priceBook.'</a>';
                 }
                 return '';
            })
            ->addColumn('is_language', function ($program) {
                return $program->is_language ? 'Language' : 'VET';
            })
            ->addColumn('calendar', function ($program) {
                $calendar = $program->calendar ? $program->calendar->name : '';
                 if($calendar){
                     return '<a href="'. route('staff.settings.dates.calendars.show',$program->calendar) .'" class="text-decoration-none">'.$calendar.'</a>';
                 }
                 return '';
            })
            ->editColumn('enabled', function ($program) {
                return $program->enabled ? 'Active' : "Inactive";
            })

            ->filter(function ($query) {
                if (!empty(request('search')['value'])) {
                    $search = request('search')['value'];
                    $query->where(function ($query)  use($search){
                        $query->orWhere('programs.name', 'like', '%' . $search . '%');
                        $query->orWhere('programs.description', 'like', '%' . $search . '%');
                        $query->orWhereHas('priceBook', function($query) use ($search) {
                            $query->where('program_price_books.name', 'like', '%' . $search . '%');
                        });
                    });
                }

                if ( request()->filled('enabled')){
                    $query->where('enabled',(int)request('enabled'));
                }
            })
            ->orderColumn('name', function ($query, $order) {
                $query->orderBy('name', $order);
            })
            ->rawColumns(['name','price_book','calendar'])
            ->make(true);
    }

    public function priceBook():BelongsTo {
        return $this->belongsTo(ProgramPriceBook::class,'program_price_book_id');
    }

    public function services(): BelongsToMany{
        return $this->belongsToMany(ProgramFeeService::class, 'program_service', 'program_id', 'program_fee_service_id')->withPivot('mandatory');
    }

    public function visas() : BelongsToMany{
        return $this->belongsToMany(Visa::class, 'program_visa', 'program_id', 'visa_id');
    }

     /**
     * @return BelongsToMany
     */
    public function applications() : BelongsToMany{
        return $this->belongsToMany(Application::class, 'application_program', 'program_id', 'application_id');
    }

    public function optionalServices(){
        return $this->services()->where('enabled',1)->wherePivot('mandatory',0);
    }

    public function mandatoryServices(){
        return $this->services()->where('enabled',1)->wherePivot('mandatory',1);
    }

    /**
     * @return BelongsToMany
     */
    public function faculties(): BelongsToMany{
        return $this->belongsToMany(Faculty::class, 'faculty_program', 'program_id','faculty_id')->withPivot(['calendar_id','ebecas_product_id']);
    }

    /**
     * @return BelongsToMany
     */
    public function calendars(): BelongsToMany{
        return $this->belongsToMany(Calendar::class, 'faculty_program', 'program_id','calendar_id')->withPivot(['faculty_id','ebecas_product_id']);

    }

    /**
     * Gives count of connected relations
     * @return bool
     */
    public function hasResources(){
        $applicationCount = $this->applications()->count();
        $facultyCount = $this->faculties()->count();
        if($facultyCount > 0 || $applicationCount > 0)
            return true;
        return false;
    }
}
