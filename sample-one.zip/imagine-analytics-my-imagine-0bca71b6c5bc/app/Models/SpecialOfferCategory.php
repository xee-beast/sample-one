<?php

namespace App\Models;

use Exception;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Http\JsonResponse;
use Yajra\DataTables\DataTables;

class SpecialOfferCategory extends Model
{
    use HasFactory;

    protected $guarded = [];

    /**
     * @return JsonResponse
     * @throws Exception
     */
    public static function  getDataTable(): JsonResponse
    {
        $query = self::query();

        return DataTables::of($query)
            ->editColumn('name', function ($category) {
                return '<a href="'. route('staff.settings.special-offer-categories.show',$category) .'" class="text-decoration-none">'.$category->name.'</a>';
            })
            ->editColumn('enabled', function ($category) {
                return $category->enabled ? 'Active' : "Inactive";
            })
            ->filter(function ($query) {
                if (!empty(request('search')['value'])) {
                    $search = request('search')['value'];
                    $query->where(function ($query)  use($search){
                        $query->orWhere('name', 'like', '%' . $search . '%');
                        $query->orWhere('description', 'like', '%' . $search . '%');
                    });
                }
            })
            ->rawColumns(['name'])
            ->make(true);
    }
}
