<?php

namespace App\Models;

use Exception;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Http\JsonResponse;
use Yajra\DataTables\DataTables;

class Agent extends Model
{
    use HasFactory;

    protected $guarded = [];

    /**
     * @return JsonResponse
     * @throws Exception
     */
    public static function  getDataTable(): JsonResponse
    {
        $query = self::query()->orderBy('name', 'asc');

        return DataTables::of($query)
            ->addColumn('name', function ($agent) {
                return '<a href="'. route('staff.agents.show',$agent) .'" class="text-decoration-none">'.$agent->name.'</a>';
            })
            ->filter(function ($query) {
                if (!empty(request('search')['value'])) {
                    $search = request('search')['value'];
                    $query->where(function ($query)  use($search){
                        $query->orWhere('agents.name', 'like', '%' . $search . '%');
                        $query->orWhere('agents.ebecas_id', 'like', '%' . $search . '%');
                    });
                }
            })
            ->rawColumns(['name'])
            ->make(true);
    }


    public function users() : HasMany
    {
        return $this->hasMany(User::class);
    }
}
