<?php

namespace App\Models;

use Exception;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\BelongsToMany;
use Illuminate\Http\JsonResponse;
use Yajra\DataTables\DataTables;

class TransportationFeeService extends Model
{
    use HasFactory;
    protected $guarded = [];


     /**
     * @return BelongsToMany
     */
    public function transportations(): BelongsToMany
    {
        return $this->belongsToMany(Transportation::class,'transportation_service','transportation_fee_service_id','transportation_id')->withPivot(['mandatory']);
    }

    /**
     * @return BelongsToMany
     */
    public function applications(): BelongsToMany
    {
        return $this->belongsToMany(Application::class,'application_transportation_service','service_id','application_id');
    }

     /**
     * Gives count of connected relations
     * @return bool
     */
    public function hasResources(){
        $transportCount = $this->transportations()->count();
        $applicationCount = $this->applications()->count();
        if($transportCount > 0 || $applicationCount > 0)
            return true;
        return false;
    }

    /**
     * @return JsonResponse
     * @throws Exception
     */
    public static function  getDataTable(): JsonResponse
    {
        $query = self::query();

        return DataTables::of($query)
            ->editColumn('name', function ($transport) {
                return '<a href="'. route('staff.settings.fees.transportation.fee-services.show',$transport) .'" class="text-decoration-none">'.$transport->name.'</a>';
            })
            ->editColumn('enabled', function ($transport) {
                return $transport->enabled ? 'Active' : "Inactive";
            })
            ->editColumn('taxable', function ($transport) {
                return $transport->taxable ? 'Yes' : "No";
            })
            ->filter(function ($query) {
                if (!empty(request('search')['value'])) {
                    $search = request('search')['value'];
                    $query->where(function ($query)  use($search){
                        $query->orWhere('name', 'like', '%' . $search . '%');
                    });
                }

                if ( request()->get('enabled') != null){
                    $query->where('enabled',(int)request('enabled'));
                }
            })
            ->orderColumn('name', function ($query, $order) {
                $query->orderBy('name', $order);
            })
            ->rawColumns(['name'])
            ->make(true);
    }
}
