<?php

namespace App\Models;

use Exception;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\BelongsToMany;
use Illuminate\Http\JsonResponse;
use Yajra\DataTables\DataTables;

class Faculty extends Model
{
    use HasFactory;
    protected $guarded = [];

    /**
     * @return BelongsTo
     */
    public function location(): BelongsTo
    {
        return $this->belongsTo(Location::class,'location_id');
    }

    /**
     * @return BelongsToMany
     */
    public function programs(): BelongsToMany{
        return $this->belongsToMany(Program::class, 'faculty_program', 'faculty_id', 'program_id')->withPivot(['calendar_id','ebecas_product_id']);
    }

    /**
     * @return BelongsToMany
     */
    public function calendars(): BelongsToMany{
        return $this->belongsToMany(Calendar::class, 'faculty_program', 'faculty_id','calendar_id')->withPivot(['program_id','ebecas_product_id']);
    }

    /**
     * @return BelongsToMany
     */
    public function programServices(): BelongsToMany{
        return $this->belongsToMany(ProgramFeeService::class, 'faculty_program_service', 'faculty_id', 'program_fee_service_id')->withPivot(['fee','ebecas_product_id']);
    }

    /**
     * @return BelongsToMany
     */
    public function accommodations(): BelongsToMany{
        return $this->belongsToMany(Accommodation::class, 'faculty_accommodation', 'faculty_id', 'accommodation_id')->withPivot(['ebecas_product_id']);
    }

    /**
     * @return BelongsToMany
     */
    public function accommodationServices(): BelongsToMany{
        return $this->belongsToMany(AccommodationFeeService::class, 'faculty_accommodation_service', 'faculty_id', 'fee_service_id')->withPivot(['ebecas_product_id']);
    }

    /**
     * @return BelongsToMany
     */
    public function accommodationAddons(): BelongsToMany{
        return $this->belongsToMany(AccommodationFeeAddon::class, 'faculty_accommodation_addon', 'faculty_id', 'addon_id')->withPivot(['ebecas_product_id']);
    }

    /**
     * @return BelongsToMany
     */
    public function transportations(): BelongsToMany
    {
        return $this->belongsToMany(Transportation::class, 'faculty_transportation', 'faculty_id', 'transportation_id')->withPivot(['ebecas_product_id']);
    }

    /**
     * @return BelongsToMany
     */
    public function transportationServices(): BelongsToMany{
        return $this->belongsToMany(TransportationFeeService::class, 'faculty_transportation_service', 'faculty_id', 'fee_service_id')->withPivot(['fee','ebecas_product_id']);
    }

    /**
     * @return BelongsToMany
     */
    public function transportationAddons(): BelongsToMany
    {
        return $this->belongsToMany(TransportationFeeAddon::class, 'faculty_transportation_addon', 'faculty_id', 'addon_id')->withPivot(['fee', 'ebecas_product_id']);
    }

    /**
     * @return BelongsToMany
     */
    public function insurances(): BelongsToMany{
        return $this->belongsToMany(InsuranceFee::class, 'faculty_insurance', 'faculty_id', 'insurance_fee_id')->withPivot(['ebecas_product_id', 'insurance_id']);
    }

    /**
     * @return BelongsToMany
     */
    public function paymentMethods(): BelongsToMany{
        return $this->belongsToMany(PaymentMethod::class, 'faculty_payment_method', 'faculty_id', 'payment_method_id')->withPivot(['ebecas_product_id']);
    }

    /**
     * @return BelongsToMany
     */
    public function applicationPrograms(): BelongsToMany{
        return $this->belongsToMany(Program::class, 'application_program', 'faculty_id', 'program_id');
    }

    /**
     * @return BelongsToMany
     */
    public function applicationProgramServices(): BelongsToMany{
        return $this->belongsToMany(ProgramFeeService::class, 'application_program_service', 'faculty_id', 'service_id');
    }

    /**
     * @return BelongsToMany
     */
    public function applicationAccommodations(): BelongsToMany{
        return $this->belongsToMany(Accommodation::class, 'application_accommodation', 'faculty_id', 'accommodation_id');
    }

    /**
     * @return BelongsToMany
     */
    public function applicationAccommodationServices(): BelongsToMany{
        return $this->belongsToMany(AccommodationFeeService::class, 'application_accommodation_service', 'faculty_id', 'service_id');
    }

    /**
     * @return BelongsToMany
     */
    public function applicationAccommodationAddons(): BelongsToMany{
        return $this->belongsToMany(AccommodationFeeAddon::class, 'application_accommodation_addon', 'faculty_id', 'addon_id');
    }

    /**
     * @return BelongsToMany
     */
    public function applicationPayments(): BelongsToMany{
        return $this->belongsToMany(PaymentMethod::class, 'application_payments', 'faculty_id', 'payment_method_id');
    }

    /**
     * @return BelongsToMany
     */
    public function applicationInsurances(): BelongsToMany{
        return $this->belongsToMany(Insurance::class, 'application_insurance', 'faculty_id', 'insurance_id');
    }

    /**
     * @return BelongsToMany
     */
    public function applicationTransports(): BelongsToMany{
        return $this->belongsToMany(Transportation::class, 'application_transportation', 'faculty_id', 'transportation_id');
    }

    /**
     * @return BelongsToMany
     */
    public function applicationTransportServices(): BelongsToMany{
        return $this->belongsToMany(TransportationFeeService::class, 'application_transportation_service', 'faculty_id', 'service_id');
    }

    /**
     * @return BelongsToMany
     */
    public function applicationTransportAddons(): BelongsToMany{
        return $this->belongsToMany(TransportationFeeAddon::class, 'application_transportation_addon', 'faculty_id', 'addon_id');
    }

    /**
     * Gives count of connected relations
     * @return bool
     */
    public function hasResources(){
        $applicationProgramCount = $this->applicationPrograms()->count();
        $applicationProgramServiceCount = $this->applicationProgramServices()->count();
        $applicationAccommodationCount = $this->applicationAccommodations()->count();
        $applicationAccommodationServiceCount = $this->applicationAccommodationServices()->count();
        $applicationAccommodationAddonCount = $this->applicationAccommodationAddons()->count();
        $applicationInsuranceCount = $this->applicationInsurances()->count();
        $applicationTransportCount = $this->applicationTransports()->count();
        $applicationTransportServiceCount = $this->applicationTransportServices()->count();
        $applicationTransportAddonCount = $this->applicationTransportAddons()->count();
        $applicationPaymentCount = $this->applicationPayments()->count();

        if($applicationProgramCount > 0 || $applicationProgramServiceCount  > 0 || $applicationTransportAddonCount  > 0 || $applicationAccommodationCount  > 0 || $applicationAccommodationServiceCount  > 0 || $applicationAccommodationAddonCount  > 0 || $applicationInsuranceCount  > 0 || $applicationTransportCount  > 0 || $applicationTransportServiceCount  > 0 || $applicationPaymentCount  > 0)
            return true;
        return false;
    }

    /**
     * @return JsonResponse
     * @throws Exception
     */
    public static function  getDataTable(): JsonResponse
    {
        $query = self::query();

        return DataTables::of($query)
            ->editColumn('name', function ($faculty) {
                return '<a href="'. route('staff.settings.faculties.details',$faculty) .'" class="text-decoration-none">'.$faculty->name.'</a>';
            })
            ->editColumn('location', function ($faculty) {
                return '<a href="'. route('staff.settings.locations.show',$faculty->location->id) .'" class="text-decoration-none">'.$faculty->location->name.'</a>';
            })
            ->editColumn('enabled', function ($faculty) {
                return $faculty->enabled ? 'Active' : "Inactive";
            })
            ->filter(function ($query) {
                if (!empty(request('search')['value'])) {
                    $search = request('search')['value'];
                    $query->where(function ($query)  use($search){
                        $query->orWhere('name', 'like', '%' . $search . '%');
                        $query->orWhere('description', 'like', '%' . $search . '%');
                    });
                    $query->orWhereHas('location', function($query) use ($search) {
                        $query->where('locations.name', 'like', '%' . $search . '%');
                    });
                }

                if ( request()->get('enabled') != null){
                    $query->where('enabled',(int)request('enabled'));
                }
                if ( request()->get('location') != null){
                    $query->where('location_id',(int)request('location'));
                }
            })
            ->orderColumn('name', function ($query, $order) {
                $query->orderBy('name', $order);
            })
            ->rawColumns(['name', 'location'])
            ->make(true);
    }
}
