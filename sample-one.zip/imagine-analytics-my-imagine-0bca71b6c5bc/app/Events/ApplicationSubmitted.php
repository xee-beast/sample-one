<?php

namespace App\Events;

use App\Models\Application;
use Illuminate\Broadcasting\InteractsWithSockets;
use Illuminate\Foundation\Events\Dispatchable;
use Illuminate\Queue\SerializesModels;

class ApplicationSubmitted
{
    use Dispatchable, InteractsWithSockets, SerializesModels;

    public Application $application;
    public string $oldStatus;

    /**
     * Create a new event instance.
     *
     * @return void
     */
    public function __construct(Application $application, $oldStatus)
    {
        $this->oldStatus = $oldStatus;
        $this->application = $application;
    }
}
