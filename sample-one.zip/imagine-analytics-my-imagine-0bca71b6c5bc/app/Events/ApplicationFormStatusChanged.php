<?php

namespace App\Events;

use App\Models\Application;
use Illuminate\Broadcasting\InteractsWithSockets;
use Illuminate\Foundation\Events\Dispatchable;
use Illuminate\Queue\SerializesModels;

class ApplicationFormStatusChanged
{
    use Dispatchable, InteractsWithSockets, SerializesModels;

    public array $eventData = [];

    /**
     * Create a new event instance.
     *
     * @return void
     */
    public function __construct(Application $application, $oldStatus, $newStatus, $user)
    {
        $this->eventData = [
            'application' => $application,
            'oldStatus' => $oldStatus,
            'newStatus' => $newStatus,
            'user' => $user,
        ];
    }
}
