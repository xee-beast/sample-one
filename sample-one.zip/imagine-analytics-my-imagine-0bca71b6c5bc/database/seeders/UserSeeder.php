<?php

namespace Database\Seeders;

use App\Models\Country;
use App\Models\User;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Str;

class UserSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $user = User::factory()->create([
            'id'=>1,
            'first_name'=>'Imagine',
            'last_name'=>'Bot',
            'email'=>'notifications@myimagine.com.au',
            'password'=> Hash::make(Str::random(15)),
            'user_type'=>config('constants.user_types.staff'),
            'country_id'=> Country::where('code','AUS')->first()->id
        ]);
        $user = User::factory()->create([
            'id'=>2,
            'first_name'=>'Trevor',
            'last_name'=>'Lim',
            'email'=>'tlim@imagineeducation.com.au',
            'password'=> Hash::make(Str::random(15)),
            'user_type'=>config('constants.user_types.staff'),
            'country_id'=> Country::where('code','AUS')->first()->id
        ]);
        //Assign superadmin role to first user
        $user->assignRole(config('constants.system_roles.superadmin'));

        $user = User::factory()->create([
            'id'=>3,
            'first_name'=>'Santiago',
            'last_name'=>'Ibarra',
            'email'=>'santiago@dwiise.au',
            'password'=> Hash::make(Str::random(15)),
            'user_type'=>config('constants.user_types.staff'),
            'country_id'=> Country::where('code','AUS')->first()->id
            ]);
        //Assign superadmin role to first user
        $user->assignRole(config('constants.system_roles.superadmin'));

        User::factory()->create([
            'id'=>4,
            'first_name'=>'101',
            'last_name'=>'Marketing',
            'email'=>'info@101-marketing.com.au',
            'password'=> Hash::make(Str::random(15)),
            'user_type'=>config('constants.user_types.staff'),
            'country_id'=> Country::where('code','AUS')->first()->id
        ]);
        User::factory()->create([
            'id'=>5,
            'first_name'=>'Imagine',
            'last_name'=>'Admissions',
            'email'=>'admissions@imagineeducation.com.au',
            'password'=> Hash::make(Str::random(15)),
            'user_type'=>config('constants.user_types.staff'),
            'country_id'=> Country::where('code','AUS')->first()->id
        ]);

        $user = User::factory()->create([
            'first_name'=>'Trevor',
            'last_name'=>'Lim',
            'email'=>'trevor@dwiise.au',
            'password'=> Hash::make(Str::random(15)),
            'user_type'=>config('constants.user_types.staff'),
            'country_id'=> Country::where('code','AUS')->first()->id
        ]);
        //Assign super-admin role to first user
        $user->assignRole(config('constants.system_roles.superadmin'));

        $user = User::factory()->create([
            'first_name'=>'Kara',
            'last_name'=>'Richardson',
            'email'=>'krichardson@imagineeducation.com.au',
            'password'=> Hash::make(Str::random(15)),
            'user_type'=>config('constants.user_types.staff'),
            'country_id'=> Country::where('code','AUS')->first()->id
        ]);
        //Assign super-admin role to first user
        $user->assignRole(config('constants.system_roles.superadmin'));






    }
}
