<?php

namespace Database\Seeders;

use App\Models\AccommodationFeeAddon;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class AccommodationServicesSeeder extends Seeder
{
    public function run()
    {
        $data = array(
            array('accommodation_id'=>1,	'accommodation_fee_service_id'=>6,	'mandatory'=>TRUE),
            array('accommodation_id'=>2,	'accommodation_fee_service_id'=>6,	'mandatory'=>TRUE),
            array('accommodation_id'=>3,	'accommodation_fee_service_id'=>6,	'mandatory'=>TRUE),
            array('accommodation_id'=>4,	'accommodation_fee_service_id'=>6,	'mandatory'=>TRUE),
            array('accommodation_id'=>5,	'accommodation_fee_service_id'=>7,	'mandatory'=>TRUE),
            array('accommodation_id'=>6,	'accommodation_fee_service_id'=>7,	'mandatory'=>TRUE),
            array('accommodation_id'=>7,	'accommodation_fee_service_id'=>7,	'mandatory'=>TRUE),
            array('accommodation_id'=>8,	'accommodation_fee_service_id'=>7,	'mandatory'=>TRUE),
            array('accommodation_id'=>9,	'accommodation_fee_service_id'=>1,	'mandatory'=>TRUE),
            array('accommodation_id'=>9,	'accommodation_fee_service_id'=>6,	'mandatory'=>TRUE),
            array('accommodation_id'=>10,	'accommodation_fee_service_id'=>1,	'mandatory'=>TRUE),
            array('accommodation_id'=>10,	'accommodation_fee_service_id'=>6,	'mandatory'=>TRUE),
            array('accommodation_id'=>11,	'accommodation_fee_service_id'=>2,	'mandatory'=>TRUE),
            array('accommodation_id'=>12,	'accommodation_fee_service_id'=>3,	'mandatory'=>TRUE),
            array('accommodation_id'=>13,	'accommodation_fee_service_id'=>4,	'mandatory'=>TRUE),
            array('accommodation_id'=>14,	'accommodation_fee_service_id'=>5,	'mandatory'=>TRUE),

        );

        DB::table('accommodation_service')->insert($data);
    }
}
