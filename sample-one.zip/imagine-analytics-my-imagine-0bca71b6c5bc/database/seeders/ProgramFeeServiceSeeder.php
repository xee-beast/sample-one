<?php

namespace Database\Seeders;

use App\Models\ProgramFeeService;
use Illuminate\Database\Seeder;

class ProgramFeeServiceSeeder extends Seeder
{
    public function run()
    {
        ProgramFeeService::create([
            'id'=>1,
            'name'=>'Enrolment Fee',
            'description'=>'Enrolment Fee',
            'taxable'=>false,
            'enabled'=>true,
            'type' => 'application',
            'fee'=> 250
        ]);

        ProgramFeeService::create([
            'id'=>2,
            'name'=>'Resource Fee',
            'description'=>'Resource Fee',
            'taxable'=>false,
            'enabled'=>true,
            'type' => 'course',
            'fee'=> 200
        ]);

        ProgramFeeService::create([
            'id'=>3,
            'name'=>'Chefs Kit & Uniform',
            'description'=>'Chefs Kit & Uniform',
            'taxable'=>true,
            'enabled'=>true,
            'type' => 'course',
            'fee'=> 989
        ]);

        ProgramFeeService::create([
            'id'=>4,
            'name'=>'Automotive Tool Kit',
            'description'=>'Automotive Tool Kit',
            'taxable'=>true,
            'enabled'=>true,
            'type' => 'course',
            'fee'=> 1400
        ]);

        ProgramFeeService::create([
            'id'=>6,
            'name'=>'Materials Fee',
            'description'=>'Materials Fee',
            'taxable'=>false,
            'enabled'=>true,
            'type' => 'course',
            'fee'=> 75
        ]);

        ProgramFeeService::create([
            'id'=>7,
            'name'=>'IELTS Book Fee up to 15 weeks',
            'description'=>'IELTS Book Fee up to 15 weeks',
            'taxable'=>true,
            'enabled'=>true,
            'type' => 'course',
            'fee'=> 90
        ]);

    }
}
