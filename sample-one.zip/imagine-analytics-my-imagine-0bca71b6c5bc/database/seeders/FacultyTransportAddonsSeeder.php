<?php

namespace Database\Seeders;

use App\Models\Faculty;
use App\Models\Location;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class FacultyTransportAddonsSeeder extends Seeder
{
    public function run()
    {
        $data = array(
            array('faculty_id'=>1,'addon_id'=>3,'fee'=>null,'ebecas_product_id'=>467),
            array('faculty_id'=>1,'addon_id'=>4,'fee'=>null,'ebecas_product_id'=>472),
            array('faculty_id'=>1,'addon_id'=>1,'fee'=>null,'ebecas_product_id'=>477),
            array('faculty_id'=>1,'addon_id'=>2,'fee'=>null,'ebecas_product_id'=>482),
            array('faculty_id'=>2,'addon_id'=>3,'fee'=>null,'ebecas_product_id'=>470),
            array('faculty_id'=>2,'addon_id'=>4,'fee'=>null,'ebecas_product_id'=>475),
            array('faculty_id'=>2,'addon_id'=>1,'fee'=>null,'ebecas_product_id'=>480),
            array('faculty_id'=>2,'addon_id'=>2,'fee'=>null,'ebecas_product_id'=>485),
            array('faculty_id'=>3,'addon_id'=>3,'fee'=>null,'ebecas_product_id'=>511),
            array('faculty_id'=>3,'addon_id'=>4,'fee'=>null,'ebecas_product_id'=>513),
            array('faculty_id'=>3,'addon_id'=>1,'fee'=>null,'ebecas_product_id'=>515),
            array('faculty_id'=>3,'addon_id'=>2,'fee'=>null,'ebecas_product_id'=>517),
            array('faculty_id'=>4,'addon_id'=>3,'fee'=>null,'ebecas_product_id'=>510),
            array('faculty_id'=>4,'addon_id'=>4,'fee'=>null,'ebecas_product_id'=>512),
            array('faculty_id'=>4,'addon_id'=>1,'fee'=>null,'ebecas_product_id'=>514),
            array('faculty_id'=>4,'addon_id'=>2,'fee'=>null,'ebecas_product_id'=>516),
            array('faculty_id'=>5,'addon_id'=>3,'fee'=>null,'ebecas_product_id'=>468),
            array('faculty_id'=>5,'addon_id'=>4,'fee'=>null,'ebecas_product_id'=>473),
            array('faculty_id'=>5,'addon_id'=>1,'fee'=>null,'ebecas_product_id'=>478),
            array('faculty_id'=>5,'addon_id'=>2,'fee'=>null,'ebecas_product_id'=>483),

        );
        DB::table('faculty_transportation_addon')->insert($data);


    }
}
