<?php

namespace Database\Seeders;

use App\Models\Faculty;
use App\Models\Location;
use Illuminate\Database\Seeder;

class FacultySeeder extends Seeder
{
    public function run()
    {

        Faculty::create(['id'=>1,'name'=>'Southport Campus (ELICOS)','description'=>'Southport Campus (ELICOS)','enabled'=>TRUE,'location_id'=>1,'ebecas_id'=>8]);
        Faculty::create(['id'=>2,'name'=>'Ashmore Campus (VET)','description'=>'Ashmore Campus (VET)','enabled'=>TRUE,'location_id'=>1,'ebecas_id'=>9]);
        Faculty::create(['id'=>3,'name'=>'Brisbane Campus (ELICOS)','description'=>'Brisbane Campus (ELICOS)','enabled'=>TRUE,'location_id'=>2,'ebecas_id'=>4]);
        Faculty::create(['id'=>4,'name'=>'Brisbane Campus (VET)','description'=>'Brisbane Campus (VET)','enabled'=>TRUE,'location_id'=>2,'ebecas_id'=>5]);
        Faculty::create(['id'=>5,'name'=>'Benowa Campus (VET)','description'=>'Benowa Campus (VET)','enabled'=>TRUE,'location_id'=>1,'ebecas_id'=>10]);


    }
}
