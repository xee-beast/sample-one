<?php

namespace Database\Seeders;

use App\Models\Faculty;
use App\Models\Location;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class FacultyAccommodationServiceSeeder extends Seeder
{
    public function run()
    {
        $data = array(
            array('faculty_id'=>1,	'fee_service_id'=>1,	'ebecas_product_id'=>383),
            array('faculty_id'=>1,	'fee_service_id'=>2,	'ebecas_product_id'=>389),
            array('faculty_id'=>1,	'fee_service_id'=>3,	'ebecas_product_id'=>391),
            array('faculty_id'=>1,	'fee_service_id'=>4,	'ebecas_product_id'=>396),
            array('faculty_id'=>1,	'fee_service_id'=>5,	'ebecas_product_id'=>399),
            array('faculty_id'=>1,	'fee_service_id'=>6,	'ebecas_product_id'=>403),
            array('faculty_id'=>1,	'fee_service_id'=>7,	'ebecas_product_id'=>409),
            array('faculty_id'=>2,	'fee_service_id'=>1,	'ebecas_product_id'=>381),
            array('faculty_id'=>2,	'fee_service_id'=>2,	'ebecas_product_id'=>388),
            array('faculty_id'=>2,	'fee_service_id'=>3,	'ebecas_product_id'=>394),
            array('faculty_id'=>2,	'fee_service_id'=>4,	'ebecas_product_id'=>395),
            array('faculty_id'=>2,	'fee_service_id'=>5,	'ebecas_product_id'=>402),
            array('faculty_id'=>2,	'fee_service_id'=>6,	'ebecas_product_id'=>404),
            array('faculty_id'=>2,	'fee_service_id'=>7,	'ebecas_product_id'=>408),
            array('faculty_id'=>3,	'fee_service_id'=>1,	'ebecas_product_id'=>413),
            array('faculty_id'=>3,	'fee_service_id'=>2,	'ebecas_product_id'=>415),
            array('faculty_id'=>3,	'fee_service_id'=>3,	'ebecas_product_id'=>417),
            array('faculty_id'=>3,	'fee_service_id'=>4,	'ebecas_product_id'=>419),
            array('faculty_id'=>3,	'fee_service_id'=>5,	'ebecas_product_id'=>421),
            array('faculty_id'=>3,	'fee_service_id'=>6,	'ebecas_product_id'=>423),
            array('faculty_id'=>3,	'fee_service_id'=>7,	'ebecas_product_id'=>425),
            array('faculty_id'=>4,	'fee_service_id'=>1,	'ebecas_product_id'=>412),
            array('faculty_id'=>4,	'fee_service_id'=>2,	'ebecas_product_id'=>414),
            array('faculty_id'=>4,	'fee_service_id'=>3,	'ebecas_product_id'=>416),
            array('faculty_id'=>4,	'fee_service_id'=>4,	'ebecas_product_id'=>418),
            array('faculty_id'=>4,	'fee_service_id'=>5,	'ebecas_product_id'=>420),
            array('faculty_id'=>4,	'fee_service_id'=>6,	'ebecas_product_id'=>422),
            array('faculty_id'=>4,	'fee_service_id'=>7,	'ebecas_product_id'=>424),
            array('faculty_id'=>5,	'fee_service_id'=>1,	'ebecas_product_id'=>384),
            array('faculty_id'=>5,	'fee_service_id'=>2,	'ebecas_product_id'=>386),
            array('faculty_id'=>5,	'fee_service_id'=>3,	'ebecas_product_id'=>392),
            array('faculty_id'=>5,	'fee_service_id'=>4,	'ebecas_product_id'=>397),
            array('faculty_id'=>5,	'fee_service_id'=>5,	'ebecas_product_id'=>400),
            array('faculty_id'=>5,	'fee_service_id'=>6,	'ebecas_product_id'=>406),
            array('faculty_id'=>5,	'fee_service_id'=>7,	'ebecas_product_id'=>410),

        );
        DB::table('faculty_accommodation_service')->insert($data);


    }
}
