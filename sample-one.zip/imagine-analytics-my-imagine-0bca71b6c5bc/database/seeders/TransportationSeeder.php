<?php

namespace Database\Seeders;

use App\Models\Location;
use App\Models\Transportation;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class TransportationSeeder extends Seeder
{
    public function run()
    {

        $data = array(
            array('id'=>1,'name'=>'Airport Transfer - Basic from Gold Coast airport to Gold Coast (GC to GC)','description'=>'Basic - GC to GC','enabled'=>TRUE,'taxable'=>TRUE,'return'=>FALSE,'origin'=>1,'destination'=>1,'fee'=>72),
            array('id'=>2,'name'=>'Airport Transfer - Basic from Gold Coast to Gold Coast airport (Return) (GC to GC)','description'=>'Basic - GC to GC (Return)','enabled'=>TRUE,'taxable'=>TRUE,'return'=>TRUE,'origin'=>1,'destination'=>1,'fee'=>43),
            array('id'=>3,'name'=>'Airport Transfer - Basic from Gold Coast airport to Brisbane (GC to BNE)','description'=>'Basic - GC to BNE','enabled'=>TRUE,'taxable'=>TRUE,'return'=>FALSE,'origin'=>1,'destination'=>2,'fee'=>96),
            array('id'=>4,'name'=>'Airport Transfer - Basic from Brisbane to Gold Coast airport (Return) (BNE to GC)','description'=>'Basic - GC to BNE (Return)','enabled'=>TRUE,'taxable'=>TRUE,'return'=>TRUE,'origin'=>1,'destination'=>2,'fee'=>49),
            array('id'=>5,'name'=>'Airport Transfer - Basic from Brisbane to Brisbane airport (Return) (BNE to BNE)','description'=>'Basic - BNE to BNE','enabled'=>TRUE,'taxable'=>TRUE,'return'=>TRUE,'origin'=>2,'destination'=>2,'fee'=>72),
            array('id'=>6,'name'=>'Airport Transfer - Basic from Brisbane airport to Brisbane (BNE to BNE)','description'=>'Basic - BNE to BNE (Return)','enabled'=>TRUE,'taxable'=>TRUE,'return'=>FALSE,'origin'=>2,'destination'=>2,'fee'=>43),
            array('id'=>7,'name'=>'Airport Transfer - Basic from Brisbane airport to Gold Coast (BNE to GC)','description'=>'Basic - BNE to GC','enabled'=>TRUE,'taxable'=>TRUE,'return'=>FALSE,'origin'=>2,'destination'=>1,'fee'=>96),
            array('id'=>8,'name'=>'Airport Transfer - Basic from Gold Coast to Brisbane airport (Return) (GC to BNE)','description'=>'Basic - BNE to GC (Return)','enabled'=>TRUE,'taxable'=>TRUE,'return'=>TRUE,'origin'=>2,'destination'=>1,'fee'=>49),
            array('id'=>9,'name'=>'Airport Transfer - Private from Gold Coast airport to Gold Coast (GC to GC)','description'=>'Private - GC to GC','enabled'=>TRUE,'taxable'=>TRUE,'return'=>FALSE,'origin'=>1,'destination'=>1,'fee'=>120),
            array('id'=>10,'name'=>'Airport Transfer - Private from Gold Coast to Gold Coast airport (Return) (GC to GC)','description'=>'Private - GC to GC (Return)','enabled'=>TRUE,'taxable'=>TRUE,'return'=>TRUE,'origin'=>1,'destination'=>1,'fee'=>95),
            array('id'=>11,'name'=>'Airport Transfer - Private from Gold Coast airport to Brisbane (GC to BNE)','description'=>'Private - GC to BNE','enabled'=>TRUE,'taxable'=>TRUE,'return'=>FALSE,'origin'=>1,'destination'=>2,'fee'=>168),
            array('id'=>12,'name'=>'Airport Transfer - Private from Brisbane to Gold Coast airport (Return) (BNE to GC)','description'=>'Private - GC to BNE (Return)','enabled'=>TRUE,'taxable'=>TRUE,'return'=>TRUE,'origin'=>1,'destination'=>2,'fee'=>144),
            array('id'=>13,'name'=>'Airport Transfer - Private from Brisbane airport to Gold Coast (BNE to GC)','description'=>'Private - BNE to GC','enabled'=>TRUE,'taxable'=>TRUE,'return'=>FALSE,'origin'=>2,'destination'=>1,'fee'=>168),
            array('id'=>14,'name'=>'Airport Transfer - Private from Gold Coast to Brisbane airport (Return) (GC to BNE)','description'=>'Private - BNE to GC (Return)','enabled'=>TRUE,'taxable'=>TRUE,'return'=>TRUE,'origin'=>2,'destination'=>1,'fee'=>144),
            array('id'=>15,'name'=>'Airport Transfer - Private from Brisbane airport to Brisbane (BNE to BNE)','description'=>'Private - BNE to BNE','enabled'=>TRUE,'taxable'=>TRUE,'return'=>FALSE,'origin'=>2,'destination'=>2,'fee'=>132),
            array('id'=>16,'name'=>'Airport Transfer - Private from Brisbane to Brisbane airport (Return) (BNE to BNE)','description'=>'Private - BNE to BNE (Return)','enabled'=>TRUE,'taxable'=>TRUE,'return'=>TRUE,'origin'=>2,'destination'=>2,'fee'=>132),
        );

        DB::table('transportations')->insert($data);
        DB::table('transportations')->update(['created_at'=>now(),'updated_at'=>now()]);



    }
}
