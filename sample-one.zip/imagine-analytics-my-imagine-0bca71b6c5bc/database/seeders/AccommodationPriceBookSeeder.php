<?php

namespace Database\Seeders;

use App\Models\AccommodationPriceBook;
use App\Models\AccommodationPriceBookFee;
use App\Models\ProgramPriceBook;
use App\Models\ProgramPriceBookFee;
use Carbon\Carbon;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class AccommodationPriceBookSeeder extends Seeder
{
    public function run()
    {
        $data = array(
            array('id'=>1,'name'=>'Homestay Individual - Room only accomodation','description'=>'Homestay Individual - Room only accomodation','expiry_date'=>'2022-12-31','enabled'=>TRUE,'expired'=>FALSE,'price_book_category_id'=>1),
            array('id'=>2,'name'=>'Homestay Individual - b\'fast & dinner daily','description'=>'Homestay Individual - b\'fast & dinner daily','expiry_date'=>'2022-12-31','enabled'=>TRUE,'expired'=>FALSE,'price_book_category_id'=>1),
            array('id'=>3,'name'=>'Homestay Individual- 3 meals daily','description'=>'Homestay Individual- 3 meals daily','expiry_date'=>'2022-12-31','enabled'=>TRUE,'expired'=>FALSE,'price_book_category_id'=>1),
            array('id'=>4,'name'=>'Homestay Individual- b\'fast & dinner weekdays, 3 meals Sat & Sun','description'=>'Homestay Individual- b\'fast & dinner weekdays, 3 meals Sat & Sun','expiry_date'=>'2022-12-31','enabled'=>TRUE,'expired'=>FALSE,'price_book_category_id'=>1),
            array('id'=>5,'name'=>'Homestay Twin Share - 3 meals daily','description'=>'Homestay Twin Share - 3 meals daily','expiry_date'=>'2022-12-31','enabled'=>TRUE,'expired'=>FALSE,'price_book_category_id'=>1),
            array('id'=>6,'name'=>'Homestay Twin Share - b\'fast & dinner daily','description'=>'Homestay Twin Share - b\'fast & dinner daily','expiry_date'=>'2022-12-31','enabled'=>TRUE,'expired'=>FALSE,'price_book_category_id'=>1),
            array('id'=>7,'name'=>'Homestay Twin Share - b\'fast & dinner weekdays, 3 meals Sat & Sun','description'=>'Homestay Twin Share - b\'fast & dinner weekdays, 3 meals Sat & Sun','expiry_date'=>'2022-12-31','enabled'=>TRUE,'expired'=>FALSE,'price_book_category_id'=>1),
            array('id'=>8,'name'=>'Homestay Twin Share- Room only accommodation','description'=>'Homestay Twin Share- Room only accomodation','expiry_date'=>'2022-12-31','enabled'=>TRUE,'expired'=>FALSE,'price_book_category_id'=>1),
            array('id'=>9,'name'=>'Homestay - Full service (for 12-18 yr olds; inc 3 x meals & transport)','description'=>'Homestay - Full service (for 12-18 yr olds; inc 3 x meals & transport)','expiry_date'=>'2022-12-31','enabled'=>TRUE,'expired'=>FALSE,'price_book_category_id'=>1),
            array('id'=>10,'name'=>'Homestay - Full service (for 8-11 yr olds; inc 3 x meals & transport)','description'=>'Homestay - Full service (for 8-11 yr olds; inc 3 x meals & transport)','expiry_date'=>'2022-12-31','enabled'=>TRUE,'expired'=>FALSE,'price_book_category_id'=>1),
            array('id'=>11,'name'=>'Homestay Family - 1 parent + 1 child - 3 meals, transport + Internet','description'=>'Homestay Family - 1 parent + 1 child - 3 meals, transport + Internet','expiry_date'=>'2022-12-31','enabled'=>TRUE,'expired'=>FALSE,'price_book_category_id'=>1),
            array('id'=>12,'name'=>'Homestay Family - 1 parent + 2 children - 3 meals, transport + Internet','description'=>'Homestay Family - 1 parent + 2 children - 3 meals, transport + Internet','expiry_date'=>'2022-12-31','enabled'=>TRUE,'expired'=>FALSE,'price_book_category_id'=>1),
            array('id'=>13,'name'=>'Homestay Family - 2 parents + 1 child - 3 meals, transport + Internet','description'=>'Homestay Family - 2 parents + 1 child - 3 meals, transport + Internet','expiry_date'=>'2022-12-31','enabled'=>TRUE,'expired'=>FALSE,'price_book_category_id'=>1),
            array('id'=>14,'name'=>'Homestay Family - 2 parents + 2 children - 3 meals, transport + Internet','description'=>'Homestay Family - 2 parents + 2 children - 3 meals, transport + Internet','expiry_date'=>'2022-12-31','enabled'=>TRUE,'expired'=>FALSE,'price_book_category_id'=>1),
        );

        DB::table('accommodation_price_books')->insert($data);


        //Fees
        $fees = array(
            array('id'=>1,'min'=>1,'max'=>150,'weekly_fee'=>240,'daily_fee'=>35,'price_book_id'=>1),
            array('id'=>2,'min'=>1,'max'=>150,'weekly_fee'=>335,'daily_fee'=>48,'price_book_id'=>2),
            array('id'=>3,'min'=>1,'max'=>150,'weekly_fee'=>385,'daily_fee'=>55,'price_book_id'=>3),
            array('id'=>4,'min'=>1,'max'=>150,'weekly_fee'=>350,'daily_fee'=>50,'price_book_id'=>4),
            array('id'=>5,'min'=>1,'max'=>150,'weekly_fee'=>325,'daily_fee'=>47,'price_book_id'=>5),
            array('id'=>6,'min'=>1,'max'=>150,'weekly_fee'=>287.5,'daily_fee'=>42,'price_book_id'=>6),
            array('id'=>7,'min'=>1,'max'=>150,'weekly_fee'=>300,'daily_fee'=>43,'price_book_id'=>7),
            array('id'=>8,'min'=>1,'max'=>150,'weekly_fee'=>205,'daily_fee'=>30,'price_book_id'=>8),
            array('id'=>9,'min'=>1,'max'=>150,'weekly_fee'=>445,'daily_fee'=>64,'price_book_id'=>9),
            array('id'=>10,'min'=>1,'max'=>150,'weekly_fee'=>485,'daily_fee'=>70,'price_book_id'=>10),
            array('id'=>11,'min'=>1,'max'=>150,'weekly_fee'=>695,'daily_fee'=>100,'price_book_id'=>11),
            array('id'=>12,'min'=>1,'max'=>150,'weekly_fee'=>975,'daily_fee'=>140,'price_book_id'=>12),
            array('id'=>13,'min'=>1,'max'=>150,'weekly_fee'=>975,'daily_fee'=>140,'price_book_id'=>13),
            array('id'=>14,'min'=>1,'max'=>150,'weekly_fee'=>1235,'daily_fee'=>177,'price_book_id'=>14),
        );
        DB::table('accommodation_price_book_fees')->insert($fees);

    }
}
