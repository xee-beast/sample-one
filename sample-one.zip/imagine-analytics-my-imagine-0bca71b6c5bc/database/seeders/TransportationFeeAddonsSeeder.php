<?php

namespace Database\Seeders;

use App\Models\TransportationFeeAddon;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class TransportationFeeAddonsSeeder extends Seeder
{
    public function run()
    {
       $data = array(
           array('id'=>1,'name'=>'Airport Transfer - Surcharge for transfers between 10:00pm and 5:00am','description'=>'Surcharge for transfers between 10:00pm and 5:00am','enabled'=>TRUE,'taxable'=>TRUE,'fee'=>48),
           array('id'=>2,'name'=>'Airport Transfer - Surcharge for transfers between 10:00pm and 5:00am (Return)','description'=>'Surcharge for transfers between 10:00pm and 5:00am (Return)','enabled'=>TRUE,'taxable'=>TRUE,'fee'=>48),
           array('id'=>3,'name'=>'Airport Transfer - Surcharge for surfboard collection','description'=>'Surcharge for surfboard collection','enabled'=>TRUE,'taxable'=>TRUE,'fee'=>48),
           array('id'=>4,'name'=>'Airport Transfer - Surcharge for surfboard collection (Return)','description'=>'Surcharge for surfboard collection (Return)','enabled'=>TRUE,'taxable'=>TRUE,'fee'=>48),
       );

        DB::table('transportation_fee_addons')->insert($data);
        DB::table('transportation_fee_addons')->update(['created_at'=>now(),'updated_at'=>now()]);
    }
}
