<?php

namespace Database\Seeders;

use App\Models\ProgramPriceBook;
use App\Models\ProgramPriceBookFee;
use Carbon\Carbon;
use Illuminate\Database\Seeder;

class ProgramPriceBookSeeder extends Seeder
{
    public function run()
    {
        $programPriceBook = ProgramPriceBook::create(['id'=>1,'name'=>'Advanced Diploma of Accounting','description'=>'Advanced Diploma of Accounting','enabled'=>TRUE,'expired'=>FALSE,'expiry_date'=>'2022-12-31','program_price_book_category_id'=>2]);
        $programPriceBook = ProgramPriceBook::create(['id'=>2,'name'=>'Advanced Diploma of Business','description'=>'Advanced Diploma of Business','enabled'=>TRUE,'expired'=>FALSE,'expiry_date'=>'2022-12-31','program_price_book_category_id'=>2]);
        $programPriceBook = ProgramPriceBook::create(['id'=>3,'name'=>'Advanced Diploma of Hospitality Management','description'=>'Advanced Diploma of Hospitality Management','enabled'=>TRUE,'expired'=>FALSE,'expiry_date'=>'2022-12-31','program_price_book_category_id'=>2]);
        $programPriceBook = ProgramPriceBook::create(['id'=>4,'name'=>'Advanced Diploma of Leadership and Management','description'=>'Advanced Diploma of Leadership and Management','enabled'=>TRUE,'expired'=>FALSE,'expiry_date'=>'2022-12-31','program_price_book_category_id'=>2]);
        $programPriceBook = ProgramPriceBook::create(['id'=>5,'name'=>'Advanced Diploma of Marketing and Communication','description'=>'Advanced Diploma of Marketing and Communication','enabled'=>TRUE,'expired'=>FALSE,'expiry_date'=>'2022-12-31','program_price_book_category_id'=>2]);
        $programPriceBook = ProgramPriceBook::create(['id'=>6,'name'=>'Certificate III in Business','description'=>'Certificate III in Business','enabled'=>TRUE,'expired'=>FALSE,'expiry_date'=>'2022-12-31','program_price_book_category_id'=>2]);
        $programPriceBook = ProgramPriceBook::create(['id'=>7,'name'=>'Certificate III in Commercial Cookery','description'=>'Certificate III in Commercial Cookery','enabled'=>TRUE,'expired'=>FALSE,'expiry_date'=>'2022-12-31','program_price_book_category_id'=>2]);
        $programPriceBook = ProgramPriceBook::create(['id'=>8,'name'=>'Certificate III in Early Childhood Education and Care','description'=>'Certificate III in Early Childhood Education and Care','enabled'=>TRUE,'expired'=>FALSE,'expiry_date'=>'2022-12-31','program_price_book_category_id'=>2]);
        $programPriceBook = ProgramPriceBook::create(['id'=>9,'name'=>'Certificate III in Hospitality','description'=>'Certificate III in Hospitality','enabled'=>TRUE,'expired'=>FALSE,'expiry_date'=>'2022-12-31','program_price_book_category_id'=>2]);
        $programPriceBook = ProgramPriceBook::create(['id'=>10,'name'=>'Certificate III in Individual Support','description'=>'Certificate III in Individual Support','enabled'=>TRUE,'expired'=>FALSE,'expiry_date'=>'2022-12-31','program_price_book_category_id'=>2]);
        $programPriceBook = ProgramPriceBook::create(['id'=>11,'name'=>'Certificate III in Light Vehicle Mechanical Technology','description'=>'Certificate III in Light Vehicle Mechanical Technology','enabled'=>TRUE,'expired'=>FALSE,'expiry_date'=>'2022-12-31','program_price_book_category_id'=>2]);
        $programPriceBook = ProgramPriceBook::create(['id'=>12,'name'=>'Certificate IV in Accounting and Bookkeeping','description'=>'Certificate IV in Accounting and Bookkeeping','enabled'=>TRUE,'expired'=>FALSE,'expiry_date'=>'2022-12-31','program_price_book_category_id'=>2]);
        $programPriceBook = ProgramPriceBook::create(['id'=>13,'name'=>'Certificate IV in Ageing Support','description'=>'Certificate IV in Ageing Support','enabled'=>TRUE,'expired'=>FALSE,'expiry_date'=>'2022-12-31','program_price_book_category_id'=>2]);
        $programPriceBook = ProgramPriceBook::create(['id'=>14,'name'=>'Certificate IV in Automotive Mechanical Diagnosis','description'=>'Certificate IV in Automotive Mechanical Diagnosis','enabled'=>TRUE,'expired'=>FALSE,'expiry_date'=>'2022-12-31','program_price_book_category_id'=>2]);
        $programPriceBook = ProgramPriceBook::create(['id'=>15,'name'=>'Certificate IV in Business','description'=>'Certificate IV in Business','enabled'=>TRUE,'expired'=>FALSE,'expiry_date'=>'2022-12-31','program_price_book_category_id'=>2]);
        $programPriceBook = ProgramPriceBook::create(['id'=>16,'name'=>'Certificate IV in Commercial Cookery','description'=>'Certificate IV in Commercial Cookery','enabled'=>TRUE,'expired'=>FALSE,'expiry_date'=>'2022-12-31','program_price_book_category_id'=>2]);
        $programPriceBook = ProgramPriceBook::create(['id'=>17,'name'=>'Certificate IV in Commercial Cookery (Upgrade)','description'=>'Certificate IV in Commercial Cookery (Upgrade)','enabled'=>TRUE,'expired'=>FALSE,'expiry_date'=>'2022-12-31','program_price_book_category_id'=>2]);
        $programPriceBook = ProgramPriceBook::create(['id'=>18,'name'=>'Certificate IV in Marketing and Communication','description'=>'Certificate IV in Marketing and Communication','enabled'=>TRUE,'expired'=>FALSE,'expiry_date'=>'2022-12-31','program_price_book_category_id'=>2]);
        $programPriceBook = ProgramPriceBook::create(['id'=>19,'name'=>'Diploma of Accounting','description'=>'Diploma of Accounting','enabled'=>TRUE,'expired'=>FALSE,'expiry_date'=>'2022-12-31','program_price_book_category_id'=>2]);
        $programPriceBook = ProgramPriceBook::create(['id'=>20,'name'=>'Diploma of Automotive Management','description'=>'Diploma of Automotive Management','enabled'=>TRUE,'expired'=>FALSE,'expiry_date'=>'2022-12-31','program_price_book_category_id'=>2]);
        $programPriceBook = ProgramPriceBook::create(['id'=>21,'name'=>'Diploma of Business','description'=>'Diploma of Business','enabled'=>TRUE,'expired'=>FALSE,'expiry_date'=>'2022-12-31','program_price_book_category_id'=>2]);
        $programPriceBook = ProgramPriceBook::create(['id'=>22,'name'=>'Diploma of Business Administration','description'=>'Diploma of Business Administration','enabled'=>TRUE,'expired'=>FALSE,'expiry_date'=>'2022-12-31','program_price_book_category_id'=>2]);
        $programPriceBook = ProgramPriceBook::create(['id'=>23,'name'=>'Diploma of Early Childhood Education and Care','description'=>'Diploma of Early Childhood Education and Care','enabled'=>TRUE,'expired'=>FALSE,'expiry_date'=>'2022-12-31','program_price_book_category_id'=>2]);
        $programPriceBook = ProgramPriceBook::create(['id'=>24,'name'=>'Diploma of Hospitality Management','description'=>'Diploma of Hospitality Management','enabled'=>TRUE,'expired'=>FALSE,'expiry_date'=>'2022-12-31','program_price_book_category_id'=>2]);
        $programPriceBook = ProgramPriceBook::create(['id'=>25,'name'=>'Diploma of Hospitality Management (Management Stream only)','description'=>'Diploma of Hospitality Management (Management Stream only)','enabled'=>TRUE,'expired'=>FALSE,'expiry_date'=>'2022-12-31','program_price_book_category_id'=>2]);
        $programPriceBook = ProgramPriceBook::create(['id'=>26,'name'=>'Diploma of Leadership and Management','description'=>'Diploma of Leadership and Management','enabled'=>TRUE,'expired'=>FALSE,'expiry_date'=>'2022-12-31','program_price_book_category_id'=>2]);
        $programPriceBook = ProgramPriceBook::create(['id'=>27,'name'=>'Diploma of Marketing and Communication','description'=>'Diploma of Marketing and Communication','enabled'=>TRUE,'expired'=>FALSE,'expiry_date'=>'2022-12-31','program_price_book_category_id'=>2]);
        $programPriceBook = ProgramPriceBook::create(['id'=>28,'name'=>'Cambridge First Certificate in English Preparation Course','description'=>'Cambridge First Certificate in English Preparation Course','enabled'=>TRUE,'expired'=>FALSE,'expiry_date'=>'2022-12-31','program_price_book_category_id'=>1]);
        $programPriceBook = ProgramPriceBook::create(['id'=>29,'name'=>'General English (Afternoon)','description'=>'General English (Afternoon) (Beginners - Advanced)','enabled'=>TRUE,'expired'=>FALSE,'expiry_date'=>'2022-12-31','program_price_book_category_id'=>1]);
        $programPriceBook = ProgramPriceBook::create(['id'=>30,'name'=>'General English (INTENSIVE)','description'=>'General English (Beginners - Advanced) (INTENSIVE)','enabled'=>TRUE,'expired'=>FALSE,'expiry_date'=>'2022-12-31','program_price_book_category_id'=>1]);
        $programPriceBook = ProgramPriceBook::create(['id'=>31,'name'=>'General English (STANDARD)','description'=>'General English (Beginners - Advanced) (STANDARD)','enabled'=>TRUE,'expired'=>FALSE,'expiry_date'=>'2022-12-31','program_price_book_category_id'=>1]);
        $programPriceBook = ProgramPriceBook::create(['id'=>32,'name'=>'General English (TURBO)','description'=>'General English (Beginners - Advanced) (TURBO)','enabled'=>TRUE,'expired'=>FALSE,'expiry_date'=>'2022-12-31','program_price_book_category_id'=>1]);
        $programPriceBook = ProgramPriceBook::create(['id'=>33,'name'=>'General English (Condensed)','description'=>'General English (Condensed) (Beginners - Advanced)','enabled'=>TRUE,'expired'=>FALSE,'expiry_date'=>'2022-12-31','program_price_book_category_id'=>1]);
        $programPriceBook = ProgramPriceBook::create(['id'=>34,'name'=>'General English (Night)','description'=>'General English (Night) (Beginners - Advanced) (STANDARD)','enabled'=>TRUE,'expired'=>FALSE,'expiry_date'=>'2022-12-31','program_price_book_category_id'=>1]);
        $programPriceBook = ProgramPriceBook::create(['id'=>35,'name'=>'High School Preparation','description'=>'High School Preparation','enabled'=>TRUE,'expired'=>FALSE,'expiry_date'=>'2022-12-31','program_price_book_category_id'=>1]);
        $programPriceBook = ProgramPriceBook::create(['id'=>36,'name'=>'IELTS Preparation','description'=>'IELTS Preparation','enabled'=>TRUE,'expired'=>FALSE,'expiry_date'=>'2022-12-31','program_price_book_category_id'=>1]);
        $programPriceBook = ProgramPriceBook::create(['id'=>37,'name'=>'Certificate IV in Kitchen Management','description'=>'Certificate IV in Kitchen Management','enabled'=>TRUE,'expired'=>FALSE,'expiry_date'=>'2022-12-31','program_price_book_category_id'=>2]);
        $programPriceBook = ProgramPriceBook::create(['id'=>38,'name'=>'Diploma of Hospitality Management','description'=>'Diploma of Hospitality Management','enabled'=>TRUE,'expired'=>FALSE,'expiry_date'=>'2022-12-31','program_price_book_category_id'=>2]);
        $programPriceBook = ProgramPriceBook::create(['id'=>39,'name'=>'Diploma of Hospitality Management (Mgmt stream only)','description'=>'Diploma of Hospitality Management (Mgmt stream only)','enabled'=>TRUE,'expired'=>FALSE,'expiry_date'=>'2022-12-31','program_price_book_category_id'=>2]);
        $programPriceBook = ProgramPriceBook::create(['id'=>40,'name'=>'Advanced Diploma of Hospitality Management','description'=>'Advanced Diploma of Hospitality Management','enabled'=>TRUE,'expired'=>FALSE,'expiry_date'=>'2022-12-31','program_price_book_category_id'=>2]);
        



        ProgramPriceBookFee::create(['min'=>36,'max'=>36,'price'=>11000,'program_price_book_id'=>1]);
        ProgramPriceBookFee::create(['min'=>40,'max'=>40,'price'=>12000,'program_price_book_id'=>7]);
        ProgramPriceBookFee::create(['min'=>40,'max'=>40,'price'=>10000,'program_price_book_id'=>9]);
        ProgramPriceBookFee::create(['min'=>27,'max'=>27,'price'=>6000,'program_price_book_id'=>10]);
        ProgramPriceBookFee::create(['min'=>60,'max'=>60,'price'=>18000,'program_price_book_id'=>11]);
        ProgramPriceBookFee::create(['min'=>39,'max'=>39,'price'=>8000,'program_price_book_id'=>13]);
        ProgramPriceBookFee::create(['min'=>36,'max'=>36,'price'=>10000,'program_price_book_id'=>14]);
        ProgramPriceBookFee::create(['min'=>56,'max'=>56,'price'=>9000,'program_price_book_id'=>16]);
        ProgramPriceBookFee::create(['min'=>56,'max'=>56,'price'=>9000,'program_price_book_id'=>17]);
        ProgramPriceBookFee::create(['min'=>27,'max'=>27,'price'=>5000,'program_price_book_id'=>24]);
        ProgramPriceBookFee::create(['min'=>56,'max'=>56,'price'=>9500,'program_price_book_id'=>25]);
        ProgramPriceBookFee::create(['min'=>30,'max'=>30,'price'=>12000,'program_price_book_id'=>2]);
        ProgramPriceBookFee::create(['min'=>51,'max'=>51,'price'=>12000,'program_price_book_id'=>3]);
        ProgramPriceBookFee::create(['min'=>32,'max'=>32,'price'=>10000,'program_price_book_id'=>4]);
        ProgramPriceBookFee::create(['min'=>32,'max'=>32,'price'=>10000,'program_price_book_id'=>5]);
        ProgramPriceBookFee::create(['min'=>22,'max'=>22,'price'=>5000,'program_price_book_id'=>6]);
        ProgramPriceBookFee::create(['min'=>28,'max'=>28,'price'=>9200,'program_price_book_id'=>8]);
        ProgramPriceBookFee::create(['min'=>32,'max'=>32,'price'=>6000,'program_price_book_id'=>12]);
        ProgramPriceBookFee::create(['min'=>24,'max'=>24,'price'=>6600,'program_price_book_id'=>15]);
        ProgramPriceBookFee::create(['min'=>32,'max'=>32,'price'=>5500,'program_price_book_id'=>18]);
        ProgramPriceBookFee::create(['min'=>29,'max'=>29,'price'=>7000,'program_price_book_id'=>19]);
        ProgramPriceBookFee::create(['min'=>30,'max'=>30,'price'=>7000,'program_price_book_id'=>20]);
        ProgramPriceBookFee::create(['min'=>35,'max'=>35,'price'=>9500,'program_price_book_id'=>21]);
        ProgramPriceBookFee::create(['min'=>23,'max'=>23,'price'=>4000,'program_price_book_id'=>22]);
        ProgramPriceBookFee::create(['min'=>50,'max'=>50,'price'=>14000,'program_price_book_id'=>23]);
        ProgramPriceBookFee::create(['min'=>36,'max'=>36,'price'=>6000,'program_price_book_id'=>26]);
        ProgramPriceBookFee::create(['min'=>32,'max'=>32,'price'=>12000,'program_price_book_id'=>27]);
        ProgramPriceBookFee::create(['min'=>1,'max'=>12,'price'=>500,'program_price_book_id'=>28]);
        ProgramPriceBookFee::create(['min'=>1,'max'=>60,'price'=>370,'program_price_book_id'=>29]);
        ProgramPriceBookFee::create(['min'=>1,'max'=>60,'price'=>380,'program_price_book_id'=>30]);
        ProgramPriceBookFee::create(['min'=>1,'max'=>60,'price'=>370,'program_price_book_id'=>31]);
        ProgramPriceBookFee::create(['min'=>1,'max'=>60,'price'=>390,'program_price_book_id'=>32]);
        ProgramPriceBookFee::create(['min'=>1,'max'=>60,'price'=>370,'program_price_book_id'=>33]);
        ProgramPriceBookFee::create(['min'=>1,'max'=>60,'price'=>370,'program_price_book_id'=>34]);
        ProgramPriceBookFee::create(['min'=>1,'max'=>12,'price'=>390,'program_price_book_id'=>35]);
        ProgramPriceBookFee::create(['min'=>1,'max'=>60,'price'=>400,'program_price_book_id'=>36]);
        ProgramPriceBookFee::create(['min'=>25,'max'=>25,'price'=>9000,'program_price_book_id'=>37]);
        ProgramPriceBookFee::create(['min'=>27,'max'=>27,'price'=>5000,'program_price_book_id'=>38]);
        ProgramPriceBookFee::create(['min'=>56,'max'=>56,'price'=>9500,'program_price_book_id'=>39]);
        ProgramPriceBookFee::create(['min'=>51,'max'=>51,'price'=>12000,'program_price_book_id'=>40]);






    }
}

