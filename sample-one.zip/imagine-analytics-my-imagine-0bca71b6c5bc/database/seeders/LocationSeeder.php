<?php

namespace Database\Seeders;

use App\Models\Location;
use Illuminate\Database\Seeder;

class LocationSeeder extends Seeder
{
    public function run()
    {
        Location::create([
            "id"=>1,
            'name'=>'Gold Coast',
            'description'=>null,
            'ebecas_id'=>1,
            'enabled'=>true,
            'created_at'=>now(),
            'updated_at'=>now(),
        ]);

        Location::create([
            "id"=>2,
            'name'=>'Brisbane',
            'description'=>null,
            'ebecas_id'=>2,
            'enabled'=>true,
            'created_at'=>now(),
            'updated_at'=>now(),
        ]);
    }
}
