<?php

namespace Database\Seeders;

use App\Models\Faculty;
use App\Models\Location;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class FacultyPaymentMethodsSeeder extends Seeder
{
    public function run()
    {
        $data = array(
            array('faculty_id'=>1,'payment_method_id'=>1,'ebecas_product_id'=>2549),
            array('faculty_id'=>1,'payment_method_id'=>2,'ebecas_product_id'=>null),
            array('faculty_id'=>1,'payment_method_id'=>3,'ebecas_product_id'=>null),
            array('faculty_id'=>1,'payment_method_id'=>4,'ebecas_product_id'=>null),
            array('faculty_id'=>2,'payment_method_id'=>1,'ebecas_product_id'=>1703),
            array('faculty_id'=>2,'payment_method_id'=>2,'ebecas_product_id'=>null),
            array('faculty_id'=>2,'payment_method_id'=>3,'ebecas_product_id'=>null),
            array('faculty_id'=>2,'payment_method_id'=>4,'ebecas_product_id'=>null),
            array('faculty_id'=>3,'payment_method_id'=>1,'ebecas_product_id'=>2586),
            array('faculty_id'=>3,'payment_method_id'=>2,'ebecas_product_id'=>null),
            array('faculty_id'=>3,'payment_method_id'=>3,'ebecas_product_id'=>null),
            array('faculty_id'=>3,'payment_method_id'=>4,'ebecas_product_id'=>null),
            array('faculty_id'=>4,'payment_method_id'=>1,'ebecas_product_id'=>1709),
            array('faculty_id'=>4,'payment_method_id'=>2,'ebecas_product_id'=>null),
            array('faculty_id'=>4,'payment_method_id'=>3,'ebecas_product_id'=>null),
            array('faculty_id'=>4,'payment_method_id'=>4,'ebecas_product_id'=>null),
            array('faculty_id'=>5,'payment_method_id'=>1,'ebecas_product_id'=>1710),
            array('faculty_id'=>5,'payment_method_id'=>2,'ebecas_product_id'=>null),
            array('faculty_id'=>5,'payment_method_id'=>3,'ebecas_product_id'=>null),
            array('faculty_id'=>5,'payment_method_id'=>4,'ebecas_product_id'=>null),
        );

        DB::table('faculty_payment_method')->insert($data);

    }
}
