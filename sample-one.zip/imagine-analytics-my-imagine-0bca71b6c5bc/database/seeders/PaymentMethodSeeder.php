<?php

namespace Database\Seeders;

use App\Models\CalendarCategory;
use App\Models\PaymentMethod;
use Illuminate\Database\Seeder;

class PaymentMethodSeeder extends Seeder
{
    public function run()
    {
        PaymentMethod::create([
            'id'=>1,
            'name'=>'Credit Card',
            'description'=>'Credit Card',
            'taxable'=>true,
            'enabled'=>true,
            'surcharge_type' => 'percentage',
            'value'=> 0.3,
            'is_payment_plan'=>false
        ]);

        PaymentMethod::create([
            'id'=>2,
            'name'=>'Bank Transfer',
            'description'=>'Bank Transfer',
            'taxable'=>false,
            'enabled'=>true,
            'surcharge_type' => 'flat_fee',
            'value'=> 0,
            'is_payment_plan'=>false
        ]);

        PaymentMethod::create([
            'id'=>3,
            'name'=>'Overseas Bank Transfer',
            'description'=>'Overseas Bank Transfer',
            'taxable'=>false,
            'enabled'=>true,
            'surcharge_type' => 'flat_fee',
            'value'=> 30,
            'is_payment_plan'=>false
        ]);

        PaymentMethod::create([
            'id'=>4,
            'name'=>'ezidebit',
            'description'=>'ezidebit',
            'taxable'=>false,
            'enabled'=>true,
            'surcharge_type' => 'flat_fee',
            'value'=> 0,
            'is_payment_plan'=>true

        ]);

    }
}
