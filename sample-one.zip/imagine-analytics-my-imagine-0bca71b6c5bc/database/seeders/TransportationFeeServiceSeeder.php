<?php

namespace Database\Seeders;

use App\Models\Location;
use App\Models\TransportationFeeService;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class TransportationFeeServiceSeeder extends Seeder
{
    public function run()
    {

        $data = array(
            array('id'=>'1','name'=>'Unaccompanied minor service from Gold Coast airport (GC to GC)','description'=>'Airport Transfer - Unaccompanied minor service from Gold Coast airport (GC to GC)','enabled'=>TRUE,'taxable'=>TRUE,'fee'=>144,'age_restriction_enabled'=>TRUE,'min_age'=>11,'max_age'=>17),
            array('id'=>'2','name'=>'Unaccompanied minor service from Gold Coast airport (Return) (GC to GC)','description'=>'Airport Transfer - Unaccompanied minor service from Gold Coast airport (Return) (GC to GC)','enabled'=>TRUE,'taxable'=>TRUE,'fee'=>120,'age_restriction_enabled'=>TRUE,'min_age'=>11,'max_age'=>17),
            array('id'=>'3','name'=>'Unaccompanied minor service from Gold Coast airport (GC to BNE)','description'=>'Airport Transfer - Unaccompanied minor service from Gold Coast airport (GC to BNE)','enabled'=>TRUE,'taxable'=>TRUE,'fee'=>198,'age_restriction_enabled'=>TRUE,'min_age'=>11,'max_age'=>17),
            array('id'=>'4','name'=>'Unaccompanied minor service from Gold Coast airport (Return) (GC to BNE)','description'=>'Airport Transfer - Unaccompanied minor service from Gold Coast airport (Return) (GC to BNE)','enabled'=>TRUE,'taxable'=>TRUE,'fee'=>190,'age_restriction_enabled'=>TRUE,'min_age'=>11,'max_age'=>17),
            array('id'=>'5','name'=>'Unaccompanied minor service from Brisbane airport (BNE to BNE)','description'=>'Airport Transfer - Unaccompanied minor service from Brisbane airport (BNE to BNE)','enabled'=>TRUE,'taxable'=>TRUE,'fee'=>180,'age_restriction_enabled'=>TRUE,'min_age'=>11,'max_age'=>17),
            array('id'=>'6','name'=>'Unaccompanied minor service from Brisbane airport (Return) (BNE to BNE)','description'=>'Airport Transfer - Unaccompanied minor service from Brisbane airport (Return) (BNE to BNE)','enabled'=>TRUE,'taxable'=>TRUE,'fee'=>180,'age_restriction_enabled'=>TRUE,'min_age'=>11,'max_age'=>17),
            array('id'=>'7','name'=>'Unaccompanied minor service from Brisbane airport (BNE to GC)','description'=>'Airport Transfer - Unaccompanied minor service from Brisbane airport (BNE to GC)','enabled'=>TRUE,'taxable'=>TRUE,'fee'=>198,'age_restriction_enabled'=>TRUE,'min_age'=>11,'max_age'=>17),
            array('id'=>'8','name'=>'Unaccompanied minor service from Brisbane airport (Return) (BNE to GC)','description'=>'Airport Transfer - Unaccompanied minor service from Brisbane airport (Return) (BNE to GC)','enabled'=>TRUE,'taxable'=>TRUE,'fee'=>174,'age_restriction_enabled'=>TRUE,'min_age'=>11,'max_age'=>17),
        );

        DB::table('transportation_fee_services')->insert($data);
        DB::table('transportation_fee_services')->update(['created_at'=>now(),'updated_at'=>now()]);

    }
}
