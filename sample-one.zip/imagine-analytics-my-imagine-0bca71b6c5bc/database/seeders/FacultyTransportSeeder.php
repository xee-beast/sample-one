<?php

namespace Database\Seeders;

use App\Models\Faculty;
use App\Models\Location;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class FacultyTransportSeeder extends Seeder
{
    public function run()
    {
        $data = array(
            array('faculty_id'=>1,'transportation_id'=>1,'ebecas_product_id'=>437),
            array('faculty_id'=>1,'transportation_id'=>2,'ebecas_product_id'=>442),
            array('faculty_id'=>1,'transportation_id'=>7,'ebecas_product_id'=>428),
            array('faculty_id'=>1,'transportation_id'=>9,'ebecas_product_id'=>457),
            array('faculty_id'=>1,'transportation_id'=>10,'ebecas_product_id'=>462),
            array('faculty_id'=>1,'transportation_id'=>13,'ebecas_product_id'=>448),
            array('faculty_id'=>1,'transportation_id'=>4,'ebecas_product_id'=>432),
            array('faculty_id'=>1,'transportation_id'=>12,'ebecas_product_id'=>452),
            // array('faculty_id'=>1,'transportation_id'=>3,'ebecas_product_id'=>428),
            // array('faculty_id'=>1,'transportation_id'=>11,'ebecas_product_id'=>448),
            array('faculty_id'=>2,'transportation_id'=>1,'ebecas_product_id'=>440),
            array('faculty_id'=>2,'transportation_id'=>2,'ebecas_product_id'=>445),
            array('faculty_id'=>2,'transportation_id'=>7,'ebecas_product_id'=>426),
            array('faculty_id'=>2,'transportation_id'=>8,'ebecas_product_id'=>435),
            array('faculty_id'=>2,'transportation_id'=>9,'ebecas_product_id'=>460),
            array('faculty_id'=>2,'transportation_id'=>10,'ebecas_product_id'=>465),
            array('faculty_id'=>2,'transportation_id'=>13,'ebecas_product_id'=>446),
            array('faculty_id'=>2,'transportation_id'=>12,'ebecas_product_id'=>455),
            // array('faculty_id'=>2,'transportation_id'=>3,'ebecas_product_id'=>426),
            // array('faculty_id'=>2,'transportation_id'=>11,'ebecas_product_id'=>446),
            array('faculty_id'=>3,'transportation_id'=>15,'ebecas_product_id'=>507),
            array('faculty_id'=>3,'transportation_id'=>16,'ebecas_product_id'=>509),
            array('faculty_id'=>3,'transportation_id'=>11,'ebecas_product_id'=>2725),
            array('faculty_id'=>3,'transportation_id'=>14,'ebecas_product_id'=>2726),
            array('faculty_id'=>4,'transportation_id'=>15,'ebecas_product_id'=>506),
            array('faculty_id'=>4,'transportation_id'=>16,'ebecas_product_id'=>508),
            array('faculty_id'=>4,'transportation_id'=>11,'ebecas_product_id'=>2723),
            array('faculty_id'=>4,'transportation_id'=>14,'ebecas_product_id'=>2724),
            array('faculty_id'=>5,'transportation_id'=>1,'ebecas_product_id'=>438),
            array('faculty_id'=>5,'transportation_id'=>2,'ebecas_product_id'=>443),
            array('faculty_id'=>5,'transportation_id'=>7,'ebecas_product_id'=>429),
            array('faculty_id'=>5,'transportation_id'=>9,'ebecas_product_id'=>458),
            array('faculty_id'=>5,'transportation_id'=>10,'ebecas_product_id'=>463),
            array('faculty_id'=>5,'transportation_id'=>13,'ebecas_product_id'=>449),
            array('faculty_id'=>5,'transportation_id'=>14,'ebecas_product_id'=>453),
            array('faculty_id'=>5,'transportation_id'=>4,'ebecas_product_id'=>433),
            // array('faculty_id'=>5,'transportation_id'=>14,'ebecas_product_id'=>429),
            // array('faculty_id'=>5,'transportation_id'=>4,'ebecas_product_id'=>449),
        );
        DB::table('faculty_transportation')->insert($data);


    }
}
