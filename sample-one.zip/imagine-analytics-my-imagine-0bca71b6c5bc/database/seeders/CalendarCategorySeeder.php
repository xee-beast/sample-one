<?php

namespace Database\Seeders;

use App\Models\CalendarCategory;
use Illuminate\Database\Seeder;

class CalendarCategorySeeder extends Seeder
{
    public function run()
    {
        CalendarCategory::create([
            'id'=>1,
            'name'=>'Weekly Intake',
            'description'=>'Weekly Intake',
            'enabled'=>true
        ]);

        CalendarCategory::create([
            'id'=>2,
            'name'=>'GC VET (BENOWA)',
            'description'=>'GC VET (BENOWA)',
            'enabled'=>true
        ]);

        CalendarCategory::create([
            'id'=>3,
            'name'=>'GC VET (ASHMORE)',
            'description'=>'GC VET (ASHMORE)',
            'enabled'=>true
        ]);
    }
}
