<?php

namespace Database\Seeders;

use App\Models\Faculty;
use App\Models\Location;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class FacultyAccommodationSeeder extends Seeder
{
    public function run()
    {
        $data = array(
            array('faculty_id'=>1,	'accommodation_id'=>1,	'ebecas_product_id'=>257),
            array('faculty_id'=>1,	'accommodation_id'=>2,	'ebecas_product_id'=>302),
            array('faculty_id'=>1,	'accommodation_id'=>3,	'ebecas_product_id'=>306),
            array('faculty_id'=>1,	'accommodation_id'=>4,	'ebecas_product_id'=>312),
            array('faculty_id'=>1,	'accommodation_id'=>5,	'ebecas_product_id'=>317),
            array('faculty_id'=>1,	'accommodation_id'=>6,	'ebecas_product_id'=>321),
            array('faculty_id'=>1,	'accommodation_id'=>7,	'ebecas_product_id'=>326),
            array('faculty_id'=>1,	'accommodation_id'=>8,	'ebecas_product_id'=>330),
            array('faculty_id'=>1,	'accommodation_id'=>9,	'ebecas_product_id'=>272),
            array('faculty_id'=>1,	'accommodation_id'=>10,	'ebecas_product_id'=>277),
            array('faculty_id'=>1,	'accommodation_id'=>11,	'ebecas_product_id'=>281),
            array('faculty_id'=>1,	'accommodation_id'=>12,	'ebecas_product_id'=>286),
            array('faculty_id'=>1,	'accommodation_id'=>13,	'ebecas_product_id'=>292),
            array('faculty_id'=>1,	'accommodation_id'=>14,	'ebecas_product_id'=>297),
            array('faculty_id'=>2,	'accommodation_id'=>1,	'ebecas_product_id'=>255),
            array('faculty_id'=>2,	'accommodation_id'=>2,	'ebecas_product_id'=>300),
            array('faculty_id'=>2,	'accommodation_id'=>3,	'ebecas_product_id'=>309),
            array('faculty_id'=>2,	'accommodation_id'=>4,	'ebecas_product_id'=>310),
            array('faculty_id'=>2,	'accommodation_id'=>6,	'ebecas_product_id'=>324),
            array('faculty_id'=>2,	'accommodation_id'=>7,	'ebecas_product_id'=>329),
            array('faculty_id'=>2,	'accommodation_id'=>8,	'ebecas_product_id'=>334),
            array('faculty_id'=>2,	'accommodation_id'=>9,	'ebecas_product_id'=>270),
            array('faculty_id'=>2,	'accommodation_id'=>10,	'ebecas_product_id'=>275),
            array('faculty_id'=>2,	'accommodation_id'=>11,	'ebecas_product_id'=>284),
            array('faculty_id'=>2,	'accommodation_id'=>12,	'ebecas_product_id'=>289),
            array('faculty_id'=>2,	'accommodation_id'=>13,	'ebecas_product_id'=>290),
            array('faculty_id'=>2,	'accommodation_id'=>14,	'ebecas_product_id'=>295),
            array('faculty_id'=>3,	'accommodation_id'=>1,	'ebecas_product_id'=>346),
            array('faculty_id'=>3,	'accommodation_id'=>2,	'ebecas_product_id'=>365),
            array('faculty_id'=>3,	'accommodation_id'=>3,	'ebecas_product_id'=>367),
            array('faculty_id'=>3,	'accommodation_id'=>4,	'ebecas_product_id'=>369),
            array('faculty_id'=>3,	'accommodation_id'=>5,	'ebecas_product_id'=>371),
            array('faculty_id'=>3,	'accommodation_id'=>6,	'ebecas_product_id'=>373),
            array('faculty_id'=>3,	'accommodation_id'=>7,	'ebecas_product_id'=>375),
            array('faculty_id'=>3,	'accommodation_id'=>8,	'ebecas_product_id'=>376),
            array('faculty_id'=>3,	'accommodation_id'=>9,	'ebecas_product_id'=>353),
            array('faculty_id'=>3,	'accommodation_id'=>10,	'ebecas_product_id'=>355),
            array('faculty_id'=>3,	'accommodation_id'=>11,	'ebecas_product_id'=>357),
            array('faculty_id'=>3,	'accommodation_id'=>12,	'ebecas_product_id'=>359),
            array('faculty_id'=>3,	'accommodation_id'=>13,	'ebecas_product_id'=>361),
            array('faculty_id'=>3,	'accommodation_id'=>14,	'ebecas_product_id'=>363),
            array('faculty_id'=>4,	'accommodation_id'=>1,	'ebecas_product_id'=>345),
            array('faculty_id'=>4,	'accommodation_id'=>2,	'ebecas_product_id'=>364),
            array('faculty_id'=>4,	'accommodation_id'=>3,	'ebecas_product_id'=>366),
            array('faculty_id'=>4,	'accommodation_id'=>4,	'ebecas_product_id'=>368),
            array('faculty_id'=>4,	'accommodation_id'=>5,	'ebecas_product_id'=>370),
            array('faculty_id'=>4,	'accommodation_id'=>6,	'ebecas_product_id'=>372),
            array('faculty_id'=>4,	'accommodation_id'=>7,	'ebecas_product_id'=>374),
            array('faculty_id'=>4,	'accommodation_id'=>8,	'ebecas_product_id'=>347),
            array('faculty_id'=>4,	'accommodation_id'=>9,	'ebecas_product_id'=>352),
            array('faculty_id'=>4,	'accommodation_id'=>10,	'ebecas_product_id'=>354),
            array('faculty_id'=>4,	'accommodation_id'=>11,	'ebecas_product_id'=>356),
            array('faculty_id'=>4,	'accommodation_id'=>12,	'ebecas_product_id'=>358),
            array('faculty_id'=>4,	'accommodation_id'=>13,	'ebecas_product_id'=>360),
            array('faculty_id'=>4,	'accommodation_id'=>14,	'ebecas_product_id'=>362),
            array('faculty_id'=>5,	'accommodation_id'=>1,	'ebecas_product_id'=>258),
            array('faculty_id'=>5,	'accommodation_id'=>2,	'ebecas_product_id'=>303),
            array('faculty_id'=>5,	'accommodation_id'=>3,	'ebecas_product_id'=>307),
            array('faculty_id'=>5,	'accommodation_id'=>4,	'ebecas_product_id'=>313),
            array('faculty_id'=>5,	'accommodation_id'=>5,	'ebecas_product_id'=>318),
            array('faculty_id'=>5,	'accommodation_id'=>6,	'ebecas_product_id'=>322),
            array('faculty_id'=>5,	'accommodation_id'=>7,	'ebecas_product_id'=>327),
            array('faculty_id'=>5,	'accommodation_id'=>8,	'ebecas_product_id'=>332),
            array('faculty_id'=>5,	'accommodation_id'=>9,	'ebecas_product_id'=>273),
            array('faculty_id'=>5,	'accommodation_id'=>10,	'ebecas_product_id'=>278),
            array('faculty_id'=>5,	'accommodation_id'=>11,	'ebecas_product_id'=>282),
            array('faculty_id'=>5,	'accommodation_id'=>12,	'ebecas_product_id'=>287),
            array('faculty_id'=>5,	'accommodation_id'=>13,	'ebecas_product_id'=>293),
            array('faculty_id'=>5,	'accommodation_id'=>14,	'ebecas_product_id'=>298),


        );
        DB::table('faculty_accommodation')->insert($data);


    }
}
