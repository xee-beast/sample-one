<?php

namespace Database\Seeders;

use App\Models\Permission;
use App\Models\PermissionsGroup;
use App\Models\User;
use Illuminate\Database\Seeder;
use Illuminate\Support\Str;
use App\Models\Role;

class PermissionsSeeder extends Seeder
{

    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        // Create the superadmin and admin roles
        $superadmin_role = Role::firstOrCreate(
            ['guard_name'=> 'web', 'name' => config('constants.system_roles.superadmin')],
            ['system'=>true,'description' => 'The superadmin role has the access to all the features and functionalities in the system']
        );

        $staff_role = Role::firstOrCreate(
            ['guard_name'=> 'web', 'name' => config('constants.system_roles.staff')],
            ['system'=>true,'description' => 'Basic role for staff users']
        );

        // Create the Permissions
        $permissions = include('data/permissions.php');
        $this->create_permissions($permissions, null);

    }

    /**
     * Recursive function to iterate through a permissions tree and create the permissions group and permission
     * if they do not exist already in the database.
     * @param array $node Array with the groups and permissions to iterate through.
     * @param PermissionsGroup|null $parent_group Permission Group that is the parent of the Group or permission.
     */
    public function create_permissions(array $node, PermissionsGroup $parent_group = null)
    {
        foreach ($node as $key => $value){

            #Permission
            if(is_string($value)){
               $permission_set = $this->extract_properties($value);
                //Create the permission if it does not exist
                $permission = Permission::firstOrCreate(
                    ['guard_name' => $permission_set['guard'], 'name' => str_replace(' ', '',$permission_set['name'])],
                    [
                        'label' => $permission_set['label'],
                        'description' => $permission_set['description'],
                        'group_id' => $parent_group->id
                    ]
                );

                continue;
            }

            #Groups
            if(is_array($value)){
                $group_set = $this->extract_properties($key);

                //We need to create the group if it does not exist.
                $slug = isset($parent_group) ? $parent_group['slug'].'.' : '';
                $slug .= $group_set['name'];
                $slug = Str::lower($slug);

                $group = PermissionsGroup::firstOrCreate(
                    ['slug'=> str_replace(' ', '',$slug)],
                    ['label' => $group_set['label'], 'parent_id' => $parent_group->id ?? null],
                );
                $this->create_permissions($value,$group);
            }
        }

    }


    /**
     * @param string $value String extract the properties from. Each property within the string
     * is expected to be key:value pair separated by a pipe '|'.
     * @return array A key=>value array where each key is the name of the property and the value the
     * value of the property.
     */
    public function extract_properties(string $value){
        $array =[];
        $permission_data = explode('|',$value); //Extract each property set '$key:$value'
        foreach ($permission_data as $item => $permission){
            list($key,$value) = explode(':',$permission);
            $key = trim($key);
            $array[$key] = trim($value);
        }
        return $array;


    }

}
