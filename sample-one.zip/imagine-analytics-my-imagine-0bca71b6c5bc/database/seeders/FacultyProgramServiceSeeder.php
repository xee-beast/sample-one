<?php

namespace Database\Seeders;

use App\Models\Faculty;
use App\Models\Location;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class FacultyProgramServiceSeeder extends Seeder
{
    public function run()
    {
        $data = array(
            array('faculty_id'=>1,'program_fee_service_id'=>1,'fee'=>null,'ebecas_product_id'=>833),
            array('faculty_id'=>1,'program_fee_service_id'=>6,'fee'=>null,'ebecas_product_id'=>840),
            array('faculty_id'=>1,'program_fee_service_id'=>7,'fee'=>null,'ebecas_product_id'=>1713),
            array('faculty_id'=>2,'program_fee_service_id'=>1,'fee'=>null,'ebecas_product_id'=>837),
            array('faculty_id'=>2,'program_fee_service_id'=>2,'fee'=>null,'ebecas_product_id'=>888),
            array('faculty_id'=>2,'program_fee_service_id'=>3,'fee'=>null,'ebecas_product_id'=>1722),
            array('faculty_id'=>2,'program_fee_service_id'=>4,'fee'=>null,'ebecas_product_id'=>2541),
            array('faculty_id'=>3,'program_fee_service_id'=>1,'fee'=>null,'ebecas_product_id'=>838),
            array('faculty_id'=>3,'program_fee_service_id'=>6,'fee'=>null,'ebecas_product_id'=>845),
            array('faculty_id'=>3,'program_fee_service_id'=>7,'fee'=>null,'ebecas_product_id'=>1711),
            array('faculty_id'=>4,'program_fee_service_id'=>1,'fee'=>null,'ebecas_product_id'=>839),
            array('faculty_id'=>4,'program_fee_service_id'=>2,'fee'=>null,'ebecas_product_id'=>891),
            array('faculty_id'=>4,'program_fee_service_id'=>3,'fee'=>null,'ebecas_product_id'=>818),
            array('faculty_id'=>4,'program_fee_service_id'=>4,'fee'=>null,'ebecas_product_id'=>1720),
            array('faculty_id'=>4,'program_fee_service_id'=>6,'fee'=>null,'ebecas_product_id'=>844),
            array('faculty_id'=>5,'program_fee_service_id'=>1,'fee'=>null,'ebecas_product_id'=>835),
            array('faculty_id'=>5,'program_fee_service_id'=>2,'fee'=>null,'ebecas_product_id'=>890),
            array('faculty_id'=>5,'program_fee_service_id'=>3,'fee'=>null,'ebecas_product_id'=>2555),
            array('faculty_id'=>5,'program_fee_service_id'=>6,'fee'=>null,'ebecas_product_id'=>843),

        );

        DB::table('faculty_program_service')->insert($data);


    }
}
