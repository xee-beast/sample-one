<?php

namespace Database\Seeders;

use App\Models\Faculty;
use App\Models\Location;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class FacultyTransportServicesSeeder extends Seeder
{
    public function run()
    {
        $data = array(
            array('faculty_id'=>1,'fee_service_id'=>7,'fee'=>null,'ebecas_product_id'=>487),
            array('faculty_id'=>1,'fee_service_id'=>8,'fee'=>null,'ebecas_product_id'=>492),
            array('faculty_id'=>1,'fee_service_id'=>1,'fee'=>null,'ebecas_product_id'=>497),
            array('faculty_id'=>1,'fee_service_id'=>2,'fee'=>null,'ebecas_product_id'=>501),
            array('faculty_id'=>2,'fee_service_id'=>7,'fee'=>null,'ebecas_product_id'=>490),
            array('faculty_id'=>2,'fee_service_id'=>8,'fee'=>null,'ebecas_product_id'=>495),
            array('faculty_id'=>2,'fee_service_id'=>1,'fee'=>null,'ebecas_product_id'=>500),
            array('faculty_id'=>2,'fee_service_id'=>2,'fee'=>null,'ebecas_product_id'=>505),
            array('faculty_id'=>3,'fee_service_id'=>5,'fee'=>null,'ebecas_product_id'=>518),
            array('faculty_id'=>3,'fee_service_id'=>6,'fee'=>null,'ebecas_product_id'=>521),
            array('faculty_id'=>4,'fee_service_id'=>5,'fee'=>null,'ebecas_product_id'=>519),
            array('faculty_id'=>4,'fee_service_id'=>6,'fee'=>null,'ebecas_product_id'=>520),
            array('faculty_id'=>5,'fee_service_id'=>7,'fee'=>null,'ebecas_product_id'=>488),
            array('faculty_id'=>5,'fee_service_id'=>8,'fee'=>null,'ebecas_product_id'=>493),
            array('faculty_id'=>5,'fee_service_id'=>1,'fee'=>null,'ebecas_product_id'=>498),
            array('faculty_id'=>5,'fee_service_id'=>2,'fee'=>null,'ebecas_product_id'=>503),

        );
        DB::table('faculty_transportation_service')->insert($data);


    }
}
