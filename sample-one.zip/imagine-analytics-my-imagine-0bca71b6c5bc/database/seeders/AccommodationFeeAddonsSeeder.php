<?php

namespace Database\Seeders;

use App\Models\AccommodationFeeAddon;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class AccommodationFeeAddonsSeeder extends Seeder
{
    public function run()
    {
        $data = array(
            array('id'=>1,'name'=>'Guardianship Fee','description'=>'Guardianship Fee','weekly_fee'=>72,'daily_fee'=>11,'taxable'=>FALSE,'enabled'=>TRUE),
            array('id'=>2,'name'=>'Halal Meals','description'=>'Halal Meals','weekly_fee'=>60,'daily_fee'=>9,'taxable'=>FALSE,'enabled'=>TRUE),
            array('id'=>3,'name'=>'Transport (To and From school)','description'=>'Transport (To and From school)','weekly_fee'=>60,'daily_fee'=>9,'taxable'=>FALSE,'enabled'=>TRUE),
            array('id'=>4,'name'=>'WIFI internet','description'=>'WIFI internet','weekly_fee'=>15,'daily_fee'=>3,'taxable'=>FALSE,'enabled'=>TRUE),
        );

        DB::table('accommodation_fee_addons')->insert($data);
    }
}
