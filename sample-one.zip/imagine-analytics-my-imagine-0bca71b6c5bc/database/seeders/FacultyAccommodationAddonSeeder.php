<?php

namespace Database\Seeders;

use App\Models\Faculty;
use App\Models\Location;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class FacultyAccommodationAddonSeeder extends Seeder
{
    public function run()
    {
        $data = array(
            array('faculty_id'=>1,	'addon_id'=>1,	'ebecas_product_id'=>262),
            array('faculty_id'=>1,	'addon_id'=>2,	'ebecas_product_id'=>267),
            array('faculty_id'=>1,	'addon_id'=>3,	'ebecas_product_id'=>337),
            array('faculty_id'=>1,	'addon_id'=>4,	'ebecas_product_id'=>342),
            array('faculty_id'=>2,	'addon_id'=>1,	'ebecas_product_id'=>260),
            array('faculty_id'=>2,	'addon_id'=>2,	'ebecas_product_id'=>265),
            array('faculty_id'=>2,	'addon_id'=>3,	'ebecas_product_id'=>335),
            array('faculty_id'=>2,	'addon_id'=>4,	'ebecas_product_id'=>340),
            array('faculty_id'=>3,	'addon_id'=>1,	'ebecas_product_id'=>349),
            array('faculty_id'=>3,	'addon_id'=>2,	'ebecas_product_id'=>351),
            array('faculty_id'=>3,	'addon_id'=>3,	'ebecas_product_id'=>378),
            array('faculty_id'=>3,	'addon_id'=>4,	'ebecas_product_id'=>380),
            array('faculty_id'=>4,	'addon_id'=>1,	'ebecas_product_id'=>348),
            array('faculty_id'=>4,	'addon_id'=>2,	'ebecas_product_id'=>350),
            array('faculty_id'=>4,	'addon_id'=>3,	'ebecas_product_id'=>377),
            array('faculty_id'=>4,	'addon_id'=>4,	'ebecas_product_id'=>379),
            array('faculty_id'=>5,	'addon_id'=>1,	'ebecas_product_id'=>263),
            array('faculty_id'=>5,	'addon_id'=>2,	'ebecas_product_id'=>268),
            array('faculty_id'=>5,	'addon_id'=>3,	'ebecas_product_id'=>338),
            array('faculty_id'=>5,	'addon_id'=>4,	'ebecas_product_id'=>343),

        );
        DB::table('faculty_accommodation_addon')->insert($data);


    }
}
