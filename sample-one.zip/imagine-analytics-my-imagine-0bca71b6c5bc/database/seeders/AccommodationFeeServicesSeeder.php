<?php

namespace Database\Seeders;

use App\Models\AccommodationFeeService;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class AccommodationFeeServicesSeeder extends Seeder
{
    public function run()
    {
        $data = array(
            array('id'=>1,'name'=>'Guardianship Placement Inspection Fee','description'=>'Guardianship Placement Inspection Fee','fee'=>150,'daily_fee'=>0,'type'=>'application','taxable'=>TRUE,'enabled'=>TRUE),
            array('id'=>2,'name'=>'Homestay Family Placement - 1 parent + 1 child','description'=>'Homestay Family Placement - 1 parent + 1 child','fee'=>420,'daily_fee'=>0,'type'=>'application','taxable'=>TRUE,'enabled'=>TRUE),
            array('id'=>3,'name'=>'Homestay Family Placement - 1 parent + 2 children','description'=>'Homestay Family Placement - 1 parent + 2 children','fee'=>540,'daily_fee'=>0,'type'=>'application','taxable'=>TRUE,'enabled'=>TRUE),
            array('id'=>4,'name'=>'Homestay Family Placement - 2 parents + 1 child','description'=>'Homestay Family Placement - 2 parents + 1 child','fee'=>540,'daily_fee'=>0,'type'=>'application','taxable'=>TRUE,'enabled'=>TRUE),
            array('id'=>5,'name'=>'Homestay Family Placement - 2 parents + 2 children','description'=>'Homestay Family Placement - 2 parents + 2 children','fee'=>660,'daily_fee'=>0,'type'=>'application','taxable'=>TRUE,'enabled'=>TRUE),
            array('id'=>6,'name'=>'Homestay Individual student placement','description'=>'Homestay Individual student placement','fee'=>275,'daily_fee'=>0,'type'=>'application','taxable'=>TRUE,'enabled'=>TRUE),
            array('id'=>7,'name'=>'Homestay twin share student placement','description'=>'Homestay twin share student placement','fee'=>210,'daily_fee'=>0,'type'=>'application','taxable'=>TRUE,'enabled'=>TRUE),
        );

        DB::table('accommodation_fee_services')->insert($data);
    }
}
