<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;

class DatabaseSeeder extends Seeder
{
    /**
     * Seed the application's database.
     *
     * @return void
     */
    public function run()
    {
        $this->call([
            PermissionsSeeder::class,
            RegionSeeder::class,
            CountrySeeder::class,
            UserSeeder::class,
            VisaSeeder::class,
            LocationSeeder::class,
            LanguageSeeder::class,
            CalendarCategorySeeder::class,
            CalendarSeeder::class,
            AccommodationPriceBookCategorySeeder::class,
            AccommodationPriceBookSeeder::class,
            AccommodationCategorySeeder::class,
            AccommodationFeeServicesSeeder::class,
            AccommodationFeeAddonsSeeder::class,
            AccommodationSeeder::class,
            AccommodationAddonsSeeder::class,
            AccommodationServicesSeeder::class,

            ProgramPriceBookCategorySeeder::class,
            ProgramPriceBookSeeder::class,
            PaymentMethodSeeder::class,
            ProgramFeeServiceSeeder::class,
            ProgramSeeder::class,
            ProgramVisaSeeder::class,
            ProgramServiceSeeder::class,
            TransportationSeeder::class,
            TransportationFeeServiceSeeder::class,
            TransportationFeeAddonsSeeder::class,
            TransportationAddonsSeeder::class,
            TransportationServiceSeeder::class,

            FacultySeeder::class,

            InsuranceSeeder::class,
            FacultyProgramSeeder::class,
            FacultyProgramServiceSeeder::class,
            FacultyInsuranceSeeder::class,
            FacultyPaymentMethodsSeeder::class,
            FacultyTransportSeeder::class,
            FacultyTransportServicesSeeder::class,
            FacultyTransportAddonsSeeder::class,
            FacultyAccommodationSeeder::class,
            FacultyAccommodationAddonSeeder::class,
            FacultyAccommodationServiceSeeder::class,
            AgentSeeder::class,

        ]);
    }
}
