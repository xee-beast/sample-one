<?php

namespace Database\Seeders;

use App\Models\Application;
use App\Services\ApplicationService;
use Illuminate\Database\Seeder;

class FetchApplicationStudentNumberSeeder extends Seeder
{
    protected ApplicationService $applicationService;
    public function __construct(ApplicationService $applicationService)
    {
        $this->applicationService = $applicationService;
    }

    public function run()
    {
        $applications = Application::whereNotNull('student_id')->get();
        foreach ($applications as $application){
            $studentRecord  = $this->applicationService->getStudentNumberFromEbecas($application->student_id);
            if ($studentRecord['data']){
                $application->student_number =$studentRecord['data']['StudentNo'];
                $application->save();
            }
        }
    }
}
