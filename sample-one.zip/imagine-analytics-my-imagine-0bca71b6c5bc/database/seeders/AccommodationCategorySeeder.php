<?php

namespace Database\Seeders;

use App\Models\AccommodationCategory;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class AccommodationCategorySeeder extends Seeder
{
    public function run()
    {
       $data = array(
           array('id'=>1,'name'=>'Individual','description'=>'Individual accommodation','enabled'=>1,'age_restricted'=>0,'min'=>null,'max'=>null),
           array('id'=>2,'name'=>'Twin Share','description'=>'Twin share accommodation','enabled'=>1,'age_restricted'=>0,'min'=>null,'max'=>null),
           array('id'=>3,'name'=>'Family','description'=>'Family accommodation','enabled'=>1,'age_restricted'=>0,'min'=>null,'max'=>null),
           array('id'=>4,'name'=>'Under 18 (8 to 11 years old)','description'=>'Accommodation for 8-11 year olds','enabled'=>1,'age_restricted'=>1,'min'=>8,'max'=>11),
           array('id'=>5,'name'=>'Under 18 (12 to 18 years old)','description'=>'Accommodation for 12-18 year olds','enabled'=>1,'age_restricted'=>1,'min'=>12,'max'=>18),
       );

        DB::table('accommodation_categories')->insert($data);

    }
}
