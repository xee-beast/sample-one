<?php

namespace Database\Seeders;

use App\Models\ProgramPriceBookCategory;
use Illuminate\Database\Seeder;

class ProgramPriceBookCategorySeeder extends Seeder
{
    public function run()
    {
        ProgramPriceBookCategory::create([
            'id'=>1,
            'name'=>'Full Fee (ELICOS)',
            'description'=>'Full fee price book for ELICOS Courses',
            'enabled'=>true
        ]);
        ProgramPriceBookCategory::create([
            'id'=>2,
            'name'=>'Full Fee (VET)',
            'description'=>'Full fee price book for VET Courses',
            'enabled'=>true
        ]);
    }
}
