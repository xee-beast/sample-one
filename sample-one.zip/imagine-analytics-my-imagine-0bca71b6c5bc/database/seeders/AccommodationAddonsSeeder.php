<?php

namespace Database\Seeders;

use App\Models\AccommodationFeeAddon;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class AccommodationAddonsSeeder extends Seeder
{
    public function run()
    {
        $data = array(
            array('accommodation_id'=>1,	'addon_id'=>2,	'mandatory'=>FALSE),
            array('accommodation_id'=>1,	'addon_id'=>3,	'mandatory'=>FALSE),
            array('accommodation_id'=>1,	'addon_id'=>4,	'mandatory'=>FALSE),
            array('accommodation_id'=>2,	'addon_id'=>2,	'mandatory'=>FALSE),
            array('accommodation_id'=>2,	'addon_id'=>3,	'mandatory'=>FALSE),
            array('accommodation_id'=>2,	'addon_id'=>4,	'mandatory'=>FALSE),
            array('accommodation_id'=>3,	'addon_id'=>2,	'mandatory'=>FALSE),
            array('accommodation_id'=>3,	'addon_id'=>3,	'mandatory'=>FALSE),
            array('accommodation_id'=>3,	'addon_id'=>4,	'mandatory'=>FALSE),
            array('accommodation_id'=>4,	'addon_id'=>2,	'mandatory'=>FALSE),
            array('accommodation_id'=>4,	'addon_id'=>3,	'mandatory'=>FALSE),
            array('accommodation_id'=>4,	'addon_id'=>4,	'mandatory'=>FALSE),
            array('accommodation_id'=>5,	'addon_id'=>2,	'mandatory'=>FALSE),
            array('accommodation_id'=>5,	'addon_id'=>3,	'mandatory'=>FALSE),
            array('accommodation_id'=>5,	'addon_id'=>4,	'mandatory'=>FALSE),
            array('accommodation_id'=>6,	'addon_id'=>2,	'mandatory'=>FALSE),
            array('accommodation_id'=>6,	'addon_id'=>3,	'mandatory'=>FALSE),
            array('accommodation_id'=>6,	'addon_id'=>4,	'mandatory'=>FALSE),
            array('accommodation_id'=>7,	'addon_id'=>2,	'mandatory'=>FALSE),
            array('accommodation_id'=>7,	'addon_id'=>3,	'mandatory'=>FALSE),
            array('accommodation_id'=>7,	'addon_id'=>4,	'mandatory'=>FALSE),
            array('accommodation_id'=>8,	'addon_id'=>2,	'mandatory'=>FALSE),
            array('accommodation_id'=>8,	'addon_id'=>3,	'mandatory'=>FALSE),
            array('accommodation_id'=>8,	'addon_id'=>4,	'mandatory'=>FALSE),
            array('accommodation_id'=>9,	'addon_id'=>1,	'mandatory'=>TRUE),
            array('accommodation_id'=>9,	'addon_id'=>2,	'mandatory'=>FALSE),
            array('accommodation_id'=>9,	'addon_id'=>4,	'mandatory'=>FALSE),
            array('accommodation_id'=>10,	'addon_id'=>1,	'mandatory'=>TRUE),
            array('accommodation_id'=>10,	'addon_id'=>2,	'mandatory'=>FALSE),
            array('accommodation_id'=>10,	'addon_id'=>4,	'mandatory'=>FALSE),
            array('accommodation_id'=>11,	'addon_id'=>2,	'mandatory'=>FALSE),
            array('accommodation_id'=>12,	'addon_id'=>2,	'mandatory'=>FALSE),
            array('accommodation_id'=>13,	'addon_id'=>2,	'mandatory'=>FALSE),
            array('accommodation_id'=>14,	'addon_id'=>2,	'mandatory'=>FALSE),

        );

        DB::table('accommodation_addon')->insert($data);
    }
}
