<?php

namespace Database\Seeders;

use App\Models\Faculty;
use App\Models\Location;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class FacultyProgramSeeder extends Seeder
{
    public function run()
    {
        $data = array(
                array('faculty_id'=>1,'program_id'=>29,'calendar_id'=>1,'ebecas_product_id'=>1728),
                array('faculty_id'=>1,'program_id'=>31,'calendar_id'=>1,'ebecas_product_id'=>1702),
                array('faculty_id'=>1,'program_id'=>34,'calendar_id'=>1,'ebecas_product_id'=>1726),
                array('faculty_id'=>1,'program_id'=>35,'calendar_id'=>1,'ebecas_product_id'=>1714),
                array('faculty_id'=>3,'program_id'=>29,'calendar_id'=>1,'ebecas_product_id'=>1727),
                array('faculty_id'=>3,'program_id'=>31,'calendar_id'=>1,'ebecas_product_id'=>2591),
                array('faculty_id'=>3,'program_id'=>34,'calendar_id'=>1,'ebecas_product_id'=>1725),
                array('faculty_id'=>3,'program_id'=>35,'calendar_id'=>1,'ebecas_product_id'=>81),
                array('faculty_id'=>2,'program_id'=>2,'calendar_id'=>3,'ebecas_product_id'=>2707),
                array('faculty_id'=>2,'program_id'=>4,'calendar_id'=>4,'ebecas_product_id'=>36),
                array('faculty_id'=>2,'program_id'=>5,'calendar_id'=>4,'ebecas_product_id'=>2561),
                array('faculty_id'=>2,'program_id'=>6,'calendar_id'=>4,'ebecas_product_id'=>39),
                array('faculty_id'=>2,'program_id'=>7,'calendar_id'=>4,'ebecas_product_id'=>24),
                array('faculty_id'=>2,'program_id'=>37,'calendar_id'=>4,'ebecas_product_id'=>2711),
                array('faculty_id'=>2,'program_id'=>38,'calendar_id'=>4,'ebecas_product_id'=>2714),
                array('faculty_id'=>2,'program_id'=>39,'calendar_id'=>4,'ebecas_product_id'=>2715),
                array('faculty_id'=>2,'program_id'=>40,'calendar_id'=>4,'ebecas_product_id'=>2713),
                array('faculty_id'=>4,'program_id'=>2,'calendar_id'=>5,'ebecas_product_id'=>2708),
                array('faculty_id'=>4,'program_id'=>5,'calendar_id'=>5,'ebecas_product_id'=>2562),
                array('faculty_id'=>4,'program_id'=>7,'calendar_id'=>5,'ebecas_product_id'=>46),
                array('faculty_id'=>4,'program_id'=>14,'calendar_id'=>5,'ebecas_product_id'=>2593),
                array('faculty_id'=>4,'program_id'=>15,'calendar_id'=>5,'ebecas_product_id'=>2589),
                array('faculty_id'=>4,'program_id'=>16,'calendar_id'=>5,'ebecas_product_id'=>2566),
                array('faculty_id'=>4,'program_id'=>17,'calendar_id'=>5,'ebecas_product_id'=>2616),
                array('faculty_id'=>4,'program_id'=>19,'calendar_id'=>5,'ebecas_product_id'=>2564),
                array('faculty_id'=>4,'program_id'=>20,'calendar_id'=>5,'ebecas_product_id'=>2570),
                array('faculty_id'=>4,'program_id'=>23,'calendar_id'=>5,'ebecas_product_id'=>2577),
                array('faculty_id'=>4,'program_id'=>25,'calendar_id'=>5,'ebecas_product_id'=>2618),
                array('faculty_id'=>4,'program_id'=>26,'calendar_id'=>5,'ebecas_product_id'=>2560),
                array('faculty_id'=>4,'program_id'=>27,'calendar_id'=>5,'ebecas_product_id'=>2572),
                array('faculty_id'=>4,'program_id'=>37,'calendar_id'=>5,'ebecas_product_id'=>2712),
                array('faculty_id'=>4,'program_id'=>38,'calendar_id'=>5,'ebecas_product_id'=>2716),
                array('faculty_id'=>5,'program_id'=>2,'calendar_id'=>2,'ebecas_product_id'=>2709),
                array('faculty_id'=>5,'program_id'=>14,'calendar_id'=>4,'ebecas_product_id'=>2575),
                array('faculty_id'=>5,'program_id'=>15,'calendar_id'=>4,'ebecas_product_id'=>2590),
                array('faculty_id'=>5,'program_id'=>16,'calendar_id'=>4,'ebecas_product_id'=>2567),
                array('faculty_id'=>5,'program_id'=>17,'calendar_id'=>4,'ebecas_product_id'=>2617),
                array('faculty_id'=>5,'program_id'=>19,'calendar_id'=>4,'ebecas_product_id'=>2565),
                array('faculty_id'=>5,'program_id'=>20,'calendar_id'=>4,'ebecas_product_id'=>2571),
                array('faculty_id'=>5,'program_id'=>22,'calendar_id'=>4,'ebecas_product_id'=>2558),
                array('faculty_id'=>5,'program_id'=>23,'calendar_id'=>4,'ebecas_product_id'=>2578),
                array('faculty_id'=>5,'program_id'=>25,'calendar_id'=>4,'ebecas_product_id'=>2619),
                array('faculty_id'=>5,'program_id'=>26,'calendar_id'=>4,'ebecas_product_id'=>2559),
                array('faculty_id'=>5,'program_id'=>27,'calendar_id'=>4,'ebecas_product_id'=>2573),

        );

        DB::table('faculty_program')->insert($data);


    }
}
