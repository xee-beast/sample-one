<?php

namespace Database\Seeders;

use App\Models\AccommodationPriceBookCategory;
use Illuminate\Database\Seeder;

class AccommodationPriceBookCategorySeeder extends Seeder
{
    public function run()
    {
        AccommodationPriceBookCategory::create([
            'id'=>1,
            'name'=>'Full Price',
            'description'=>'Full Price',
            'enabled'=>true
        ]);
    }
}
