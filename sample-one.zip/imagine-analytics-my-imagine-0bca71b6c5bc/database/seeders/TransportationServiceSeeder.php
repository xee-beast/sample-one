<?php

namespace Database\Seeders;

use App\Models\TransportationFeeAddon;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class TransportationServiceSeeder extends Seeder
{
    public function run()
    {
       $data = array(
           array('transportation_id'=>1,'transportation_fee_service_id'=>1,'mandatory'=>FALSE),
           array('transportation_id'=>2,'transportation_fee_service_id'=>2,'mandatory'=>FALSE),
           array('transportation_id'=>3,'transportation_fee_service_id'=>3,'mandatory'=>FALSE),
           array('transportation_id'=>4,'transportation_fee_service_id'=>4,'mandatory'=>FALSE),
           array('transportation_id'=>5,'transportation_fee_service_id'=>6,'mandatory'=>FALSE),
           array('transportation_id'=>6,'transportation_fee_service_id'=>5,'mandatory'=>FALSE),
           array('transportation_id'=>7,'transportation_fee_service_id'=>7,'mandatory'=>FALSE),
           array('transportation_id'=>8,'transportation_fee_service_id'=>8,'mandatory'=>FALSE),
           array('transportation_id'=>9,'transportation_fee_service_id'=>1,'mandatory'=>FALSE),
           array('transportation_id'=>10,'transportation_fee_service_id'=>2,'mandatory'=>FALSE),
           array('transportation_id'=>11,'transportation_fee_service_id'=>3,'mandatory'=>FALSE),
           array('transportation_id'=>12,'transportation_fee_service_id'=>4,'mandatory'=>FALSE),
           array('transportation_id'=>13,'transportation_fee_service_id'=>7,'mandatory'=>FALSE),
           array('transportation_id'=>14,'transportation_fee_service_id'=>8,'mandatory'=>FALSE),
           array('transportation_id'=>15,'transportation_fee_service_id'=>5,'mandatory'=>FALSE),
           array('transportation_id'=>16,'transportation_fee_service_id'=>6,'mandatory'=>FALSE),
       );

        DB::table('transportation_service')->insert($data);
    }
}
