<?php

namespace Database\Seeders;

use App\Models\Visa;
use Illuminate\Database\Seeder;

class VisaSeeder extends Seeder
{
    public function run()
    {
        Visa::create(['id'=>1,'name'=>'Student Visa','max_weeks'=>300,'is_student'=>TRUE,'enabled'=>TRUE]);
        Visa::create(['id'=>2,'name'=>'Tourist/Visitor Visa','max_weeks'=>12,'is_student'=>FALSE,'enabled'=>TRUE]);
        Visa::create(['id'=>3,'name'=>'Working Holiday Visa','max_weeks'=>17,'is_student'=>FALSE,'enabled'=>TRUE]);
        Visa::create(['id'=>4,'name'=>'Other Visa','max_weeks'=>300,'is_student'=>FALSE,'enabled'=>TRUE]);
        Visa::create(['id'=>5,'name'=>'Temporary Visa','max_weeks'=>300,'is_student'=>FALSE,'enabled'=>TRUE]);

    }
}
