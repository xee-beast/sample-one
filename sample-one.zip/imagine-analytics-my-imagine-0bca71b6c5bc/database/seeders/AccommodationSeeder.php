<?php

namespace Database\Seeders;

use App\Models\Accommodation;
use App\Models\AccommodationCategory;
use App\Models\AccommodationPriceBook;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class AccommodationSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $data = array(
            array('id'=>1,'name'=>'Homestay Individual - Room only accommodation','description'=>'Homestay Individual - Room only accommodation','enabled'=>TRUE,'accommodation_price_book_id'=>1,'accommodation_category_id'=>1,'length_restriction_enabled'=>TRUE,'min_length'=>1,'max_length'=>150),
            array('id'=>2,'name'=>'Homestay Individual - b\'fast & dinner daily','description'=>'Homestay Individual - b\'fast & dinner daily','enabled'=>TRUE,'accommodation_price_book_id'=>2,'accommodation_category_id'=>1,'length_restriction_enabled'=>TRUE,'min_length'=>1,'max_length'=>150),
            array('id'=>3,'name'=>'Homestay Individual- 3 meals daily','description'=>'Homestay Individual- 3 meals daily','enabled'=>TRUE,'accommodation_price_book_id'=>3,'accommodation_category_id'=>1,'length_restriction_enabled'=>TRUE,'min_length'=>1,'max_length'=>150),
            array('id'=>4,'name'=>'Homestay Individual- b\'fast & dinner weekdays, 3 meals Sat & Sun','description'=>'Homestay Individual- b\'fast & dinner weekdays, 3 meals Sat & Sun','enabled'=>TRUE,'accommodation_price_book_id'=>4,'accommodation_category_id'=>1,'length_restriction_enabled'=>TRUE,'min_length'=>1,'max_length'=>150),
            array('id'=>5,'name'=>'Homestay Twin Share - 3 meals daily','description'=>'Homestay Twin Share - 3 meals daily','enabled'=>TRUE,'accommodation_price_book_id'=>5,'accommodation_category_id'=>2,'length_restriction_enabled'=>TRUE,'min_length'=>1,'max_length'=>150),
            array('id'=>6,'name'=>'Homestay Twin Share - b\'fast & dinner daily','description'=>'Homestay Twin Share - b\'fast & dinner daily','enabled'=>TRUE,'accommodation_price_book_id'=>6,'accommodation_category_id'=>2,'length_restriction_enabled'=>TRUE,'min_length'=>1,'max_length'=>150),
            array('id'=>7,'name'=>'Homestay Twin Share - b\'fast & dinner weekdays, 3 meals Sat & Sun','description'=>'Homestay Twin Share - b\'fast & dinner weekdays, 3 meals Sat & Sun','enabled'=>TRUE,'accommodation_price_book_id'=>7,'accommodation_category_id'=>2,'length_restriction_enabled'=>TRUE,'min_length'=>1,'max_length'=>150),
            array('id'=>8,'name'=>'Homestay Twin Share- Room only accommodation','description'=>'Homestay Twin Share- Room only accommodation','enabled'=>TRUE,'accommodation_price_book_id'=>8,'accommodation_category_id'=>2,'length_restriction_enabled'=>TRUE,'min_length'=>1,'max_length'=>150),
            array('id'=>9,'name'=>'Homestay - Full service (for 12-18 yr olds; inc 3 x meals & transport)','description'=>'Homestay - Full service (for 12-18 yr olds; inc 3 x meals & transport)','enabled'=>TRUE,'accommodation_price_book_id'=>9,'accommodation_category_id'=>5,'length_restriction_enabled'=>TRUE,'min_length'=>1,'max_length'=>150),
            array('id'=>10,'name'=>'Homestay - Full service (for 8-11 yr olds; inc 3 x meals & transport)','description'=>'Homestay - Full service (for 8-11 yr olds; inc 3 x meals & transport)','enabled'=>TRUE,'accommodation_price_book_id'=>10,'accommodation_category_id'=>4,'length_restriction_enabled'=>TRUE,'min_length'=>1,'max_length'=>150),
            array('id'=>11,'name'=>'Homestay Family - 1 parent + 1 child - 3 meals, transport + Internet','description'=>'Homestay Family - 1 parent + 1 child - 3 meals, transport + Internet','enabled'=>TRUE,'accommodation_price_book_id'=>11,'accommodation_category_id'=>3,'length_restriction_enabled'=>TRUE,'min_length'=>1,'max_length'=>150),
            array('id'=>12,'name'=>'Homestay Family - 1 parent + 2 children - 3 meals, transport + Internet','description'=>'Homestay Family - 1 parent + 2 children - 3 meals, transport + Internet','enabled'=>TRUE,'accommodation_price_book_id'=>12,'accommodation_category_id'=>3,'length_restriction_enabled'=>TRUE,'min_length'=>1,'max_length'=>150),
            array('id'=>13,'name'=>'Homestay Family - 2 parents + 1 child - 3 meals, transport + Internet','description'=>'Homestay Family - 2 parents + 1 child - 3 meals, transport + Internet','enabled'=>TRUE,'accommodation_price_book_id'=>13,'accommodation_category_id'=>3,'length_restriction_enabled'=>TRUE,'min_length'=>1,'max_length'=>150),
            array('id'=>14,'name'=>'Homestay Family - 2 parents + 2 children - 3 meals, transport + Internet','description'=>'Homestay Family - 2 parents + 2 children - 3 meals, transport + Internet','enabled'=>TRUE,'accommodation_price_book_id'=>14,'accommodation_category_id'=>3,'length_restriction_enabled'=>TRUE,'min_length'=>1,'max_length'=>150),
        );

        DB::table('accommodations')->insert($data);

    }
}
