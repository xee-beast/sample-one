<?php

namespace Database\Seeders;

use App\Models\Calendar;
use App\Models\Program;
use App\Models\ProgramFeeService;
use App\Models\ProgramPriceBook;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class ProgramServiceSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {

        $data = array(
            array('program_id'=>1,'program_fee_service_id'=>2,'mandatory'=>TRUE),
            array('program_id'=>1,'program_fee_service_id'=>1,'mandatory'=>TRUE),
            array('program_id'=>2,'program_fee_service_id'=>2,'mandatory'=>TRUE),
            array('program_id'=>2,'program_fee_service_id'=>1,'mandatory'=>TRUE),
            array('program_id'=>3,'program_fee_service_id'=>2,'mandatory'=>TRUE),
            array('program_id'=>3,'program_fee_service_id'=>1,'mandatory'=>TRUE),
            array('program_id'=>4,'program_fee_service_id'=>2,'mandatory'=>TRUE),
            array('program_id'=>4,'program_fee_service_id'=>1,'mandatory'=>TRUE),
            array('program_id'=>5,'program_fee_service_id'=>2,'mandatory'=>TRUE),
            array('program_id'=>5,'program_fee_service_id'=>1,'mandatory'=>TRUE),
            array('program_id'=>6,'program_fee_service_id'=>2,'mandatory'=>TRUE),
            array('program_id'=>6,'program_fee_service_id'=>1,'mandatory'=>TRUE),
            array('program_id'=>7,'program_fee_service_id'=>2,'mandatory'=>TRUE),
            array('program_id'=>7,'program_fee_service_id'=>3,'mandatory'=>TRUE),
            array('program_id'=>7,'program_fee_service_id'=>1,'mandatory'=>TRUE),
            array('program_id'=>8,'program_fee_service_id'=>2,'mandatory'=>TRUE),
            array('program_id'=>8,'program_fee_service_id'=>1,'mandatory'=>TRUE),
            array('program_id'=>9,'program_fee_service_id'=>2,'mandatory'=>TRUE),
            array('program_id'=>9,'program_fee_service_id'=>1,'mandatory'=>TRUE),
            array('program_id'=>10,'program_fee_service_id'=>2,'mandatory'=>TRUE),
            array('program_id'=>10,'program_fee_service_id'=>1,'mandatory'=>TRUE),
            array('program_id'=>11,'program_fee_service_id'=>4,'mandatory'=>TRUE),
            array('program_id'=>11,'program_fee_service_id'=>1,'mandatory'=>TRUE),
            array('program_id'=>12,'program_fee_service_id'=>2,'mandatory'=>TRUE),
            array('program_id'=>12,'program_fee_service_id'=>1,'mandatory'=>TRUE),
            array('program_id'=>13,'program_fee_service_id'=>1,'mandatory'=>TRUE),
            array('program_id'=>14,'program_fee_service_id'=>1,'mandatory'=>TRUE),
            array('program_id'=>15,'program_fee_service_id'=>2,'mandatory'=>TRUE),
            array('program_id'=>15,'program_fee_service_id'=>1,'mandatory'=>TRUE),
            array('program_id'=>16,'program_fee_service_id'=>1,'mandatory'=>TRUE),
            array('program_id'=>17,'program_fee_service_id'=>1,'mandatory'=>TRUE),
            array('program_id'=>18,'program_fee_service_id'=>2,'mandatory'=>TRUE),
            array('program_id'=>18,'program_fee_service_id'=>1,'mandatory'=>TRUE),
            array('program_id'=>19,'program_fee_service_id'=>2,'mandatory'=>TRUE),
            array('program_id'=>19,'program_fee_service_id'=>1,'mandatory'=>TRUE),
            array('program_id'=>20,'program_fee_service_id'=>2,'mandatory'=>TRUE),
            array('program_id'=>20,'program_fee_service_id'=>1,'mandatory'=>TRUE),
            array('program_id'=>21,'program_fee_service_id'=>2,'mandatory'=>TRUE),
            array('program_id'=>21,'program_fee_service_id'=>1,'mandatory'=>TRUE),
            array('program_id'=>22,'program_fee_service_id'=>2,'mandatory'=>TRUE),
            array('program_id'=>22,'program_fee_service_id'=>1,'mandatory'=>TRUE),
            array('program_id'=>23,'program_fee_service_id'=>2,'mandatory'=>TRUE),
            array('program_id'=>23,'program_fee_service_id'=>1,'mandatory'=>TRUE),
            array('program_id'=>24,'program_fee_service_id'=>2,'mandatory'=>TRUE),
            array('program_id'=>24,'program_fee_service_id'=>1,'mandatory'=>TRUE),
            array('program_id'=>25,'program_fee_service_id'=>2,'mandatory'=>TRUE),
            array('program_id'=>25,'program_fee_service_id'=>1,'mandatory'=>TRUE),
            array('program_id'=>26,'program_fee_service_id'=>2,'mandatory'=>TRUE),
            array('program_id'=>26,'program_fee_service_id'=>1,'mandatory'=>TRUE),
            array('program_id'=>27,'program_fee_service_id'=>2,'mandatory'=>TRUE),
            array('program_id'=>27,'program_fee_service_id'=>1,'mandatory'=>TRUE),
            array('program_id'=>28,'program_fee_service_id'=>6,'mandatory'=>TRUE),
            array('program_id'=>28,'program_fee_service_id'=>1,'mandatory'=>TRUE),
            array('program_id'=>29,'program_fee_service_id'=>6,'mandatory'=>TRUE),
            array('program_id'=>29,'program_fee_service_id'=>1,'mandatory'=>TRUE),
            array('program_id'=>30,'program_fee_service_id'=>6,'mandatory'=>TRUE),
            array('program_id'=>30,'program_fee_service_id'=>1,'mandatory'=>TRUE),
            array('program_id'=>31,'program_fee_service_id'=>6,'mandatory'=>TRUE),
            array('program_id'=>31,'program_fee_service_id'=>1,'mandatory'=>TRUE),
            array('program_id'=>32,'program_fee_service_id'=>6,'mandatory'=>TRUE),
            array('program_id'=>32,'program_fee_service_id'=>1,'mandatory'=>TRUE),
            array('program_id'=>33,'program_fee_service_id'=>6,'mandatory'=>TRUE),
            array('program_id'=>33,'program_fee_service_id'=>1,'mandatory'=>TRUE),
            array('program_id'=>34,'program_fee_service_id'=>1,'mandatory'=>TRUE),
            array('program_id'=>35,'program_fee_service_id'=>6,'mandatory'=>TRUE),
            array('program_id'=>35,'program_fee_service_id'=>1,'mandatory'=>TRUE),
            array('program_id'=>36,'program_fee_service_id'=>6,'mandatory'=>TRUE),
            array('program_id'=>36,'program_fee_service_id'=>1,'mandatory'=>TRUE),
            array('program_id'=>37,'program_fee_service_id'=>7,'mandatory'=>TRUE),
            array('program_id'=>37,'program_fee_service_id'=>1,'mandatory'=>TRUE),
            array('program_id'=>37,'program_fee_service_id'=>2,'mandatory'=>TRUE),
            array('program_id'=>38,'program_fee_service_id'=>1,'mandatory'=>TRUE),
            array('program_id'=>38,'program_fee_service_id'=>2,'mandatory'=>TRUE),
            array('program_id'=>39,'program_fee_service_id'=>1,'mandatory'=>TRUE),
            array('program_id'=>39,'program_fee_service_id'=>2,'mandatory'=>TRUE),
            array('program_id'=>40,'program_fee_service_id'=>1,'mandatory'=>TRUE),
            array('program_id'=>40,'program_fee_service_id'=>2,'mandatory'=>TRUE),

        );



        DB::table('program_service')->insert($data);
    }
}
