<?php

namespace Database\Factories;

use App\Models\Insurance;
use Illuminate\Database\Eloquent\Factories\Factory;

/**
 * @extends \Illuminate\Database\Eloquent\Factories\Factory<\App\Models\InsuranceFee>
 */
class InsuranceFeeFactory extends Factory
{
    /**
     * Define the model's default state.
     *
     * @return array<string, mixed>
     */
    public function definition()
    {
        return [
            'duration' => $this->faker->numberBetween(1,9),
            'fee' => $this->faker->numberBetween(10,50),
            'insurance_id' => Insurance::first()->id
        ];
    }
}
