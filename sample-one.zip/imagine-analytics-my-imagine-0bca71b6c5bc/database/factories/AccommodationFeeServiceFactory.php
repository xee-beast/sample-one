<?php

namespace Database\Factories;

use Illuminate\Database\Eloquent\Factories\Factory;

/**
 * @extends \Illuminate\Database\Eloquent\Factories\Factory<\App\Models\AccommodationFeeService>
 */
class AccommodationFeeServiceFactory extends Factory
{
    /**
     * Define the model's default state.
     *
     * @return array<string, mixed>
     */
    public function definition()
    {
        return [
            'name' => $this->faker->firstName().' Service',
            'description' => $this->faker->text(20),
            'type' => 'application',
            'taxable' => true,
            'fee' => $this->faker->numberBetween(10,50),
            'daily_fee' => $this->faker->numberBetween(10,50),
            'enabled' => true,
        ];
    }
}
