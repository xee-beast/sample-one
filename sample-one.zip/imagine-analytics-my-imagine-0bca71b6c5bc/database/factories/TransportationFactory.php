<?php

namespace Database\Factories;

use App\Models\Location;
use Illuminate\Database\Eloquent\Factories\Factory;

/**
 * @extends \Illuminate\Database\Eloquent\Factories\Factory<\App\Models\Transportation>
 */
class TransportationFactory extends Factory
{
    /**
     * Define the model's default state.
     *
     * @return array<string, mixed>
     */
    public function definition()
    {
        return [
            'name' => $this->faker->firstName().' Transport',
            'description' => $this->faker->text(20),
            'enabled' => true,
            'taxable' => true,
            'return' => false,
            'origin' => Location::first()->id,
            'destination' => Location::first()->id,
            'fee' => $this->faker->numberBetween(10,50),
        ];
    }
}
