<?php

namespace Database\Factories;

use App\Models\CalendarCategory;
use Illuminate\Database\Eloquent\Factories\Factory;

/**
 * @extends \Illuminate\Database\Eloquent\Factories\Factory<\App\Models\CalendarCategory>
 */

class CalendarCategoryFactory extends Factory
{

    public function definition(): array
    {
        return [
            'name' => $this->faker->name(),
            'description' => $this->faker->text(100),
            'enabled'=>true
        ];
    }
}
