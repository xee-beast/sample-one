<?php

namespace Database\Factories;

use App\Models\Region;
use App\Models\SpecialOffer;
use App\Models\SpecialOfferCategory;
use Carbon\Carbon;
use Illuminate\Database\Eloquent\Factories\Factory;

/**
 * @extends \Illuminate\Database\Eloquent\Factories\Factory<\App\Models\SpecialOffer>
 */
class SpecialOfferFactory extends Factory
{
    /**
     * Define the model's default state.
     *
     * @return array<string, mixed>
     */
    public function definition()
    {
        $category = SpecialOfferCategory::first();
        if(is_null($category)){
            $category = SpecialOfferCategory::create(['name'=>$this->faker->text(5),'enabled'=>1]);
        }

        return [
            'name' => $this->faker->text(20),
            'description' => $this->faker->text(50),
            'enabled' => false,
            'category_id' => $category->id,
            'region_id' => Region::first()->id,
            'application_submitted_from' => Carbon::now()->format('Y-m-d'),
            'application_submitted_to' => Carbon::now()->addDays(5)->format('Y-m-d'),
            'application_program_from' => Carbon::now()->format('Y-m-d'),
            'application_program_to' => Carbon::now()->addDays(5)->format('Y-m-d'),
            'onshore' => true,
            'offshore' => true,
            'restrict_by_program_length' => false,
            'services' => [],
            'pricebooks' => [],
            'locations' => []
        ];
    }
}
