<?php

namespace Database\Factories;

use Illuminate\Database\Eloquent\Factories\Factory;

/**
 * @extends \Illuminate\Database\Eloquent\Factories\Factory<\App\Models\Program>
 */
class ProgramFactory extends Factory
{
    /**
     * Define the model's default state.
     *
     * @return array<string, mixed>
     */
    public function definition()
    {
        return [
            'name' => $this->faker->firstName().' Program',
            'description' => $this->faker->text(20),
            'enabled' => true,
            'program_price_book_id' => 36,
            'length_restriction_enabled' => false,
            'age_restriction_enabled' => false,
            'visa_restriction_enabled' => false,
            'is_language' => false
        ];
    }
}
