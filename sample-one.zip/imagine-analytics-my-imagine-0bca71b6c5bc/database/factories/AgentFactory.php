<?php

namespace Database\Factories;

use App\Models\Agent;
use App\Models\Country;
use Illuminate\Database\Eloquent\Factories\Factory;
use Illuminate\Support\Str;


class AgentFactory extends Factory
{
    /**
     * Define the model's default state.
     *
     * @return array<string, mixed>
     */
    public function definition()
    {
        $latest_agent = Agent::max('ebecas_id');

        return [
            'name'=>$this->faker->company(),
            'ebecas_id' => $latest_agent ? $latest_agent+1 : 1,
            'created_at'=>now(),
            'updated_at'=>now()
        ];
    }


}
