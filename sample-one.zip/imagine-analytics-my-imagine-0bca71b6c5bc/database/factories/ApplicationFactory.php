<?php

namespace Database\Factories;

use App\Models\Application;
use App\Models\User;
use Illuminate\Database\Eloquent\Factories\Factory;

class ApplicationFactory extends Factory
{
    protected $model = Application::class;

    public function definition(): array
    {
        return [
            'status'=>'draft',
            'created_by'=>User::first()->id,
            'owner'=>User::first()->id,
            'created_at'=>now(),
            'updated_at'=>now()
        ];
    }
}
