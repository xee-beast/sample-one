<?php

namespace Database\Factories;

use App\Models\ApplicationDetail;
use App\Models\Country;
use App\Models\Language;
use App\Models\Visa;
use Illuminate\Database\Eloquent\Factories\Factory;

class ApplicationDetailFactory extends Factory
{
    protected $model = ApplicationDetail::class;

    public function definition(): array
    {
        return [
            'salutation' => 'Mr',
            'gender'=>'Male',
            'first_name'=>fake()->firstName(),
            'middle_name'=>null,
            'last_name'=>fake()->lastName(),
            'email'=>fake()->email(),
            'mobile'=>fake()->phoneNumber(),
            'marketing_consent'=>false,
            'dob'=>fake()->date(),
            'passport_number'=>fake()->randomNumber(5),
            'country'=>Country::first()->id,
            'country_of_birth'=>Country::first()->id+1,
            'language'=>Language::first()->id,
            'occupation'=>fake()->jobTitle(),
            'living_in_australia'=>false,
            'australian_resident'=>false,
            'has_australian_visa'=>false,
            'current_visa_type'=>null,
            'current_visa_expiry'=>null,
            'has_had_student_visa'=>false,
            'visa_applying_for'=>Visa::where('is_student', true)->first()->id,
            'visa_application_australia'=>false,
            'visa_application_location'=>Country::find(2)->id,
            'current_residence_address_line_1'=>fake()->streetAddress(),
            'current_residence_address_line_2'=>null,
            'current_residence_address_line_3'=>null,
            'current_residence_address_city'=>fake()->city(),
            'current_residence_address_state'=>fake()->city(),
            'current_residence_address_postcode'=>"1234",
            'current_residence_address_country'=>Country::find(3)->id,
            'next_of_kin_full_name'=>fake()->name(),
            'next_of_kin_phone'=>fake()->phoneNumber(),
            'next_of_kin_email'=>fake()->email(),
            'next_of_kin_relationship'=>"Partner",
            'agent_assistance'=>true,
            'agent_name'=>fake()->company(),
            'created_at'=>now(),
            'updated_at'=>now(),
        ];
    }
}
