<?php

namespace Database\Factories;

use App\Models\Country;
use Illuminate\Database\Eloquent\Factories\Factory;
use Illuminate\Support\Str;

/**
 * @extends \Illuminate\Database\Eloquent\Factories\Factory<\App\Models\User>
 */
class UserFactory extends Factory
{
    /**
     * Define the model's default state.
     *
     * @return array<string, mixed>
     */
    public function definition()
    {
        return [
            'first_name' => $this->faker->name(),
            'last_name' => $this->faker->name(),
            'email' => uniqid()."@".uniqid().'.com',
            'email_verified_at' => now(),
            'verified_at' => now(),
            'mobile'=>null,
            'password' => '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', // password
            'remember_token' => Str::random(10),
            'user_type' => config('constants.user_types.staff'),
            'enabled'=>true,
            'country_id' => Country::first()->id
        ];
    }

    /**
     * Indicate that the model's email address should be unverified.
     *
     * @return static
     */
    public function emailUnverified()
    {
        return $this->state(function (array $attributes) {
            return [
                'email_verified_at' => null,
            ];
        });
    }

    /**
     * Indicate that the model's account should be unverified.
     *
     * @return static
     */
    public function unverified()
    {
        return $this->state(function (array $attributes) {
            return [
                'verified_at' => null,
            ];
        });
    }

    /**
     * Indicate that the model's account should be disabled.
     *
     * @return static
     */
    public function disabled()
    {
        return $this->state(function (array $attributes) {
            return [
                'enabled' => false,
            ];
        });
    }

    /**
     * Indicate that the model has type staff.
     *
     * @return Factory
     */
    public function isOfStaffType()
    {
        return $this->state(function (array $attributes) {
            return [
                'user_type' => config('constants.user_types.staff'),
            ];
        });
    }

    /**
     * Indicate that the model has type agent.
     *
     * @return Factory
     */
    public function isOfAgentType()
    {
        return $this->state(function (array $attributes) {
            return [
                'user_type' => config('constants.user_types.agent'),
            ];
        });
    }

    /**
     * Indicate that the model has type student.
     *
     * @return Factory
     */
    public function isOfStudentType()
    {
        return $this->state(function (array $attributes) {
            return [
                'user_type' => config('constants.user_types.student'),
            ];
        });
    }


}
