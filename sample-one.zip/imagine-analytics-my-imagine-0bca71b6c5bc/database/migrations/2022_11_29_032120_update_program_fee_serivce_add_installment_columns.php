<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('program_fee_services', function (Blueprint $table) {
            $table->boolean('instalment_plan_enabled')->after('type')->default(false);
            $table->decimal('first_instalment_amount')->after('instalment_plan_enabled')->nullable(true);
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('program_fee_services', function (Blueprint $table) {
            $table->dropColumn(['instalment_plan_enabled', 'first_instalment_amount']);
        });
    }
};
