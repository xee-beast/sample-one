<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('faculty_insurance', function (Blueprint $table) {
            $table->foreignId('faculty_id')->constrained('faculties');
            $table->foreignId('insurance_fee_id')->constrained('insurance_fees');
            $table->foreignId('insurance_id')->constrained('insurances');
            $table->integer('ebecas_product_id');

            $table->unique(['insurance_fee_id', 'ebecas_product_id'], 'faculty_id');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('faculty_insurance');
    }
};
