<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('transportation_fee_services', function (Blueprint $table) {
            $table->id();

            $table->string('name',100);
            $table->string('description',255)->nullable(true);
            $table->boolean("enabled")->default(true);
            $table->boolean("taxable")->default(false);
            $table->boolean('age_restriction_enabled')->default(false);
            $table->integer('min_age')->nullable();
            $table->integer('max_age')->nullable();
            $table->decimal('fee');

            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('transportation_fee_services');
    }
};
