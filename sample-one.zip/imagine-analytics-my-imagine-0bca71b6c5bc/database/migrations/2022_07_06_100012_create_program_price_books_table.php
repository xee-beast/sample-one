<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('program_price_books', function (Blueprint $table) {
            $table->id();

            $table->string('name',100);
            $table->string('description',255)->nullable(true);
            $table->date('expiry_date');
            $table->boolean("enabled")->default(true);
            $table->boolean("expired")->default(false);
            $table->foreignId('program_price_book_category_id')->constrained('program_price_book_categories');

            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('program_price_books');
    }
};
