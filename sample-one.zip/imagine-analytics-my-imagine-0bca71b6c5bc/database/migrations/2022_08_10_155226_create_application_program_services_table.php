<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('application_program_service', function (Blueprint $table) {
            $table->foreignId('application_id')->constrained('applications');
            $table->foreignId('service_id')->constrained('program_fee_services');
            $table->foreignId('program_id')->constrained('programs');
            $table->foreignId('faculty_id')->constrained('faculties');
            $table->date('program_start_date');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('application_program_service');
    }
};
