<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateInsurancesTable extends Migration
{
    public function up()
    {
        Schema::create('insurances', function (Blueprint $table) {
            $table->id();
            $table->string('type')->unique();
            $table->boolean('taxable')->default(false);
            $table->timestamps();
        });


        Schema::create('insurance_fees', function (Blueprint $table) {
            $table->id();
            $table->integer('duration');
            $table->float('fee');
            $table->foreignId('insurance_id')->nullable()->constrained('insurances')->onUpdate('cascade')->onDelete('cascade');
            $table->timestamps();

            $table->unique(['duration', 'insurance_id']);
        });




    }

    public function down()
    {
        Schema::dropIfExists('insurances');
        Schema::dropIfExists('insurance_fees');
    }
}
