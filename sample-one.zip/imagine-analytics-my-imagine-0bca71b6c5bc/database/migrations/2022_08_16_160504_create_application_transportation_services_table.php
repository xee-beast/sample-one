<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('application_transportation_service', function (Blueprint $table) {
            $table->foreignId('application_id')->constrained('applications');
            $table->foreignId('service_id')->constrained('transportation_fee_services');
            $table->foreignId('transportation_id')->constrained('transportations');
            $table->foreignId('faculty_id')->constrained('faculties');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('application_transportation_service');
    }
};
