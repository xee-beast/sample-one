<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class AddExtraColumnsPermissions extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('permissions', function (Blueprint $table) {
            $table->string('label',100);
            $table->mediumText('description');
            $table->foreignId('group_id')->constrained('permissions_groups');

        });

        Schema::table('roles', function (Blueprint $table) {
            $table->mediumText('description')->nullable()->after('guard_name');
            $table->boolean('system')->default(false)->after('description');;
        });

    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('permissions', function (Blueprint $table) {
            $table->dropColumn('label');
            $table->dropColumn('description');
            $table->dropColumn('group_id');
        });

        Schema::table('roles', function (Blueprint $table) {
            $table->dropColumn('description');
            $table->dropColumn('system');
        });
    }
}
