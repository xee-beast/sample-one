<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('application_details', function (Blueprint $table) {
            $table->id();

            $table->foreignId('application_id')->constrained('applications')->onDelete('cascade');
            $table->string("salutation");
            $table->string("other_salutation")->nullable(true);
            $table->string("gender");
            $table->string("first_name");
            $table->string("middle_name")->nullable(true);
            $table->string("last_name");
            $table->string("email");
            $table->string("mobile")->nullable(true);
            $table->boolean('marketing_consent')->default(false);
            $table->date("dob");
            $table->string("passport_number");
            $table->foreignId('country')->constrained('countries');
            $table->foreignId('country_of_birth')->constrained('countries');
            $table->foreignId('language')->constrained('languages');
            $table->string("occupation")->nullable(true);

            $table->boolean('living_in_australia')->default(false);
            $table->boolean('australian_resident')->default(false);
            $table->boolean('has_australian_visa')->default(false);
            $table->foreignId('current_visa_type')->nullable(true)->constrained('visas');
            $table->date("current_visa_expiry")->nullable(true);
            $table->boolean('has_had_student_visa')->default(false);
            $table->foreignId('visa_applying_for')->constrained('visas');
            $table->boolean('visa_application_australia')->default(false);
            $table->foreignId("visa_application_location")->nullable(true)->constrained('countries');

            $table->string("current_residence_address_line_1");
            $table->string("current_residence_address_line_2")->nullable(true);
            $table->string("current_residence_address_line_3")->nullable(true);
            $table->string("current_residence_address_city");
            $table->string("current_residence_address_state")->nullable(true);
            $table->string("current_residence_address_postcode");
            $table->foreignId('current_residence_address_country')->constrained('countries');

            $table->string("next_of_kin_full_name");
            $table->string("next_of_kin_phone");
            $table->string("next_of_kin_email");
            $table->string("next_of_kin_relationship");

            $table->boolean("agent_assistance")->default(false);
            $table->string("agent_name")->nullable(true);

            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('application_details');
    }
};
