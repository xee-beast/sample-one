<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('faculty_transportation_service', function (Blueprint $table) {
            $table->foreignId('faculty_id')->constrained('faculties');
            $table->foreignId('fee_service_id')->constrained('transportation_fee_services');
            $table->decimal('fee')->nullable(true);
            $table->integer('ebecas_product_id');

             $table->unique(['fee_service_id', 'faculty_id']);
             // the default identifier 'faculty_transportation_service_ebecas_product_id_faculty_id_unique' was long so gave a manual identifier
             $table->unique(['ebecas_product_id', 'faculty_id'], 'faculty_transportation_service_ebecas_product_faculty_unique');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('faculty_transportation_service');
    }
};
