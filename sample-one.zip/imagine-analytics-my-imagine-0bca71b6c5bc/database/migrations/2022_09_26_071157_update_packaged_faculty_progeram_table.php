<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('packaged_faculty_program', function (Blueprint $table) {
            $table->dropConstrainedForeignId('price_book_id');
            $table->decimal('discount', 8, 4);
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('packaged_faculty_program', function (Blueprint $table) {
            $table->dropColumn('discount', 8, 4);
            $table->foreignId('price_book_id')->constrained('program_price_books');
        });
    }
};
