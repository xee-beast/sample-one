<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('packaged_faculty_program', function (Blueprint $table) {
            $table->foreignId('package_id')->constrained('packaged_programs');
            $table->foreignId('faculty_id')->constrained('faculties');
            $table->foreignId('program_id')->constrained('programs');
            $table->foreignId('price_book_id')->constrained('program_price_books');
            $table->integer('order', true);
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('packaged_programs');
    }
};
