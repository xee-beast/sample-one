<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('special_offer_service', function (Blueprint $table) {
            $table->foreignId('special_offer_id')->constrained('special_offers')->onDelete('cascade');
            $table->foreignId('service_id')->constrained('program_fee_services');
            $table->enum('off_type', ['percentage', 'value', 'override']);
            $table->decimal('value',8,4)->nullable(true);
            $table->boolean('override_duration')->default(false);
            $table->integer('duration_length_start')->nullable(true);
            $table->integer('duration_length_end')->nullable(true);
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('special_offer_service');
    }
};
