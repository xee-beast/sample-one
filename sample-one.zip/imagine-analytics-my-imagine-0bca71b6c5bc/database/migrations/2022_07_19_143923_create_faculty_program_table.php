<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('faculty_program', function (Blueprint $table) {

            $table->foreignId('faculty_id')->constrained('faculties');
            $table->foreignId('program_id')->constrained('programs');
            $table->foreignId('calendar_id')->constrained('calendars');
            $table->integer('ebecas_product_id');

            $table->unique(['program_id', 'faculty_id']);
            $table->unique(['ebecas_product_id', 'faculty_id']);

        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('faculty_program');
    }
};
