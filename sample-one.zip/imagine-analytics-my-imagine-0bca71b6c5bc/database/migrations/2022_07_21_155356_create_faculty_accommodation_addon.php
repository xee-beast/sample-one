<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('faculty_accommodation_addon', function (Blueprint $table) {
            $table->foreignId('faculty_id')->constrained('faculties');
            $table->foreignId('addon_id')->constrained('accommodation_fee_addons');
            $table->integer('ebecas_product_id');
            
            $table->unique(['addon_id', 'faculty_id']);
            $table->unique(['ebecas_product_id', 'faculty_id']);
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('faculty_accommodation_addon');
    }
};
