<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('letter_of_offer_template_sections', function (Blueprint $table) {
            $table->string('type');
            $table->string('section_name')->nullable(true);
            $table->foreignId('template_id')->nullable(true)->constrained('letter_of_offer_templates')->cascadeOnDelete();
            $table->foreignId('section_id')->nullable(true)->constrained('letter_of_offer_sections')->cascadeOnDelete();
            $table->integer('order', true);
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('letter_of_offer_template_sections');
    }
};
