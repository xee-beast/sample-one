<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('faculty_payment_method', function (Blueprint $table) {
            $table->foreignId('faculty_id')->constrained('faculties');
            $table->foreignId('payment_method_id')->constrained('payment_methods');
            $table->integer('ebecas_product_id')->nullable(true);

            $table->unique(['payment_method_id', 'faculty_id']);
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('faculty_payment_method');
    }
};
