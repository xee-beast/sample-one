<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('application_transportation', function (Blueprint $table) {
            $table->foreignId('transportation_id')->constrained('transportations');
            $table->foreignId('application_id')->constrained('applications');
            $table->foreignId('faculty_id')->constrained('faculties');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('application_transportation');
    }
};
