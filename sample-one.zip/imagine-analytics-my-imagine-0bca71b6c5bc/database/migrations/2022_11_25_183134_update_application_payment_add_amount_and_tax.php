<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('application_payments', function (Blueprint $table) {
            $table->decimal('default_amount')->after('payment_method_id')->default(0);
            $table->decimal('default_tax')->after('default_amount')->default(0);
            $table->decimal('amount')->after('default_tax')->default(0);
            $table->decimal('tax')->after('amount')->default(0);
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('application_payments', function (Blueprint $table) {
            $table->dropColumn(['default_amount', 'default_tax','amount','tax']);
        });
    }
};
