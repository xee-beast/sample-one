<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('application_accommodation_addon', function (Blueprint $table) {
            $table->foreignId('application_id')->constrained('applications');
            $table->foreignId('addon_id')->constrained('accommodation_fee_addons');
            $table->foreignId('accommodation_id')->constrained('accommodations');
            $table->foreignId('faculty_id')->constrained('faculties');
            $table->date('accommodation_start_date');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('application_accommodation_addon');
    }
};
