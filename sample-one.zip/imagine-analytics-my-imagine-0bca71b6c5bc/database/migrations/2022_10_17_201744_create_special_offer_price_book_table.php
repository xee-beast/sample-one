<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('special_offer_price_book', function (Blueprint $table) {
            $table->foreignId('special_offer_id')->constrained('special_offers')->onDelete('cascade');
            $table->foreignId('program_id')->constrained('programs');
            $table->foreignId('price_book_id')->constrained('program_price_books');

            $table->unique(['special_offer_id', 'program_id']);
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('special_offer_price_book');
    }
};
