<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('special_offers', function (Blueprint $table) {
            $table->id();

            $table->string('name',100);
            $table->string('description',255)->nullable(true);
            $table->boolean("enabled")->default(true);
            $table->foreignId('category_id')->constrained('special_offer_categories');
            $table->foreignId('region_id')->constrained('regions');
            $table->date('application_submitted_from');
            $table->date('application_submitted_to');
            $table->date('application_program_from');
            $table->date('application_program_to');
            $table->boolean('onshore')->default(false);
            $table->boolean('offshore')->default(false);
            $table->boolean('restrict_by_program_length')->default(false);
            $table->integer('restrict_by_program_length_from')->nullable(true);
            $table->integer('restrict_by_program_length_to')->nullable(true);

            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('special_offers');
    }
};
