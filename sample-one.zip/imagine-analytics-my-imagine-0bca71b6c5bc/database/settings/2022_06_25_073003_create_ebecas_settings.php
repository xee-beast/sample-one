<?php

use Spatie\LaravelSettings\Migrations\SettingsMigration;

class CreateEbecasSettings extends SettingsMigration
{
    public function up(): void
    {
        $this->migrator->add('ebecas.college_code', 'imagine.test');
        $this->migrator->add('ebecas.api_url', 'https://ebecas.equatorit.net/ebecas.sandbox');
        $this->migrator->add('ebecas.api_key', '32055E56723946198CD0F1B29BF49037');
        $this->migrator->add('ebecas.api_secret', 'E501F927F9D940C0B6C76A9EB4EC8AC5');
        $this->migrator->add('ebecas.api_username', 'tlim');
    }
}
