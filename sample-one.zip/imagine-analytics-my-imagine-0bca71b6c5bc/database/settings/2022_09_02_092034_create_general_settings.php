<?php

use Spatie\LaravelSettings\Migrations\SettingsMigration;

class CreateGeneralSettings extends SettingsMigration
{
    public function up(): void
    {
        $this->migrator->add('general.notifiers_on_agent_registration', [2,3]);
        $this->migrator->add('general.notifiers_on_app_form_submission', [2,3]);
    }
}
