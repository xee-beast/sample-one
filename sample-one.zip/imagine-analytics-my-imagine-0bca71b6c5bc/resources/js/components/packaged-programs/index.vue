<template>
    <div class="mt-4">
        <div class="filter-datatable">
            <table class="table table-bordered table-striped" id="packaged-program-table">
                <thead>
                <tr>
                    <th scope="col" >Name</th>
                    <th scope="col" >Programs</th>
                    <th scope="col" >Gap allowed</th>
                    <th scope="col" >Status</th>
                </tr>
                </thead>
                <tbody></tbody>
            </table>
        </div>
    </div>
</template>

<script>
    import 'datatables.net-dt/js/dataTables.dataTables';
    import 'datatables.net-dt/css/jquery.dataTables.min.css';
    import 'datatables.net-dt/js/dataTables.dataTables';
    import 'datatables.net-dt/css/jquery.dataTables.min.css';
    import vSelect from "vue-select";
    export default {
        props:['categories'],
        components: {
            vSelect
        },
        data() {
            var self = this;
            return {
                filter:{
                    enabled:null
                },
                datatable: null,
            }
        },
        mounted() {
            this.setDataTable();

        },
        computed : {
        },
        methods: {
            setDataTable(){
                let self = this;
                this.datatable = $('#packaged-program-table').DataTable( {
                    // f - indicate search-bar
                    // <tlip> - t(sign to move to bottom)| l(chaining input)| i(summary info)| p(pagination)
                    dom: 'f <tilp>',
                    processing: true,
                    serverSide: true,
                    ordering: true,
                    responsive: true,
                    ajax: {
                        url: route('staff.settings.products.packaged-programs.list'),
                    },
                    columns: [
                        {data: 'name', name: 'name', orderable: true},
                        {data: 'programs', name: 'programs', orderable: false},
                        {data: 'gap_limit', name: 'gap_limit', orderable: false},
                        {data: 'enabled', name: 'enabled', orderable: false},
                    ]
                });
            },
            reloadDataTable(){
                if ( this.datatable ) {
                    this.datatable.draw();
                }
            }
        }
    }
</script>

