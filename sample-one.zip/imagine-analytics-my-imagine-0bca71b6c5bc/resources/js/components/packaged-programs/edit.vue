<template>
    <form>

        <div class="mt-2">
            <div class="form-group form-check form-switch">
                <input type="hidden" name="enabled" value="0">
                <input @click="isStatusCheck(!form.enabled)" class="form-check-input" type="checkbox" :checked="!!form.enabled">
                <label class="form-check-label">Active</label>
            </div>
        </div>

        <!--    Name        -->
        <div class="col-12 form-group required mt-3">
            <label class="form-label">Name</label>
            <input v-model="form.name" type="text" class="form-control" required >
            <p class="text-danger" v-if="errors.name">{{ errors.name }}</p>
        </div>
        <!--    Description            -->
        <div class="col-12 form-group mt-2">
            <label class="form-label">Description</label>
            <textarea v-model="form.description" class="form-control" maxlength="255" id="description" name="description" rows="3" placeholder="">{{form.description}}</textarea>
        </div>

        <div class="col-12 form-group required mt-2">
        <label class="form-label">Maximum Gap Between Programs (weeks)</label>
            <v-select  label="label" v-model="form.gap_limit" :options="gapOption"  :reduce="option => option.value"  placeholder="Choose option..." >
                <template #no-options="{ search, searching, loading }">
                    <span>No options available</span>
                </template>
            </v-select>
            <p class="text-danger" v-if="errors.gap_limit">{{ errors.gap_limit }}</p>
        </div>

        <!--    Programs    -->
        <h5 class="mt-3">Programs</h5>
        <div v-for="(item,index) in form.selectedPrograms" class="row mt-1 mb-3 justify-content-between">

            <div class="col-1">
                <label class="col-form-label">Action</label> <br>
                <button type="button" @click="deleteProgramRow(index)" class="btn btn-outline-danger btn-sm"><i class="fa fa-times"></i></button>
            </div>

            <div class="col-3">
                <label class="col-form-label">Faculty</label>
                <v-select label="name" v-model="form.selectedPrograms[index].faculty_id" :options="faculties"  :reduce="option => option.id"  placeholder="Choose Faculty..." >
                    <template #no-options="{ search, searching, loading }">
                        <span>No options available</span>
                    </template>
                </v-select>
                <span class="text-danger" v-if="errorText(item,'faculty_error')">{{errorText(item,'faculty_error')}}</span>
            </div>

            <div class="col-4">
                <label class="col-form-label">Program</label>
                <v-select :change="checkSelectedProgramExists(index)" :loading="form.selectedPrograms[index].loading" label="name" v-model="form.selectedPrograms[index].program_id" :options="facultyPrograms[form.selectedPrograms[index].faculty_id]"  :reduce="option => option.id"  placeholder="Choose Program..." >
                    <template #no-options="{ search, searching, loading }">
                        <span>No options available</span>
                    </template>
                </v-select>
                <span class="text-danger" v-if="errorText(item,'program_error')">{{errorText(item,'program_error')}}</span>
            </div>

            <div class="col-3">
                <label class="col-form-label">Discount (%)
                    <i data-bs-toggle="tooltip" data-bs-placement="right"
                       data-bs-title="This discount will be applied on top of any applicable special offer."
                       class="fa-regular fa-circle-question ms-1 mt-0">
                    </i>
                </label>
                <input v-model="form.selectedPrograms[index].discount" type="number" class="form-control" required min="0">
                <span class="text-danger" v-if="errorText(item,'discount_error')">{{errorText(item,'discount_error')}}</span>
            </div>
        </div>

        <p class="text-center mt-2 mb-2" v-if="form.selectedPrograms.length === 0">No faculty programs selected</p>
        <button type="button" @click="addProgramRow()" class="btn btn-sm btn-outline-success">Add Program</button>
        <p class="text-danger" v-if="errors.program_required">{{ errors.program_required }}</p>

        <div class="row mt-5">
            <div class="d-flex justify-content-between">
                <a v-if="showBackBtn" :href="backUrl" class="btn btn-outline-secondary">
                    <i data-feather="arrow-left"></i>
                    Back
                </a>
                <a v-else :href="cancelUrl" class="btn btn-outline-secondary">
                    <!-- <i data-feather="arrow-left"></i> -->
                    Cancel
                </a>
                <button @click="submit" type="button" class="btn btn-primary" :disabled="loading"><i class="fa fa-spinner fa-spin" v-if="loading"></i>{{ formBtnText }}</button>
            </div>
        </div>

    </form>
</template>

<script>
import vSelect from "vue-select";
import {HttpService} from "../../services/HttpService";

export default {
    props: [
        'package',
        'selectedPrograms',
        'faculties',
        'facultyPrograms'
    ], components: {
        vSelect,
    },
    data() {
        return {
            request: new HttpService(),
            loading:false,
            rowsAdded: false,
            programLoading:true,
            form :{
                selectedPrograms: [
                    {
                        faculty_id: null,
                        program_id: null,
                        discount: 0,
                    }
                ],
                name:'',
                description: '',
                enabled : false,
                gap_limit:null,
            },
            errors:{
                name:'',
                gap_limit:'',
            },
        }
    },
    mounted() {
        if(typeof this.package !== 'undefined'){
            this.form.selectedPrograms = this.selectedPrograms;
            this.setValues();
        }
    },
    methods: {
        // submits the form
        async submit() {
            let self = this;

            if(this.validateData()){
                return;
            }
            // this.loading = true;
            let formData = this.getFormData();
            // update request
            if ( this.package.id ) {
                this.makeUpdateRequest(formData).then((response) => {
                    self.loading = false;
                    if (response.success === false) {
                        self.showToast(response.message, false)
                    } else {
                        window.location.href= response.redirect_route;
                    }
                }).catch(function (error) {
                    $.each(error.data.errors, function ( fieldName, msg ){
                        if ( self.errors.hasOwnProperty(fieldName) ) {
                            self.errors[fieldName] = msg[0];
                        }else{
                            self.showToast(error.data.message, false)
                        }
                        self.loading = false;
                    });
                });
            }else {
                // create request
                this.makeCreateRequest(formData).then((response) => {
                    self.loading = false;
                    if (response.success === false) {
                        self.showToast(response.message, false)
                    } else {
                        window.location.href= response.redirect_route;
                    }
                }).catch(function (error) {
                    $.each(error.data.errors, function ( fieldName, msg ){
                        if ( self.errors.hasOwnProperty(fieldName) ) {
                            self.errors[fieldName] = msg[0];
                        }else{
                            self.showToast(error.data.message, false)
                        }
                        self.loading = false;
                    });
                });
            }
        },
        // update request
        makeUpdateRequest(formData){
            return this.request.patch(route('staff.settings.products.packaged-programs.update', this.package.id), formData,{})
        },
        // create request
        makeCreateRequest(formData){
            return this.request.post(route('staff.settings.products.packaged-programs.store'), formData,{})
        },
        getFormData(){
            return {
                programs: this.form.selectedPrograms,
                name: this.form.name,
                description: this.form.description,
                gap_limit: this.form.gap_limit,
                enabled: this.form.enabled ? this.form.enabled : false,
            };
        },
        validateData(){
            let self = this;
            let check = false;

            $.each( self.errors, function (fieldName) {self.errors[fieldName] = '';});

            if ( ! this.form.name || typeof this.form.name == 'undefined' || this.form.name === '' ){
                check = true;
                this.errors.name = "This field is required"
            }
            if ( this.form.gap_limit === null || typeof this.form.gap_limit == 'undefined' || this.form.gap_limit === '' ){
                check = true;
                this.errors.gap_limit = "This field is required"
            }

            if(this.form.selectedPrograms.length === 0){
                check = true;
                this.errors.program_required = "Product must have at-least one program"
            }

            for(let index in this.form.selectedPrograms) {
                let item = JSON.parse(JSON.stringify(this.form.selectedPrograms[index]));

                let duplicateProgram = [];
                this.form.selectedPrograms.forEach(obj => {
                    if( (obj.program_id === item.program_id) && (obj.faculty_id === item.faculty_id))
                        if((obj.program_id !==null && item.program_id!==null) && (obj.faculty_id !==null && item.faculty_id!==null)){
                            duplicateProgram.push(obj);
                        }
                });

                if ( !item.program_id || typeof item.program_id == 'undefined' || item.program_id === ''){
                    check = true;
                    Object.assign(this.form.selectedPrograms[index], {program_error: 'This field is required'});
                }else{
                    this.form.selectedPrograms[index]['program_error'] = '';
                }

                if ( !item.faculty_id || typeof item.faculty_id == 'undefined' || item.faculty_id === ''){
                    check = true;
                    Object.assign(this.form.selectedPrograms[index], {faculty_error: 'This field is required'});
                }else{
                    this.form.selectedPrograms[index]['faculty_error'] = '';
                }

                if ( typeof item.discount == 'undefined' || item.discount === ''){
                    check = true;
                    Object.assign(this.form.selectedPrograms[index], {discount_error: 'This field is required'});
                }else{
                    if (item.discount < 0){
                        check = true;
                        Object.assign(this.form.selectedPrograms[index], {discount_error: 'This field cannot be less than zero'});
                    }else {
                        this.form.selectedPrograms[index]['discount_error'] = '';
                    }
                }

                if(duplicateProgram.length > 1){
                    check = true;
                    this.form.selectedPrograms[index]['faculty_error'] = 'This faculty and program combination already exits';
                }
            }

            return check;
        },
        checkSelectedProgramExists(index){
            if ( typeof this.facultyPrograms[this.form.selectedPrograms[index].faculty_id] !== 'undefined'){
                if ( this.facultyPrograms[this.form.selectedPrograms[index].faculty_id].length < 1  ) {
                    this.form.selectedPrograms[index].program_id = null;
                }else {
                    let hasProgram = false;
                    this.facultyPrograms[this.form.selectedPrograms[index].faculty_id].map( program => {
                        if ( program.id === this.form.selectedPrograms[index].program_id){
                            hasProgram = true;
                        }
                    });
                    if ( ! hasProgram ){
                        this.form.selectedPrograms[index].program_id = null;
                    }
                }
            }
        },
        setValues() {
            this.form.name = this.package.name;
            this.form.enabled = this.package.enabled === 1;
            this.form.description = this.package.description;
            this.form.gap_limit = this.package.gap_limit;
        },
        addProgramRow(){
            this.rowsAdded = true;
            this.form.selectedPrograms.push({
                faculty_id: null,
                program_id: null,
                discount: 0,
            });
        },
        deleteProgramRow(index){
            this.form.selectedPrograms.splice(index,1);
        },
        isStatusCheck(value){
            this.form.enabled = value
        },
        errorText(item,key){
            if(item[key] !== ''){
                return item[key];
            }
            return '';
        },
    },
    computed: {
        formBtnText(){
            if(typeof this.package.id !== 'undefined'){
                return 'Update';
            }
            return 'Create';
        },
        showBackBtn(){
            return typeof this.package.id === 'undefined';
        },
        backUrl(){
            return route('staff.settings.products.packaged-programs.index');
        },
        cancelUrl(){
            return route('staff.settings.products.packaged-programs.index');
        },
        gapOption(){
            let lengthOptions = [];
            for(let i = 0; i <= 24 ; i++){
                lengthOptions.push({
                    label: i,
                    value : i
                });
            }
            return lengthOptions;
        },
    },
}
</script>

<style scoped>

</style>
