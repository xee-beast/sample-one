<template>
    <nav class="sidebar">
        <div class="sidebar-top">
            <span class="shrink-btn">
                <i class="fa-solid fa-arrow-left"></i>
            </span>
        </div>
        <div class="aside-btm scroll">
            <div class="aside-listing">
                <div v-for="item in content" class="parent-item">
                    <div v-if="item.header">
                        <h6>
                            <span>{{item.header}}</span>
                            <i v-if="item.icon" :class="item.icon"></i>
                        </h6>
                    </div>
                    <div v-else class="list-item">
                        <a :href="item.route ? item.route : '#'" :class="getClass(item)">
                            <i :class="item.icon"></i>
                            <p>{{item.title}}</p>
                            <span v-if="item.children" class="fas fa-angle-right"></span>
                        </a>
                        <sub-menu v-if="item.children" :items="item.children" />
                    </div>
                </div>
            </div>
        </div>
    </nav>
</template>
<script>

export default {
    props: ['content'],

    methods: {
        getClass(item) {
            return item.class ? item.class : '';
        }
    }

}
</script>
