<template>
        <div class="sub-menu">
            <ul>
                <div v-for="item in items" :key="item.id">
                    <div v-if="item.header">
                        <h6>
                            <span>{{item.header}}</span>
                            <i v-if="item.icon" :class="item.icon"></i>
                        </h6>
                    </div>
                   
                    <li  v-else class="child-item">
                        <a :href="item.route ? item.route : '#'" :class="getClass(item)">
                            <i :class="item.icon"></i>
                            <p>{{item.title}}</p>
                            <span v-if="item.children" class="fas fa-angle-right"></span>
                        </a>
                        <sub-menu v-if="item.children"  :items="item.children"/>
                    </li>
                  
                </div>
            </ul>
        </div>
</template>

<script>

    export default {
        props:['items'],
        data() {
            var self = this;
            return {
                loading: false
            }
        },
        methods:{
          getClass(item){
           return  item.class ? item.class: '';  
          }
        }
    }
</script>
