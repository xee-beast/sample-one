<template>
    <div class="mt-4">
        <table class="table table-bordered table-striped" id="agent-table">
            <thead>
            <tr>
                <th scope="col" >Name</th>
                <th scope="col" >Ebecas Id</th>
            </tr>
            </thead>
            <tbody></tbody>
        </table>
    </div>
</template>

<script>
    import 'datatables.net-dt/js/dataTables.dataTables';
    import 'datatables.net-dt/css/jquery.dataTables.min.css';
    export default {
        components: {
        },
        data() {
            var self = this;
            return {
                datatable:null
            }
        },
        mounted() {
            this.setDataTable();

        },
        computed : {
        },
        methods: {
            setDataTable(){
                this.datatable = $('#agent-table').DataTable( {
                    // f - indicate search-bar
                    // <tlip> - t(sign to move to bottom)| l(chaining input)| i(summary info)| p(pagination)
                    dom: 'f <tilp>',
                    processing: true,
                    serverSide: true,
                    ordering: false,
                    responsive: true,
                    ajax: route('staff.agents.list'),
                    columns: [
                        {data: 'name', name: 'name',orderable: false},
                        {data: 'ebecas_id', name: 'ebecas_id',orderable: false}
                    ]
                });
            }
        }
    }
</script>

