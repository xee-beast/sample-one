<template>
    <div class="mt-4">
        <table class="table table-bordered table-striped" id="agent-user-table">
            <thead>
            <tr>
                <th scope="col" >First Name</th>
                <th scope="col" >Last Name</th>
                <th scope="col" >Email</th>
            </tr>
            </thead>
            <tbody></tbody>
        </table>
    </div>
</template>

<script>
    import 'datatables.net-dt/js/dataTables.dataTables';
    import 'datatables.net-dt/css/jquery.dataTables.min.css';
    export default {
        props: ['agentId'],
        components: {
        },
        data() {
            var self = this;
            return {
                datatable:null
            }
        },
        mounted() {
            this.setDataTable();
        },
        computed : {
        },
        methods: {
            setDataTable(){
                let self = this
                this.datatable = $('#agent-user-table').DataTable( {
                    // f - indicate search-bar
                    // <tlip> - t(sign to move to bottom)| l(chaining input)| i(summary info)| p(pagination)
                    dom: '<tilp>',
                    processing: true,
                    serverSide: true,
                    ordering: true,
                    responsive: true,
                    language: {
                        infoFiltered: ""
                    },
                    ajax: {
                        url: route('staff.users.list'),
                        data: function ( d ) { d.agent_id = self.agentId },
                    },
                    columns: [
                        {data: 'first_name', name: 'first_name', orderable: true},
                        {data: 'last_name' , name: 'last_name', orderable: true},
                        {data: 'email_ref', name: 'email', orderable: true},
                    ]
                });
            }
        }
    }
</script>

