<template>
    <form>

        <div class="row">
            <div class="col-7">
                <div class="mt-2">
                    <div class="form-group form-check form-switch">
                        <input type="hidden" name="enabled" value="0">
                        <input v-model="form.enabled" class="form-check-input" id="enabled" type="checkbox" >
                        <label class="form-check-label" for="enabled">Active</label>
                    </div>
                </div>

                <!--   Name Field     -->
                <div class="col-12 form-group required mt-3">
                    <label class="form-label">Name</label>
                    <input placeholder="Name" v-model="form.name" type="text" class="form-control" required >
                    <p class="text-danger" v-if="errors.name">{{ errors.name }}</p>
                </div>

                <!--    Description  Field  -->
                <div class="col-12 form-group mt-3">
                    <label class="form-label">Description</label>
                    <textarea class="form-control" maxlength="255" id="description" name="description" rows="3" placeholder="Description" v-model="form.description"></textarea>
                </div>

                <!--   Age Restriction Field     -->
                <div class="col-12 form-group required mt-3">
                    <div class="form-group form-check form-switch">
                        <input type="hidden" name="age_restricted" value="0">
                        <input v-model="form.age_restricted" class="form-check-input" id="age_restricted" type="checkbox" >
                        <label class="form-check-label" for="age_restricted">Restrict by student's age</label>
                    </div>
                </div>

                <!--   Age Restriction Field     -->
                <div v-if="form.age_restricted" class="row mt-3">
                    <div class="col-6 form-group required">
                        <label class="form-label">Min</label>
                        <v-select
                                  v-model="form.min"
                                  placeholder="Select Minimum Age"
                                  :options="ageOptions"
                                  :reduce="option => option.value"
                        >
                        </v-select>
                        <p class="text-danger" v-if="errors.min">{{ errors.min }}</p>
                    </div>
                    <div class="col-6 form-group required">
                        <label class="form-label">Max</label>
                        <v-select
                                  v-model="form.max"
                                  placeholder="Select Maximum Age"
                                  :options="ageOptions"
                                  :reduce="option => option.value"
                        >
                        </v-select>
                        <p class="text-danger" v-if="errors.max">{{ errors.max }}</p>
                    </div>
                </div>

            <div class="col-5"></div>
        </div>
    </div>



        <div class="row mt-5">
            <div class="d-flex justify-content-between">
                <a  :href="backUrl" class="btn btn-outline-secondary">
                    Cancel
                </a>
                <button @click="submit" type="button" class="btn btn-primary" :disabled="loading"><i class="fa fa-spinner fa-spin" v-if="loading"></i>{{ formBtnText }}</button>
            </div>
        </div>

    </form>
</template>

<script>
import vSelect from "vue-select";
import 'bs5-toast'
import '@vuepic/vue-datepicker/dist/main.css'
import {HttpService} from "../../services/HttpService";

export default {
    props: [
        'category',
    ],
    components: {
        vSelect
    },
    data() {
        return {
            request: new HttpService(),
            searchInterval:null,
            loading:false,
            priceBook:null,
            calendar:null,
            form :{
                name:'',
                description: '',
                enabled : null,
                age_restricted: null,
                min: null,
                max: null,
            },
            errors:{
                name:'',
                description: '',
                min:'',
                max:'',
            },
        }
    },
    mounted() {
        if(typeof this.category.id !== 'undefined'){
            this.setValues();
        }
    },
    methods: {
        // submits the form
        async submit() {
            let self = this;

            if(this.validateData()){
                return;
            }

            let formData = this.getFormData();
            if(typeof this.category.id !== 'undefined'){
                this.makeUpdateRequest(formData);
            }else{
                this.makeCreateRequest(formData);
            }
        },
        getFormData(){
            return {
                'name': this.form.name,
                'description': this.form.description,
                'enabled': this.form.enabled ? this.form.enabled : false,
                'age_restricted': this.form.age_restricted ? this.form.age_restricted : false,
                'min': this.form.min,
                'max': this.form.max,
            };
        },
        // update request
        makeUpdateRequest(formData){
            let self = this;
            this.loading = true;
            this.request.patch(route('staff.settings.products.accommodation-categories.update', this.category.id), formData)
                .then(function (response) {
                    self.loading = false;
                    if(response.success){
                        window.location.href= response.redirect_route;
                    }else{
                        self.showToast(response.message,response.success);
                    }
                }).catch(function (err) {
                    self.loading = false;
                    if(typeof err.data.errors !== 'undefined'){
                        self.showErrors(err.data.errors);
                    }
                });
        },
        // create request
        makeCreateRequest(formData){
            let self = this;
            this.loading = true;
            return this.request.post(route('staff.settings.products.accommodation-categories.store'), formData,{})
                .then(function (response) {
                    self.loading = false;
                    if(response.success){
                        window.location.href= response.redirect_route;
                    }else{
                        self.showToast(response.message,response.success);
                    }
                }).catch(function (err) {
                    self.loading = false;
                    if(typeof err.data.errors !== 'undefined'){
                        self.showErrors(err.data.errors);
                    }
                });
        },
        // show validation errors from backend
        showErrors(errors){
            for (var key in errors) {
                this.errors[key] = errors[key][0];
            }
        },
        // show toaster
        showToast(message, isSuccess) {
            new bs5.Toast({
                body: message,
                className: !isSuccess ? 'border-0 bg-danger text-white' : 'border-0 bg-success text-white',
                btnCloseWhite: true,
            }).show();
        },
        // validate form
        validateData: function () {
            let self = this;
            let check = false;

            $.each(this.errors, function (fieldName) {
                self.errors[fieldName] = ''
            });

            if ( ! this.form.name || typeof this.form.name == 'undefined' || this.form.name === '' ){
                check = true;
                this.errors.name = "This field is required"
            } else {
                this.errors.name = ''
            }

            if (this.form.age_restricted) {
                if (!this.form.min || typeof this.form.min == 'undefined' || this.form.min === '') {
                    check = true;
                    this.errors.min = "This field is required"
                }
                if (!this.form.max || typeof this.form.max == 'undefined' || this.form.max === '') {
                    check = true;
                    this.errors.max = "This field is required"
                }

                if (this.form.min && this.form.max && (this.form.min > this.form.max)) {
                    check = true;
                    this.errors.min = "Minimum value cannot be greater then the maximum value"
                }

            }

            return check;
        },
        setValues(){
            this.form.name  = this.category.name;
            this.form.description  =  this.category.description;
            this.form.enabled  = this.category.enabled === 1;
            this.form.age_restricted  = this.category.age_restricted === 1;
            this.form.min  = this.category.min;
            this.form.max  = this.category.max;
        }
    },
    computed: {
        formBtnText(){
            if(typeof this.category.id !== 'undefined'){
                return 'Update';
            }
            return 'Create';
        },
        backUrl(){
            return route('staff.settings.products.accommodation-categories.index');
        },
        ageOptions(){
            let opts = [];
            for(let i = 8; i <= 100; i++){
                opts.push({label:i, value:i})
            }
            return opts;
        }
    },
    watch: {
        'form.age_restricted' : {
            handler: function (newVal, oldVal) {
                if( oldVal ) {
                    this.errors.min = '';
                    this.errors.max = '';
                    this.form.min = null;
                    this.form.max = null;
                }
            },
            deep: true
        }
    },
}
</script>
