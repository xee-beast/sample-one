<template>
    <form method="POST" action="#">

        <div class="row">
            <div class="col-12 col-lg-6 form-group required">
                <label for="first_name" class="form-label">First Name</label>
                <input type="text" v-bind:class="[errors.first_name ? 'is-invalid':'','form-control']" v-model="form.first_name" name="first_name"  id="input-first_name" placeholder="" required>
                <span v-if="errors.first_name" class="invalid-feedback" role="alert">
                    <strong>{{ errors.first_name }}</strong>
                </span>
            </div>

            <div class="col-12 col-lg-6 form-group required">
                <label for="last_name" class="form-label">Last Name</label>
                <input type="text" v-bind:class="[errors.last_name ? 'is-invalid':'','form-control']" v-model="form.last_name"  name="last_name"   id="input-last_name" placeholder="" required>
                <span v-if="errors.last_name" class="invalid-feedback" role="alert">
                <strong>{{ errors.last_name }}</strong>
            </span>
            </div>
        </div>


        <div class="row mt-3">
            <div class="col-12 col-lg-6 form-group required">
                <label for="email" class="form-label">Email</label>
                <input type="email" v-bind:class="[errors.email ? 'is-invalid' : '','form-control']" name="email" v-model="form.email" id="input-email" placeholder="" required>
                <span v-if="errors.email" class="invalid-feedback" role="alert"><strong>{{ errors.email }}</strong></span>
            </div>

            <div class="col-12 col-lg-6 form-group">
                <label for="mobile" class="form-label">Mobile Phone</label>
                <input type="text" v-bind:class="[errors.mobile ? 'is-invalid':'','form-control']" v-model="form.mobile"  name="mobile"   id="input-mobile" placeholder="">
                <span v-if="errors.mobile" class="invalid-feedback" role="alert">
                <strong>{{ errors.mobile }}</strong>
            </span>
            </div>
        </div>

        <div class="row mt-3">
            <div class="col-12 col-lg-6 form-group required">
                <label for="password" class="form-label">Password</label>
                <input type="password" v-bind:class="[errors.password ? 'is-invalid':'','form-control']" v-model="form.password"  name="password"  id="input-password" placeholder="" required>
                <span class="invalid-feedback" v-if="errors.password" role="alert">
                <strong>{{ errors.password }}</strong>
            </span>
            </div>

            <div class="col-12 col-lg-6 form-group required">
                <label for="password_confirmation" class="form-label">Confirm Password</label>
                <input type="password"  v-bind:class="[errors.password_confirmation ? 'is-invalid':'','form-control']" v-model="form.password_confirmation"  name="password_confirmation"  id="input-confirm-password" placeholder="" required>
                <span class="invalid-feedback" v-if="errors.password_confirmation" role="alert">
                <strong>{{ errors.password_confirmation }}</strong>
            </span>
            </div>
        </div>

        <div class="row mt-4">
            <div class="col-12 form-group required">
                <label for="user_type" class="form-label">Describe the option that describes you the best</label>
                <v-select label="name" name="user_type" v-model="form.user_type" :options="userTypes" :reduce="option => option.id"  v-bind:class="[errors.user_type ? 'is-invalid':'','']" placeholder="-- Select --">
                    <template #no-options="{ search, searching, loading }">
                        <span>No options available</span>
                    </template>
                </v-select>
                <span class="invalid-feedback" style="display:block;" v-if="errors.user_type" role="alert">
                <strong>{{ errors.user_type }}</strong>
            </span>
            </div>
        </div>



        <div v-if="form.user_type == 'agent'" class="row mt-3">
            <div class="col-12 form-group required">
                <label for="company" class="form-label">Company Name</label>
                <input type="text" v-bind:class="[errors.company ? 'is-invalid':'','form-control']" v-model="form.company"  name="company"  id="input-company" placeholder="" required>
                <span v-if="errors.company" class="invalid-feedback" role="alert">
                <strong>{{ errors.company }}</strong>
            </span>
            </div>
        </div>

        <div v-if="form.user_type !== null" class="row mt-3">
            <div class="col-12 form-group required">
                <label for="country_id" class="form-label">{{countryPlaceholder}}</label>
                <v-select label="name" v-model="form.country_id" :options="countries" :reduce="option => option.id"  v-bind:class="[errors.country_id ? 'is-invalid':'','']" placeholder="-- Select --">
                    <template #no-options="{ search, searching, loading }">
                        <span>No options available</span>
                    </template>
                </v-select>
                <span class="invalid-feedback" style="display:block;" v-if="errors.country_id" role="alert">
                    <strong>{{ errors.country_id }}</strong>
                </span>
            </div>
        </div>



        <div class="row mt-4">
            <div class="form-check mb-3 mt-4">
                <input class="form-check-input" v-model="form.terms_and_conditions" type="checkbox" checked value="1" id="flexCheckDefault">
                <label class="form-check-label" for="flexCheckDefault">I accept the terms and conditions of the site.</label>
                <span class="invalid-feedback" style="display:block;" v-if="errors.terms_and_conditions" role="alert">
                    <strong>{{ errors.terms_and_conditions }}</strong>
                </span>
            </div>
        </div>

        <span class="text-danger" v-if="errors['g-recaptcha-response']">{{errors['g-recaptcha-response']}}</span>

        <div class="my-3">
            <button class="btn btn-info w-100 text-white" type="button" @click="submitForm" :disabled="loading"><i class="fa fa-spinner fa-spin" v-if="loading"></i> Register</button>
        </div>

        <div class="mt-5 text-center">
            <p class="text-muted mb-0">Already have an account?
                <a href="/login" class="text-primary fw-semibold"> Log in now </a>
            </p>
        </div>


    </form>
</template>

<script>
    //  route('register')
    import vSelect from 'vue-select';
    import 'vue-select/dist/vue-select.css';
    import { HttpService } from '../../services/HttpService';
    import { VueRecaptcha } from 'vue-recaptcha';
    export default {
        props:['countries', 'recaptcha'],
        components: {
            VueRecaptcha,
            vSelect
        },
        data() {

            return {
                loading: false,
                recaptcha_error: false,
                request: new HttpService(),
                userTypes:[
                    {
                        'id' : 'agent',
                        'name':'I am an agent',
                    },
                    {
                        'id' : 'student',
                        'name':'I am a student',
                    }
                ],
                form:{
                    first_name:'',
                    last_name:'',
                    email:'',
                    mobile:'',
                    password:'',
                    password_confirmation:'',
                    country_id:null,
                    user_type:null,
                    company:'',
                    terms_and_conditions:true,
                },
                errors:{
                    first_name:'',
                    last_name:'',
                    email:'',
                    mobile:'',
                    password:'',
                    user_type:'',
                    country_id:'',
                    password_confirmation:'',
                    company:'',
                    terms_and_conditions:'',
                    'g-recaptcha-response':''
                }
            }
        },
        mounted() {
        },
        computed:{
           countryPlaceholder(){
            if(this.form.user_type === 'student'){
                return 'What is your nationality?';
            }
            return 'Where is your office located?';
        }
        },
        methods:{
            submitForm(){
                let self = this;
                if(this.validateForm()){
                    return ;
                }

                self.loading = true;
                this.request.post( '/register',this.form)
                    .then(function (response) {
                        self.loading = false;
                        if(response.success){
                            window.location.href= response.redirect_route;
                        }else{
                            Swal.fire('Error',response.message,'error');
                        }
                    }).catch(function (err) {
                        self.loading = false;
                        if(typeof err.data.errors !== 'undefined'){
                            self.showErrors(err.data.errors);
                        }
                    });
            },
            showErrors(errors){
                for (var key in errors) {
                    this.errors[key] = errors[key][0];
                }
            },
            validateForm(){
                let check = false;
                let requiredFields = ['first_name','last_name','email','password','password_confirmation','country_id','user_type','terms_and_conditions','company'];
                for( let i =0; i < requiredFields.length; i++){
                    let key = requiredFields[i];
                    if(this.form[key] === '' || this.form[key] === null || this.form[key] === false){
                        if(key === 'company' && this.form.user_type !== 'agent'){
                            continue;
                        }
                        check = true;
                        this.errors[key] = 'This field is required';
                    }else{
                        this.errors[key] = '';
                    }
                }
                return check;
            }
        },
        watch :{
            'form.user_type': function (value){
                if(value === 'student'){
                    this.form.company = '';
                }
            }
        }
    }
</script>
