<template>
    <div class="mt-4">
        <div class="filter-datatable">
            <div class="row filter-dropdown">
                <div class="col-3">
                    <v-select :loading="surchargeTypes.length <= 0"
                              v-model="filter.surcharge_type"
                              :options="surchargeTypesFilter"
                              :reduce="option => option.value"
                              append-to-body
                              placeholder="Filter By Surcharge Type"
                              :change="reloadDataTable()"
                    >
                    </v-select>
                </div>
                <div class="col-3">
                    <v-select  label="label" v-model="filter.enabled"
                               :options="enabledOptions"
                               :change="reloadDataTable()"
                               :reduce="option => option.value" placeholder="Filter by Status">
                        <template #no-options="{ search, searching, loading }">
                            <span>No options available</span>
                        </template>
                    </v-select>
                </div>
            </div>
        </div>
        <table class="table table-bordered table-striped" id="payment-method-table">
            <thead>
            <tr>
                <th scope="col" >Name</th>
                <th scope="col" class="text-center">Description</th>
                <th scope="col" >Surcharge Type</th>
                <th scope="col" >Taxable</th>
                <th scope="col" >Payment Plan</th>
                <th scope="col" >Value</th>
                <th scope="col" >Status</th>
            </tr>
            </thead>
            <tbody></tbody>
        </table>
    </div>
</template>

<script>
    import 'datatables.net-dt/js/dataTables.dataTables';
    import 'datatables.net-dt/css/jquery.dataTables.min.css';
    import vSelect from "vue-select";
    export default {
        components: {
            vSelect
        },
        props:[
            'surchargeTypes'
        ],
        data() {
            var self = this;
            return {
                datatable:null,
                enabledOptions:[
                    {
                        label:'--All--',
                        value:''
                    },
                    {
                        label:'Active',
                        value:1
                    },
                    {
                        label:'Inactive',
                        value:0
                    }
                ],
                filter:{
                    enabled:null,
                    surcharge_type:null
                }
            }
        },
        mounted() {
            this.setDataTable();

        },
        computed : {
            surchargeTypesFilter(){
                let types = [];
                for ( let item in this.surchargeTypes) {
                    types.push({label:this.surchargeTypes[item].label, value:this.surchargeTypes[item].key})
                }
                return types;
            }
        },
        methods: {
            setDataTable(){
                var self = this;
                this.datatable = $('#payment-method-table').DataTable( {
                    dom: 'f <tilp>',
                    processing: true,
                    serverSide: true,
                    ordering: true,
                    responsive: true,
                    ajax: {
                        url: route('staff.settings.fees.payment-methods.list'),
                        data: function ( d ) {
                            d.surcharge_type = self.filter.surcharge_type,
                            d.enabled =  self.filter.enabled
                        },
                    },
                    columns: [
                        {data: 'name', name: 'name', ordering: true},
                        {data: 'description', name: 'description' },
                        {data: 'surcharge_type', name: 'surcharge_type' },
                        {data: 'taxable', name: 'taxable' },
                        {data: 'is_payment_plan', name: 'is_payment_plan' },
                        {data: 'value', name: 'value' },
                        {data: 'enabled', name: 'enabled' },
                    ]
                });
            },
            reloadDataTable(){
                if ( this.datatable ) {
                    this.datatable.draw();
                }
            }
        }
    }
</script>

