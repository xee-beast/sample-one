<template>
    <form>

        <div class="mt-2">
            <div class="form-group form-check form-switch">
                <input type="hidden" name="enabled" value="0">
                <input @click="isStatusCheck(!form.enabled)" class="form-check-input" type="checkbox" :checked="!!form.enabled">
                <label class="form-check-label">Active</label>
            </div>
        </div>

            <!--    Name        -->
        <div class="col-12 form-group required mt-3">
                <label class="form-label">Name</label>
                <input v-model="form.name" type="text" class="form-control" required >
                <p class="text-danger" v-if="errors.name">{{ errors.name }}</p>
        </div>
            <!--    Description            -->
        <div class="col-12 form-group mt-2">
                <label class="form-label">Description</label>
                <textarea v-model="form.description" class="form-control" maxlength="255" id="description" name="description" rows="3" placeholder="">{{form.description}}</textarea>
        </div>

            <!--    Surcharge type            -->
        <div class="col-12 form-group required mt-2">
            <label class="form-label">Surcharge Type</label>
            <v-select :loading="surchargeTypes.length <= 0"
                      v-model="form.surcharge_type"
                      :options="surchargeTypesFilter"
                      :reduce="option => option.value"
                      :disabled="!!form.is_payment_plan"
                      append-to-body
                      placeholder="Select Surcharge Type"
            >
            </v-select>
            <p class="text-danger" v-if="errors.surcharge_type">{{ errors.surcharge_type }}</p>
        </div>

            <!--    Is Payment Plan            -->
        <div class="col-12 form-group mt-2">
            <label class="form-check-label">Payment Plan</label>
            <i data-bs-toggle="tooltip"
               data-bs-placement="right"
               data-bs-title="A Payment plan method is an additional fee but it is not a transaction fee as such"
               data-feather="info"
               class="feather-14 ms-1 mt-0"
            >
            </i>
            <div class="form-group form-check form-switch">
                <input type="hidden" name="enabled" value="0">
                <input @click="isPaymentPlanCheck(!form.is_payment_plan)" class="form-check-input" type="checkbox" :checked="form.is_payment_plan">
            </div>
            <p class="text-danger" v-if="errors.is_payment_plan">{{ errors.is_payment_plan }}</p>
        </div>

        <!--    Taxable            -->
        <div class="col-12 form-group mt-2">
            <label class="form-check-label">Taxable</label>
            <div class="form-group form-check form-switch">
                <input type="hidden" name="enabled" value="0">
                <input @click="isTaxableCheck(!form.taxable)" class="form-check-input" type="checkbox" :checked="form.taxable">
            </div>
        </div>

            <!--    Value            -->
        <div class="col-12 form-group mt-2">
            <label class="form-label">Value</label>
            <div class="input-group">
                <div class="input-group-text">{{ valueType }}</div>
                <input v-model="form.value" type="number" class="form-control" required min="0">
            </div>
            <p class="text-danger" v-if="errors.value">{{ errors.value }}</p>
        </div>


        <div class="row mt-5">
            <div class="d-flex justify-content-between">
                <a v-if="showBackBtn" :href="backUrl" class="btn btn-outline-secondary">
                    <i data-feather="arrow-left"></i>
                    Back
                </a>
                <a v-else :href="cancelUrl" class="btn btn-outline-secondary">
                    <!-- <i data-feather="arrow-left"></i> -->
                    Cancel
                </a>
                <button @click="submit" type="button" class="btn btn-primary" :disabled="loading"><i class="fa fa-spinner fa-spin" v-if="loading"></i>{{ formBtnText }}</button>
            </div>
        </div>

    </form>
</template>

<script>
    import vSelect from "vue-select";
    import 'bs5-toast'
    import {HttpService} from "../../services/HttpService";
    import generalHelpers from "../../helpers/generalHelpers";
    import form from "../users/form";
    export default {
        props: [
            'paymentMethod',
            'surchargeTypes',
        ],
        components: {
            vSelect,
        },
        data() {
            return {
                request: new HttpService(),
                loading:false,
                form: {
                    name: null,
                    description: null,
                    surcharge_type: null,
                    taxable: false,
                    is_payment_plan: false,
                    value: null,
                    enabled: false,
                },
                errors:{
                    name:'',
                    surchargeType:'',
                    value:'',
                },
            }
        },
        mounted() {
            if(this.paymentMethod.id){
                this.setFormValues()
            }
        },
        methods: {
            setFormValues(){
                this.form.name = this.paymentMethod.name
                this.form.description = this.paymentMethod.description
                if ( this.paymentMethod.surcharge_type === 'percentage' ){
                    this.form.value = generalHelpers.percentageFormatter(this.paymentMethod.value).toFixed(2)
                }else {
                    this.form.value = parseFloat(this.paymentMethod.value).toFixed(2)
                }
                this.form.surcharge_type = this.paymentMethod.surcharge_type
                this.form.taxable = this.paymentMethod.taxable
                this.form.is_payment_plan = this.paymentMethod.is_payment_plan
                this.form.enabled = this.paymentMethod.enabled
            },
            // submits the form
            async submit() {
                let self = this;

                if(this.validateData()){
                    return;
                }
                this.loading = true;
                let formData = this.getFormData();
                // update request
                if ( this.paymentMethod.id ) {
                    this.makeUpdateRequest(formData).then((response) => {
                        self.loading = false;
                        if (response.success === false) {
                            self.showToast(response.message, false)
                        } else {
                            window.location.href= response.redirect_route;
                        }
                    }).catch(function (err) {
                    self.loading = false;
                    if(typeof err.data.errors !== 'undefined'){
                        self.showErrors(err.data.errors);
                    }
                });
                }else {
                    // create request
                    this.makeCreateRequest(formData).then((response) => {
                        self.loading = false;
                        if (response.success === false) {
                            self.showToast(response.message, false)
                        } else {
                            window.location.href= response.redirect_route;
                        }
                    }).catch(function (err) {
                    self.loading = false;
                    if(typeof err.data.errors !== 'undefined'){
                        self.showErrors(err.data.errors);
                    }
                });
                }
            },
            // show validation errors from backend
            showErrors(errors){
                for (var key in errors) {
                    this.errors[key] = errors[key][0];
                }
            },
            // update request
            makeUpdateRequest(formData){
                return this.request.patch(route('staff.settings.fees.payment-methods.update', this.paymentMethod.id), formData,{})
            },
            // create request
            makeCreateRequest(formData){
                return this.request.post(route('staff.settings.fees.payment-methods.store'), formData,{})
            },
            // get form data
            getFormData(){
                return {
                    'name': this.form.name,
                    'description': this.form.description,
                    'surcharge_type': this.form.surcharge_type.replace(' ', '_').toLowerCase(),
                    'taxable': this.form.taxable,
                    'is_payment_plan': this.form.is_payment_plan,
                    'value': parseFloat(this.form.value).toFixed(2),
                    'enabled': this.form.enabled,
                };
            },
            // show toaster
            showToast(message, isSuccess) {
                new bs5.Toast({
                    body: message,
                    className: !isSuccess ? 'border-0 bg-danger text-white' : 'border-0 bg-success text-white',
                    btnCloseWhite: true,
                }).show();
            },
            // validates form
            validateData(){
                let self = this;
                let check = false;

                if ( ! this.form.name || typeof this.form.name == 'undefined' || this.form.name === '' ){
                    check = true;
                    this.errors.name = "This field is required"
                }else{
                    this.errors.name = ''
                }
                if ( ! this.form.surcharge_type || typeof this.form.surcharge_type == 'undefined' || this.form.surcharge_type === '' ){
                    check = true;
                    this.errors.surcharge_type = "This field is required"
                }else{
                    this.errors.surcharge_type = ''
                }

                if ( typeof this.form.value == 'undefined' || this.form.value === '' ){
                    check = true;
                    this.errors.value = "This field is required"
                }else{
                    this.errors.value = ''
                }

                return check;
            },
            // update taxable checkbox
            isPaymentPlanCheck(value){
                this.form.is_payment_plan = value
                if ( value ){
                    this.form.surcharge_type = 'flat_fee'
                }
            },
            // update taxable checkbox
            isTaxableCheck(value){
                this.form.taxable = value
            },
            // update payment method status
            isStatusCheck(value){
                this.form.enabled = value
            },
            capitalizeFirstLetter(string){
                return string.charAt(0).toUpperCase() + string.slice(1);
            }
        },
        computed: {
            formBtnText(){
                if(typeof this.paymentMethod.id !== 'undefined'){
                    return 'Update';
                }
                return 'Create';
            },
            showBackBtn(){
                return typeof this.paymentMethod === 'undefined';
            },
            backUrl(){
                return route('staff.settings.fees.payment-methods.index');
            },
            cancelUrl(){
                return route('staff.settings.fees.payment-methods.index');
            },
            valueType(){
                if ( this.form.surcharge_type === this.surchargeTypes.percentage.key){
                    return '%';
                }
                return '$';
            },

            surchargeTypesFilter(){
                let types = [];
                for ( let item in this.surchargeTypes) {
                    types.push({label:this.surchargeTypes[item].label, value:this.surchargeTypes[item].key})
                }
                return types;
            }
        }
    }
</script>

