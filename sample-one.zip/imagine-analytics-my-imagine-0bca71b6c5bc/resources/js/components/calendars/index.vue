<template>
    <div class="mt-4">
        <table class="table table-bordered table-striped" id="calendar-table">
            <thead>
            <tr>
                <th scope="col" >Name</th>
                <th scope="col" >Category</th>
                <th scope="col" >Status</th>
                <th scope="col" >Action</th>
            </tr>
            </thead>
            <tbody></tbody>
        </table>
    </div>
</template>

<script>
    import 'datatables.net-dt/js/dataTables.dataTables';
    import 'datatables.net-dt/css/jquery.dataTables.min.css';
    import {HttpService} from "../../services/HttpService";
    import generalHelpers from "../../helpers/generalHelpers";
    export default {
        components: {
        },
        data() {
            var self = this;
            return {
                request: new HttpService(),
                datatable:null
            }
        },
        mounted() {
            this.setDataTable();

        },
        computed : {
        },
        methods: {
            setDataTable(){
                let self = this;
                this.datatable = $('#calendar-table').DataTable( {
                    // f - indicate search-bar
                    // <tlip> - t(sign to move to bottom)| l(chaining input)| i(summary info)| p(pagination)
                    dom: 'f <tilp>',
                    processing: true,
                    serverSide: true,
                    ordering: false,
                    responsive: true,
                    ajax: route('staff.settings.dates.calendars.list'),
                    columns: [
                        {data: 'name', name: 'name', orderable: false},
                        {data: 'category', orderable: false },
                        {data: 'enabled', name: 'enabled'},
                        {data:   null,
                            render : function ( data, type, full, meta ) {
                                return `<a class="text-end small clone-calendar cursor-pointer" >
                                            <i class="fa fa-clone" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Clone"></i>
                                        </a>`
                            }
                        }
                    ]
                });

                $('tbody', this.$refs.table).on( 'click', '.clone-calendar', function(){
                    const cell = self.datatable.cell( $(this).closest("td") );
                    self.clonePriceBook(cell.data())
                });
            },
            clonePriceBook(data){
                let self = this;
                Swal.fire({
                    customClass: {
                        confirmButton: 'btn btn-info text-white px-3',
                        cancelButton: 'btn btn-outline-secondary px-3 mx-3',
                    },
                    confirmButtonText: "Confirm",
                    cancelButtonText: "Cancel",
                    buttonsStyling: false,
                    reverseButtons:true,
                    title: 'Are you sure?',
                    text: "Are you sure you want to clone this calendar?",
                    icon: 'warning',
                    showCancelButton: true,
                }).then((result) => {
                    if (result.isConfirmed) {
                        this.sendCloneRequest(data.id)
                    }
                });
            },
            sendCloneRequest(id){
                let self = this;
                return this.request.post(route('staff.settings.dates.calendars.clone', id))
                    .then(async function (response) {
                        if (response.success){
                            self.reloadDataTable();
                            generalHelpers.showToast('Calendar cloned successfully!',true);
                        }
                    }).catch(function (err) {
                    });
            },
            reloadDataTable(){
                if ( this.datatable ) {
                    this.datatable.draw();
                }
            },
        }
    }
</script>

