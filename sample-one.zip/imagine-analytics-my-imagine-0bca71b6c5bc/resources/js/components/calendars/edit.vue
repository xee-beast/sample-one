<template>
    <form>

        <div class="mt-2">
            <div class="form-group form-check form-switch">
                <input type="hidden" name="enabled" value="0">
                <input @click="isStatusCheck(!calendar.enabled)" class="form-check-input" type="checkbox" :checked="!!calendar.enabled">
                <label class="form-check-label">Active</label>
            </div>
        </div>

        <div class="col-12 form-group required mt-3">
            <label class="form-label">Name</label>
            <input v-model="calendar.name" type="text" class="form-control" required >
            <p class="text-danger" v-if="errors.name">{{ errors.name }}</p>
        </div>

        <div class="col-12 form-group mt-2">
            <label class="form-label">Description</label>
            <textarea v-model="calendar.description" class="form-control" maxlength="255" id="description" name="description" rows="3" placeholder="">{{calendar.description}}</textarea>
        </div>

        <div class="col-12 form-group required mt-2">
            <label class="form-label">Category</label>
            <v-select  label="name" v-model="selectedCategory" :options="categories" :reduce="option => option.id" placeholder="Choose Category...">
                <template #no-options="{ search, searching, loading }">
                    <span>No options available</span>
                </template>
            </v-select>
            <p class="text-danger" v-if="errors.category">{{ errors.category }}</p>
        </div>

        <!--   Date rows header    -->
        <div class="row mt-3 justify-content-center">
            <div class="col-3">
                <label class="form-label">Start Date</label>
            </div>
            <div class="col-3">
                <label class="form-label">Weeks</label>
            </div>
            <div class="col-1">
                <label class="form-label">Action</label>
            </div>
        </div>
        <!--   Date rows data    -->
        <div v-for="(date,index) in dates" :key="date.id">
            <input type="hidden" :value="date.id">
            <div class="row mt-2 justify-content-center">
                <div class="col-3">
                    <Datepicker utc="preserve" v-model="date.start_date" placeholder="dd/mm/yyyy" textInput :format="format" autoApply :closeOnAutoApply="true" :enableTimePicker="false" required></Datepicker>
                    <span class="text-danger" v-if="errorText(date,'start_date_error')">{{errorText(date,'start_date_error')}}</span>
                </div>
                <div class="col-3">
                    <input v-model="date.weeks" type="number" class="form-control" required min="0" oninput="validity.valid||(value='');" >
                    <span class="text-danger" v-if="errorText(date,'weeks_error')">{{errorText(date,'weeks_error')}}</span>
                </div>
                <div class="col-1">
                    <button @click="removeDateFields(date.id, index)" class="btn btn-sm btn-outline-danger" type="button"><i class="fa fa-close"></i></button>
                </div>
            </div>
        </div>

        <!--   add new row     -->
        <div class="row mt-4">
            <div class="row">
                <div class="col-2 offset-2">
                    <button @click="addDateFields" type="button" class="btn btn-outline-success"><i class="fa fa-plus"></i> Add new</button>
                </div>
            </div>
        </div>
        <hr>
        <div class="row mt-5">
            <div class="d-flex justify-content-between">
                <a v-if="showBackBtn" :href="backUrl" class="btn btn-outline-secondary">
                    <i data-feather="arrow-left"></i>
                    Back
                </a>
                <a v-else :href="cancelUrl" class="btn btn-outline-secondary">
                    <!-- <i data-feather="arrow-left"></i> -->
                    Cancel
                </a>
                <button @click="submit" type="button" class="btn btn-primary" :disabled="loading"><i class="fa fa-spinner fa-spin" v-if="loading"></i>{{ formBtnText }}</button>
            </div>
        </div>

    </form>
</template>

<script>
    import vSelect from "vue-select";
    import 'bs5-toast'
    import Datepicker from '@vuepic/vue-datepicker';
    import '@vuepic/vue-datepicker/dist/main.css'
    import { ref } from 'vue';
    import {HttpService} from "../../services/HttpService";
    export default {
        props: [
            'calendar',
            'categories',
            'calendarDates'
        ],
        components: {
            vSelect,
            Datepicker
        },
        data() {
            return {
                request: new HttpService(),
                loading:false,
                selectedCategory: null,
                dates: [],
                deleteDates: [],
                errors:{
                    name:'',
                    category:'',
                },
                // datepicker
                format: "dd/MM/yyyy"
            }
        },
        mounted() {
            this.dates = this.calendarDates
            this.selectedCategory = this.calendar.calendar_category_id
        },
        methods: {
            // add new date field row
            addDateFields(){
                let fields = {
                    start_date: null,
                    weeks: null
                };

                this.dates.push(fields)
            },
            // remove date field row
            removeDateFields(id, index){
                if ( id )
                    this.deleteDates.push(id)

                this.dates.splice(index, 1)
            },
            // displays error
            errorText(date,key){
                if(date[key] !== ''){
                    return date[key];
                }
                return '';
            },
            // submits the form
            async submit() {
                let self = this;

                if(this.validateData()){
                    return;
                }
                this.loading = true;
                let formData = {
                    dates: this.dates,
                    deleted_records: this.deleteDates,
                    name: this.calendar.name,
                    description: this.calendar.description,
                    enabled: this.calendar.enabled ?? false,
                    calendar_category_id: this.selectedCategory
                };
                // update request
                if ( this.calendar.id ) {
                    this.makeUpdateRequest(formData).then((response) => {
                        self.loading = false;
                        if (response.success === false) {
                            self.showToast(response.message, false)
                        } else {
                            window.location.href= response.redirect_route;
                        }
                    }).catch(function (error) {
                            self.showToast(error.data.message, false)
                            self.loading = false;
                        });
                }else {
                    // create request
                    this.makeCreateRequest(formData).then((response) => {
                        self.loading = false;
                        if (response.success === false) {
                            self.showToast(response.message, false)
                        } else {
                            window.location.href= response.redirect_route;
                        }
                    }).catch(function (error) {
                            self.showToast(error.data.message, false)
                            self.loading = false;
                        });
                }
            },
            // update request
            makeUpdateRequest(formData){
                return this.request.patch(route('staff.settings.dates.calendars.update', this.calendar.id), formData,{})
            },
            // create request
            makeCreateRequest(formData){
                return this.request.post(route('staff.settings.dates.calendars.store'), formData,{})
            },
            // show toaster
            showToast(message, isSuccess) {
                new bs5.Toast({
                    body: message,
                    className: !isSuccess ? 'border-0 bg-danger text-white' : 'border-0 bg-success text-white',
                    btnCloseWhite: true,
                }).show();
            },
            // validates form
            validateData(){
                let self = this;
                let check = false;

                if ( typeof this.calendar.name == 'undefined' || this.calendar.name === '' ){
                    check = true;
                    this.errors.name = "This field is required"
                }else{
                    this.errors.name = ''
                }
                if ( !this.selectedCategory || typeof this.selectedCategory == 'undefined' || this.calendar.selectedCategory === '' ){
                    check = true;
                    this.errors.category = "This field is required"
                }else{
                    this.errors.category = ''
                }
                // validating dates
                for(let index in this.dates) {
                    let item = JSON.parse(JSON.stringify(this.dates[index]));

                    if ( !item.start_date || typeof item.start_date == 'undefined' || item.start_date === ''){
                        check = true;
                        Object.assign(this.dates[index], {start_date_error: 'This field is required'});
                    }else{
                        this.dates[index]['start_date_error'] = '';
                    }
                }
                return check;
            },
            // update calendar status
            isStatusCheck(value){
                this.calendar.enabled = value
            }
        },
        computed: {
            formBtnText(){
                if(typeof this.calendar.id !== 'undefined'){
                    return 'Update';
                }
                return 'Create';
            },
            showBackBtn(){
                return typeof this.calendar === 'undefined';
            },
            backUrl(){
                return route('staff.settings.dates.calendars.index');
            },
            cancelUrl(){
                return route('staff.settings.dates.calendars.index');
            },
        }
    }
</script>

