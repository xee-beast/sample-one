<template>
    <form>

        <div class="row">
            <div class="col-7">
                <div class="mt-2">
                    <div class="form-group form-check form-switch">
                        <input type="hidden" name="enabled" value="0">
                        <input v-model="form.enabled" class="form-check-input" id="enabled" type="checkbox" >
                        <label class="form-check-label" for="enabled">Active</label>
                    </div>
                </div>

                <!--   Name Field     -->
                <div class="col-12 form-group required mt-3">
                    <label class="form-label">Name</label>
                    <input placeholder="Name" v-model="form.name" type="text" class="form-control" required >
                    <p class="text-danger" v-if="errors.name">{{ errors.name }}</p>
                </div>

                <!--    Description  Field  -->
                <div class="col-12 form-group mt-3">
                    <label class="form-label">Description</label>
                    <textarea class="form-control" maxlength="255" id="description" name="description" rows="3" placeholder="Description" v-model="form.description"></textarea>
                </div>

                 <!--    Category  -->
                <div class="col-12 form-group required mt-2">
                    <label class="form-label">Category</label>
                    <v-select  label="name" v-model="category" :options="categories"  placeholder="Choose Category..." :search-able="true">
                        <template #no-options="{ search, searching, loading }">
                            <span>No options available</span>
                        </template>
                    </v-select>
                    <p class="text-danger" v-if="errors.accommodation_category_id">{{ errors.accommodation_category_id }}</p>
                </div>

                <!--    Price book  -->
                <div class="col-12 form-group required mt-2">
                    <label class="form-label">Price Book</label>
                    <v-select  label="name" v-model="priceBook" :options="priceBooks"  placeholder="Choose Price Book..." :search-able="true">
                        <template #no-options="{ search, searching, loading }">
                            <span>No options available</span>
                        </template>
                    </v-select>
                    <p class="text-danger" v-if="errors.accommodation_price_book_id">{{ errors.accommodation_price_book_id }}</p>
                </div>
            </div>

            <div class="col-5 mt-4">
                <div class="card mt-5">
                    <div class="card-body">
                        <h5>Restrictions</h5>
                        <div class="mt-4">
                            <div class="form-group form-check form-switch">
                                <input type="hidden" name="length_restriction_enabled" value="0">
                                <input v-model="form.length_restriction_enabled" class="form-check-input" :checked="form.length_restriction_enabled" id="length_restriction_enabled" type="checkbox" >
                                <label class="form-check-label" for="length_restriction_enabled">Length (weeks)</label>
                            </div>
                        </div>
                        <div class="row" v-if="form.length_restriction_enabled">
                            <div class="col-6 form-group required mt-3">
                                <label class="form-label">Min</label>
                                <v-select  label="label" v-model="form.min_length" :options="minLengthOption"  :reduce="option => option.value"  placeholder="Choose option..." >
                                    <template #no-options="{ search, searching, loading }">
                                        <span>No options available</span>
                                    </template>
                                </v-select>
                                <p class="text-danger" v-if="errors.min_length">{{ errors.min_length }}</p>
                            </div>
                            <div class="col-6 form-group required mt-3">
                                <label class="form-label">Max</label>
                                <v-select  label="label" v-model="form.max_length" :options="maxLengthOption"  :reduce="option => option.value"  placeholder="Choose option..." >
                                    <template #no-options="{ search, searching, loading }">
                                        <span>No options available</span>
                                    </template>
                                </v-select>
                                <p class="text-danger" v-if="errors.max_length">{{ errors.max_length }}</p>
                            </div>
                        </div>
                        <hr/>
                    </div>
                </div>

                <div class="card mt-4">
                    <div class="card-body">
                        <h5>Services</h5>
                        <p class="mt-3 text-center" v-if="formLoading"><i class="fa fa-spinner fa-spin"></i> </p>
                        <Services v-else :service-options="services" :services="form.services" :show-errors="serviceErrors" @update="onServiceUpdate"/>
                    </div>
                </div>

                <div class="card mt-4">
                    <div class="card-body">
                        <h5>Add-ons</h5>
                        <p class="mt-3 text-center" v-if="formLoading"><i class="fa fa-spinner fa-spin"></i> </p>
                        <Addons v-else :addons="addons" :selectedAddons="form.addons" :show-errors="addonErrors" @update="onAddonUpdate"/>
                    </div>
                </div>

            </div>
        </div>

        <div class="row mt-5">
            <div class="d-flex justify-content-between">
                <a  :href="backUrl" class="btn btn-outline-secondary">
                    Cancel
                </a>
                <button @click="submit" type="button" class="btn btn-primary" :disabled="loading"><i class="fa fa-spinner fa-spin" v-if="loading"></i>{{ formBtnText }}</button>
            </div>
        </div>

    </form>
</template>

<script>

import Services from './partials/services';
import Addons from './partials/addons';
import vSelect from "vue-select";
import 'bs5-toast'
import '@vuepic/vue-datepicker/dist/main.css'
import {HttpService} from "../../services/HttpService";
export default {
    props: [
        'accommodation',
        'priceBooks',
        'categories',
        'services',
        'addons',
        'selectedAddons',
        'selectedServices'
    ],
    components: {
        Addons,
        vSelect,
        Services
    },
    data() {
        return {
            request: new HttpService(),
            searchInterval:null,
            loading:false,
            priceBook:null,
            category:null,
            serviceErrors:false,
            addonErrors:false,
            formLoading:true,
            form :{
                name:'',
                description: '',
                enabled : false,
                accommodation_price_book_id:null,
                accommodation_category_id:null,
                min_length:null,
                max_length:null,
                length_restriction_enabled:false,
                addons:[],
                services:[]
            },
            errors:{
                name:'',
                description: '',
                enabled : false,
                accommodation_price_book_id:null,
                accommodation_category_id:null,
                min_length:'',
                max_length:'',
            },
        }
    },
    mounted() {
        if(typeof this.accommodation !== 'undefined'){
            this.setValues();
        }else{
            this.formLoading = false;
        }
    },
    methods: {
        // displays error
        errorText(date,key) {
            if (date[key] !== '') {
                return date[key];
            }
            return '';
        },
        onServiceUpdate(value){
            let values = JSON.parse(JSON.stringify(value));
            this.form.services = values;
        },
        onAddonUpdate(value){
            let values = JSON.parse(JSON.stringify(value));
            this.form.addons = values;
        },
        // submits the form
        async submit() {
            let self = this;

            if(this.validateData()){
                return;
            }

            let formData = this.getFormData();
            if(typeof this.accommodation !== 'undefined'){
                this.makeUpdateRequest(formData);
            }else{
                this.makeCreateRequest(formData);
            }
        },
        getFormData(){
            let formData = this.form;
            return formData;
        },
        // update request
        makeUpdateRequest(formData){
            let self = this;
            this.loading = true;
            this.request.patch(route('staff.settings.products.accommodation.update', this.accommodation.id), formData)
                .then(function (response) {
                    self.loading = false;
                    if(response.success){
                        window.location.href= response.redirect_route;
                    }else{
                        self.showToast(response.message,response.success);
                    }
                }).catch(function (err) {
                    self.loading = false;
                    if(typeof err.data.errors !== 'undefined'){
                        self.showErrors(err.data.errors);
                    }
                });
        },
        // create request
        makeCreateRequest(formData){
            let self = this;
            this.loading = true;
            return this.request.post(route('staff.settings.products.accommodation.store'), formData,{})
                .then(function (response) {
                    self.loading = false;
                    if(response.success){
                        window.location.href= response.redirect_route;
                    }else{
                        self.showToast(response.message,response.success);
                    }
                }).catch(function (err) {
                    self.loading = false;
                    if(typeof err.data.errors !== 'undefined'){
                        self.showErrors(err.data.errors);
                    }
                });
        },
        // show validation errors from backend
        showErrors(errors){
            for (var key in errors) {
                this.errors[key] = errors[key][0];
            }
            this.serviceErrors = true;
            this.addonErrors = true;
        },
        // show toaster
        showToast(message, isSuccess) {
            new bs5.Toast({
                body: message,
                className: !isSuccess ? 'border-0 bg-danger text-white' : 'border-0 bg-success text-white',
                btnCloseWhite: true,
            }).show();
        },
        // validate form
        validateData(){
            let self = this;
            let check = false;
            this.serviceErrors = false;
            this.addonErrors = false;

            $.each(self.errors, function(fieldName) {self.errors[fieldName] = ''});

            if (this.form.name === '' ){
                check = true;
                this.errors.name = "This field is required"
            }else{
                this.errors.name = ''
            }
            if ( ! this.form.accommodation_price_book_id || this.form.accommodation_price_book_id === '' ){
                check = true;
                this.errors.accommodation_price_book_id = "This field is required"
            }else{
                this.errors.accommodation_price_book_id = ''
            }
            if ( ! this.form.accommodation_category_id || this.form.accommodation_category_id === '' ){
                check = true;
                this.errors.accommodation_category_id = "This field is required"
            }else{
                this.errors.accommodation_category_id = ''
            }

            if ( this.form.length_restriction_enabled === true ){
                if ( this.form.min_length  === null ){
                    check = true;
                    this.errors.min_length = "This field is required"
                }else{
                    this.errors.min_length = ''
                }

                if ( this.form.max_length  === null ){
                    check = true;
                    this.errors.max_length = "This field is required"
                }else{
                    this.errors.max_length = ''
                }

                if(parseInt(this.form.max_length) <  parseInt(this.form.min_length)){
                    check = true;
                    this.errors.max_length = "Max length should be greater then min length"
                }
            }

            if(this.form.services.length > 0 ){
                let serviceError = false;
                for(let key in this.form.services){
                    let item = this.form.services[key];
                    let duplicate = [];
                    this.form.services.forEach(obj => {
                        if(obj.accommodation_fee_service_id === item.accommodation_fee_service_id)
                            duplicate.push(obj);
                    });
                    if(item.accommodation_fee_service_id == null){
                        serviceError = true;
                    }else if(duplicate.length > 1){
                        serviceError = true;
                    }
                }
                if(serviceError){
                    setTimeout(() => {this.serviceErrors = true},100) ;
                    check = true;
                }
            }
            if(this.form.addons.length > 0 ){
                let addonError = false;
                for(let key in this.form.addons){
                    let item = this.form.addons[key];
                    let duplicate = [];
                    this.form.addons.forEach(obj => {
                        if(obj.accommodation_fee_addon_id === item.accommodation_fee_addon_id)
                            duplicate.push(obj);
                    });
                    if(item.accommodation_fee_addon_id == null){
                        addonError = true;
                    }else if(duplicate.length > 1){
                        addonError = true;
                    }
                }
                if(addonError){
                    setTimeout(() => {this.addonErrors = true},100) ;
                    check = true;
                }
            }

            return check;
        },
        setValues(){
            this.form.name  = this.accommodation.name;
            this.form.enabled  = this.accommodation.enabled === 1;
            this.form.description  =  this.accommodation.description;
            this.priceBook  = this.accommodation.price_book;
            this.category  = this.accommodation.category;
            this.form.addons = this.selectedAddons;
            this.form.min_length = this.accommodation.min_length;
            this.form.max_length = this.accommodation.max_length;
            this.form.length_restriction_enabled = this.accommodation.length_restriction_enabled === 1;
            if(typeof this.selectedServices !== 'undefined'){
                this.form.services = this.selectedServices;
            }
            this.formLoading = false;
        }
    },
    computed: {
        formBtnText(){
            if(typeof this.accommodation !== 'undefined'){
                return 'Update';
            }
            return 'Create';
        },
        backUrl(){
            return route('staff.settings.products.accommodation.index');
        },
        minLengthOption(){
            let lengthOptions = [];
            for(let i = 1; i <= 100 ; i++){
                lengthOptions.push({
                    label: i,
                    value : i
                });
            }
            return lengthOptions;
        },
        maxLengthOption(){
            let i = 1;
            if(this.form.min_length !== null)
                i = this.form.min_length;
            let lengthOptions = [];
            for(i ; i <= 100 ; i++){
                lengthOptions.push({
                    label: i,
                    value : i
                });
            }
            return lengthOptions;
        }
    },
    watch: {
        priceBook(value){
            if(value !== null){
                this.form.accommodation_price_book_id = value.id;
            }else{
                this.form.accommodation_price_book_id = null;
            }
        },
        category(value){
            if(value !== null){
                this.form.accommodation_category_id = value.id;
            }else{
                this.form.accommodation_category_id = null;
            }
        },
        'form.length_restriction_enabled' : function (value){
            if(value === false){
                this.form.min_length = null;
                this.form.max_length = null;
            }
        }
    }
}
</script>
