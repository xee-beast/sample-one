<template>
    <div class="mt-4">
        <div class="filter-datatable">

            <table class="table table-bordered table-striped" id="accommodation-table">
                <thead>
                <tr>
                    <th scope="col" >Name</th>
                    <th scope="col" >Price Book</th>
                    <th scope="col" >Category</th>
                    <th scope="col" class="text-center">Description</th>
                    <th scope="col" >Status</th>
                </tr>
                </thead>
                <tbody></tbody>
            </table>
        </div>
    </div>
</template>

<script>
    import 'datatables.net-dt/js/dataTables.dataTables';
    import 'datatables.net-dt/css/jquery.dataTables.min.css';
    import 'datatables.net-dt/js/dataTables.dataTables';
    import 'datatables.net-dt/css/jquery.dataTables.min.css';
    import vSelect from "vue-select";
    export default {
        props:['categories'],
        components: {
            vSelect
        },
        data() {
            var self = this;
            return {
                datatable: null,
            }
        },
        mounted() {
            this.setDataTable();

        },
        computed : {
        },
        methods: {
            setDataTable(){
                let self = this;
                this.datatable = $('#accommodation-table').DataTable( {
                    // f - indicate search-bar
                    // <tlip> - t(sign to move to bottom)| l(chaining input)| i(summary info)| p(pagination)
                    dom: 'f <tilp>',
                    processing: true,
                    serverSide: true,
                    ordering: true,
                    responsive: true,
                    ajax: {
                        url: route('staff.settings.products.accommodation.list'),
                    },
                    columns: [
                        {data: 'name', name: 'name', orderable: true},
                        {data: 'price_book', name: 'price_book',orderable: false},
                        {data: 'category', name: 'category',orderable: false},
                        {data: 'description', name: 'description',orderable: false},
                        {data: 'enabled', name: 'enabled',orderable: false},
                    ]
                });
            },
            reloadDataTable(){
                if ( this.datatable ) {
                    this.datatable.draw();
                }
            }
        }
    }
</script>

