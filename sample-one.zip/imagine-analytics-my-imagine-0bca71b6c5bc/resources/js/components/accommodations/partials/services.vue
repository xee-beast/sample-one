<template>
    <div class="mt-4">
        <div v-for="(item,index) in selectedServices" class="col-12 mb-3">
            <div class="row">
                <label class="col-sm-3 col-form-label">Name</label>
                <div class="col-sm-9">
                    <v-select  label="name" v-model="selectedServices[index].accommodation_fee_service_id" :options="serviceOptions"  :reduce="option => option.id"  placeholder="Choose option..." >
                        <template #no-options="{ search, searching, loading }">
                            <span>No options available</span>
                        </template>
                    </v-select>
                    <p class="text-danger" v-if="selectedServices[index].error">{{selectedServices[index].error}}</p>
                </div>
            </div>
            <div class="row mt-3">
                <label for="mandatory" class="col-sm-3 col-form-label">Mandatory</label>
                <div class="col-sm-9">
                    <div class="form-group form-check form-switch">
                        <input type="hidden" name="enabled" value="0">
                        <input v-model="selectedServices[index].mandatory" :checked="selectedServices[index].mandatory" class="form-check-input" id="mandatory" type="checkbox" >
                    </div>
                </div>
            </div>
            <div class="row mt-3">
                <label class="col-sm-3 col-form-label">Action</label>
                <div class="col-sm-9">
                    <button type="button" @click="deleteRow(index)" class="btn btn-outline-danger btn-sm"><i class="fa fa-times"></i></button>
                </div>
            </div>
            <hr/>
        </div>
        <p class="text-center mt-2 mb-2" v-if="selectedServices.length === 0">No services selected</p>
        <button type="button" @click="addRow()" class="btn btn-sm btn-outline-success">Add Service</button>
    </div>
</template>

<script>
    import vSelect from "vue-select";
    export default {
        props:['serviceOptions','services','showErrors'],
        components: {
            vSelect
        },
        data() {
            var self = this;
            return {
                selectedServices:[
                    {
                        accommodation_fee_service_id:null,
                        mandatory:false
                    }
                ]
            }
        },
        mounted() {
            this.selectedServices = this.services;
        },
        computed : {

        },
        methods: {
            addRow(){
                this.selectedServices.push({
                    accommodation_fee_service_id:null,
                    mandatory:false
                });
            },
            deleteRow(index){
                this.selectedServices.splice(index,1);
            },
            setErrors(){
                if(this.selectedServices.length > 0){
                    for(let key in this.selectedServices){
                        let item = this.selectedServices[key];
                        let duplicate = [];
                        this.selectedServices.forEach(obj => {
                            if(obj.accommodation_fee_service_id === item.accommodation_fee_service_id)
                                if(obj.accommodation_fee_service_id!==null && item.accommodation_fee_service_id!==null){
                                    duplicate.push(obj);
                                }   
                        });

                        if(item['accommodation_fee_service_id'] === null){
                            this.selectedServices[key]['error'] = 'This field is required';
                        }else{
                            this.selectedServices[key]['error'] = '';
                        }

                        if(duplicate.length > 1){
                            this.selectedServices[key]['error'] = 'This service is already included';
                        }
                    }
                }
            }
        },
        watch:{
            selectedServices: {
                handler: function(serviceArray) {
                    this.$emit('update',serviceArray);
                },
                deep: true
            },
            showErrors (value){
                this.setErrors();
            }
        }
    }
</script>

