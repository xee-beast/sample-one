<template>

    <div class="mt-4">
        <div v-for="(addon,index) in addonsSelected">

            <div class="row">
                <label class="col-sm-3 col-form-label">Name</label>
                <div class="col-sm-9">
                    <v-select  label="name" v-model="addonsSelected[index].accommodation_fee_addon_id" :options="addons"  :reduce="option => option.id"  placeholder="Choose option..." :search-able="true">
                        <template #no-options="{ search, searching, loading }">
                            <span>No options available</span>
                        </template>
                    </v-select>
                    <p class="text-danger" v-if="addonsSelected[index].add_on_error">{{addonsSelected[index].add_on_error}}</p>
                </div>
            </div>

            <div class="row mt-3">
                <label for="mandatory" class="col-sm-3 col-form-label">Mandatory</label>
                <div class="col-sm-9 mt-2">
                    <div class="form-group form-check form-switch">
                        <input type="hidden" name="enabled" value="0">
                        <input v-model="addonsSelected[index]['mandatory']" :checked="addonsSelected[index]['mandatory']" class="form-check-input" id="mandatory" type="checkbox" >
                    </div>
                </div>
            </div>

            <div class="row mt-3">
                <label class="col-sm-3 col-form-label">Action</label>
                <div class="col-sm-9">
                    <button type="button" @click="removeAddonFields(addon.id, index)" class="btn btn-outline-danger btn-sm"><i class="fa fa-times"></i></button>
                </div>
            </div>
            <hr/>
        </div>

        <!--   add new row     -->
        <p class="text-center mt-2 mb-2" v-if="addonsSelected.length === 0">No add-on selected</p>
        <button type="button" @click="addAddonFields" class="btn btn-sm btn-outline-success">Add Add-on</button>
    </div>

</template>

<script>
import vSelect from "vue-select";
export default {
    props: [
        'addons',
        'selectedAddons',
        'showErrors'
    ],
    components: {
        vSelect
    },
    data() {
        var self = this;
        return {
            addonsSelected: [
                {
                    accommodation_fee_addon_id: null,
                    mandatory: false
                }
            ]
        }
    },
    mounted() {
        this.addonsSelected = this.selectedAddons;
    },
    computed: {},
    methods: {
        // add new addon row
        addAddonFields() {
            let fields = {
                accommodation_fee_addon_id: null,
                name: null,
                mandatory: false,
            };

            this.addonsSelected.push(fields)
        },
        // remove add-on field row
        removeAddonFields(id, index) {
            this.addonsSelected.splice(index, 1)
        },
        setErrors() {
            if (this.addonsSelected.length > 0) {
                for (let key in this.addonsSelected) {
                    let item = this.addonsSelected[key];
                    let duplicate = [];
                    this.addonsSelected.forEach(obj => {
                        if (obj.accommodation_fee_addon_id === item.accommodation_fee_addon_id)
                            duplicate.push(obj);
                    });

                    if (item['accommodation_fee_addon_id'] === null) {
                        this.addonsSelected[key]['add_on_error'] = 'This field is required';
                    } else {
                        this.addonsSelected[key]['add_on_error'] = '';
                    }

                    if (duplicate.length > 1) {
                        this.addonsSelected[key]['add_on_error'] = 'This add-on is already included';
                    }
                }
            }
        }
    },
    watch: {
        addonsSelected: {
            handler: function (addonArray) {
                this.$emit('update', addonArray);
            },
            deep: true
        },
        showErrors(value) {
            this.setErrors();
        }
    }
}
</script>


