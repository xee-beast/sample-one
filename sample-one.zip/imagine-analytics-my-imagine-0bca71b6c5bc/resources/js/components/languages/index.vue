<template>
    <div class="mt-4">
        <div class="filter-datatable">
            <div class="row filter-dropdown">
                <div class="col-3">
                    <v-select  label="label" v-model="filter.enabled"
                               :options="enabledOptions"
                               :change="reloadDataTable()"
                               :reduce="option => option.value" placeholder="Filter by Status">
                        <template #no-options="{ search, searching, loading }">
                            <span>No options available</span>
                        </template>
                    </v-select>
                </div>
            </div>
            <table class="table table-bordered table-striped" id="price-book-table">
                <thead>
                <tr>
                    <th scope="col" >Name</th>
                    <th scope="col" >Status</th>
                </tr>
                </thead>
                <tbody></tbody>
            </table>
        </div>
    </div>
</template>

<script>
import 'datatables.net-dt/js/dataTables.dataTables';
import 'datatables.net-dt/css/jquery.dataTables.min.css';
import 'datatables.net-dt/js/dataTables.dataTables';
import 'datatables.net-dt/css/jquery.dataTables.min.css';
import vSelect from "vue-select";
export default {
    components: {
        vSelect
    },
    data() {
        var self = this;
        return {
            datatable: null,
            enabledOptions:[
                {
                    label:'--All--',
                    value:''
                },
                {
                    label:'Active',
                    value:1
                },
                {
                    label:'Inactive',
                    value:0
                }
            ],
            selected: null,
            filter:{
                enabled:null,
            }
        }
    },
    mounted() {
        this.setDataTable();

    },
    computed : {
    },
    methods: {
        setDataTable(){
            let self = this;
            this.datatable = $('#price-book-table').DataTable( {
                dom: 'f <tilp>',
                processing: true,
                serverSide: true,
                ordering: false,
                responsive: true,
                ajax: {
                    url: route('staff.settings.languages.list'),
                    data: function ( d ) {
                        d.enabled = self.filter.enabled
                    },
                },
                columns: [
                    {data: 'name', name: 'name', orderable: true},
                    {data: 'enabled', name: 'enabled',orderable: false},
                ]
            });
        },
        reloadDataTable(){
            if ( this.datatable ) {
                this.datatable.draw();
            }
        }
    }
}
</script>

