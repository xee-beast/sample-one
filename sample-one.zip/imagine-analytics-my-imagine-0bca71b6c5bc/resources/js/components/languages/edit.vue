<template>
    <form>

        <div class="mt-2">
            <div class="form-group form-check form-switch">
                <input type="hidden" name="enabled" value="0">
                <input @click="isStatusCheck(!form.enabled)" class="form-check-input" type="checkbox" :checked="!!form.enabled">
                <label class="form-check-label">Active</label>
            </div>
        </div>

        <div class="col-12 form-group required mt-3">
            <label class="form-label">Name</label>
            <input v-model="form.name" type="text" class="form-control" required >
            <p class="text-danger" v-if="errors.name">{{ errors.name }}</p>
        </div>

        <div class="col-12 form-group mt-3">
            <label class="form-label">eBECAS Id</label>
            <v-select label="LanguageName" v-model="form.ebecas_id"
                        :options="languageList" :reduce="option => option.LanguageId"
                        placeholder="Choose Language..." :search-able="true">
                <template #no-options="{ search, searching, loading }">
                    <span>No options available</span>
                </template>
            </v-select>
            <p class="text-danger" v-if="errors.ebecas_id">{{ errors.ebecas_id }}</p>
        </div>

        <div class="row mt-5">
            <div class="d-flex justify-content-between">
                <a v-if="showBackBtn" :href="backUrl" class="btn btn-outline-secondary">
                    <i data-feather="arrow-left"></i>
                    Back
                </a>
                <a v-else :href="cancelUrl" class="btn btn-outline-secondary">
                    <!-- <i data-feather="arrow-left"></i> -->
                    Cancel
                </a>
                <button @click="submit" type="button" class="btn btn-primary" :disabled="loading"><i class="fa fa-spinner fa-spin" v-if="loading"></i>{{ formBtnText }}</button>
            </div>
        </div>

    </form>
</template>

<script>
    import vSelect from "vue-select";
    import {HttpService} from "../../services/HttpService";
    export default {
        props: [
            'language',
            'languageList'
        ],
        components: {
            vSelect,
        },
        data() {
            return {
                request: new HttpService(),
                loading:false,
                errors:{
                    name:'',
                },
                form: {
                    name:null,
                    enabled:true,
                    ebecas_id: null
                }
            }
        },
        mounted() {
            if ( typeof this.language.id !== 'undefined'){
                this.form.name = this.language.name
                this.form.enabled = this.language.enabled
                this.form.ebecas_id = this.language.ebecas_id
            }
        },
        methods: {
            // submits the form
            async submit() {
                let self = this;

                if(this.validateData()){
                    return;
                }
                this.loading = true;
                let formData = {
                    name: this.form.name,
                    enabled: this.form.enabled ? this.form.enabled : false,
                    ebecas_id: this.form.ebecas_id
                };
                // update request
                if ( this.language.id ) {
                    this.makeUpdateRequest(formData).then((response) => {
                        self.loading = false;
                        if (response.success === false) {
                            self.showToast(response.message, false)
                        } else {
                            window.location.href= response.redirect_route;
                        }
                    }).catch(function (err) {
                    self.loading = false;
                    if(typeof err.data.errors !== 'undefined'){
                        self.showErrors(err.data.errors);
                    }
                });
                }else {
                    // create request
                    this.makeCreateRequest(formData).then((response) => {
                        self.loading = false;
                        if (response.success === false) {
                            self.showToast(response.message, false)
                        } else {
                            window.location.href= response.redirect_route;
                        }
                    }).catch(function (err) {
                    self.loading = false;
                    if(typeof err.data.errors !== 'undefined'){
                        self.showErrors(err.data.errors);
                    }
                });
                }
            },
            // show validation errors from backend
            showErrors(errors){
                for (var key in errors) {
                    this.errors[key] = errors[key][0];
                }
            },
            // update request
            makeUpdateRequest(formData){
                return this.request.patch(route('staff.settings.languages.update', this.language.id), formData,{})
            },
            // create request
            makeCreateRequest(formData){
                return this.request.post(route('staff.settings.languages.store'), formData,{})
            },
            // show toaster
            showToast(message, isSuccess) {
                new bs5.Toast({
                    body: message,
                    className: !isSuccess ? 'border-0 bg-danger text-white' : 'border-0 bg-success text-white',
                    btnCloseWhite: true,
                }).show();
            },
            // validates form
            validateData(){
                let self = this;
                let check = false;

                if ( !this.form.name || typeof this.form.name == 'undefined' || this.form.name === '' ){
                    check = true;
                    this.errors.name = "This field is required"
                }else{
                    this.errors.name = ''
                }
                return check;
            },
            // update language status
            isStatusCheck(value){
                this.form.enabled = value
            }
        },
        computed: {
            formBtnText(){
                if(typeof this.language.id !== 'undefined'){
                    return 'Update';
                }
                return 'Create';
            },
            showBackBtn(){
                return typeof this.language === 'undefined';
            },
            backUrl(){
                return route('staff.settings.languages.index');
            },
            cancelUrl(){
                return route('staff.settings.languages.index');
            },
        }
    }
</script>

