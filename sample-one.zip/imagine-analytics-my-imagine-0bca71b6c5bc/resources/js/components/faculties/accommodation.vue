<template>
    <form class="mt-4">
        <!--    Accommodations    -->
        <h5>Accommodations</h5>
        <div v-for="(item,index) in form.selectedAccommodations" class="row mb-3">
            <div class="col-1">
                <label class="col-form-label">Action</label> <br>
                <button type="button" @click="deleteAccommodationRow(index)" class="btn btn-outline-danger btn-sm"><i class="fa fa-times"></i></button>
            </div>
            <div class="col-5">
                <label class="col-form-label">Accommodation</label>
                <v-select  label="name" v-model="form.selectedAccommodations[index].accommodation_id" :options="accommodations"  :reduce="option => option.id"  placeholder="Choose accommodation..." >
                    <template #no-options="{ search, searching, loading }">
                        <span>No options available</span>
                    </template>
                </v-select>
                <span class="text-danger" v-if="errorText(item,'accommodation_error')">{{errorText(item,'accommodation_error')}}</span>
            </div>

            <div class="col-6">
                <label class="col-form-label"> eBecas Product</label>
                <v-select label="name" v-model="form.selectedAccommodations[index].ebecas_product_id" :options="ebecasProductFilter"  :reduce="option => option.id"  placeholder="Choose eBECAS product..." >
                    <template #no-options="{ search, searching, loading }">
                        <span>No options available</span>
                    </template>
                </v-select>
                <span class="text-danger" v-if="errorText(item,'product_error')">{{errorText(item,'product_error')}}</span>
            </div>
        </div>
        <div class="">
            <p class="text-center mt-2 mb-2" v-if="form.selectedAccommodations.length === 0">No accommodation selected</p>
            <button type="button" @click="addRow()" class="btn btn-sm btn-outline-success">Add Accommodation</button>
        </div>

        <hr>

        <!--    Services    -->
        <h5 class="mt-4">Services</h5>
        <div v-for="(item,index) in form.selectedServices" class="row mb-3">
            <div class="col-1">
                <label class="col-form-label">Action</label> <br>
                <button type="button" @click="deleteServiceRow(index)" class="btn btn-outline-danger btn-sm"><i class="fa fa-times"></i></button>
            </div>
            <div class="col-5">
                <label class="col-form-label">Service</label>
                <v-select  label="name" v-model="form.selectedServices[index].fee_service_id" :options="services"  :reduce="option => option.id"  placeholder="Choose service..." >
                    <template #no-options="{ search, searching, loading }">
                        <span>No options available</span>
                    </template>
                </v-select>
                <span class="text-danger" v-if="errorText(item,'service_error')">{{errorText(item,'service_error')}}</span>
            </div>
            <div class="col-6">
                <label class="col-form-label"> eBecas Product</label>
                <v-select append-to-body label="name" v-model="form.selectedServices[index].ebecas_product_id" :options="ebecasServiceFilter"  :reduce="option => option.id"  placeholder="Choose eBECAS product..." >
                    <template #no-options="{ search, searching, loading }">
                        <span>No options available</span>
                    </template>
                </v-select>
                <span class="text-danger" v-if="errorText(item,'service_product_error')">{{errorText(item,'service_product_error')}}</span>
            </div>
        </div>
        <div class="">
            <p class="text-center mt-2 mb-2" v-if="form.selectedServices.length === 0">No service selected</p>
            <button type="button" @click="addServiceRow()" class="btn btn-sm btn-outline-success">Add Service</button>
        </div>

        <hr/>

        <!-- Add-ons section -->
        <h5 class="mt-4">Add-On</h5>
        <div v-for="(item,index) in form.selectedAddons" class="row mb-3">
            <div class="col-1">
                <label class="col-form-label">Action</label> <br>
                <button type="button" @click="deleteAddon(index)" class="btn btn-outline-danger btn-sm"><i class="fa fa-times"></i></button>
            </div>
            <div class="col-5">
                <label class="col-form-label">Add on</label>
                <v-select  label="name" v-model="form.selectedAddons[index].addon_id" :options="addons"  :reduce="option => option.id"  placeholder="Choose Add-on..." >
                    <template #no-options="{ search, searching, loading }">
                        <span>No options available</span>
                    </template>
                </v-select>
                <span class="text-danger" v-if="errorText(item,'addon_error')">{{errorText(item,'addon_error')}}</span>
            </div>
            <div class="col-6">
                <label class="col-form-label"> eBecas Product</label>
                <v-select append-to-body label="name" v-model="form.selectedAddons[index].ebecas_product_id" :options="ebecasServiceFilter"  :reduce="option => option.id"  placeholder="Choose eBECAS product..." >
                    <template #no-options="{ search, searching, loading }">
                        <span>No options available</span>
                    </template>
                </v-select>
                <span class="text-danger" v-if="errorText(item,'service_product_error')">{{errorText(item,'service_product_error')}}</span>
            </div>
        </div>
        <div class="">
            <p class="text-center mt-2 mb-2" v-if="form.selectedAddons.length === 0">No add-on selected</p>
            <button type="button" @click="addAddonRow()" class="btn btn-sm btn-outline-success">Add Add-on</button>
        </div>
        <hr/>

        <div class="row mt-5">
            <div class="d-flex justify-content-between">
                <a v-if="showBackBtn" :href="backUrl" class="btn btn-outline-secondary">
                    <i data-feather="arrow-left"></i>
                    Back
                </a>
                <a v-else :href="cancelUrl" class="btn btn-outline-secondary">
                    <!-- <i data-feather="arrow-left"></i> -->
                    Cancel
                </a>
                <button @click="submit" type="button" class="btn btn-primary" :disabled="loading"><i class="fa fa-spinner fa-spin" v-if="loading"></i>{{ formBtnText }}</button>
            </div>
        </div>

    </form>
</template>

<script>

import vSelect from "vue-select";
import {HttpService} from "../../services/HttpService";

export default {
    props: [
        'faculty',
        'accommodations',
        'selectedAccommodations',
        'ebecasProducts',
        'services',
        'selectedServices',
        'ebecasServices',
        'addons',
        'selectedAddons'
    ],
    components: {
        vSelect,
    },
    data() {
        var self = this;
        return {
            request: new HttpService(),
            loading:false,
            form : {
                selectedAccommodations: [
                    {
                        accommodation_id: null,
                        faculty_id: null,
                        ebecas_product_id: null,
                    }
                ],
                selectedServices: [
                    {
                        fee_service_id: null,
                        fee: null,
                        faculty_id: null,
                        ebecas_product_id: null,
                    }
                ],
                selectedAddons:[
                    {
                        addon_id: null,
                        faculty_id: null,
                        ebecas_product_id: null,
                    }
                ]
            },
            errors:{}
        }
    },
    mounted() {
        this.form.selectedAccommodations = this.selectedAccommodations;
        this.form.selectedServices = this.selectedServices;
        this.form.selectedAddons = this.selectedAddons;
    },
    methods : {
        addRow(){
            this.form.selectedAccommodations.push({
                accommodation_id: null,
                faculty_id: this.faculty.id,
                ebecas_product_id: null,
            });
        },
        addServiceRow(){
            this.form.selectedServices.push({
                fee_service_id: null,
                faculty_id: this.faculty.id,
                ebecas_product_id: null,
            });
        },
        addAddonRow(){
             this.form.selectedAddons.push({
                addon_id: null,
                faculty_id: this.faculty.id,
                ebecas_product_id: null,
            });
        },
        deleteAccommodationRow(index){
            this.form.selectedAccommodations.splice(index,1);
        },
        deleteServiceRow(index){
            this.form.selectedServices.splice(index,1);
        },
        deleteAddon(index){
            this.form.selectedAddons.splice(index,1);
        },
        submit() {
            if(this.validateData()){
                return;
            }

            let formData = this.getFormData();
            this.makeRequest(formData);
        },
        makeRequest(formData){
            let self = this;
            this.loading = true;
            this.request.patch(route('staff.settings.faculties.accommodation.update', this.faculty.id), formData)
                .then(function (response) {
                    self.loading = false;
                    if(response.success){
                        window.location.href= response.redirect_route;
                    }else{
                        self.showToast(response.message,response.success);
                    }
                }).catch(function (err) {
                self.loading = false;
                if(typeof err.data.errors !== 'undefined'){
                    self.showErrors(err.data.errors);
                }
            });
        },
        // show validation errors from backend
        showErrors(errors){
            for (var key in errors) {
                this.errors[key] = errors[key][0];
            }
        },
        getFormData(){
            return {
                accommodations: this.form.selectedAccommodations,
                services: this.form.selectedServices,
                addons: this.form.selectedAddons
            };
        },
        validateData(){
            
            let check1 = this.validatePrograms();
            let check2 = this.validateServices();
            let check3 = this.validateAddons();

            return check1 || check2 || check3;
        },
        validatePrograms() {
            let check = false;
            for(let index in this.form.selectedAccommodations) {
                let item = JSON.parse(JSON.stringify(this.form.selectedAccommodations[index]));

                let duplicateProgram = [];
                this.form.selectedAccommodations.forEach(obj => {
                    if(obj.accommodation_id === item.accommodation_id)
                        if(obj.accommodation_id !==null && item.accommodation_id!==null){
                            duplicateProgram.push(obj);
                        }
                });
                let duplicateProduct = [];
                this.form.selectedAccommodations.forEach(obj => {
                    if(obj.ebecas_product_id === item.ebecas_product_id)
                        if(obj.ebecas_product_id !==null && item.ebecas_product_id!==null){
                            duplicateProduct.push(obj);
                        }
                });

                if ( !item.accommodation_id || typeof item.accommodation_id == 'undefined' || item.accommodation_id === ''){
                    check = true;
                    Object.assign(this.form.selectedAccommodations[index], {accommodation_error: 'This field is required'});
                }else{
                    this.form.selectedAccommodations[index]['accommodation_error'] = '';
                }

                if ( !item.ebecas_product_id || typeof item.ebecas_product_id == 'undefined' || item.ebecas_product_id === ''){
                    check = true;
                    Object.assign(this.form.selectedAccommodations[index], {product_error: 'This field is required'});
                }else{
                    this.form.selectedAccommodations[index]['product_error'] = '';
                }

                if(duplicateProgram.length > 1){
                    check = true;
                    this.form.selectedAccommodations[index]['accommodation_error'] = 'This program is already included';
                }
                if(duplicateProduct.length > 1){
                    check = true;
                    this.form.selectedAccommodations[index]['product_error'] = 'This product is already included';
                }
            }

            return check;
        },
        validateServices() {
            let check = false;
            for(let index in this.form.selectedServices) {
                let item = JSON.parse(JSON.stringify(this.form.selectedServices[index]));

                let duplicateService = [];
                this.form.selectedServices.forEach(obj => {
                    if(obj.fee_service_id === item.fee_service_id)
                        if(obj.fee_service_id !==null && item.fee_service_id!==null){
                            duplicateService.push(obj);
                        }
                });
                let duplicateProduct = [];
                this.form.selectedServices.forEach(obj => {
                    if(obj.ebecas_product_id === item.ebecas_product_id)
                        if(obj.ebecas_product_id !==null && item.ebecas_product_id!==null){
                            duplicateProduct.push(obj);
                        }
                });

                if ( !item.fee_service_id || typeof item.fee_service_id == 'undefined' || item.fee_service_id === ''){
                    check = true;
                    Object.assign(this.form.selectedServices[index], {service_error: 'This field is required'});
                }else{
                    this.form.selectedServices[index]['service_error'] = '';
                }

                if ( !item.ebecas_product_id || typeof item.ebecas_product_id == 'undefined' || item.ebecas_product_id === ''){
                    check = true;
                    Object.assign(this.form.selectedServices[index], {service_product_error: 'This field is required'});
                }else{
                    this.form.selectedServices[index]['service_product_error'] = '';
                }

                if(duplicateService.length > 1){
                    check = true;
                    this.form.selectedServices[index]['service_error'] = 'This program is already included';
                }
                if(duplicateProduct.length > 1){
                    check = true;
                    this.form.selectedServices[index]['service_product_error'] = 'This product is already included';
                }
            }

            return check;
        },
        validateAddons() {
            let check = false;
            for(let index in this.form.selectedAddons) {
                let item = JSON.parse(JSON.stringify(this.form.selectedAddons[index]));

                let duplicateService = [];
                this.form.selectedAddons.forEach(obj => {
                    if(obj.addon_id === item.addon_id)
                        if(obj.addon_id !==null && item.addon_id!==null){
                            duplicateService.push(obj);
                        }
                });
                let duplicateProduct = [];
                this.form.selectedAddons.forEach(obj => {
                    if(obj.ebecas_product_id === item.ebecas_product_id)
                        if(obj.ebecas_product_id !==null && item.ebecas_product_id!==null){
                            duplicateProduct.push(obj);
                        }
                });

                if ( !item.addon_id || typeof item.addon_id == 'undefined' || item.addon_id === ''){
                    check = true;
                    Object.assign(this.form.selectedAddons[index], {addon_error: 'This field is required'});
                }else{
                    this.form.selectedAddons[index]['addon_error'] = '';
                }

                if ( !item.ebecas_product_id || typeof item.ebecas_product_id == 'undefined' || item.ebecas_product_id === ''){
                    check = true;
                    Object.assign(this.form.selectedAddons[index], {service_product_error: 'This field is required'});
                }else{
                    this.form.selectedAddons[index]['service_product_error'] = '';
                }

                if(duplicateService.length > 1){
                    check = true;
                    this.form.selectedAddons[index]['addon_error'] = 'This program is already included';
                }
                if(duplicateProduct.length > 1){
                    check = true;
                    this.form.selectedAddons[index]['service_product_error'] = 'This product is already included';
                }
            }

            return check;
        },
        errorText(item,key){
            if(item[key] !== ''){
                return item[key];
            }
            return '';
        },
    },
    computed : {
        formBtnText(){
            if(typeof this.faculty.id !== 'undefined'){
                return 'Update';
            }
            return 'Create';
        },
        showBackBtn(){
            return typeof this.faculty.id === 'undefined';
        },
        backUrl(){
            return route('staff.settings.faculties.index');
        },
        cancelUrl(){
            return route('staff.settings.faculties.index');
        },
        ebecasProductFilter(){
            let types = [];
            for ( let item in this.ebecasProducts) {
                types.push({
                    name:this.ebecasProducts[item].Name +'  ('+this.ebecasProducts[item].ProductId+')',
                    id:this.ebecasProducts[item].ProductId
                })
            }
            return types;
        },
        ebecasServiceFilter(){
            let types = [];
            for ( let item in this.ebecasServices) {
                let service = this.ebecasServices[item];
                if(typeof service !== 'undefined'){
                    types.push({
                        name:this.ebecasServices[item]['Name'] +'  ('+this.ebecasServices[item]['ProductId']+')',
                        id:this.ebecasServices[item]['ProductId']
                    })
                }
            }
            return types;
        }
    }
}
</script>

<style scoped>

</style>
