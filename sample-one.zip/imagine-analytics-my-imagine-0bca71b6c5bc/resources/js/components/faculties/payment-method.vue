<template>
    <form class="mt-4">
        <!--    payment methods    -->
        <h5>Payment Method</h5>
        <div v-for="(item,index) in form.selectedPaymentMethods" class="row mb-3">
            <div class="col-1">
                <label class="col-form-label">Action</label> <br>
                <button type="button" @click="deleteRow(index)" class="btn btn-outline-danger btn-sm"><i class="fa fa-times"></i></button>
            </div>
            <div class="col-5">
                <label class="col-form-label">Payment Method</label>
                <v-select  label="name" v-model="form.selectedPaymentMethods[index].payment_method_id" :options="paymentMethods"  :reduce="option => option.id"  placeholder="Choose Payment Method..." >
                    <template #no-options="{ search, searching, loading }">
                        <span>No options available</span>
                    </template>
                </v-select>
                <span class="text-danger" v-if="errorText(item,'payment_method_error')">{{errorText(item,'payment_method_error')}}</span>
            </div>

            <div class="col-6">
                <label class="col-form-label">eBecas Product</label>
                <v-select label="name" v-model="form.selectedPaymentMethods[index].ebecas_product_id" :options="ebecasProductFilter"  :reduce="option => option.id"  placeholder="Choose eBECAS product..." >
                    <template #no-options="{ search, searching, loading }">
                        <span>No options available</span>
                    </template>
                </v-select>
                <span class="text-danger" v-if="errorText(item,'product_error')">{{errorText(item,'product_error')}}</span>
            </div>
        </div>

        <div class="">
           <p class="text-center mt-2 mb-2" v-if="form.selectedPaymentMethods.length === 0">No payment method selected</p>
            <button type="button" @click="addRow()" class="btn btn-sm btn-outline-success">Add Payment Method</button>
        </div>


        <div class="row mt-5">
            <div class="d-flex justify-content-between">
                <a v-if="showBackBtn" :href="backUrl" class="btn btn-outline-secondary">
                    <i data-feather="arrow-left"></i>
                    Back
                </a>
                <a v-else :href="cancelUrl" class="btn btn-outline-secondary">
                    <!-- <i data-feather="arrow-left"></i> -->
                    Cancel
                </a>
                <button @click="submit" type="button" class="btn btn-primary" :disabled="loading"><i class="fa fa-spinner fa-spin" v-if="loading"></i>{{ formBtnText }}</button>
            </div>
        </div>

    </form>
</template>

<script>

import vSelect from "vue-select";
import {HttpService} from "../../services/HttpService";

export default {
    props: [
        'faculty',
        'paymentMethods',
        'products',
        'selectedPaymentMethods'
    ],
    components: {
        vSelect,
    },
    data() {
        var self = this;
        return {
            request: new HttpService(),
            loading:false,
            form : {
                selectedPaymentMethods: [
                    {
                        payment_method_id: null,
                        faculty_id: null,
                        ebecas_product_id:null

                    }
                ]
            },
            errors:{}
        }
    },
    mounted() {
        this.form.selectedPaymentMethods = this.selectedPaymentMethods;
    },
    methods : {
        addRow(){
            this.form.selectedPaymentMethods.push({
                payment_method_id: null,
                faculty_id: this.faculty.id,
                ebecas_product_id:null
            });
        },

        deleteRow(index){
            this.form.selectedPaymentMethods.splice(index,1);
        },

        submit() {
            if(this.validatePaymentMethod()){
                return;
            }

            let formData = this.getFormData();
            this.makeRequest(formData);
        },
        makeRequest(formData){
            let self = this;
            this.loading = true;
            this.request.patch(route('staff.settings.faculties.payment-methods.update', this.faculty.id), formData)
                .then(function (response) {
                    self.loading = false;
                    if(response.success){
                        window.location.href= response.redirect_route;
                    }else{
                        self.showToast(response.message,response.success);
                    }
                }).catch(function (err) {
                self.loading = false;
                if(typeof err.data.errors !== 'undefined'){
                    self.showErrors(err.data.errors);
                }
            });
        },
        // show validation errors from backend
        showErrors(errors){
            for (var key in errors) {
                this.errors[key] = errors[key][0];
            }
        },
        getFormData(){
            return {
                payment_methods: this.form.selectedPaymentMethods,
            };
        },

        validatePaymentMethod() {
            let check = false;
            for(let index in this.form.selectedPaymentMethods) {
                let item = JSON.parse(JSON.stringify(this.form.selectedPaymentMethods[index]));

                let duplicatePaymentMethod = [];
                this.form.selectedPaymentMethods.forEach(obj => {
                    if(obj.payment_method_id === item.payment_method_id)
                        if(obj.payment_method_id !==null && item.payment_method_id!==null){
                            duplicatePaymentMethod.push(obj);
                        }
                });

                let duplicateProduct = [];
                this.form.selectedPaymentMethods.forEach(obj => {
                    if(obj.ebecas_product_id === item.ebecas_product_id)
                        if(obj.ebecas_product_id !==null && item.ebecas_product_id!==null){
                            duplicateProduct.push(obj);
                        }
                });

                if ( !item.payment_method_id || typeof item.payment_method_id == 'undefined' || item.payment_method_id === ''){
                    check = true;
                    Object.assign(this.form.selectedPaymentMethods[index], {payment_method_error: 'This field is required'});
                }else{
                    this.form.selectedPaymentMethods[index]['payment_method_error'] = '';
                }

                if ( !item.ebecas_product_id || typeof item.ebecas_product_id == 'undefined' || item.ebecas_product_id === ''){
                    check = true;
                    Object.assign(this.form.selectedPaymentMethods[index], {product_error: 'This field is required'});
                }else{
                    this.form.selectedPaymentMethods[index]['product_error'] = '';
                }

                if(duplicatePaymentMethod.length > 1){
                    check = true;
                    this.form.selectedPaymentMethods[index]['payment_method_error'] = 'This payment method is already included';
                }

                if(duplicateProduct.length > 1){
                    check = true;
                    this.form.selectedPaymentMethods[index]['product_error'] = 'This product is already included';
                }

            }

            return check;
        },

        errorText(item,key){
            if(item[key] !== ''){
                return item[key];
            }
            return '';
        },
    },
    computed : {
        formBtnText(){
            if(typeof this.faculty.id !== 'undefined'){
                return 'Update';
            }
            return 'Create';
        },
        showBackBtn(){
            return typeof this.faculty.id === 'undefined';
        },
        backUrl(){
            return route('staff.settings.faculties.index');
        },
        cancelUrl(){
            return route('staff.settings.faculties.index');
        },
        ebecasProductFilter(){
            let types = [];
            for ( let item in this.products) {
                types.push({
                    name:this.products[item].Name +'  ('+this.products[item].ProductId+')',
                    id:this.products[item].ProductId
                })
            }
            return types;
        }


    }
}
</script>

<style scoped>

</style>
