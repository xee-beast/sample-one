<template>
    <form class="mt-4">
        <!--    insurance    -->

        <div class="row mb-3">

            <div class="col-12">
                <label class="col-form-label">Select the insurance type to view or update</label>
                <v-select :clearable="false" label="type" v-model="form.selectedInsurance" :options="insuranceFilter"  :reduce="option => option.id"  placeholder="Choose Insurance..." >
                    <template #no-options="{ search, searching, loading }">
                        <span>No options available</span>
                    </template>
                </v-select>
            </div>

            <div class="row mt-3">
                <div class="col-6">
                    <label><b>Duration</b></label>
                </div>
                <div class="col-6">
                    <label><b>eBECAS product</b></label>
                </div>
            </div>

            <div class="row mt-3" v-for="(item,index) in fees">
                <div class="col-6">
                    <input disabled id="duration" type="number" class="form-control" placeholder="Duration" required v-model="item.duration">
                </div>
                <div class="col-6">
                    <v-select label="name" v-model="fees[index].ebecas_product_id" :options="ebecasInsuranceProductFilter"  :reduce="option => option.id"  placeholder="Choose eBECAS product..." >
                        <template #no-options="{ search, searching, loading }">
                            <span>No options available</span>
                        </template>
                    </v-select>
                    <span class="text-danger" v-if="errorText(item,'product_error')">{{errorText(item,'product_error')}}</span>
                </div>
            </div>

        </div>

        <div class="row mt-5">
            <div class="d-flex justify-content-between">
                <a v-if="showBackBtn" :href="backUrl" class="btn btn-outline-secondary">
                    <i data-feather="arrow-left"></i>
                    Back
                </a>
                <a v-else :href="cancelUrl" class="btn btn-outline-secondary">
                    <!-- <i data-feather="arrow-left"></i> -->
                    Cancel
                </a>
                <button @click="submit" type="button" class="btn btn-primary" :disabled="loading"><i class="fa fa-spinner fa-spin" v-if="loading"></i>{{ formBtnText }}</button>
            </div>
        </div>

    </form>
</template>

<script>

import vSelect from "vue-select";
import {HttpService} from "../../services/HttpService";
import generalHelpers from "../../helpers/generalHelpers";

export default {
    props: [
        'faculty',
        'insurances',
        'insuranceProducts',
        'selectedInsurance'
    ],
    components: {
        vSelect,
    },
    data() {
        var self = this;
        return {
            request: new HttpService(),
            loading:false,
            fees: [],
            form : {
                selectedInsurance : 1
            },
            errors:{}
        }
    },
    mounted() {
        this.getFees();
    },
    methods : {
        async submit() {
            if (await this.validateInsurance()) {
                return;
            }

            let formData = this.getFormData();
            this.makeRequest(formData);
        },
        makeRequest(formData){
            let self = this;
            this.loading = true;
            this.request.patch(route('staff.settings.faculties.insurance.update', this.faculty.id), formData)
                .then(function (response) {
                    self.loading = false;
                    if(response.success){
                        window.location.href= response.redirect_route;
                    }else{
                        self.showToast(response.message,response.success);
                    }
                }).catch(function (err) {
                self.loading = false;
                if(typeof err.data.errors !== 'undefined'){
                    self.showErrors(err.data.errors);
                }
            });
        },
        getFees(){
            // clearing error
            for(let index in this.fees) {
                this.fees[index]['product_error'] = '';
            }
            for (const insuranceKey in this.insurances) {
                if (this.insurances[insuranceKey].id === this.form.selectedInsurance){
                    this.fees = this.insurances[insuranceKey].fees;
                }
            }
            // updating selected insurances
            for (const feeKey in this.fees) {
                for (const feeInsuranceKey in this.selectedInsurance) {
                    if (this.selectedInsurance[feeInsuranceKey].insurance_fee_id === this.fees[feeKey].id){
                        this.fees[feeKey].ebecas_product_id = this.selectedInsurance[feeInsuranceKey].ebecas_product_id;
                        this.fees[feeKey]['product_error'] = '';
                    }
                }
            }
        },
        // show validation errors from backend
        showErrors(errors){
            for (var key in errors) {
                this.errors[key] = errors[key][0];
            }
        },
        getFormData(){
            let data = [];
            this.fees.map(fee => {
               data.push({
                   insurance_fee_id : fee.id,
                   ebecas_product_id : fee.ebecas_product_id,
                   duration : fee.duration,
               })
            });
            return {
                insurances: data,
                insurance_id: this.form.selectedInsurance
            };
        },

        async validateInsurance() {
            let check = false;

            for(let index in this.fees) {
                let item = JSON.parse(JSON.stringify(this.fees[index]));

                if ( !item.ebecas_product_id || typeof item.ebecas_product_id == 'undefined' || item.ebecas_product_id === ''){
                    check = true;
                    Object.assign(this.fees[index], {product_error: 'This field is required'});
                }else{
                    this.fees[index]['product_error'] = '';
                }

            }

            return check;
        },
        errorText(item,key){
            if(item[key] !== ''){
                return item[key];
            }
            return '';
        },
    },
    computed : {
        formBtnText(){
            if(typeof this.faculty.id !== 'undefined'){
                return 'Update';
            }
            return 'Create';
        },
        showBackBtn(){
            return typeof this.faculty.id === 'undefined';
        },
        backUrl(){
            return route('staff.settings.faculties.index');
        },
        cancelUrl(){
            return route('staff.settings.faculties.index');
        },
        ebecasInsuranceProductFilter(){
            let types = [];
            for ( let item in this.insuranceProducts) {
                types.push({
                    name:this.insuranceProducts[item].Name +'  ('+this.insuranceProducts[item].ProductId+')',
                    id:this.insuranceProducts[item].ProductId
                })
            }
            return types;
        },
        insuranceFilter(){
            let types = [];
            for ( let item in this.insurances) {
                types.push({
                    type:generalHelpers.capitalizeFirstLetter(this.insurances[item].type),
                    id:this.insurances[item].id
                })
            }
            return types;
        }
    },
    watch : {
        'form.selectedInsurance':function(newVal,oldVal){
            this.getFees()
        },
    }
}
</script>

<style scoped>

</style>
