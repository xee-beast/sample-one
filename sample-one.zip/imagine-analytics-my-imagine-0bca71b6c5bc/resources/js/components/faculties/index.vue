<template>
    <div class="mt-4">
        <div class="filter-datatable">
            <div class="row filter-dropdown">
                <div class="col-3">
                    <v-select  label="name" v-model="filter.location"
                               :options="locations"
                               :change="reloadDataTable()"
                               :reduce="option => option.id" placeholder="Filter by Location">
                        <template #no-options="{ search, searching, loading }">
                            <span>No options available</span>
                        </template>
                    </v-select>
                </div>
                <div class="col-3">
                    <v-select  label="label" v-model="filter.enabled"
                               :options="enabledOptions"
                               :change="reloadDataTable()"
                               :reduce="option => option.value" placeholder="Filter by Status">
                        <template #no-options="{ search, searching, loading }">
                            <span>No options available</span>
                        </template>
                    </v-select>
                </div>
            </div>
            <table class="table table-bordered table-striped" id="faculty-table">
                <thead>
                <tr>
                    <th scope="col" >Name</th>
                    <th scope="col" >Location</th>
                    <th scope="col" >eBECAS Id</th>
                    <th scope="col" >Status</th>
                </tr>
                </thead>
                <tbody></tbody>
            </table>
        </div>
    </div>
</template>

<script>
    import 'datatables.net-dt/js/dataTables.dataTables';
    import 'datatables.net-dt/css/jquery.dataTables.min.css';
    import 'datatables.net-dt/js/dataTables.dataTables';
    import 'datatables.net-dt/css/jquery.dataTables.min.css';
    import vSelect from "vue-select";
    export default {
        props:['locations'],
        components: {
            vSelect
        },
        data() {
            var self = this;
            return {
                datatable: null,
                enabledOptions:[
                    {
                        label:'--All--',
                        value:''
                    },
                    {
                        label:'Active',
                        value:1
                    },
                    {
                        label:'Inactive',
                        value:0
                    }
                ],
                selected: null,
                filter:{
                    enabled:null,
                    location:null,
                }
            }
        },
        mounted() {
            this.setDataTable();

        },
        computed : {
        },
        methods: {
            setDataTable(){
                let self = this;
                this.datatable = $('#faculty-table').DataTable( {
                    dom: 'f <tilp>',
                    processing: true,
                    serverSide: true,
                    ordering: true,
                    responsive: true,
                    ajax: {
                        url: route('staff.settings.faculties.list'),
                        data: function ( d ) {
                            d.location = self.filter.location,
                            d.enabled =  self.filter.enabled
                        },
                    },
                    columns: [
                        {data: 'name', name: 'name', orderable: true},
                        {data: 'location', name: 'location',orderable: false},
                        {data: 'ebecas_id', name: 'ebecas_id',orderable: false},
                        {data: 'enabled', name: 'enabled',orderable: false},
                    ]
                });
            },
            reloadDataTable(){
                if ( this.datatable ) {
                    this.datatable.draw();
                }
            }
        }
    }
</script>

