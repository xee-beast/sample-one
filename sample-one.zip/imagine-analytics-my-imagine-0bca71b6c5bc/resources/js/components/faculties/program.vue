<template>
    <form>
        <!--    Programs    -->
        <h5>Programs</h5>
        <div v-for="(item,index) in form.selectedPrograms" class="row mb-3">
            <div class="col-1">
                <label class="col-form-label">Action</label> <br>
                <button type="button" @click="deleteProgramRow(index)" class="btn btn-outline-danger btn-sm"><i class="fa fa-times"></i></button>
            </div>
            <div class="col-3">
                <label class="col-form-label">Program</label>
                <v-select  label="name" v-model="form.selectedPrograms[index].program_id" :options="programs"  :reduce="option => option.id"  placeholder="Choose program..." >
                    <template #no-options="{ search, searching, loading }">
                        <span>No options available</span>
                    </template>
                </v-select>
                <span class="text-danger" v-if="errorText(item,'program_error')">{{errorText(item,'program_error')}}</span>
            </div>
            <div class="col-2">
                <label class="col-form-label">Calendar</label>
                <v-select  label="name" v-model="form.selectedPrograms[index].calendar_id" :options="calendars"  :reduce="option => option.id"  placeholder="Choose Calendar..." >
                    <template #no-options="{ search, searching, loading }">
                        <span>No options available</span>
                    </template>
                </v-select>
                <span class="text-danger" v-if="errorText(item,'calendar_error')">{{errorText(item,'calendar_error')}}</span>
            </div>
            <div class="col-6">
                <label class="col-form-label"> eBecas Product</label>
                <v-select label="name" v-model="form.selectedPrograms[index].ebecas_product_id" :options="ebecasCourseProductFilter"  :reduce="option => option.id"  placeholder="Choose eBECAS product..." >
                    <template #no-options="{ search, searching, loading }">
                        <span>No options available</span>
                    </template>
                </v-select>
                <span class="text-danger" v-if="errorText(item,'product_error')">{{errorText(item,'product_error')}}</span>
            </div>
        </div>

        <p class="text-center mt-2 mb-2" v-if="form.selectedPrograms.length === 0">No programs selected</p>
        <button type="button" @click="addProgramRow()" class="btn btn-sm btn-outline-success">Add Program</button>

        <hr>

        <!--    Services    -->
        <h5 class="mt-4">Services</h5>
        <div v-for="(item,index) in form.selectedServices" class="row mb-3">
            <div class="col-1">
                <label class="col-form-label">Action</label> <br>
                <button type="button" @click="deleteServiceRow(index)" class="btn btn-outline-danger btn-sm"><i class="fa fa-times"></i></button>
            </div>
            <div class="col-3">
                <label class="col-form-label">Service</label>
                <v-select  label="name" v-model="form.selectedServices[index].program_fee_service_id" :options="services"  :reduce="option => option.id"  placeholder="Choose service..." >
                    <template #no-options="{ search, searching, loading }">
                        <span>No options available</span>
                    </template>
                </v-select>
                <span class="text-danger" v-if="errorText(item,'service_error')">{{errorText(item,'service_error')}}</span>
            </div>
            <div class="col-2">
                <label class="col-form-label">Fee ($)</label>
                <input v-model="form.selectedServices[index].fee" type="number" class="form-control" required min="0" oninput="validity.valid||(value='');">
                <span class="text-danger" v-if="errorText(item,'fee_error')">{{errorText(item,'fee_error')}}</span>
            </div>
            <div class="col-6">
                <label class="col-form-label"> eBecas Product</label>
                <v-select append-to-body label="name" v-model="form.selectedServices[index].ebecas_product_id" :options="ebecasOtherProductFilter"  :reduce="option => option.id"  placeholder="Choose eBECAS product..." >
                    <template #no-options="{ search, searching, loading }">
                        <span>No options available</span>
                    </template>
                </v-select>
                <span class="text-danger" v-if="errorText(item,'service_product_error')">{{errorText(item,'service_product_error')}}</span>
            </div>
        </div>

        <p class="text-center mt-2 mb-2" v-if="form.selectedServices.length === 0">No service selected</p>
        <button type="button" @click="addServiceRow()" class="btn btn-sm btn-outline-success">Add Service</button>



        <div class="row mt-5">
            <div class="d-flex justify-content-between">
                <a v-if="showBackBtn" :href="backUrl" class="btn btn-outline-secondary">
                    <i data-feather="arrow-left"></i>
                    Back
                </a>
                <a v-else :href="cancelUrl" class="btn btn-outline-secondary">
                    <!-- <i data-feather="arrow-left"></i> -->
                    Cancel
                </a>
                <button @click="submit" type="button" class="btn btn-primary" :disabled="loading"><i class="fa fa-spinner fa-spin" v-if="loading"></i>{{ formBtnText }}</button>
            </div>
        </div>

    </form>
</template>

<script>

import vSelect from "vue-select";
import {HttpService} from "../../services/HttpService";
import generalHelpers from "../../helpers/generalHelpers";

export default {
    props: [
        'faculty',
        'programs',
        'calendars',
        'selectedPrograms',
        'ebecasCourseProducts',
        'ebecasOtherProducts',
        'services',
        'selectedServices'
    ],
    components: {
        vSelect,
    },
    data() {
        var self = this;
        return {
            request: new HttpService(),
            loading:false,
            form : {
                selectedPrograms: [
                    {
                        program_id: null,
                        calendar_id: null,
                        faculty_id: null,
                        ebecas_product_id: null,
                    }
                ],
                selectedServices: [
                    {
                        program_fee_service_id: null,
                        fee: null,
                        faculty_id: null,
                        ebecas_product_id: null,
                    }
                ]
            },
            errors:{}
        }
    },
    mounted() {
        this.form.selectedPrograms = this.selectedPrograms;
        this.form.selectedServices = this.selectedServices;
    },
    methods : {
        addProgramRow(){
            this.form.selectedPrograms.push({
                program_id: null,
                calendar_id: null,
                faculty_id: this.faculty.id,
                ebecas_product_id: null,
            });
        },
        addServiceRow(){
            this.form.selectedServices.push({
                program_fee_service_id: null,
                fee: null,
                faculty_id: this.faculty.id,
                ebecas_product_id: null,
            });
        },
        deleteProgramRow(index){
            this.form.selectedPrograms.splice(index,1);
        },
        deleteServiceRow(index){
            this.form.selectedServices.splice(index,1);
        },
        submit() {
            if(this.validateData()){
                return;
            }

            let formData = this.getFormData();
            this.makeRequest(formData);
        },
        makeRequest(formData){
            let self = this;
            this.loading = true;
            this.request.patch(route('staff.settings.faculties.programs.update', this.faculty.id), formData)
                .then(function (response) {
                    self.loading = false;
                    if(response.success){
                        window.location.href= response.redirect_route;
                    }else{
                        generalHelpers.showToast(response.message,response.success);
                    }
                }).catch(function (err) {
                self.loading = false;
                if(typeof err.data.errors !== 'undefined'){
                    self.showErrors(err.data.errors);
                }
            });
        },
        // show validation errors from backend
        showErrors(errors){
            for (var key in errors) {
                this.errors[key] = errors[key][0];
            }
        },
        getFormData(){
            return {
                programs: this.form.selectedPrograms,
                services: this.form.selectedServices,
            };
        },
        validateData(){
            let check1 = this.validatePrograms();
            let check2 = this.validateServices();
            return check1 || check2;
        },
        validatePrograms() {
            let check = false;
            for(let index in this.form.selectedPrograms) {
                let item = JSON.parse(JSON.stringify(this.form.selectedPrograms[index]));

                let duplicateProgram = [];
                this.form.selectedPrograms.forEach(obj => {
                    if(obj.program_id === item.program_id)
                        if(obj.program_id !==null && item.program_id!==null){
                            duplicateProgram.push(obj);
                        }
                });
                let duplicateProduct = [];
                this.form.selectedPrograms.forEach(obj => {
                    if(obj.ebecas_product_id === item.ebecas_product_id)
                        if(obj.ebecas_product_id !==null && item.ebecas_product_id!==null){
                            duplicateProduct.push(obj);
                        }
                });

                if ( !item.program_id || typeof item.program_id == 'undefined' || item.program_id === ''){
                    check = true;
                    Object.assign(this.form.selectedPrograms[index], {program_error: 'This field is required'});
                }else{
                    this.form.selectedPrograms[index]['program_error'] = '';
                }

                if ( !item.ebecas_product_id || typeof item.ebecas_product_id == 'undefined' || item.ebecas_product_id === ''){
                    check = true;
                    Object.assign(this.form.selectedPrograms[index], {product_error: 'This field is required'});
                }else{
                    this.form.selectedPrograms[index]['product_error'] = '';
                }

                if ( !item.calendar_id || typeof item.calendar_id == 'undefined' || item.calendar_id === ''){
                    check = true;
                    Object.assign(this.form.selectedPrograms[index], {calendar_error: 'This field is required'});
                }else{
                    this.form.selectedPrograms[index]['calendar_error'] = '';
                }

                if(duplicateProgram.length > 1){
                    check = true;
                    this.form.selectedPrograms[index]['program_error'] = 'This program is already included';
                }
                if(duplicateProduct.length > 1){
                    check = true;
                    this.form.selectedPrograms[index]['product_error'] = 'This product is already included';
                }
            }

            return check;
        },
        validateServices() {
            let check = false;
            for(let index in this.form.selectedServices) {
                let item = JSON.parse(JSON.stringify(this.form.selectedServices[index]));

                let duplicateService = [];
                this.form.selectedServices.forEach(obj => {
                    if(obj.program_fee_service_id === item.program_fee_service_id)
                        if(obj.program_fee_service_id !==null && item.program_fee_service_id!==null){
                            duplicateService.push(obj);
                        }
                });
                let duplicateProduct = [];
                this.form.selectedServices.forEach(obj => {
                    if(obj.ebecas_product_id === item.ebecas_product_id)
                        if(obj.ebecas_product_id !==null && item.ebecas_product_id!==null){
                            duplicateProduct.push(obj);
                        }
                });

                if ( !item.program_fee_service_id || typeof item.program_fee_service_id == 'undefined' || item.program_fee_service_id === ''){
                    check = true;
                    Object.assign(this.form.selectedServices[index], {service_error: 'This field is required'});
                }else{
                    this.form.selectedServices[index]['service_error'] = '';
                }

                if ( !item.ebecas_product_id || typeof item.ebecas_product_id == 'undefined' || item.ebecas_product_id === ''){
                    check = true;
                    Object.assign(this.form.selectedServices[index], {service_product_error: 'This field is required'});
                }else{
                    this.form.selectedServices[index]['service_product_error'] = '';
                }

                if(duplicateService.length > 1){
                    check = true;
                    this.form.selectedServices[index]['service_error'] = 'This program is already included';
                }
                if(duplicateProduct.length > 1){
                    check = true;
                    this.form.selectedServices[index]['service_product_error'] = 'This product is already included';
                }
            }

            return check;
        },
        errorText(item,key){
            if(item[key] !== ''){
                return item[key];
            }
            return '';
        },
    },
    computed : {
        formBtnText(){
            if(typeof this.faculty.id !== 'undefined'){
                return 'Update';
            }
            return 'Create';
        },
        showBackBtn(){
            return typeof this.faculty.id === 'undefined';
        },
        backUrl(){
            return route('staff.settings.faculties.index');
        },
        cancelUrl(){
            return route('staff.settings.faculties.index');
        },
        ebecasCourseProductFilter(){
            let types = [];
            for ( let item in this.ebecasCourseProducts) {
                types.push({
                    name:this.ebecasCourseProducts[item].Name +'  ('+this.ebecasCourseProducts[item].ProductId+')',
                    id:this.ebecasCourseProducts[item].ProductId
                })
            }
            return types;
        }
        ,
        ebecasOtherProductFilter(){
            let types = [];
            for ( let item in this.ebecasOtherProducts) {
                types.push({
                    name:this.ebecasOtherProducts[item].Name +'  ('+this.ebecasOtherProducts[item].ProductId+')',
                    id:this.ebecasOtherProducts[item].ProductId
                })
            }
            return types;
        }
    }
}
</script>

<style scoped>

</style>
