<template>
    <form>

        <div class="mt-2">
            <div class="form-group form-check form-switch">
                <input type="hidden" name="enabled" value="0">
                <input @click="isStatusCheck(!form.enabled)" class="form-check-input" type="checkbox" :checked="!!form.enabled">
                <label class="form-check-label">Active</label>
            </div>
        </div>

        <!--    Name        -->
        <div class="col-12 form-group required mt-3">
            <label class="form-label">Name</label>
            <input v-model="form.name" type="text" class="form-control" required >
            <p class="text-danger" v-if="errors.name">{{ errors.name }}</p>
        </div>
        <!--    Description            -->
        <div class="col-12 form-group mt-2">
            <label class="form-label">Description</label>
            <textarea v-model="form.description" class="form-control" maxlength="255" id="description" name="description" rows="3" placeholder="">{{form.description}}</textarea>
        </div>

        <!--    Locations            -->
        <div class="col-12 form-group required mt-2">
            <label class="form-label">Location</label>
            <v-select label="name" v-model="form.location_id" :options="locations" :reduce="option => option.id"  placeholder="Choose Location..." :search-able="true">
                <template #no-options="{ search, searching, loading }">
                    <span>No options available</span>
                </template>
            </v-select>
            <p class="text-danger" v-if="errors.location_id">{{ errors.location_id }}</p>
        </div>

        <div class="col-12 form-group required mt-2">
            <label class="form-label">eBECAS Faculty</label>
            <v-select :loading="loadingEbecas" label="FacultyName" key="FacultyId" v-model="form.ebecas_id"
                      :options="ebecasFaculties" :reduce="option => option.FacultyId"
                      :class="{ disabled: loadingEbecas }"
                      placeholder="Choose Faculty..." :search-able="true">
                <template #no-options="{ search, searching, loading }">
                    <span>No options available</span>
                </template>
                <template #spinner="{ loading }">
                    <div
                        v-if="loadingEbecas"
                        style="border-left-color: rgba(88, 151, 251, 0.71)"
                        class="vs__spinner"
                    >
                    </div>
                </template>
            </v-select>
            <p class="text-danger" v-if="errors.ebecas_id">{{ errors.ebecas_id }}</p>
        </div>

        <div class="row mt-5">
            <div class="d-flex justify-content-between">
                <a v-if="showBackBtn" :href="backUrl" class="btn btn-outline-secondary">
                    <i data-feather="arrow-left"></i>
                    Back
                </a>
                <a v-else :href="cancelUrl" class="btn btn-outline-secondary">
                    <!-- <i data-feather="arrow-left"></i> -->
                    Cancel
                </a>
                <button @click="submit" type="button" class="btn btn-primary" :disabled="loading"><i class="fa fa-spinner fa-spin" v-if="loading"></i>{{ formBtnText }}</button>
            </div>
        </div>

    </form>
</template>

<script>
import vSelect from "vue-select";
import 'bs5-toast'
import {HttpService} from "../../services/HttpService";

export default {
    props: [
        'faculty',
        'locations',
    ],
    components: {
        vSelect,
    },
    data() {
        return {
            request: new HttpService(),
            loading:false,
            loadingEbecas:false,
            ebecasFaculties:[],
            firstLoad:true,
            form: {
                name: null,
                description: null,
                location_id: null,
                ebecas_id: null,
            },
            errors:{
                name:'',
                location_id:'',
                ebecas_id:'',
            },
        }
    },
    async mounted() {
        if(this.faculty.id){
            await this.getEbecasData()
            this.setFormValues()
        }
    },
    methods: {
        setFormValues(){
            this.form.name = this.faculty.name
            this.form.enabled = this.faculty.enabled
            this.form.description = this.faculty.description
            this.form.location_id = this.faculty.location_id
            this.form.ebecas_id = this.faculty.ebecas_id
        },
        // submits the form
        async submit() {
            let self = this;

            if(this.validateData()){
                return;
            }
            this.loading = true;
            let formData = this.getFormData();
            // update request
            if ( this.faculty.id ) {
                this.makeUpdateRequest(formData).then((response) => {
                    self.loading = false;
                    if (response.success === false) {
                        self.showToast(response.message, false)
                    } else {
                        window.location.href= response.redirect_route;
                    }
                }).catch(function (error) {
                    $.each(error.data.errors, function ( fieldName, msg ){
                        if ( self.errors.hasOwnProperty(fieldName) ) {
                            self.errors[fieldName] = msg[0];
                        }else{
                            self.showToast(error.data.message, false)
                        }
                        self.loading = false;
                    });
                });
            }else {
                // create request
                this.makeCreateRequest(formData).then((response) => {
                    self.loading = false;
                    if (response.success === false) {
                        self.showToast(response.message, false)
                    } else {
                        window.location.href= response.redirect_route;
                    }
                }).catch(function (error) {
                    $.each(error.data.errors, function ( fieldName, msg ){
                        if ( self.errors.hasOwnProperty(fieldName) ) {
                            self.errors[fieldName] = msg[0];
                        }else{
                            self.showToast(error.data.message, false)
                        }
                        self.loading = false;
                    });
                });
            }
        },
        // update request
        makeUpdateRequest(formData){
            return this.request.patch(route('staff.settings.faculties.update', this.faculty.id), formData,{})
        },
        // create request
        makeCreateRequest(formData){
            return this.request.post(route('staff.settings.faculties.store'), formData,{})
        },
        // get form data
        getFormData(){
            return {
                'name': this.form.name,
                'description': this.form.description,
                'location_id': this.form.location_id,
                'ebecas_id': this.form.ebecas_id,
                'enabled': this.form.enabled ? this.form.enabled : false,
            };
        },
        // show toaster
        showToast(message, isSuccess) {
            new bs5.Toast({
                body: message,
                className: !isSuccess ? 'border-0 bg-danger text-white' : 'border-0 bg-success text-white',
                btnCloseWhite: true,
            }).show();
        },
        // validates form
        validateData(){
            let self = this;
            let check = false;

            $.each( self.errors, function (fieldName) {self.errors[fieldName] = '';});

            if ( ! this.form.name || typeof this.form.name == 'undefined' || this.form.name === '' ){
                check = true;
                this.errors.name = "This field is required"
            }
            if ( ! this.form.location_id || typeof this.form.location_id == 'undefined' || this.form.location_id === '' ){
                check = true;
                this.errors.location_id = "This field is required"
            }
            if ( ! this.form.ebecas_id || typeof this.form.ebecas_id == 'undefined' || this.form.ebecas_id === '' ){
                check = true;
                this.errors.ebecas_id = "This field is required"
            }

            return check;
        },
        // update faculty status
        isStatusCheck(value){
            this.form.enabled = value
        },
        getEbecasData(){
            const self = this;
            if(self.form.location_id){
                self.loadingEbecas = true;
                this.request.get(route('location.faculties.get', self.form.location_id),{}).then((response) => {
                    self.loadingEbecas = false;
                    self.ebecasFaculties = response.faculties
                    if ( ! self.firstLoad ) {
                        self.form.ebecas_id = null
                    }
                    self.firstLoad = false
                }).catch(function (error) {
                    self.loadingEbecas = false;
                    $.each(error.data.errors, function ( fieldName, msg ){
                        if ( self.errors.hasOwnProperty(fieldName) ) {
                            self.errors[fieldName] = msg[0];
                        }
                    })
                });
            }
        },
    },
    watch: {
        'form.location_id' : {
            handler: function handler(newVal, oldVal) {
                if (newVal !== oldVal) {
                    this.getEbecasData()
                }
            },
        },
    },
    computed: {
        formBtnText(){
            if(typeof this.faculty.id !== 'undefined'){
                return 'Update';
            }
            return 'Create';
        },
        showBackBtn(){
            return typeof this.faculty.id === 'undefined';
        },
        backUrl(){
            return route('staff.settings.faculties.index');
        },
        cancelUrl(){
            return route('staff.settings.faculties.index');
        },
    }
}
</script>
