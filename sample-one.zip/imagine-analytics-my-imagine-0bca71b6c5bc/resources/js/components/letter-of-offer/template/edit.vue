<template>
    <div class="row">
        <div class="col-12">
            <form>
                <div class="mt-2">
                    <div class="form-group form-check form-switch">
                        <input type="hidden" name="enabled" value="0">
                        <input @click="isStatusCheck(!form.enabled)" class="form-check-input" type="checkbox" :checked="!!form.enabled">
                        <label class="form-check-label">Active</label>
                    </div>
                </div>

                    <!--    Name        -->
                <div class="col-12 form-group required mt-3">
                        <label class="form-label">Name</label>
                        <input v-model="form.name" type="text" class="form-control" required >
                        <p class="text-danger" v-if="errors.name">{{ errors.name }}</p>
                </div>

                    <!--    Description            -->
                <div class="col-12 form-group mt-3">
                        <label class="form-label">Description</label>
                        <textarea v-model="form.description" class="form-control" maxlength="255" id="description" name="description" rows="3" placeholder="">{{form.description}}</textarea>
                </div>

                <!--    Faculty            -->
                <div class="col-12 form-group mt-3 required">
                        <label class="form-label">Faculty</label>
                    <v-select  label="name" v-model="form.faculty"
                               :options="faculties"
                               :reduce="option => option.id" placeholder="Select Faculty">
                        <template #no-options="{ search, searching, loading }">
                            <span>No options available</span>
                        </template>
                    </v-select>
                    <p class="text-danger" v-if="errors.faculty_id">{{ errors.faculty_id }}</p>
                </div>

            </form>
        </div>
    </div>

    <div class="row mt-3">

        <label class="form-label">Sections</label>

        <!--   Date rows header    -->
        <div class="row mt-4 justify-content-center">
            <div class="col-3">
                <label class="form-label">Type</label>
            </div>
            <div class="col-3">
                <label class="form-label">Name</label>
            </div>
            <div class="col-3">
                <label class="form-label">Section</label>
            </div>
            <div class="col-1">
                <label class="form-label">Action</label>
            </div>
        </div>
        <!--   Date rows data    -->

        <!--    Sections      -->
        <div class="col-12 form-group required mt-3 lof-ck">
            <!--   Date rows data    -->
            <div v-for="(section,index) in sections">
                <div class="row mt-2 justify-content-center">
                    <div class="col-3">
                        <v-select  label="label" v-model="section.type"
                                   :options="typeOptions"
                                   :clearable="false"
                                   :reduce="option => option.value" placeholder="Select Type">
                            <template #no-options="{ search, searching, loading }">
                                <span>No options available</span>
                            </template>
                        </v-select>
                        <span class="text-danger" v-if="errorText(section,'type_error')">{{errorText(section,'type_error')}}</span>
                    </div>
                    <div :class="{ invisible: section.type != 'section' }" class="col-3">
                        <input v-model="section.name" class="form-control" placeholder="Name" type="text" required/>
                        <span class="text-danger" v-if="errorText(section,'name_error')">{{errorText(section,'name_error')}}</span>
                    </div>
                    <div :class="{ invisible: section.type != 'section' }" class="col-3">
                        <v-select  label="name" v-model="section.section"
                                   :options="allSections"
                                   :clearable="false"
                                   :reduce="option => option.id" placeholder="Select Section">
                            <template #no-options="{ search, searching, loading }">
                                <span>No options available</span>
                            </template>
                        </v-select>
                        <span class="text-danger" v-if="errorText(section,'section_error')">{{errorText(section,'section_error')}}</span>
                    </div>
                    <div class="col-1">
                        <button @click="removeSectionFields(section.id, index)" class="btn btn-sm btn-outline-danger" type="button"><i class="fa fa-close"></i></button>
                    </div>
                </div>
            </div>

        </div>

        <!--   add new row     -->
        <div class="row mt-4">
            <div class="row">
                <div class="col-2 offset-1">
                    <button @click="addSectionFields" type="button" class="btn btn-outline-success"><i class="fa fa-plus"></i> Add new</button>
                </div>
            </div>
        </div>
    </div>

    <div class="row">
        <div class="row mt-5">
            <div class="d-flex justify-content-between">
                <a v-if="showBackBtn" :href="backUrl" class="btn btn-outline-secondary">
                    <i data-feather="arrow-left"></i>
                    Back
                </a>
                <a v-else :href="cancelUrl" class="btn btn-outline-secondary">
                    <!-- <i data-feather="arrow-left"></i> -->
                    Cancel
                </a>
                <button @click="submit" type="button" class="btn btn-primary" :disabled="loading"><i class="fa fa-spinner fa-spin" v-if="loading"></i>{{ formBtnText }}</button>
            </div>
        </div>
    </div>
</template>

<script>
    import 'bs5-toast'
    import {HttpService} from "../../../services/HttpService";
    import vSelect from "vue-select";
    import generalHelpers from "../../../helpers/generalHelpers";

    export default {
        props: [
            'template', 'allSections', 'faculties', 'sectionType', 'templateSections'
        ],
        components: {
            vSelect
        },
        data() {
            return {
                request: new HttpService(),
                loading:false,
                sections: [],
                deletedSection: [],
                form: {
                    name: null,
                    description: null,
                    faculty: null,
                    enabled: false,
                },
                errors:{
                    name:'',
                    faculty:'',
                },
            }
        },
        mounted() {
            if(this.template.id){
                this.setFormValues()
            }
        },
        methods: {
            // add new section field row
            addSectionFields(){
                let fields = {
                    type: 'section',
                    name: null,
                    section: null,
                };

                this.sections.push(fields)
            },
            // remove section field row
            removeSectionFields(id, index){
                if ( id )
                    this.deletedSection.push(id)

                this.sections.splice(index, 1)
            },
            // displays error
            errorText(section,key){
                if(section[key] !== ''){
                    return section[key];
                }
                return '';
            },
            setFormValues(){
                this.form.name = this.template.name
                this.form.description = this.template.description
                this.form.enabled = this.template.enabled
                this.form.faculty = this.template.faculty_id
                for (const section of this.templateSections) {
                    let fields = {
                        type: section.type,
                        name: section.section_name,
                        section: section.section_id
                    };
                    this.sections.push(fields)
                }
            },
            // submits the form
            async submit() {
                let self = this;

                if(this.validateData()){
                    return;
                }
                this.loading = true;
                let formData = this.getFormData();
                // update request
                if ( this.template.id ) {
                    this.makeUpdateRequest(formData).then((response) => {
                        self.loading = false;
                        if (response.success === false) {
                            generalHelpers.showToast(response.message, false)
                        } else {
                            window.location.href= response.redirect_route;
                        }
                    }).catch(function (err) {
                    self.loading = false;
                    if(typeof err.data.errors !== 'undefined'){
                        self.showErrors(err.data.errors);
                    }
                });
                }else {
                    // create request
                    this.makeCreateRequest(formData).then((response) => {
                        self.loading = false;
                        if (response.success === false) {
                            generalHelpers.showToast(response.message, false)
                        } else {
                            window.location.href= response.redirect_route;
                        }
                    }).catch(function (err) {
                    self.loading = false;
                    if(typeof err.data.errors !== 'undefined'){
                        self.showErrors(err.data.errors);
                    }
                });
                }
            },
            // show validation errors from backend
            showErrors(errors){
                for (var key in errors) {
                    this.errors[key] = errors[key][0];
                }
            },
            // update request
            makeUpdateRequest(formData){
                return this.request.patch(route('staff.settings.offer-letters.templates.update', this.template.id), formData,{})
            },
            // create request
            makeCreateRequest(formData){
                return this.request.post(route('staff.settings.offer-letters.templates.store'), formData,{})
            },
            // get form data
            getFormData(){
                return {
                    'name': this.form.name,
                    'description': this.form.description,
                    'faculty_id': this.form.faculty,
                    'enabled': this.form.enabled,
                    'sections': this.sections,
                };
            },
            // validates form
            validateData(){
                let self = this;
                let check = false;

                if ( ! this.form.name || typeof this.form.name == 'undefined' || this.form.name === '' ){
                    check = true;
                    this.errors.name = "This field is required"
                }else{
                    this.errors.name = ''
                }

                if ( ! this.form.faculty || typeof this.form.faculty == 'undefined' || this.form.faculty === '' ){
                    check = true;
                    this.errors.faculty_id = "This field is required"
                }else{
                    this.errors.faculty_id = ''
                }

                for(let index in this.sections) {
                    let item = JSON.parse(JSON.stringify(this.sections[index]));

                    if ( !item.type || typeof item.type == 'undefined' || item.type === ''){
                        check = true;
                        Object.assign(this.sections[index], {type_error: 'This field is required'});
                    }else{
                        this.sections[index]['type_error'] = '';
                    }

                    if(item.type == 'section'){
                        if ( !item.name || typeof item.name == 'undefined' || item.name === ''){
                            check = true;
                            Object.assign(this.sections[index], {name_error: 'This field is required'});
                        }else{
                            this.sections[index]['name_error'] = '';
                        }
                        if ( !item.section || typeof item.section == 'undefined' || item.section === ''){
                            check = true;
                            Object.assign(this.sections[index], {section_error: 'This field is required'});
                        }else{
                            this.sections[index]['section_error'] = '';
                        }
                    }

                }

                return check;
            },
            // update template status
            isStatusCheck(value){
                this.form.enabled = value
            },
        },
        computed: {
            typeOptions(){
                let types = [];
                for ( let item in this.sectionType) {
                    types.push({label: generalHelpers.capitalizeFirstLetter(this.sectionType[item]), value: this.sectionType[item]})
                }
                return types;
            },
            formBtnText(){
                if(typeof this.template.id !== 'undefined'){
                    return 'Update';
                }
                return 'Create';
            },
            showBackBtn(){
                return typeof this.template === 'undefined';
            },
            backUrl(){
                return route('staff.settings.offer-letters.templates.index');
            },
            cancelUrl(){
                return route('staff.settings.offer-letters.templates.index');
            },
        }
    }
</script>
