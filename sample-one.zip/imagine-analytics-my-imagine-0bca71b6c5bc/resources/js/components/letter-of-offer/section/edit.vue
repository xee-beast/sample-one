<template>
    <div class="row">
        <div class="col-8">
            <form>
                <div class="mt-2">
                    <div class="form-group form-check form-switch">
                        <input type="hidden" name="enabled" value="0">

                        <label class="form-check-label">
                            <input @click="isStatusCheck(!form.enabled)" class="form-check-input pe-2" type="checkbox" :checked="!!form.enabled">
                            Active</label>
                    </div>
                </div>

                    <!--    Name        -->
                <div class="col-12 form-group required mt-3">
                        <label class="form-label">Name</label>
                        <input v-model="form.name" type="text" class="form-control" required >
                        <p class="text-danger" v-if="errors.name">{{ errors.name }}</p>
                </div>

                    <!--    Description            -->
                <div class="col-12 form-group mt-3">
                        <label class="form-label">Description</label>
                        <textarea v-model="form.description" class="form-control" maxlength="255" id="description" name="description" rows="3" placeholder="">{{form.description}}</textarea>
                </div>

            </form>
        </div>

        <div class="col-4">
            <div class="card offer-letter-section-card">
                <div class="card-body">
                    <div class="card-text">

                        <div class="justify-content-center text-center"><b>The available variables are:</b></div>
                        <div class="row mt-4">
                            <div class="col-12">
                                <span>*|text:field_name:required|*</span>
                            </div>
                        </div>
                        <hr class="text-muted">
                        <div class="row mt-5">
                            <div class="col-12">
                                <span>*|checkbox:field_name:required|*</span>
                            </div>
                        </div>
                        <hr class="text-muted">
                        <div class="row mt-5">
                            <div class="col-12">
                                <span>*|signature:field_name:required|*</span>
                            </div>
                        </div>

                        <div class="justify-content-center text-center mt-5"><b>To make the optional fields, use this:</b></div>
                        <div class="row mt-4">
                            <div class="col-12">
                                <span>*|text:field_name|*</span>
                            </div>
                        </div>
                        <hr class="text-muted">
                        <div class="row mt-5">
                            <div class="col-12">
                                <span>*|checkbox:field_name|*</span>
                            </div>
                        </div>
                        <hr class="text-muted">
                        <div class="row mt-5 mb-3">
                            <div class="col-12">
                                <span>*|signature:field_name|*</span>
                            </div>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="row">
        <!--    Editor            -->
        <div class="col-12 form-group required mt-3 lof-ck">
            <label class="form-label">Section Text</label>
            <div id="app">
                <editor v-model="form.text" :api-key="tinyKey" :init="editorOptions" />
                <p class="text-danger" v-if="errors.text">{{ errors.text }}</p>
            </div>
        </div>
    </div>

    <div class="row">
        <div class="row mt-5">
            <div class="d-flex justify-content-between">
                <a v-if="showBackBtn" :href="backUrl" class="btn btn-outline-secondary">
                    <i data-feather="arrow-left"></i>
                    Back
                </a>
                <a v-else :href="cancelUrl" class="btn btn-outline-secondary">
                    <!-- <i data-feather="arrow-left"></i> -->
                    Cancel
                </a>
                <button @click="submit" type="button" class="btn btn-primary" :disabled="loading"><i class="fa fa-spinner fa-spin" v-if="loading"></i>{{ formBtnText }}</button>
            </div>
        </div>
    </div>
</template>

<script>
    import 'bs5-toast'
    import {HttpService} from "../../../services/HttpService";
    import Editor from '@tinymce/tinymce-vue';

    export default {
        components: {
            'editor': Editor
        },
        props: [
            'section',
            'tinyKey'
        ],
        data() {
            return {
                request: new HttpService(),
                loading:false,
                editorOptions: {
                    menubar: false,
                    plugins: 'code | fullscreen | link | lists',
                    toolbar: 'undo redo | styleselect | bold italic | alignleft aligncenter alignright alignjustify | outdent indent | numlist bullist | forecolor | link  | fullscreen  | code',
                    selector: 'textarea',
                    min_height: 500,
                    branding: false,
                    elementpath: false
            },
                form: {
                    name: null,
                    description: null,
                    enabled: false,
                    text: ''
                },
                errors:{
                    name:'',
                    text:'',
                },
            }
        },
        mounted() {
            if(this.section.id){
                this.setFormValues()
            }
        },
        methods: {
            setFormValues(){
                this.form.name = this.section.name
                this.form.description = this.section.description
                this.form.enabled = this.section.enabled
                this.form.text = this.section.text
            },
            // submits the form
            async submit() {
                let self = this;

                if(this.validateData()){
                    return;
                }
                this.loading = true;
                let formData = this.getFormData();
                // update request
                if ( this.section.id ) {
                    this.makeUpdateRequest(formData).then((response) => {
                        self.loading = false;
                        if (response.success === false) {
                            self.showToast(response.message, false)
                        } else {
                            window.location.href= response.redirect_route;
                        }
                    }).catch(function (err) {
                    self.loading = false;
                    if(typeof err.data.errors !== 'undefined'){
                        self.showErrors(err.data.errors);
                    }
                });
                }else {
                    // create request
                    this.makeCreateRequest(formData).then((response) => {
                        self.loading = false;
                        if (response.success === false) {
                            self.showToast(response.message, false)
                        } else {
                            window.location.href= response.redirect_route;
                        }
                    }).catch(function (err) {
                    self.loading = false;
                    if(typeof err.data.errors !== 'undefined'){
                        self.showErrors(err.data.errors);
                    }
                });
                }
            },
            // show validation errors from backend
            showErrors(errors){
                for (var key in errors) {
                    this.errors[key] = errors[key][0];
                }
            },
            // update request
            makeUpdateRequest(formData){
                return this.request.patch(route('staff.settings.offer-letters.sections.update', this.section.id), formData,{})
            },
            // create request
            makeCreateRequest(formData){
                return this.request.post(route('staff.settings.offer-letters.sections.store'), formData,{})
            },
            // get form data
            getFormData(){
                return {
                    'name': this.form.name,
                    'description': this.form.description,
                    'enabled': this.form.enabled,
                    'text': this.form.text,
                };
            },
            // show toaster
            showToast(message, isSuccess) {
                new bs5.Toast({
                    body: message,
                    className: !isSuccess ? 'border-0 bg-danger text-white' : 'border-0 bg-success text-white',
                    btnCloseWhite: true,
                }).show();
            },
            // validates form
            validateData(){
                let self = this;
                let check = false;

                if ( ! this.form.name || typeof this.form.name == 'undefined' || this.form.name === '' ){
                    check = true;
                    this.errors.name = "This field is required"
                }else{
                    this.errors.name = ''
                }

                if ( ! this.form.text || typeof this.form.text == 'undefined' || this.form.text === '' ){
                    check = true;
                    this.errors.text = "This field is required"
                }else{
                    this.errors.text = ''
                }

                return check;
            },
            // update section status
            isStatusCheck(value){
                this.form.enabled = value
            },
        },
        computed: {
            formBtnText(){
                if(typeof this.section.id !== 'undefined'){
                    return 'Update';
                }
                return 'Create';
            },
            showBackBtn(){
                return typeof this.section === 'undefined';
            },
            backUrl(){
                return route('staff.settings.offer-letters.sections.index');
            },
            cancelUrl(){
                return route('staff.settings.offer-letters.sections.index');
            },
        }
    }
</script>
