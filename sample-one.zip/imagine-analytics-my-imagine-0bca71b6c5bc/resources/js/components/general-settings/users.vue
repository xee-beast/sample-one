<template>
    <form>
        <div class="row mt-3">
            <div class="col-12 form-group required mt-2">
                <label class="form-label">Users to notify when agents self-register</label>
                <v-select multiple label="full_name" v-model="form.users"
                          :options="users" :reduce="option => option.id"
                          placeholder="Choose users..." :search-able="true">
                    <template #no-options="{ search, searching, loading }">
                        <span>No options available</span>
                    </template>
                </v-select>
                <p class="text-danger" v-if="errors.users">{{ errors.users }}</p>
            </div>
            
            <div class="row mt-4 pe-0">
                <div class="col-12 text-end pe-0">
                    <button  @click="reloadPage()" type="button" class="btn btn-outline-secondary btn-sm px-4 ms-2 ">Cancel</button>
                    <button @click="submit" type="button" class="btn btn-info btn-sm text-white px-4 ms-2" :disabled="loading"><i class="fa fa-spinner fa-spin" v-if="loading"></i>Update</button>
                </div>
            </div>

        </div>
    </form>
</template>

<script>
import vSelect from "vue-select";
import 'bs5-toast'
import {HttpService} from "../../services/HttpService";

export default {
    props: [
        'users',
        'selectedUsers'
    ],
    components: {
        vSelect,
    },
    data() {
        return {
            request: new HttpService(),
            loading:false,
            form: {
                users: null,
            },
            errors:{
                users:'',
            },
        }
    },
    mounted() {
        if(this.selectedUsers){
            this.form.users = this.selectedUsers;
        }
    },
    methods: {
        reloadPage(){
            window.location.reload();  
        },
        async submit() {
            let self = this;

            if(this.validateData()){
                return;
            }
            this.loading = true;
            let formData = this.getFormData();

            this.makeRequest(formData).then((response) => {
                self.loading = false;
                if (response.success) {
                    self.showToast(response.message, true)
                }
            }).catch(function (error) {
                    
            });
        },
        // create request
        makeRequest(formData){
            return this.request.post(route('staff.settings.general-settings.users.store'), formData,{})
        },
        // get form data
        getFormData(){
            return {
                'notifiers_on_agent_registration': this.form.users
            };
        },
        // show toaster
        showToast(message, isSuccess) {
            new bs5.Toast({
                body: message,
                className: !isSuccess ? 'border-0 bg-danger text-white' : 'border-0 bg-success text-white',
                btnCloseWhite: true,
            }).show();
        },
        // validates form
        validateData(){
            let check = false;
            if (this.form.users  === null || this.form.users  === '' ){
                check = true;
                this.errors.users = "This field is required"
            }else{
                this.errors.users = ""
            }
            return check;
        },

    },
    watch: {
        
    },
    computed: {
    }
}
</script>
