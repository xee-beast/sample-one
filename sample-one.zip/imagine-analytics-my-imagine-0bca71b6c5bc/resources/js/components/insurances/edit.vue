<template>
    <form>
        <div class="row mt-3 justify-content-center">
            <div class="col-3"><label><b>Duration</b></label></div>
            <div class="col-3"><label><b>Fee ($)</b></label></div>
            <div class="col-1"></div>
        </div>

        <div v-for="(item,index) in list" :key="item.id" class="mt-3">
            <div class="row justify-content-center">
                <input type="hidden" :value="item.id">
                <div class="col-3">
                    <input id="duration" type="number" placeholder="Duration" required v-model="item.duration"  v-bind:class="[errorText(item,'duration_error') ? 'is-invalid': (submitted ? 'is-valid' : '' ),'form-control']">
                    <span class="text-danger" v-if="errorText(item,'duration_error')">{{errorText(item,'duration_error')}}</span>
                </div>
                <div class="col-3">
                    <input id="single_fee" min="0" oninput="validity.valid||(value='');" type="number" placeholder="Single Fee" required v-model="item.fee"  v-bind:class="[errorText(item,'fee_error') ? 'is-invalid':(submitted ? 'is-valid' : '' ),'form-control']">
                    <span class="text-danger" v-if="errorText(item,'fee_error')">{{errorText(item,'fee_error')}}</span>
                </div>
                <div class="col-1">
                    <button @click="removeRow(index,item.id)" class="btn btn-sm btn-outline-danger" type="button"><i class="fa fa-close"></i></button>
                </div>
            </div>
        </div>


        <div class="row mt-3 justify-content-center">
            <div class="col-3"><button @click="addNewRow" type="button" class="btn btn-outline-success"><i class="fa fa-plus"></i> Add new</button></div>
            <div class="col-3"></div>
            <div class="col-1"></div>
        </div>
    </form>

    <div class="row mt-3 text-center">
            <div class="row">
                <div class="col text-start">
                    <a :href="indexUrl" class="btn btn-outline-secondary" >Cancel</a>
                </div>
                <div class="col text-end">
                    <button @click="submit" type="button" class="btn btn-primary" :disabled="loading"><i class="fa fa-spinner fa-spin" v-if="loading"></i>  Submit</button>
                </div>
            </div>
    </div>

</template>

<script>
    import { HttpService } from '../../services/HttpService';
    import 'bs5-toast'
    export default {
        props:['insurance','fees'],
        components: {

        },
        data() {
            var self = this;
            return {
                loading:false,
                list:[],
                submitted:false,
                deletedRows: [],
                request: new HttpService(),
            }
        },
        mounted() {
            this.list = this.fees;

        },
        computed : {
            indexUrl(){
                return route('staff.settings.fees.insurance.index');
            }
        },
        methods: {
            errorText(fee,key){
                if(fee[key] !== ''){
                    return fee[key];
                }
                return '';
            },
            // add new row
            addNewRow(){
                let fields = {
                    duration: "",
                    fee: ""
                };

                this.list.push(fields);
            },

            // submits the form
            async submit() {
                let self = this;
                this.submitted = true;

                if(this.validateData()){
                    return;
                }
                this.loading = true;
                let formData = {
                    fees:this.list,
                    deleted_records: this.deletedRows
                };

                this.request.patch(route('staff.settings.fees.insurance.update',this.insurance.id), formData)
                    .then(function (response) {
                        self.loading  =false;
                        if (response.success === false) {
                            new bs5.Toast({
                                body: response.message,
                                className: 'border-0 bg-danger text-white',
                                btnCloseWhite: true,
                            }).show();
                        }else {
                            window.location.href = self.indexUrl;
                        }
                    }).catch(function (err) {
                        self.loading  =false;
                    });
            },
            // remove a row
            removeRow(index,id){
                if(id)
                    this.deletedRows.push(id);

                this.list.splice(index, 1);
            },
            validateData(){
                let self = this;
                let check = false;
                for(let index in this.list) {
                    let item = JSON.parse(JSON.stringify(this.list[index]));
                    if ( item.duration === ''){
                        check = true;
                        Object.assign(this.list[index], {duration_error: 'This field is required'});
                    }else{
                        let duplicateDuration = this.list.filter((fee) => {
                            return (fee.duration === item.duration)
                        });

                        if(duplicateDuration.length > 1){
                            check = true;
                            Object.assign(this.list[index], {duration_error: 'This duration is duplicated'});
                        }else{
                            this.list[index]['duration_error'] = '';
                        }
                    }

                    if ( item.fee === ''){
                        check = true;
                        Object.assign(this.list[index], {fee_error: 'This field is required'});
                    }else{
                        this.list[index]['fee_error'] = '';
                    }
                }
                return check;
            }
        }
    }
</script>

