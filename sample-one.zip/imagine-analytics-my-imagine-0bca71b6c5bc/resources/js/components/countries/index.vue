<template>
    <div class="mt-4">
        <div class="filter-datatable">
            <div class="row filter-dropdown">
                <div class="col-3">
                    <v-select  label="name" v-model="region"
                               :options="regions"
                               :change="reloadDataTable()"
                               :reduce="option => option.id" placeholder="Filter by Region">
                        <template #no-options="{ search, searching, loading }">
                            <span>No options available</span>
                        </template>
                    </v-select>
                </div>
            </div>
                <table class="table table-bordered table-striped" id="country-table">
                    <thead>
                    <tr>
                        <th scope="col" >Name</th>
                        <th scope="col" >Region</th>
                        <th scope="col" class="text-center">Code</th>
                    </tr>
                    </thead>
                    <tbody></tbody>
                </table>
            </div>
    </div>
</template>

<script>
    import 'datatables.net-dt/js/dataTables.dataTables';
    import 'datatables.net-dt/css/jquery.dataTables.min.css';
    import vSelect from "vue-select";
    export default {
        props:['regions'],
        components: {
            vSelect
        },
        data() {
            var self = this;
            return {
                datatable:null,
                region:null
            }
        },
        mounted() {
            this.setDataTable();

        },
        computed : {
        },
        methods: {
            setDataTable(){
                let self = this;
                this.datatable = $('#country-table').DataTable( {
                    // f - indicate search-bar
                    // <tlip> - t(sign to move to bottom)| l(chaining input)| i(summary info)| p(pagination)
                    dom: 'f <tilp>',
                    processing: true,
                    serverSide: true,
                    ordering: true,
                    responsive: true,
                    ajax: {
                        url: route('staff.settings.countries.list'),
                        data: function ( d ) {
                            d.region = self.region
                        },
                    },
                    columns: [
                        {data: 'name', name: 'name', orderable: true},
                        {data: 'region', name: 'region', orderable: true},
                        {data: 'code', name: 'code', orderable: true},
                    ]
                });
            },
            reloadDataTable(){
                if ( this.datatable ) {
                    this.datatable.draw();
                }
            }
        }
    }
</script>

