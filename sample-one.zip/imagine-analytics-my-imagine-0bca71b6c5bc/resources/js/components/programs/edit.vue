<template>
    <form>

        <div class="row">
            <div class="col-7">
                <div class="mt-2">
                    <div class="form-group form-check form-switch">
                        <input type="hidden" name="enabled" value="0">
                        <input v-model="form.enabled" class="form-check-input" id="enabled" type="checkbox" >
                        <label class="form-check-label" for="enabled">Active</label>
                    </div>
                </div>

                <!--   Name Field     -->
                <div class="col-12 form-group required mt-3">
                    <label class="form-label">Name</label>
                    <input placeholder="Name" v-model="form.name" type="text" class="form-control" required >
                    <p class="text-danger" v-if="errors.name">{{ errors.name }}</p>
                </div>

                <!--    Description  Field  -->
                <div class="col-12 form-group mt-3">
                    <label class="form-label">Description</label>
                    <textarea class="form-control" maxlength="255" id="description" name="description" rows="3" placeholder="Description" v-model="form.description"></textarea>
                </div>


                <div class="col-12 form-group required mt-2">
                    <label class="form-label">Price Book</label>
                    <v-select  label="name" v-model="form.program_price_book_id" :options="priceBooks" :reduce="option => option.id"   placeholder="Choose Price Book..." :search-able="true">
                        <template #no-options="{ search, searching, loading }">
                            <span>No options available</span>
                        </template>
                    </v-select>
                    <p class="text-danger" v-if="errors.program_price_book_id">{{ errors.program_price_book_id }}</p>
                </div>

                <div class="col-12 form-group required mt-2">
                    <label class="form-label">Program Type</label>
                    <v-select  label="label" v-model="form.is_language"
                               :options="languageOptions"
                               :reduce="option => option.value" placeholder="Filter by Program Type" :clearable="false">
                        <template #no-options="{ search, searching, loading }">
                            <span>No options available</span>
                        </template>
                    </v-select>
                    <p class="text-danger" v-if="errors.is_language">{{ errors.is_language }}</p>
                </div>
            </div>

            <div class="col-5 mt-5">
                <div class="card mt-4">
                    <div class="card-body">
                        <h5>Restrictions</h5>


                        <div class="mt-4">
                            <div class="form-group form-check form-switch">
                                <input type="hidden" name="length_restriction_enabled" value="0">
                                <input v-model="form.age_restriction_enabled" class="form-check-input" :checked="form.age_restriction_enabled" id="age_restriction_enabled" type="checkbox" >
                                <label class="form-check-label" for="age_restriction_enabled">Student Age</label>
                            </div>
                        </div>
                        <div class="row" v-if="form.age_restriction_enabled">
                            <div class="col-6 form-group required mt-3">
                                <label class="form-label">Min</label>
                                <v-select  label="label" v-model="form.min_age" :options="minAgeOption"  :reduce="option => option.value"  placeholder="Choose option..." >
                                    <template #no-options="{ search, searching, loading }">
                                        <span>No options available</span>
                                    </template>
                                </v-select>
                                <p class="text-danger" v-if="errors.min_age">{{ errors.min_age }}</p>
                            </div>
                            <div class="col-6 form-group required mt-3">
                                <label class="form-label">Max</label>
                                <v-select  label="label" v-model="form.max_age" :options="maxAgeOption"  :reduce="option => option.value"  placeholder="Choose option..." >
                                    <template #no-options="{ search, searching, loading }">
                                        <span>No options available</span>
                                    </template>
                                </v-select>
                                <p class="text-danger" v-if="errors.max_age">{{ errors.max_age }}</p>
                            </div>
                        </div>

                        <hr/>
                        <div class="mt-4">
                            <div class="form-group form-check form-switch">
                                <input type="hidden" name="length_restriction_enabled" value="0">
                                <input v-model="form.length_restriction_enabled" class="form-check-input" :checked="form.length_restriction_enabled" id="length_restriction_enabled" type="checkbox" >
                                <label class="form-check-label" for="length_restriction_enabled">Course Length (weeks)</label>
                            </div>
                        </div>
                        <div class="row" v-if="form.length_restriction_enabled">
                            <div class="col-6 form-group required mt-3">
                                <label class="form-label">Min</label>
                                <v-select  label="label" v-model="form.min_length" :options="minLengthOption"  :reduce="option => option.value"  placeholder="Choose option..." >
                                    <template #no-options="{ search, searching, loading }">
                                        <span>No options available</span>
                                    </template>
                                </v-select>
                                <p class="text-danger" v-if="errors.min_length">{{ errors.min_length }}</p>
                            </div>
                            <div class="col-6 form-group required mt-3">
                                <label class="form-label">Max</label>
                                <v-select  label="label" v-model="form.max_length" :options="maxLengthOption"  :reduce="option => option.value"  placeholder="Choose option..." >
                                    <template #no-options="{ search, searching, loading }">
                                        <span>No options available</span>
                                    </template>
                                </v-select>
                                <p class="text-danger" v-if="errors.max_length">{{ errors.max_length }}</p>
                            </div>
                        </div>
                        <hr/>

                        <div class="mt-4">
                            <div class="form-group form-check form-switch">
                                <input type="hidden" name="visa_restriction_enabled" value="0">
                                <input v-model="form.visa_restriction_enabled" :checked="form.visa_restriction_enabled" class="form-check-input" id="visa_restriction_enabled" type="checkbox" >
                                <label class="form-check-label" for="visa_restriction_enabled">Visa Required</label>
                            </div>
                        </div>
                        <div class="row" v-if="form.visa_restriction_enabled">
                            <div class="col-12 form-group required mt-3">
                                <v-select  label="name" v-model="form.active_visas" :options="visas"  :reduce="option => option.id"  placeholder="Choose option..."  multiple>
                                    <template #no-options="{ search, searching, loading }">
                                        <span>No options available</span>
                                    </template>
                                </v-select>
                                <p class="text-danger" v-if="errors.active_visas">{{ errors.active_visas }}</p>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="card mt-4">
                    <div class="card-body">
                        <h5>Services</h5>
                        <p class="mt-3 text-center" v-if="formLoading"><i class="fa fa-spinner fa-spin"></i> </p>
                        <Services v-else :service-options="services" :services="form.services" :show-errors="serviceErrors" @update="onServiceUpdate"/>
                    </div>
                </div>
            </div>
        </div>

        <div class="row mt-5">
            <div class="d-flex justify-content-between">
                <a  :href="backUrl" class="btn btn-outline-secondary">
                    Cancel
                </a>
                <button @click="submit" type="button" class="btn btn-primary" :disabled="loading"><i class="fa fa-spinner fa-spin" v-if="loading"></i>{{ formBtnText }}</button>
            </div>
        </div>

    </form>
</template>

<script>
import vSelect from "vue-select";
import 'bs5-toast'
import Datepicker from '@vuepic/vue-datepicker';
import '@vuepic/vue-datepicker/dist/main.css'
import {HttpService} from "../../services/HttpService";
import Services from './partials/services';
export default {
    props: [
        'program',
        'priceBooks',
        'visas',
        'selectedVisas',
        'services',
        'selectedServices'
    ],
    components: {
        vSelect,
        Services
    },
    data() {
        return {
            request: new HttpService(),
            searchInterval:null,
            loading:false,
            formLoading:true,
            serviceErrors:false,
            form :{
                name:'',
                description: '',
                enabled : false,
                program_price_book_id:null,
                min_length:null,
                max_length:null,
                min_age:null,
                max_age:null,
                active_visas:null,
                length_restriction_enabled:false,
                age_restriction_enabled:false,
                visa_restriction_enabled:false,
                is_language: false,
                services:[]
            },
            errors:{
                name:'',
                description: '',
                active_visas:'',
                min_length:'',
                max_length:'',
                min_age:'',
                max_age:'',
                program_price_book_id:'',
            },
            languageOptions:[
                {
                    label:'Language',
                    value:true
                },
                {
                    label:'VET',
                    value:false
                }
            ]
        }
    },
    mounted() {

        if(typeof this.program !== 'undefined'){
            this.setValues();
        }else{
            this.formLoading = false;
        }
    },
    methods: {
        onServiceUpdate(value){
            let values = JSON.parse(JSON.stringify(value));
            this.form.services = values;
        },
        // submits the form
        async submit() {
            let self = this;

            if(this.validateData()){
                return;
            }

            let formData = this.getFormData();
            if(typeof this.program !== 'undefined'){
                this.makeUpdateRequest(formData);
            }else{
                this.makeCreateRequest(formData);
            }
        },
        getFormData(){
            let formData = this.form;
            return formData;
        },
        // update request
        makeUpdateRequest(formData){
            let self = this;
            this.loading = true;
            this.request.patch(route('staff.settings.products.programs.update', this.program.id), formData)
                .then(function (response) {
                    self.loading = false;
                    if(response.success){
                        window.location.href= response.redirect_route;
                    }else{
                        self.showToast(response.message,response.success);
                    }
                }).catch(function (err) {
                    self.loading = false;
                    if(typeof err.data.errors !== 'undefined'){
                        self.showErrors(err.data.errors);
                    }
                });
        },
        // create request
        makeCreateRequest(formData){
            let self = this;
            return this.request.post(route('staff.settings.products.programs.store'), formData,{})
                .then(function (response) {
                    self.loading = false;
                    if(response.success){
                        window.location.href= response.redirect_route;
                    }else{
                        self.showToast(response.message,response.success);
                    }
                }).catch(function (err) {
                    self.loading = false;
                    if(typeof err.data.errors !== 'undefined'){
                        self.showErrors(err.data.errors);
                    }
                });
        },
        // show validation errors from backend
        showErrors(errors){
            for (var key in errors) {
                this.errors[key] = errors[key][0];
            }
            this.serviceErrors = true;
        },
        // show toaster
        showToast(message, isSuccess) {
            new bs5.Toast({
                body: message,
                className: !isSuccess ? 'border-0 bg-danger text-white' : 'border-0 bg-success text-white',
                btnCloseWhite: true,
            }).show();
        },
        // validate form
        validateData(){
            let self = this;
            let check = false;
            this.serviceErrors = false;
            if (this.form.name === '' ){
                check = true;
                this.errors.name = "This field is required"
            }else{
                this.errors.name = ''
            }
            if ( ! this.form.program_price_book_id || this.form.program_price_book_id === '' ){
                check = true;
                this.errors.program_price_book_id = "This field is required"
            }else{
                this.errors.program_price_book_id = ''
            }


            if ( this.form.length_restriction_enabled ){
                if ( this.form.min_length  === '' ){
                    check = true;
                    this.errors.min_length = "This field is required"
                }else{
                    this.errors.min_length = ''
                }

                if ( this.form.max_length  === '' ){
                    check = true;
                    this.errors.max_length = "This field is required"
                }else{
                    this.errors.max_length = ''
                }

                if(parseInt(this.form.max_length) <  parseInt(this.form.min_length)){
                    check = true;
                    this.errors.max_length = "Max length should be greater then min length"
                }
            }

            if ( this.form.age_restriction_enabled ){
                if ( ! this.form.min_age || this.form.min_age  === '' ){
                    check = true;
                    this.errors.min_age = "This field is required"
                }else{
                    this.errors.min_age = ''
                }

                if ( ! this.form.max_age || this.form.max_age  === '' ){
                    check = true;
                    this.errors.max_age = "This field is required"
                }else{
                    this.errors.max_age = ''
                }

                if(parseInt(this.form.max_age) <  parseInt(this.form.min_age)){
                    check = true;
                    this.errors.max_age = "Max length should be greater then min length"
                }
            }

            if ( this.form.visa_restriction_enabled ){
                if ( this.form.active_visas  === null ){
                    check = true;
                    this.errors.active_visas = "This field is required"
                }else{
                    this.errors.active_visas = ''
                }
            }

            if(this.form.services.length > 0 ){
                let serviceError = false;
                for(let key in this.form.services){
                    let item = this.form.services[key];
                    let duplicate = [];
                    this.form.services.forEach(obj => {
                        if(obj.program_fee_service_id === item.program_fee_service_id)
                            duplicate.push(obj);
                    });
                    if(item.program_fee_service_id == null){
                        serviceError = true;
                    }else if(duplicate.length > 1){
                        serviceError = true;
                    }
                }

                if(serviceError){
                    setTimeout(() => {this.serviceErrors = true},100) ;
                    check = true;
                }

            }


            return check;
        },
        setValues(){
            this.form.name  = this.program.name;
            this.form.enabled  = this.program.enabled == 1 ? true: false;
            this.form.is_language  = this.program.is_language == 1 ? true: false;
            this.form.description  =  this.program.description;
            this.form.min_length  =  this.program.min_length;
            this.form.max_length  =  this.program.max_length;
            this.form.min_age  =  this.program.min_age;
            this.form.max_age  =  this.program.max_age;
            this.form.active_visas  =  this.selectedVisas ? this.selectedVisas : null;
            this.form.program_price_book_id  = this.program.price_book ? this.program.price_book.id : null;
            this.form.length_restriction_enabled  = this.program.length_restriction_enabled;
            this.form.age_restriction_enabled  = this.program.age_restriction_enabled;
            this.form.visa_restriction_enabled  = this.program.visa_restriction_enabled;
            if(typeof this.selectedServices !== 'undefined'){
                this.form.services = this.selectedServices;
            }
            this.formLoading = false;
        }
    },
    computed: {
        formBtnText(){
            if(typeof this.program !== 'undefined'){
                return 'Update';
            }
            return 'Create';
        },
        backUrl(){
            return route('staff.settings.products.programs.index');
        },
        minLengthOption(){
            let lengthOptions = [];
            for(let i = 1; i <= 100 ; i++){
                lengthOptions.push({
                    label: i,
                    value : i
                });
            }
            return lengthOptions;
        },
        maxLengthOption(){
            let i = 1;
            if(this.form.min_length !== null)
                i = this.form.min_length;

            let lengthOptions = [];
            for(i ; i <= 100 ; i++){
                lengthOptions.push({
                    label: i,
                    value : i
                });
            }
            return lengthOptions;
        },
        minAgeOption(){
            let lengthOptions = [];
            for(let i = 1; i <= 100 ; i++){
                lengthOptions.push({
                    label: i,
                    value : i
                });
            }
            return lengthOptions;
        },
        maxAgeOption(){
            let i = 1;
            if(this.form.min_age !== null)
                i = this.form.min_age;

            let lengthOptions = [];
            for(i ; i <= 100 ; i++){
                lengthOptions.push({
                    label: i,
                    value : i
                });
            }
            return lengthOptions;
        }
    },
    watch: {
        'form.age_restriction_enabled' : function (value){
            if(value === false){
                this.form.min_age = null;
                this.form.max_age = null;
            }
        },
        'form.length_restriction_enabled' : function (value){
            if(value === false){
                this.form.min_length = null;
                this.form.max_length = null;
            }
        },
        'form.visa_restriction_enabled' : function (value){
            if(value === false){
                this.form.active_visas = null;
            }
        },

    }
}
</script>
