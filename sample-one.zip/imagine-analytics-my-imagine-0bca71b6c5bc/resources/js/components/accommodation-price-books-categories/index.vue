<template>
    <div class="mt-4">
        <table class="table table-bordered table-striped" id="price-book-category-table">
            <thead>
            <tr>
                <th scope="col" >Name</th>
                <th scope="col" class="text-center">Description</th>
                <th scope="col" >Status</th>
            </tr>
            </thead>
            <tbody></tbody>
        </table>
    </div>
</template>

<script>
    import 'datatables.net-dt/js/dataTables.dataTables';
    import 'datatables.net-dt/css/jquery.dataTables.min.css';
    export default {
        components: {
        },
        data() {
            var self = this;
            return {
                datatable:null
            }
        },
        mounted() {
            this.setDataTable();

        },
        computed : {
        },
        methods: {
            setDataTable(){
                this.datatable = $('#price-book-category-table').DataTable( {
                    // f - indicate search-bar
                    // <tlip> - t(sign to move to bottom)| l(chaining input)| i(summary info)| p(pagination)
                    dom: 'f <tilp>',
                    processing: true,
                    serverSide: true,
                    ordering: false,
                    responsive: true,
                    ajax: route('staff.settings.fees.accommodation.pricebook-categories.list'),
                    columns: [
                        {data: 'name', name: 'name', orderable: true},
                        {data: 'description', name: 'description', class: 'pre-wrap', orderable: true},
                        {data: 'enabled', name: 'enabled'},
                    ]
                });
            }
        }
    }
</script>

