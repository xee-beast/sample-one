<template>

    <div class="accordion" id="accordionAppDetails">
        <div class="accordion-item">
            <h2 class="accordion-header" id="panelsStayOpen-headingOne">
                <button class="accordion-button" type="button" data-bs-toggle="collapse" data-bs-target="#panelsStayOpen-collapseOne" aria-expanded="true" aria-controls="panelsStayOpen-collapseOne">
                    Details
                </button>
            </h2>
            <div v-if="data.detail" id="panelsStayOpen-collapseOne" class="accordion-collapse collapse show" aria-labelledby="panelsStayOpen-headingOne" data-bs-parent="#accordionAppDetails">
                <div class="accordion-body">

                    <ul class="key-value">
                        <li>
                            <span>Application Number</span>
                            <p><span class="edit-link me-0">
                                    {{data.id}}
                                    <a class="ps-2 text-end small" title="Edit" :href="getApplicationUpdateRoute()" v-if="userPermissions.edit_application">
                                            <i class="fa fa-pencil"></i>
                                    </a>
                                </span>
                            </p>
                        </li>
                        <li>
                            <span>Status</span>
                            <p class="text-end">{{status[data.status]['label']}}
                                <a v-if="allowStatusChange()" class="ps-2 text-end small" title="Edit" href="#" @click.prevent="updateStatusModal()">
                                    <i class="fa-solid fa-arrow-right-arrow-left"></i>
                                </a>
                            </p>
                        </li>
                        <li>
                            <span>Student id</span>
                            <p class="text-end">
                                {{data.student_number}}
                                <span v-if="loadingStudent" class="spinner-border spinner-border-sm text-end"></span>
                                <span v-if="userPermissions.edit_application_properties">
                                    <a v-show="allowStudentCreation()" class="ps-2 text-end small" href="#" @click.prevent="addOrRemoveStudent(true)">
                                        <i data-bs-toggle="tooltip" data-bs-placement="right"
                                           data-bs-title="Create student in Ebecas"
                                           class="fa fa-plus ms-1 mt-0">
                                        </i>
                                    </a>
                                    <a v-show="data.student_number && !loadingStudent" class="ps-2 text-end small" href="#" @click.prevent="addOrRemoveStudent(false)">
                                        <i data-bs-toggle="tooltip" data-bs-placement="right"
                                           data-bs-title="Remove the student id from this application"
                                           class="fa fa-trash ms-1 mt-0">
                                        </i>
                                    </a>
                                </span>
                            </p>
                        </li>

                        <!-- Owner -->
                        <li>
                            <span>Owner</span>
                            <p v-if="data.application_owner" class="text-end">
                                <a href="#" @click.prevent="goToUser(data.application_owner.id)">
                                    <i class="fa-solid fa-circle-user text-success"></i>{{data.application_owner.first_name}} {{data.application_owner.last_name}}
                                </a>
                                <a v-if="userPermissions.edit_application_properties" class="ps-2 text-end small" title="Edit" href="#" @click.prevent="updateOwnerModal()">
                                    <i class="fa-solid fa-arrow-right-arrow-left"></i>
                                </a>
                                <br>
                                {{data.application_owner.email}}<br>
                                {{capitalizeWord(data.application_owner.user_type)}}
                            </p>
                        </li>

                        <!-- Submitted by -->
                        <li>
                            <span>Submitted by</span>
                            <p v-if="data.submitted_by" class="text-end">
                                <a href="#" @click.prevent="goToUser(data.submitted_by.id)">
                                    <i class="fa-solid fa-circle-user text-success"></i>{{data.submitted_by.first_name}} {{data.submitted_by.last_name}}
                                </a>
                                <br>
                                {{data.submitted_by.email}}<br>
                                {{capitalizeWord(data.submitted_by.user_type)}}
                            </p>
                        </li>

                        <!-- Agent -->
                        <li v-if="data.detail.agent_assistance">
                            <span>Agent</span>
                            <p class="text-end">{{data.detail.agent_name}}</p>
                        </li>
                    </ul>
                </div>

    <!--   MODALS         -->

                <div class="modal fade" id="statusModal" tabindex="-1" role="dialog" aria-labelledby="statusModalLabel" aria-hidden="true">
                    <div class="modal-dialog modal-lg">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title" id="statusModalLabel">Update Application Status</h5>
                            </div>
                            <div class="modal-body">

                                <div class="col-12 form-group required mt-2">
                                    <label class="form-label">Select Status</label>
                                    <v-select :loading="status.length <= 0"
                                              :clearable="false"
                                              v-model="selectedStatus"
                                              :options="applicationStatusDropdown"
                                              :reduce="option => option.value"
                                              placeholder="Select Status"
                                    >
                                    </v-select>
                                </div>

                            </div>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-outline-secondary" @click="closeStatusModal()">Cancel</button>
                                <button type="button" class="btn btn-primary" :disabled="loading" @click.prevent="updateStatus"> Update</button>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="modal fade" id="ownerModal" tabindex="-1" role="dialog" aria-labelledby="ownerModalLabel" aria-hidden="true">
                    <div class="modal-dialog modal-lg">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title" id="ownerModalLabel">Transfer Application</h5>
                            </div>
                            <div class="modal-body">

                                <div class="row">
                                    <div class="col-6 form-group">
                                        <v-select id="getSearchModule"
                                                  v-model="selectedUserType"
                                                  :options="userTypeDropdown"
                                                  :reduce="option => option.value"
                                                  placeholder="Select the user type"
                                        >
                                        </v-select>
                                    </div>

                                </div>
                                <div class="row mt-3">
                                    <div class="col-12 form-group">
                                        <v-select v-model="selectedUser" :options="users" placeholder="Type to search...">
                                            <template #no-options="{ search, searching, loading }">
                                                <span>{{getDropdownText(search)}}</span>
                                            </template>
                                        </v-select>
                                    </div>
                                </div>

                            </div>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-outline-secondary" @click="closeOwnerModal()">Cancel</button>
                                <button type="button" class="btn btn-primary" :disabled="loading" @click.prevent="updateApplicationOwner()"> Update</button>
                            </div>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </div>
</template>

<script>
import {useFormStore} from "../../../stores/applicationForm";
import vSelect from "vue-select";
import {HttpService} from "../../../services/HttpService";
import generalHelpers from "../../../helpers/generalHelpers";

export default {
    // Pinia state setup to initialize state data
    setup(){
        const formStore  = useFormStore();
        const {addApplicationData, getApplicationData} = formStore;
        return {addApplicationData, getApplicationData};
    },
    components: {
        vSelect,
    },
    props:['application', 'status', 'userPermissions', 'userType'],
    name: "detail",
    data() {
        return {
            data: {},
            loading: false,
            loadingStudent: false,
            loadingUsers: false,
            users:[],
            errors: {},
            selectedStatus: null,
            selectedUser: null,
            request: new HttpService(),
            selectedUserType: null,
        }
    },
    async mounted() {
        // getting application details from pinia
        this.data = await this.getApplicationData('track');
        if (!Object.keys(this.data).length && typeof this.application.id !== 'undefined') {
            await this.addApplicationData('track', this.application);
            this.data = await this.getApplicationData('track');

            this.selectedStatus = this.data.status;
            this.applicationStatus = this.status[this.data.status]['label'];
        }
    },
    methods: {
        goToUser(id){
            window.location.href = route('staff.users.show', id)
        },
        getApplicationUpdateRoute(){
            return route('applications.edit',this.application.id)
        },
        updateStatusModal(){
            $('#statusModal').modal('show');
        },
        closeStatusModal(){
            $('#statusModal').modal('hide');
        },
        updateOwnerModal(){
            this.selectedUserType = null;
            this.selectedUser = null;
            this.users = [];
            $('#ownerModal').modal('show');
        },
        closeOwnerModal(){
            this.selectedUserType = null;
            this.selectedUser = null;
            this.users = [];
            $('#ownerModal').modal('hide');
        },
        updateStatus(){
            let self = this;
            this.loading = true;
            if ( this.data.status !== this.selectedStatus ) {
                return this.request.patch(route('staff.applications.status.update', this.data.id),
                    {status: self.selectedStatus})
                    .then(function (response) {
                        self.loading = false;
                        if(response.success){
                            self.showToast("Status Updated", true)
                            self.data.status = self.selectedStatus
                            self.closeStatusModal();
                        } else {
                            self.showToast("There was some error, please try again", false)
                        }

                    }).catch(function (err) {
                        self.loading = false;
                        self.showToast("There was some error, please try again", false)
                    });
            }
            self.closeStatusModal();
            self.loading = false;
        },
        updateApplicationOwner(){
            let self = this;
            this.loading = true;
            if ( this.selectedUserType && this.selectedUser ){
                return this.request.patch(route('staff.applications.submission-detail.update', self.data.id, self.selectedUser.id),
                    {status: self.selectedStatus})
                    .then(function (response) {
                        self.loading = false;
                        if(response.success){
                            self.showToast("Application Updated", true)
                            self.data.application_owner = response.data
                            self.closeOwnerModal();
                        } else {
                            self.showToast("There was some error, please try again", false)
                        }

                    }).catch(function (err) {
                        self.loading = false;
                        self.showToast("There was some error, please try again", false)
                    });
            }
            this.closeOwnerModal();
            this.loading = false;
        },
        addOrRemoveStudent(toAdd){
            var text = "You are about to create a student in Ebecas with the details of this application.";
            var confirmBtnText = "Yes, I go ahead!";
            if ( ! toAdd ){
                text = "You are about to remove this student id from the application form.";
                confirmBtnText = "Yes, I am sure";
            }
            let self = this;
            Swal.fire({
                customClass: {
                    confirmButton: 'btn btn-info text-white px-3',
                    cancelButton: 'btn btn-outline-secondary px-3 mx-3',
                },
                confirmButtonText: confirmBtnText,
                cancelButtonText: "Cancel",
                buttonsStyling: false,
                reverseButtons:true,
                title: 'Are you sure?',
                text: text,
                icon: 'warning',
                showCancelButton: true,
            }).then((result) => {
                if (result.isConfirmed && toAdd) {
                    self.createStudentRequest();
                }
                if (result.isConfirmed && ! toAdd) {
                    self.removeStudentRequest();
                }
            });
        },
        createStudentRequest(){
            let self = this;
            this.loadingStudent = true;
            if ( ! this.data.student_id ) {
                return this.request.post(route('staff.applications.student.create', this.data.id))
                    .then(function (response) {
                        self.showToast(response.message, response.success)
                        self.data.student_id = response.data.student_id;
                        self.data.student_number = response.data.student_number;
                        self.loadingStudent = false;
                    }).catch(function (err) {
                        self.showToast("Try again later", false);
                        self.loadingStudent = false;
                    });
            }
        },
        removeStudentRequest(){
            let self = this;
            this.loadingStudent = true;
            if ( this.data.student_id ) {
                return this.request.post(route('staff.applications.student.remove', this.data.id))
                    .then(function (response) {
                        if (!response.success){
                            self.showToast(response.message, response.success);
                            self.loadingStudent = false;
                            return false;
                        }
                        self.showToast(response.message, response.success);
                        self.data.student_id = response.data.student_id
                        self.data.student_number = response.data.student_number
                        self.data.offer_id = response.data.offer_id
                        self.loadingStudent = false;
                    }).catch(function (err) {
                        self.showToast("Try again later", false);
                        self.loadingStudent = false;
                    });
            }
        },
        getUsersByUserType(){
            this.users = [];
            this.selectedUser = null;
            if ( this.selectedUserType ) {
                let self = this;
                this.loadingUsers = true;
                return this.request.get(route('staff.users.type.list', this.selectedUserType))
                    .then(function (response) {
                        self.users = response
                        self.loadingUsers = false;
                    }).catch(function (err) {
                        self.loadingUsers = false;
                    });
            }
        },
        getDropdownText(search){
            if(search != '' && this.users.length == 0){
                return 'No matching results';
            }
            return 'Type to search users';
        },
        showToast(message, isSuccess) {
            new bs5.Toast({
                body: message,
                className: !isSuccess ? 'border-0 bg-danger text-white' : 'border-0 bg-success text-white',
                btnCloseWhite: true,
            }).show();
        },
        capitalizeWord(string) {
            return generalHelpers.capitalizeFirstLetter(string);
        },
        allowStatusChange(){
            if (! this.userPermissions.edit_application_properties || this.data.offer_id){
                return false;
            }
            else if ( this.data.status === 'expired' ){
                return false;
            }
            return true;
        },
        allowStudentCreation(){
            if (this.data.student_id || this.loadingStudent){
                return false;
            }
            else if ( this.data.status === 'expired' || this.data.status === 'draft' || this.data.status === 'on_hold' ){
                return false;
            }
            return true;
        }
    },
    computed: {
        applicationStatusDropdown(){
            let statuses = [];
            if (this.data.status === 'draft'){
                statuses.push({label:this.status['cancelled'].label, value: 'cancelled'})
                return statuses;
            }
            if (this.data.status === 'cancelled'){
                statuses.push({label:this.status['draft'].label, value: 'draft'})
                statuses.push({label:this.status['submitted'].label, value: 'submitted'})
                return statuses;
            }
            for ( let item in this.status) {
                statuses.push({label:this.status[item].label, value: item})
            }
            return statuses;
        },
        usersFilter(){
            let users = [];
            for ( let item in this.users) {
                users.push({
                    name:this.users[item].name,
                    id:this.users[item].id
                })
            }
            return users;
        },
        userTypeDropdown(){
            let userTypes = [];
            for ( let item in this.userType) {
                userTypes.push({label: generalHelpers.capitalizeFirstLetter(this.userType[item]), value: this.userType[item]})
            }
            return userTypes;
        }
    },
    watch: {
        selectedUserType: function formStart_date(value) {
            this.users = [];
            this.selectedUser = null;
            if ( value ){
                this.getUsersByUserType()
            }
        },
    }
}
</script>

<style scoped>

</style>
