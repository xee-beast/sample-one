<template>
    <div class="summary-accrodion">
        <div class="accordion-item">
            <h2 class="accordion-header" id="personal-details">
                <button
                    class="accordion-button collapsed"
                    type="button"
                    data-bs-toggle="collapse"
                    data-bs-target="#personal-details-collapse"
                    aria-expanded="true"
                    aria-controls="collapseOne"
                >
                    <span>Personal Details</span>
                </button>
            </h2>
            <div
                v-if="data.detail"
                id="personal-details-collapse"
                class="accordion-collapse collapse"
                aria-labelledby="personal-details"
                data-bs-parent="#app-details"
            >
                <div class="accordion-body">
                    <div class="personal-details">
                        <!-- ++++++++++++++ First section || Student personal details++++++++++++++ -->
                        <div class="details-section">
                            <h1><i class="fa-solid fa-circle-user"></i> Student personal details</h1>
                            <div class="row">
                                <div class="col-lg-4">
                                    <span class="label">First Name</span>
                                    <p class="detail">{{ data.detail.first_name }}</p>
                                </div>
                                <div class="col-lg-4">
                                    <span class="label">Middle Name</span>
                                    <p class="detail">{{ data.detail.middle_name }}</p>
                                </div>
                                <div class="col-lg-4">
                                    <span class="label">Last Name</span>
                                    <p class="detail">{{ data.detail.last_name }}</p>
                                </div>
                                <div class="col-lg-4">
                                    <span class="label">Salutation</span>
                                    <p class="detail">
                                        {{ data.detail.other_salutation ?? data.detail.salutation }}
                                    </p>
                                </div>
                                <div class="col-lg-4">
                                    <span class="label">Gender</span>
                                    <p class="detail">{{ data.detail.gender }}</p>
                                </div>
                                <div class="col-lg-4">
                                    <span class="label">Date of birth</span>
                                    <p class="detail">
                                        {{ formatDate(data.detail.dob) }} ({{
                                            getAgeFromDate(data.detail.dob)
                                        }}
                                        years old)
                                    </p>
                                </div>
                                <div class="col-lg-4">
                                    <span class="label">Passport Number</span>
                                    <p class="detail">{{ data.detail.passport_number }}</p>
                                </div>
                                <div class="col-lg-4">
                                    <span class="label">Email</span>
                                    <p class="detail">{{ data.detail.email }}</p>
                                </div>
                                <div class="col-lg-4">
                                    <span class="label">Phone</span>
                                    <p class="detail">{{ data.detail.mobile }}</p>
                                </div>

                                <div class="col-lg-4">
                                    <span class="label">Nationality</span>
                                    <p class="detail">
                                        {{ data.detail.nationality ? data.detail.nationality.name : "" }}
                                    </p>
                                </div>
                                <div class="col-lg-4">
                                    <span class="label">Country of birth</span>
                                    <p class="detail">
                                        {{ data.detail.birth_country ? data.detail.birth_country.name : "" }}
                                    </p>
                                </div>
                                <div class="col-lg-4">
                                    <span class="label">First Language</span>
                                    <p class="detail">
                                        {{
                                            data.detail.first_language ? data.detail.first_language.name : ""
                                        }}
                                    </p>
                                </div>
                                <div class="col-lg-4">
                                    <span class="label">Current Occupation</span>
                                    <p class="detail">{{ data.detail.occupation }}</p>
                                </div>
                                <div class="col-lg-4">
                                    <span class="label">Living in australia?</span>
                                    <p class="detail">
                                        {{ data.detail.living_in_australia ? "Yes" : "No" }}
                                    </p>
                                </div>
                                <div class="col-lg-4">
                                    <span class="label">Australian Resident?</span>
                                    <p class="detail">
                                        {{ data.detail.australian_resident ? "Yes" : "No" }}
                                    </p>
                                </div>
                                <div class="col-lg-4">
                                    <span class="label">Allow Marketing Contact?</span>
                                    <p class="detail">
                                        {{ !data.detail.marketing_consent ? "Yes" : "No" }}
                                    </p>
                                </div>
                            </div>
                        </div>
                        <!-- ++++++++++++++ Second section || Australian Visa Details++++++++++++++ -->
                        <div class="details-section">
                            <h1><i class="fa-solid fa-file-lines"></i> Australian Visa Details</h1>
                            <div class="row">
                                <div class="col-lg-6">
                                    <span class="label">Do you currently hold an Australian visa </span>
                                    <p class="detail">
                                        {{ data.detail.has_australian_visa ? "Yes" : "No" }}
                                    </p>
                                </div>
                                <div v-if="data.detail.has_australian_visa == 1" class="col-lg-6">
                                    <span class="label">Visa Type </span>
                                    <p class="detail">{{ data.detail.visa_type.name }}</p>
                                </div>
                                <div v-if="data.detail.has_australian_visa == 1" class="col-lg-6">
                                    <span class="label">Current Visa expiry date </span>
                                    <p class="detail">{{ formatDate(data.detail.current_visa_expiry) }}</p>
                                </div>
                                <div class="col-lg-6">
                  <span class="label"
                  >Have you ever held a student visa for Australia?</span
                  >
                                    <p class="detail">
                                        {{ data.detail.has_had_student_visa ? "Yes" : "No" }}
                                    </p>
                                </div>
                                <div class="col-lg-6">
                                    <span class="label">Which visa are you applying?</span>
                                    <p class="detail">
                                        {{
                                            data.detail.visa_applying_for
                                                ? data.detail.visa_applying_for.name
                                                : ""
                                        }}
                                    </p>
                                </div>
                                <div class="col-lg-6">
                  <span class="label"
                  >Will you be lodging your visa application in Australia?</span
                  >
                                    <p class="detail">
                                        {{ data.detail.visa_application_australia ? "Yes" : "No" }}
                                    </p>
                                </div>
                                <div v-if="data.detail.visa_application_australia == 0" class="col-lg-6">
                  <span class="label"
                  >Which country will you lodge the visa application?</span
                  >
                                    <p class="detail">
                                        {{
                                            data.detail.visa_application_location
                                                ? data.detail.visa_application_location.name
                                                : ""
                                        }}
                                    </p>
                                </div>
                            </div>
                        </div>

                        <!-- ++++++++++++++  Section 3 || Address in Home Country ++++++++++++++ -->
                        <div class="details-section">
                            <h1><i class="fa-solid fa-location-dot"></i> Current Residence Address</h1>
                            <div class="row">
                                <div class="col-lg-4">
                                    <span class="label">Address Line 1</span>
                                    <p class="detail">{{ data.detail.current_residence_address_line_1 }}</p>
                                </div>
                                <div class="col-lg-4">
                                    <span class="label">Address Line 2</span>
                                    <p class="detail">{{ data.detail.current_residence_address_line_2 }}</p>
                                </div>
                                <div class="col-lg-4">
                                    <span class="label">Address Line 3</span>
                                    <p class="detail">{{ data.detail.current_residence_address_line_3 }}</p>
                                </div>
                                <div class="col-lg-4">
                                    <span class="label">City</span>
                                    <p class="detail">{{ data.detail.current_residence_address_city }}</p>
                                </div>
                                <div class="col-lg-4">
                                    <span class="label">State</span>
                                    <p class="detail">{{ data.detail.current_residence_address_state }}</p>
                                </div>
                                <div class="col-lg-4">
                                    <span class="label">Postcode</span>
                                    <p class="detail">{{ data.detail.current_residence_address_postcode }}</p>
                                </div>
                                <div class="col-lg-4">
                                    <span class="label">Country</span>
                                    <p class="detail">{{ data.detail.current_residence_country.name }}</p>
                                </div>
                            </div>
                        </div>

                        <!-- ++++++++++++++ Section 4 || Next of KIN ++++++++++++++ -->
                        <div class="details-section">
                            <h1><i class="fa-solid fa-people-group"></i> Next of KIN</h1>
                            <div class="row">
                                <div class="col-lg-6">
                                    <span class="label">Contact's full name</span>
                                    <p class="detail">{{ data.detail.next_of_kin_full_name }}</p>
                                </div>
                                <div class="col-lg-6">
                                    <span class="label">Contact's telephone</span>
                                    <p class="detail">{{ data.detail.next_of_kin_phone }}</p>
                                </div>
                                <div class="col-lg-6">
                                    <span class="label">Contact's e-mail</span>
                                    <p class="detail">{{ data.detail.next_of_kin_email }}</p>
                                </div>
                                <div class="col-lg-6">
                                    <span class="label">Contact's relationship</span>
                                    <p class="detail">{{ data.detail.next_of_kin_relationship }}</p>
                                </div>
                            </div>
                        </div>

                        <!-- ++++++++++++++ Section 5 || Agent Details ++++++++++++++ -->
                        <div v-if="data.application_owner.user_type !== 'agent'" class="details-section">
                            <h1><i class="fa-solid fa-user-tie"></i> Agent Details</h1>
                            <div class="row">
                                <div class="col-lg-4">
                                    <span class="label">Receiving advice from an education agent?</span>
                                    <p class="detail">{{ data.detail.agent_assistance ? "Yes" : "No" }}</p>
                                </div>
                                <div v-if="data.detail.agent_assistance == 1" class="col-lg-4">
                                    <span class="label">Name of the agent</span>
                                    <p class="detail">{{ data.detail.agent_name }}</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!--  program  -->
        <div class="accordion-item">
            <h2 class="accordion-header" id="panelsStayOpen-programs">
                <button
                    class="accordion-button collapsed"
                    type="button"
                    data-bs-toggle="collapse"
                    data-bs-target="#panelsStayOpen-collapsePrograms"
                    aria-expanded="false"
                    aria-controls="panelsStayOpen-collapsePrograms"
                >
                    Academic Details
                </button>
            </h2>
            <div
                v-if="data.application_programs"
                id="panelsStayOpen-collapsePrograms"
                class="accordion-collapse collapse"
                aria-labelledby="panelsStayOpen-programs"
            >
                <div class="accordion-body">
                    <div class="personal-details">
                        <div class="details-section">
                            <div class="academic-col academic-items">
                                <!-- program start -->
                                <div class="products">

                                    <div class="product-list" v-if="data.sorted_programs.length > 0">

                                        <div class="product-item mt-3" v-for="(program, key) in data.sorted_programs">
                                            <div v-if="program.package" class="mt-3">

                                                <h5>{{program.package.name}}</h5>
                                                <div class="product-item mt-3 ms-2 ps-4" v-for="(pkgProgram, packageProgramKey) in program.programs">
                                                    <h1>{{ pkgProgram.program }}</h1>

                                                    <div class="row">
                                                        <div class="col">
                                                            <span class="label">Location/Faculty </span>
                                                            <p class="detail"> {{ pkgProgram.location }} / {{ pkgProgram.faculty }} </p>
                                                        </div>

                                                        <div class="col">
                                                            <span class="label">Start Date</span>
                                                            <p class="detail">  <span>{{ formatDate(pkgProgram.start_date) }}</span> </p>
                                                        </div>


                                                        <div class="col">
                                                            <span class="label">End Date</span>
                                                            <p class="detail"><span>{{ formatDate(pkgProgram.end_date) }}</span></p>
                                                        </div>

                                                        <div class="col">
                                                            <span class="label">Length (weeks)</span>
                                                            <p class="detail"> <span class="duration">{{ pkgProgram.length }}</span></p>
                                                        </div>

                                                    </div>

                                                    <div class="products mt-3 ps-4" v-if="programServices(pkgProgram).length > 0 || programAdditionalServices(pkgProgram).length > 0">
                                                        <div class="product-title"><h5>Services</h5></div>
                                                        <div class="product-list">
                                                            <div class="product-list" v-if="programServices(pkgProgram).length > 0 || programAdditionalServices(pkgProgram).length > 0">
                                                                <div class="product-item">

                                                                    <h6 v-for="(service, key) in programServices(pkgProgram)">
                                                                        {{ service.name }}
                                                                        <span v-if="service.mandatory" class="text-danger"> * </span>
                                                                    </h6>

                                                                    <!-- Additional Services -->
                                                                    <h6 v-for="(additionalService, key) in programAdditionalServices(pkgProgram)">
                                                                        {{ additionalService.name }}
                                                                        <span v-if="additionalService.mandatory" class="text-danger"> * </span>
                                                                    </h6>

                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>

                                                    <div v-if="calculateBreakForPackage(packageProgramKey,pkgProgram, program.programs) !== ''" class="my-3 border-bottom border-top py-3 bg-light bg-gradient">
                                                        <h6 class="text-center">{{calculateBreakForPackage(packageProgramKey,pkgProgram, program.programs)}} break</h6>
                                                    </div>
                                                </div>

                                            </div>

                                            <div v-else class="mt-4">
                                                <h1>{{ program.program }}</h1>

                                                <div class="row">
                                                    <div class="col">
                                                        <span class="label">Location/Faculty </span>
                                                        <p class="detail"> {{ program.location }} / {{ program.faculty }} </p>
                                                    </div>

                                                    <div class="col">
                                                        <span class="label">Start Date</span>
                                                        <p class="detail">  <span>{{ formatDate(program.start_date) }}</span> </p>
                                                    </div>


                                                    <div class="col">
                                                        <span class="label">End Date</span>
                                                        <p class="detail"><span>{{ formatDate(program.end_date) }}</span></p>
                                                    </div>

                                                    <div class="col">
                                                        <span class="label">Length (weeks)</span>
                                                        <p class="detail"> <span class="duration">{{ program.length }}</span></p>
                                                    </div>

                                                </div>

                                                <div class="products mt-3 ps-4" v-if="programServices(program).length > 0 || programAdditionalServices(program).length > 0">
                                                    <div class="product-title"><h5>Services</h5></div>
                                                    <div class="product-list">
                                                        <div class="product-list" v-if="programServices(program).length > 0 || programAdditionalServices(program).length > 0">
                                                            <div class="product-item">

                                                                <h6 v-for="(service, key) in programServices(program)">
                                                                    {{ service.name }}
                                                                    <span v-if="service.mandatory" class="text-danger"> * </span>
                                                                </h6>

                                                                <!-- Additional Services -->
                                                                <h6 v-for="(additionalService, key) in programAdditionalServices(program)">
                                                                    {{ additionalService.name }}
                                                                    <span v-if="additionalService.mandatory" class="text-danger"> * </span>
                                                                </h6>

                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>

                                            <div v-if="calculateBreak(key,program) !== ''" class="my-3 border-bottom border-top py-3 bg-light bg-gradient">
                                                <h6 class="text-center">{{calculateBreak(key,program)}} break</h6>
                                            </div>

                                        </div>

                                    </div>
                                    <div v-if="data.sorted_programs.length > 0">
                                        <hr class="text-muted mt-5" />
                                        <span class="text-danger"> * </span>
                                        <i><small>Indicates the fee or product is mandatory</small></i>
                                    </div>
                                    <div class="text-center" v-else>
                                        <small>No data to display</small>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!--  Accommodation  -->
        <div class="accordion-item">
            <h2 class="accordion-header" id="panelsStayOpen-accommodation">
                <button
                    class="accordion-button collapsed"
                    type="button"
                    data-bs-toggle="collapse"
                    data-bs-target="#panelsStayOpen-collapseAccommodation"
                    aria-expanded="false"
                    aria-controls="panelsStayOpen-collapseAccommodation"
                >
                    Accommodation
                </button>
            </h2>
            <div
                v-if="data.application_accommodations"
                id="panelsStayOpen-collapseAccommodation"
                class="accordion-collapse collapse"
                aria-labelledby="panelsStayOpen-accommodation"
            >
                <div class="accordion-body">
                    <div class="personal-details">
                        <div class="details-section">
                            <div class="academic-col academic-items">
                                <div class="products">
                                    <div class="product-list" v-if="data.application_accommodations.length > 0">
                                        <div
                                            class="product-item mt-3"
                                            v-for="(accommodation, key) in data.application_accommodations"
                                        >
                                            <h1>{{ accommodation.accommodation }}</h1>

                                            <div class="row">
                                                <div class="col">
                                                    <span class="label">Type</span>
                                                    <p class="detail">{{ accommodation.accommodation_category }}</p>
                                                </div>

                                                <div class="col">
                                                    <span class="label">Check-in Date</span>
                                                    <p class="detail"><span>{{ formatDate(accommodation.start_date) }}</span></p>
                                                </div>

                                                <div class="col">
                                                    <span class="label">Check-out Date</span>
                                                    <p class="detail"><span>{{ formatDate(accommodation.end_date)}}</span></p>
                                                </div>

                                                <div class="col">
                                                    <span class="label">Length</span>
                                                    <p class="detail">
                                                        <span class="duration">
                                                            {{ accommodation.weeks }} week(s) |
                                                            {{ accommodation.days }} day(s)
                                                        </span>
                                                    </p>
                                                </div>
                                            </div>

                                            <div class="products mt-3 ps-4" v-if="accommodationServices(accommodation).length > 0 || accommodationAdditionalServices(accommodation).length > 0">
                                                <div class="product-title"><h5>Services</h5></div>
                                                <div class="product-list">
                                                    <div class="product-list" v-if="accommodationServices(accommodation).length > 0 || accommodationAdditionalServices(accommodation).length > 0">
                                                        <div class="product-item">
                                                            <h6 v-for="(service, key) in accommodationServices(accommodation)">
                                                                {{ service.name }}
                                                                <span v-if="service.mandatory" class="text-danger"> *</span>
                                                            </h6>

                                                            <!-- Additional Services -->
                                                            <h6 v-for="(additionalService, key) in accommodationAdditionalServices(accommodation)" >
                                                                {{ additionalService.name }}
                                                                <span v-if="additionalService.mandatory" class="text-danger"> *</span>
                                                            </h6>

                                                        </div>
                                                    </div>
                                                </div>
                                            </div>

                                            <div class="products mt-3 ps-4" v-if="accommodationAddons(accommodation).length > 0">
                                                <div class="product-title"><h5>Add-ons</h5></div>
                                                <div class="product-list">
                                                    <div class="product-list" v-if="accommodationAddons(accommodation).length > 0">
                                                        <div
                                                            class="product-item"
                                                            v-for="(addon, key) in accommodationAddons(accommodation)"
                                                        >
                                                            <h6>
                                                                {{ addon.name }}
                                                                <span v-if="addon.mandatory" class="text-danger"> *</span>
                                                            </h6>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>

                                        </div>
                                    </div>

                                    <div v-if="data.application_accommodations.length > 0">
                                        <hr class="text-muted mt-5" />
                                        <span class="text-danger"> * </span>
                                        <i><small>Indicates the fee or product is mandatory</small></i>
                                    </div>
                                    <div class="text-center" v-else>
                                        <small>No data to display</small>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!--  Transportation  -->
        <div class="accordion-item">
            <h2 class="accordion-header" id="panelsStayOpen-transportation">
                <button
                    class="accordion-button collapsed"
                    type="button"
                    data-bs-toggle="collapse"
                    data-bs-target="#panelsStayOpen-collapseTransportation"
                    aria-expanded="false"
                    aria-controls="panelsStayOpen-collapseTransportation"
                >
                    Airport Transfer
                </button>
            </h2>
            <div
                v-if="data.application_transportations"
                id="panelsStayOpen-collapseTransportation"
                class="accordion-collapse collapse"
                aria-labelledby="panelsStayOpen-transportation"
            >
                <div class="accordion-body">
                    <div class="personal-details">
                        <div class="details-section">
                            <div class="academic-col academic-items">
                                <div class="products">
                                    <div class="product-list" v-if="data.application_transportations.length > 0">
                                        <div
                                            class="product-item mt-5"
                                            v-for="(transportation, key) in data.application_transportations"
                                        >
                                            <h1>{{ transportation.transportation }}</h1>

                                            <div class="products mt-3 ps-4" v-if="transportationServices(transportation).length > 0">
                                                <div class="product-title"><h5>Services</h5></div>
                                                <div class="product-list">
                                                    <div class="product-list" v-if="transportationServices(transportation).length > 0">
                                                        <div
                                                            class="product-item"
                                                            v-for="(service, key) in transportationServices(transportation)"
                                                        >
                                                            <h6>
                                                                {{ service.name }}
                                                                <span v-if="service.mandatory" class="text-danger"> *</span>
                                                            </h6>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>

                                            <div class="products mt-3 ps-4" v-if="transportationAddons(transportation).length > 0">
                                                <div class="product-title"><h5>Add-ons</h5></div>
                                                <div class="product-list">
                                                    <div class="product-list" v-if="transportationAddons(transportation).length > 0">
                                                        <div
                                                            class="product-item"
                                                            v-for="(addon, key) in transportationAddons(transportation)"
                                                        >
                                                            <h6>
                                                                {{ addon.name }}
                                                                <span v-if="addon.mandatory" class="text-danger"> * </span>
                                                            </h6>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>

                                        </div>
                                    </div>
                                    <div v-if="data.application_transportations.length > 0">
                                        <hr class="text-muted mt-5" />
                                        <span class="text-danger"> * </span>
                                        <i><small>Indicates the fee or product is mandatory</small></i>
                                    </div>
                                    <div class="text-center" v-else>
                                        <small>No data to display</small>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!--  insurance  -->
        <div class="accordion-item">
            <h2 class="accordion-header" id="panelsStayOpen-insurances">
                <button
                    class="accordion-button collapsed"
                    type="button"
                    data-bs-toggle="collapse"
                    data-bs-target="#panelsStayOpen-collapseInsurances"
                    aria-expanded="false"
                    aria-controls="panelsStayOpen-collapseInsurances"
                >
                    Overseas Student Health Cover (OSHC)
                </button>
            </h2>
            <div
                v-if="data.application_insurances"
                id="panelsStayOpen-collapseInsurances"
                class="accordion-collapse collapse"
                aria-labelledby="panelsStayOpen-insurances"
            >
                <div class="accordion-body">
                    <div class="personal-details">
                        <div class="details-section">
                            <div class="academic-col academic-items">
                                <!-- program start -->
                                <div class="products">
                                    <div class="product-list" v-if="data.application_insurances.length > 0">
                                        <div class="product-item mt-3" v-for="(insurance, key) in data.application_insurances">
                                            <h1 class="text-capitalize">{{ insurance.insurance_name }}</h1>

                                            <div class="row">

                                                <div class="col">
                                                    <span class="label">Start Date</span>
                                                    <p class="detail">  <span>{{ insurance.start_date }}</span> </p>
                                                </div>


                                                <div class="col">
                                                    <span class="label">End Date</span>
                                                    <p class="detail"><span>{{ insurance.end_date }}</span></p>
                                                </div>

                                                <div class="col">
                                                    <span class="label">Length (months)</span>
                                                    <p class="detail"> <span class="duration">{{ insurance.duration }}</span></p>
                                                </div>
                                            </div>

                                            <!-- <hr /> -->
                                        </div>

                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="text-center" v-if="!data.application_insurances.length">
                        <small>No data to display</small>
                    </div>
                </div>
            </div>
        </div>

        <!--  payment  -->
        <div class="accordion-item">
            <h2 class="accordion-header" id="panelsStayOpen-payment">
                <button
                    class="accordion-button collapsed"
                    type="button"
                    data-bs-toggle="collapse"
                    data-bs-target="#panelsStayOpen-collapsePayment"
                    aria-expanded="false"
                    aria-controls="panelsStayOpen-collapsePayment"
                >
                    Payment Details
                </button>
            </h2>
            <div
                v-if="data.payment"
                id="panelsStayOpen-collapsePayment"
                class="accordion-collapse collapse"
                aria-labelledby="panelsStayOpen-payment"
            >
                <div class="accordion-body">
                    <div class="personal-details">
                        <div class="details-section">
                            <div class="academic-col academic-items">
                                <div class="row">
                                    <div class="col-lg-4">
                                        <span class="label">Payment Plan</span>
                                        <p class="detail">
                                            {{ data.payment.payment_plan_enabled ? "Yes" : "No" }}
                                        </p>
                                    </div>
                                    <div class="col-lg-4">
                                        <span class="label">Payment Method</span>
                                        <p class="detail">{{ data.payment.payment_method.name }}</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="text-center" v-if="!data.payment">
                        <small>No data to display</small>
                    </div>
                </div>
            </div>
        </div>


    </div>
</template>
<script>
import moment from "moment";
import { useFormStore } from "../../../stores/applicationForm";
import generalHelpers from "../../../helpers/generalHelpers";

export default {
    // Pinia state setup to initialize state data
    setup() {
        const formStore = useFormStore();
        const { addApplicationData, getApplicationData } = formStore;
        return { addApplicationData, getApplicationData };
    },
    props: ["application"],
    name: "application-summary",
    data() {
        return {
            data: {},
            program_additional_services: [],
        };
    },
    async mounted() {
        // getting application details from pinia
        this.data = await this.getApplicationData("track");
        if (!Object.keys(this.data).length && typeof this.application.id !== "undefined") {
            await this.addApplicationData("track", this.application);
            this.data = await this.getApplicationData("track");
        }
    },
    methods: {
        formatDate(date) {
            return moment(date).format("DD/MM/YYYY", ['DD/MM/YYYY', 'DD/MM/YY']);
        },
        getAgeFromDate(date) {
            return moment().diff(date, "years");
        },
        calculateBreak(key, program) {
            let programLength = key + 1;
            if (this.data.sorted_programs.length !== 1 && this.data.sorted_programs.length > programLength) {
                let nextItem = this.data.sorted_programs[programLength];
                let nextStart = moment(nextItem.start_date);
                let currentEnd = moment(program.end_date);
                let weeks = nextStart.diff(currentEnd, "week");
                if (weeks === 0) return "";
                return weeks + " week(s)";
            }
            return "";
        },

        calculateBreakForPackage(key,program,programs){
            let programLength = key+1;
            if(programs.length !== 1 &&  programs.length > programLength){
                let nextItem = programs[programLength];
                let nextStart = moment(nextItem.start_date);
                let currentEnd = moment(program.end_date);
                let weeks = nextStart.diff(currentEnd,'week');
                if(weeks===0)
                    return '';
                return weeks +' week(s)';
            }
            return '';
        },

        calculateAccommodationBreak(key, accommodation) {
            let AccommodationLength = key + 1;
            if (
                this.data.application_accommodations.length !== 1 &&
                this.data.application_accommodations.length > AccommodationLength
            ) {
                let nextItem = this.data.application_accommodations[AccommodationLength];
                let nextStart = moment(nextItem.start_date);
                let currentEnd = moment(accommodation.end_date);
                let weeks = nextStart.diff(currentEnd, "week");
                if (weeks === 0) return "";
                return weeks + " week(s)";
            }
            return "";
        },
        programServices(program){
            let services = this.data.application_program_services;
            let list = services.filter((service) => {
                return service.program_start_date === program.start_date && service.type !== 'application';
            });
            return list;
        },
        programAdditionalServices(program){
            let services = this.data.application_program_services;
            let list = services.filter((service) => {
                return service.program_start_date === program.start_date && service.type === 'application';
            });
            return list;
        },
        accommodationServices(accommodation){
            let services = this.data.application_accommodation_services;
            let list = services.filter((service) => {
                return service.accommodation_start_date === accommodation.start_date && service.type !== 'application';
            });
            return list;
        },
        accommodationAdditionalServices(accommodation){
            let services = this.data.application_accommodation_services;
            let list = services.filter((service) => {
                return service.accommodation_start_date === accommodation.start_date && service.type === 'application';
            });
            return list;
        },
        accommodationAddons(accommodation) {
            let addons =  this.data.application_accommodation_addons;
            let list = addons.filter((addon) => {
                return addon.accommodation_start_date === accommodation.start_date;
            });
            return list;
        },
        transportationServices(transportation) {
            let services = this.data.application_transportation_services;
            let list = services.filter((service) => {
                return service.transportation_id === transportation.transportation_id;
            });
            return list;
        },
        transportationAddons(transportation) {
            let addons = this.data.application_transportation_addons;
            let list = addons.filter((addon) => {
                return addon.transportation_id === transportation.transportation_id;
            });
            return list;
        }
    },
};
</script>

<style scoped></style>
