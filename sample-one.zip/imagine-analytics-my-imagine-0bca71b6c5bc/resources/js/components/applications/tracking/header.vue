<template>
    <div class="card-body" v-if="data.detail">
        <div class="wizard-title ">
            <div class="wizard-title-left">
                <div>
                    <span>Application {{data.id}}</span>
                    <h5>{{data.detail.first_name}} {{data.detail.last_name}}</h5>
                    <div v-if="data.student_id" class="span-student-id">Student Id: {{data.student_number}}</div>
                </div>
            </div>

            <div class="wizard-title-right">
                <div>
                    <span>Status</span>
                    <h5>{{status[data.status]['label']}}</h5>
                </div>

            </div>
        </div>
    </div>
</template>

<script>
import {useFormStore} from "../../../stores/applicationForm";

export default {
    // Pinia state setup to initialize state data
    setup(){
        const formStore  = useFormStore();
        const {addApplicationData, getApplicationData} = formStore;
        return {addApplicationData, getApplicationData};
    },
    props:['application', 'status'],
    data() {
        return {
            data: {},
        }
    },
    async mounted() {
        // getting application details from pinia
        this.data = await this.getApplicationData('track');
        if (!Object.keys(this.data).length && typeof this.application.id !== 'undefined') {
            await this.addApplicationData('track', this.application);
            this.data = await this.getApplicationData('track');
        }
    },
}
</script>

<style scoped>

</style>
