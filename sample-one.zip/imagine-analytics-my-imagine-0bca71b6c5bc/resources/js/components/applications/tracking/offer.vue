<template>
    <div class="accordion" id="accordionOffer">
        <div class="accordion-item">
            <h2 class="accordion-header" id="panelsHeadOffer">
                <button class="accordion-button" type="button" data-bs-toggle="collapse" data-bs-target="#panelsStayOpen-offer" aria-expanded="true" aria-controls="panelsStayOpen-offer">
                    Offer
                </button>
            </h2>
            <div id="panelsStayOpen-offer" class="accordion-collapse collapse show" aria-labelledby="panelsHeadOffer" data-bs-parent="#accordionOffer">
                <div class="accordion-body">
                    <ul class="key-value">
                        <li>
                            <span>Offer Number</span>
                            <p><span class="edit-link me-0">
                                {{data.offer_id}}

                            <span v-if="loadingOffer" class="spinner-border spinner-border-sm text-end" ></span>

                            <a v-show="allowOfferCreation()" class="ps-2 small" href="#" @click.prevent="updateOfferLinkModal()">
                                <i data-bs-toggle="tooltip" data-bs-placement="top"
                                   data-bs-title="Link an exiting offer"
                                   class="fa fa-link">
                                </i>
                            </a>

                            <a v-show="allowOfferCreation()" class="ps-2 text-end small" href="#" @click.prevent="addOrRemoveOffer(true)">
                                <i data-bs-toggle="tooltip" data-bs-placement="top"
                                   data-bs-title="Create Offer"
                                   class="fa fa-plus">
                                </i>
                            </a>

                            <a v-show="data.offer_id && !loadingOffer" class="ps-2 text-end small" href="#" @click.prevent="syncOfferWithEbecas()">
                                <i data-bs-toggle="tooltip" data-bs-placement="top"
                                   data-bs-title="Update offer details with data from Ebecas"
                                   class="fa fa-rotate">
                                </i>
                            </a>

                            <a v-show="data.offer_id && !loadingOffer" class="ps-2 text-end small" href="#" @click.prevent="addOrRemoveOffer(false)">
                                <i data-bs-toggle="tooltip" data-bs-placement="top"
                                   data-bs-title="Unlink the offer from this application"
                                   class="fa fa-link-slash">
                                </i>
                            </a>


                            </span>
                            </p>
                        </li>

                        <li v-if="offerDetails">
                            <span>Offer Date</span>
                            <p>{{formatDate(offerDetails.OfferDate)}}</p>
                        </li>

                        <li v-if="offerDetails">
                            <span>Offer Status</span>
                            <p>{{offerDetails.OfferStatus}}</p>
                        </li>

                        <li v-if="offerDetails">
                            <span>Agent Name</span>
                            <p>{{offerDetails.AgentName}}</p>
                        </li>

                        <li v-if="offerDetails">
                            <span>Offer Total</span>
                            <p>{{currencyFormat(offerDetails.OfferTotal)}}</p>
                        </li>
                    </ul>
                </div>

                <!--   MODALS   -->

                <div class="modal fade" id="offerLinkModal" tabindex="-1" role="dialog" aria-labelledby="offerLinkLabel" aria-hidden="true">
                    <div class="modal-dialog modal-lg">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title" id="offerLinkLabel">Link an existing offer</h5>
                            </div>
                            <div class="modal-body">

                                <div class="row">
                                    <div class="col-lg-10 col-md-12 col-xs-12 form-group">
                                        <label class="form-label">Offer Number</label>
                                        <input v-model="searchOfferNumber" type="number" class="form-control" required >
                                        <p class="text-danger" v-if="offerSearchError">{{ offerSearchError }}</p>
                                    </div>
                                    <div class="col-lg-2 col-md-12 col-xs-12 form-group mt-4 pt-2">
                                        <button type="button" class="btn btn-primary form-control" :disabled="offerSearchBtn" @click.prevent="getExistingOffer()">
                                            <i v-if="loading" class="fa fa-spinner fa-spin"></i>
                                            Search
                                        </button>
                                    </div>
                                </div>

                                <div v-if="Object.keys(searchedOffer).length" class="row m-2 mt-3">
                                    <table class="table table-bordered table-striped">
                                        <thead><tr>
                                            <th>Offer Number</th>
                                            <th>Offer Status</th>
                                        </tr>
                                        </thead>
                                        <tbody>
                                        <tr>
                                            <td>{{ searchedOffer['number'] }}</td>
                                            <td>{{ searchedOffer['status'] }}</td>

                                        </tr>
                                        </tbody>
                                    </table>
                                </div>

                            </div>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-outline-secondary" @click="closeOfferLinkModal()">Cancel</button>
                                <button type="button" class="btn btn-primary" :disabled="!Object.keys(searchedOffer).length" @click.prevent="linkOfferToApplication()"> Link</button>
                            </div>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </div>

</template>

<script>
import {useFormStore} from "../../../stores/applicationForm";
import vSelect from "vue-select";
import {HttpService} from "../../../services/HttpService";
import moment from "moment";
import generalHelpers from "../../../helpers/generalHelpers";

export default {
    // Pinia state setup to initialize state data
    setup(){
        const formStore  = useFormStore();
        const {addApplicationData, getApplicationData} = formStore;
        return {addApplicationData, getApplicationData};
    },
    components: {
        vSelect,
    },
    props:['application', 'status'],
    name: "detail",
    data() {
        return {
            data: {},
            loadingOffer: false,
            loading: false,
            searchOfferNumber: null,
            offerDetails: null,
            offerSearchError: false,
            searchedOffer: [],
            errors: {},
            request: new HttpService(),
        }
    },
    async mounted() {
        // getting application details from pinia
        this.data = await this.getApplicationData('track');
        if (!Object.keys(this.data).length && typeof this.application.id !== 'undefined') {
            await this.addApplicationData('track', this.application);
            this.data = await this.getApplicationData('track');
        }
        await this.getOfferDetails()
    },
    methods: {
        addOrRemoveOffer(toAdd){
            var text = "You are about to create an offer for this application";
            if ( ! toAdd ){
                text = "You are about to unlink this offer from this application";
            }
            let self = this;
            Swal.fire({
                customClass: {
                    confirmButton: 'btn btn-info text-white px-3',
                    cancelButton: 'btn btn-outline-secondary px-3 mx-3',
                },
                confirmButtonText: "Confirm",
                cancelButtonText: "Cancel",
                buttonsStyling: false,
                reverseButtons:true,
                title: 'Are you sure?',
                text: text,
                icon: 'warning',
                showCancelButton: true,
            }).then((result) => {
                if (result.isConfirmed && toAdd) {
                    self.createOfferRequest();
                }
                if (result.isConfirmed && ! toAdd) {
                    self.removeOfferRequest();
                }
            });
        },
        createOfferRequest(){
            let self = this;
            this.loadingOffer = true;
            if ( ! this.data.offer_id ) {
                return this.request.post(route('staff.applications.offer.create', this.data.id))
                    .then(async function (response) {
                        self.showToast(response.message, response.success);
                        self.data.offer_id = await response.data.offer_id;
                        await self.syncOfferWithEbecas();
                        self.loadingOffer = false;
                    }).catch(function (err) {
                        self.showToast("Something went wrong. Try again later", false);
                        self.loadingOffer = false;
                    });
            }else {
                this.loadingOffer = false;
            }
        },
        removeOfferRequest(){
            let self = this;
            this.loadingOffer = true;
            if ( this.data.offer_id ) {
                return this.request.post(route('staff.applications.offer.remove', this.data.id))
                    .then(function (response) {
                        self.showToast(response.message, response.success);
                        self.data.offer_id = null;
                        self.loadingOffer = false;
                        self.offerDetails = null;
                    }).catch(function (err) {
                        self.showToast("Something went wrong. Try again later", false);
                        self.loadingOffer = false;
                    });
            }else {
                this.loadingOffer = false;
            }
        },
        syncOfferWithEbecas(){
            let self = this;
            this.loadingOffer = true;
            if ( this.data.offer_id ) {
                return this.request.post(route('staff.applications.offer.sync', this.data.id))
                    .then(function (response) {
                        self.showToast(response.message, response.success);
                        self.data.status = response.data.OfferStatus.toLowerCase();
                        self.offerDetails = response.data;
                        self.loadingOffer = false;
                    }).catch(function (err) {
                        self.showToast("Something went wrong. Try again later", false);
                        self.loadingOffer = false;
                    });
            }else {
                this.loadingOffer = false;
            }
        },
        async getOfferDetails(){
            let self = this;
            this.loadingOffer = true;
            if ( this.data.offer_id ) {
                return this.request.get(route('staff.applications.offer.get', this.data.id))
                    .then(function (response) {
                       if (response.data !== null) {
                           self.offerDetails = response.data.data;
                       }
                        self.loadingOffer = false;
                    }).catch(function (err) {
                        self.showToast("Something went wrong. Try again later", false);
                        self.loadingOffer = false;
                    });
            }else {
                this.loadingOffer = false;
            }
        },
        getExistingOffer(){
          let self = this;
          this.loading = true;
          this.offerSearchError = false;
          this.searchedOffer = [];

          return this.request.get(route('staff.application.offer.search', this.data.id), {search : this.searchOfferNumber})
              .then(async function (response) {

                  // validations
                  let data = response.data.data
                  if (response.data.success === false) {
                      self.offerSearchError = await response.data.message;
                  }else if (data.StudentId != self.data.student_id){
                       self.offerSearchError = "The student id for this offer is different to the student id in this application. Please update and try again.";
                  }else {
                      self.searchedOffer.number = data.OfferId;
                      self.searchedOffer.status = data.OfferStatus;
                  }

                  self.loading = false
              }).catch(function (err) {
                  self.showToast("Something went wrong. Try again later", false);
                  self.loading = false
              });
        },
        linkOfferToApplication(){
            let self = this;
            self.loadingOffer = true;
            return this.request.patch(route('staff.application.offer.link', this.data.id), {offer_id : this.searchedOffer.number})
                .then(async function (response) {
                    if (!response.success){
                        self.showToast(response.message, response.success);
                        self.loadingOffer = false
                        return false;
                    }
                    self.data.offer_id = response.data.offer_id;
                    await self.syncOfferWithEbecas();
                    self.loadingOffer = false;
                    self.closeOfferLinkModal();
                }).catch(function (err) {
                    self.showToast("Something went wrong. Try again later", false);
                    self.loading = false
                });
        },
        showToast(message, isSuccess) {
            new bs5.Toast({
                body: message,
                className: !isSuccess ? 'border-0 bg-danger text-white' : 'border-0 bg-success text-white',
                btnCloseWhite: true,
            }).show();
        },
        formatDate(date){
            return moment(date, 'M/D/YYYY').format("DD/MM/YYYY")
        },
        currencyFormat(value){
            return generalHelpers.currencyFormatter('en-US', 'USD', value);
        },
        allowOfferCreation(){
            if(this.data.offer_id || this.loadingOffer){
                return false;
            }
            else if ( this.data.status === 'expired' || this.data.status === 'draft' || this.data.status === 'on_hold' ){
                return false;
            }
            return true;
        },
        updateOfferLinkModal(){
            if (! this.data.student_id ){
                this.showToast("Kindly create the student Id to continue.", false)
                return;
            }
            $('#offerLinkModal').modal('show');
        },
        closeOfferLinkModal(){
            this.offerSearchError = false;
            this.searchOfferNumber = null;
            this.searchedOffer = [];
            $('#offerLinkModal').modal('hide');
        },
    },
    computed: {
        offerSearchBtn(){
            if (!this.searchOfferNumber || this.searchOfferNumber.toString().length<3){
                return true;
            }
            else if (this.loading){
                return true;
            }
            return false;
        }
    },
    watch: {
    }
}
</script>

<style scoped>

</style>
