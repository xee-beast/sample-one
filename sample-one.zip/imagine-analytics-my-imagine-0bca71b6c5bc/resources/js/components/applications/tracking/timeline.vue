<template>
    <div class="accordion-item">
        <h2 class="accordion-header" id="panel-activity-headingOne">
            <button class="accordion-button" type="button" data-bs-toggle="collapse" data-bs-target="#panel-activity-collapseOne" aria-expanded="true" aria-controls="panel-activity-collapseOne">
                Application Timeline
            </button>
        </h2>
        <div id="panel-activity-collapseOne" class="accordion-collapse collapse show" aria-labelledby="panel-activity-headingOne">
            <div class="accordion-body application-timeline-section" id="timeline-scroll">
                <div class="text-center mt-3">
                    <div v-if="loading && activities.length  === 0" class="spinner-border" role="status">
                        <span class="visually-hidden">Loading...</span>
                    </div>
                </div>

                <div class="d-flex border-bottom mt-3"  v-for="activity in activities">

                    <i class="fa-solid fa-circle-user me-3 fa-3x text-secondary"></i>

                    <!-- Body -->
                    <div>
                      <h6>
                        {{getUserName(activity)}}
                         - <small class="text-muted">{{getTime(activity)}}</small>
                      </h6>
                      <p v-html="activity.event"></p>
                    </div>
                </div>
                <div v-if="activities.length > 0">
                    <InfiniteLoading @infinite="loadActivity">
                        <template #spinner>
                            <div class="text-center mt-2">
                                <div v-if="loading" class="spinner-border" role="status">
                                    <span class="visually-hidden">Loading...</span>
                                </div>
                            </div>
                        </template>
                        <template #complete>
                            <p class="text-center"></p>
                        </template>
                    </InfiniteLoading>
                </div>
            </div>
        </div>
    </div>
</template>

<script>
    import moment from 'moment';
    import {useFormStore} from "../../../stores/applicationForm";
    import vSelect from "vue-select";
    import {HttpService} from "../../../services/HttpService";
    import 'perfect-scrollbar/css/perfect-scrollbar.css'
    import PerfectScrollbar from 'perfect-scrollbar';
    import InfiniteLoading from 'v3-infinite-loading'
    import 'v3-infinite-loading/lib/style.css'
export default {
    // Pinia state setup to initialize state data
    setup(){
        const formStore  = useFormStore();
        const {addApplicationData, getApplicationData} = formStore;
        return {addApplicationData, getApplicationData};
    },
    components: {
        vSelect,
        InfiniteLoading
    },
    props:['application'],
    name: "activity",
    data() {
        return {
            activities: [],
            loading: false,
            nextUrl :null,
            disableScrollLoading:false,
            request: new HttpService(),
            ps:null
        }
    },
    mounted() {
        this.loadActivity();
        this.ps = new PerfectScrollbar("#timeline-scroll");
    },
    methods: {
        getTime(activity){
            let time =  moment(activity.created_at).fromNow();
            return  time +' '+moment(activity.created_at).format("DD/MM/YYYY LT");
        },
        getUserName(activity){
            return activity.user.first_name+' '+activity.user.last_name;
        },
        loadActivity(state = null){
            let self = this;
            this.loading = true;
            if(this.disableScrollLoading && state !== null){
                state.complete();
                return;
            }
            return this.request.get(this.nextUrl ? this.nextUrl : route('staff.application.activity', this.application.id))
                .then(function (response) {
                    self.loading = false;
                    if(response.success){
                        self.setData(response.data.data);
                        self.nextUrl = response.data.next_page_url;

                        if(response.data.next_page_url === null)
                            self.disableScrollLoading = true;

                    } else {
                        self.showToast("There was some error, please try again", false)
                    }
                }).catch(function (err) {
                    self.loading = false;
                    self.showToast("There was some error, please try again", false)
                });
        },
        setData(data){
            if(this.activities.length === 0)
                this.activities = data;
            else{
                for(let i in data){
                    let item = data[i];
                    this.activities.push(item);
                }
            }
        },
        showToast(message, isSuccess) {
            new bs5.Toast({
                body: message,
                className: !isSuccess ? 'border-0 bg-danger text-white' : 'border-0 bg-success text-white',
                btnCloseWhite: true,
            }).show();
        },
    }
}
</script>

<style scoped>

</style>
