<template>
    <div>
        <h3>Documents</h3>

        <div v-if="data.documents">
            <table  class="table table-bordered">
                <thead>
                <tr>
                    <th scope="col">Type</th>
                    <th scope="col">File Name</th>
                    <th scope="col">Uploaded by</th>
                    <th scope="col">Download</th>
                </tr>
                </thead>
                <tbody>
                <tr v-for="(item,key) in data.documents">
                    <td>{{item.document_name}}</td>
                    <td>{{item.name}}</td>
                    <td>
                        {{item.created_by_name}} <br>
                        <i>{{formatDocumentDate(item.created_at)}}</i>

                    </td>

                    <td align="center">
                        <a class="ps-2 text-end small" :href="item.download_route">
                            <button class="btn btn-outline-success"><i class="fa fa-download"></i></button>
                        </a>
                        <a v-if="canDeleteDocuments()" class="ps-2 text-end small" href="javascript:;" @click.prevent="deleteDocument(item,key)">
                            <button class="btn btn-outline-danger"><i v-if="loading && deleteIndex === key" class="fa fa-spin fa-spinner"></i>  <i v-else class="fa fa-times" title="Delete document" :disabled="loading && deleteIndex === key" ></i></button>
                        </a>
                    </td>
                </tr>
                </tbody>
            </table>
        </div>
        <div v-else>
            <p class="text-center fw-bold mt-2 mb-2">No documents available..</p>
            <br/>
        </div>
    </div>
</template>

<script>
import {useFormStore} from "../../../stores/applicationForm";
import moment from "moment";
import {HttpService} from "../../../services/HttpService";
import generalHelpers from "../../../helpers/generalHelpers";

export default {
    props:['application', 'userPermissions'],
    name: "documents",
    // Pinia state setup to initialize state data
    setup(){
        const formStore  = useFormStore();
        const {addApplicationData, getApplicationData, removeTrackingDocument} = formStore;
        return {addApplicationData, getApplicationData, removeTrackingDocument,};
    },
    data() {
        return {
            data: {},
            request: new HttpService(),
            deleteIndex:null,
            loading:false
        }
    },
    async mounted() {
        // getting application details from pinia
        this.data = await this.getApplicationData('track');
        if (!Object.keys(this.data).length && typeof this.application.id !== 'undefined') {
            await this.addApplicationData('track', this.application);
            this.data = await this.getApplicationData('track');
        }
    },
    methods: {
        formatDocumentDate(date) {
            return moment(date).format("DD/MM/YYYY h:mm a", ['DD/MM/YYYY', 'DD/MM/YY']);
        },

        deleteDocument(item,index) {
            let self = this;
            Swal.fire({
            customClass: {
                confirmButton: 'btn btn-info text-white px-3',
                cancelButton: 'btn btn-outline-secondary px-3 mx-3',
            },
            buttonsStyling: false,
            reverseButtons: true,
            title: 'Are you sure?',
            text: "You are about to delete this item!",
            icon: 'warning',
            showCancelButton: true,
            }).then((result) => {
            if (result.isConfirmed) {
                
                if(typeof item.id !== 'undefined'){
                    self.deleteDocumentFromS3(item,index);
                } else {
                let key = this.getApplicationData('documents').indexOf(item);
                self.removeTrackingDocument(key);
                }
            }
            });
        },

        deleteDocumentFromS3(item,index){
            let self = this;
            this.loading = true;
            this.deleteIndex = index;
            return this.request.delete(route('applications.document.delete', item.id))
            .then(function (response) {
                self.loading = false;
                if(response.success){
                let key = self.getApplicationData('track').documents.indexOf(item);
                self.removeTrackingDocument(key);
                generalHelpers.showToast("Document deleted successfully", true);
                }else{
                generalHelpers.showToast(response.message, false);
                }
                self.deleteIndex = null;
            }).catch(function (err) {
                self.deleteIndex = null;
                self.loading = false;
                generalHelpers.showToast("Something went wrong", false);
            });
        },

        canDeleteDocuments(){
            if(this.userPermissions.edit_application_properties){
                return true;
            }
            return false;
        }

    }
}
</script>

<style scoped>

</style>
