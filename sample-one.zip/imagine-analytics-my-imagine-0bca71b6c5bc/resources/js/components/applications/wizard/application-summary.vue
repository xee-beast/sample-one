<template>

    <div :id="sectionId" class="active">
        <div class="wizard-data">
            <div class="row">
                <div class="col-md-7 accordian-main">
                    <div class="accordion" id="app-details">

                            <application-tracking-summary
                                v-if="applicationData"
                                :application="applicationData"
                            >
                            </application-tracking-summary>
                    </div>
                </div>
                <div class="col-md-5 accordian-main">
                    <application-documents :document-types="documentTypes" :error-list="errorList"/>
                    <!-- Comments -->
                    <div>
                        <h3>Additional Comments</h3>
                        <div>
                            <textarea v-if="applicationData" class="form-control" maxlength="500" id="comments" name="comments" rows="5" placeholder="Comments..." v-model="comments"></textarea>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="wizard-controls">
            <ul class="">
                <li>
                    <a @click="goBack()" class="btn btn-dark prevBtn">
                        <i class="fa-solid fa-arrow-left-long"></i>
                        <span>Previous</span>
                    </a>
                </li>
                <li>

                <a @click="submit()" class="btn btn-primary nextBtn">
                    <i v-if="loading" class="fa fa-spinner fa-spin"></i>
                    <span class="nextBtnText">Submit</span>
                </a>

                </li>
            </ul>
        </div>

    </div>

</template>

<script>
import ApplicationDocuments from "./application-documents";
import {HttpService} from "../../../services/HttpService";
import {useFormStore} from "../../../stores/applicationForm";

export default {
    props: ["step","documentTypes"],
    name: "application-summary",
    components: {
        ApplicationDocuments
    },
    setup(){
        const formStore  = useFormStore();
        const {getApplicationData} = formStore;
        return {getApplicationData};
    },
    data(){
        return {
            request: new HttpService(),
            applicationId: null,
            applicationData: null,
            comments: '',
            statues: null,
            loading: false,
            document_error:null,
            errorList:[]
        }
    },
    async mounted() {
        this.applicationId = await this.getApplicationData('application_number');
        if ( this.applicationId ){
            this.getApplication();
        }
    },
    methods: {
        getApplication() {
            let self = this;
            if(this.loading){
                return;
            }

            this.loading = true;
            return this.request.get(route('application.single.get', this.applicationId))
                .then(function (response) {
                    self.applicationData = response.data
                    self.statues = response.statues
                    self.comments = self.applicationData.comments
                    self.loading = false;
                }).catch(function (err) {
                    self.showToast("Something went wrong", false);
                    self.loading = false;
                });
        },
        submit(){
            this.errorList = [];
            let data = this.getFormData();
            let self = this;
            this.loading = true;

            return this.request.post(route('applications.submit', this.applicationId),data)
                .then(function (response) {
                    self.loading = false;
                    if(response.success)
                        window.location = response.redirect_url;
                    else{
                        self.showToast("Please fix the errors highlighted and try again.", false);
                        self.errorList.push(response.message);
                    }
                }).catch(function (err) {
                    self.loading = false;
                    if(typeof err.data.errors !== 'undefined'){
                        self.parseErrors(err.data.errors);
                    }else{
                        self.showToast("Something went wrong", false);
                    }
                });
        },
        parseErrors(errors){
            let keys = Object.keys(errors);
            for(let i in keys){
                let key = keys[i];
                if(this.errorList.indexOf(errors[key][0]) === -1){
                    this.errorList.push(errors[key][0]);
                }
            }
        },
        getFormData(){
            let documents =  this.getApplicationData('documents');
            let formData = new FormData();
            for(let i in documents){
                let item = documents[i];
                if(typeof item.id !== 'undefined')
                    continue;

                formData.append('document[][file]',item.document);
                formData.append('document[][type]',item.type);
            }
            formData.append('comments', this.comments)
            return  formData;
        },
        showToast(message, isSuccess) {
            new bs5.Toast({
                body: message,
                className: !isSuccess ? 'border-0 bg-danger text-white' : 'border-0 bg-success text-white',
                btnCloseWhite: true,
            }).show();
        },
        goBack() {
            this.$emit("prevStep");
        },
        nextStep() {
            this.$emit("nextStep");
        },
    },
    computed: {
        sectionId() {
            return "step-" + this.step;
        }
    }
}
</script>

<style scoped>

</style>
