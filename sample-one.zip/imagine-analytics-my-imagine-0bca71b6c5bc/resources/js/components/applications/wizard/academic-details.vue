<template>
  <div :id="sectionId" class="active">
    <div class="academic-form personal-form">
      <h3><i class="fa-solid fa-book-open"></i> Academic Details</h3>
      <div class="academic-row">

          <!-- Individual courses tree -->
        <div class="academic-col academic-tree">

            <ul class="nav nav-tabs" id="myTab" role="tablist">
                <li class="nav-item" role="presentation">
                    <button class="nav-link active text-dark" id="indv-tab" data-bs-toggle="tab" data-bs-target="#indv" type="button" role="tab" aria-controls="indv" aria-selected="true">Individual courses</button>
                </li>
                <li class="nav-item" role="presentation">
                    <button class="nav-link text-dark" id="pkg-tab" data-bs-toggle="tab" data-bs-target="#pkg" type="button" role="tab" aria-controls="pkg" aria-selected="false">Packaged courses</button>
                </li>
            </ul>
            <div class="tab-content" id="myTabContent">
                <div class="tab-pane fade show active" id="indv" role="tabpanel" aria-labelledby="indv-tab">
                    <div class="form-group mt-3">
                        <input type="text" class="form-control" v-model="search" placeholder="Search Program" />
                    </div>
                    <div class="tree-outer">
                        <div v-if="locations.length > 0">
                            <div class="expand-all-outer style-2">
                                <a href="javascript:;" class="expandAll"> Expand All </a>
                                <a href="javascript:;" class="collapseAll"> Collapse All </a>
                            </div>
                        </div>
                        <div v-if="locationLoading" class="text-center mt-4">
                            <i class="fa fa-spinner fa-spin fa-2x"></i>
                        </div>
                        <div class="academicTree" v-else-if="locations.length > 0">
                            <!-- <div> -->
                            <section v-for="location in locations" class="item parent">
                                <div class="tree-title">
                                    <i class="fa-solid fa-location-dot"></i> {{location.name}}
                                </div>
                                <section v-for="faculty in location.faculties" class="item parent child">
                                    <div class="tree-title">
                                        <i class="fa-solid fa-map"></i> {{faculty.name}}
                                    </div>
                                    <section v-for="program in faculty.programs"  class="item child">
                                        <div class="tree-title">
                                            <i class="fa-solid fa-bars-progress"></i> {{program.name}} <button @click.prevent="selectProgram(location,faculty,program)" class="btn btn-primary">Add </button>
                                        </div>
                                    </section>
                                </section>
                            </section>

                        </div>
                        <div v-else><p class="text-danger">There are no results for your search</p></div>
                    </div>
                </div>
                <div class="tab-pane fade" id="pkg" role="tabpanel" aria-labelledby="pkg-tab">
                    <!-- Packaged courses tree -->
                    <div class="mt-3">
                        <div class="tree-outer">
                            <div v-if="packagedPrograms.length > 0">
                                <div class="expand-all-outer style-2">
                                    <a href="javascript:;" class="expandPackagedProgramAll"> Expand All </a>
                                    <a href="javascript:;" class="collapsePackagedProgramAll"> Collapse All </a>
                                </div>
                            </div>
                            <div v-if="locationLoading" class="text-center mt-4">
                                <i class="fa fa-spinner fa-spin fa-2x"></i>
                            </div>
                            <div class="packagedProgramTree" v-else-if="packagedPrograms.length > 0">
                                <!-- <div> -->
                                <section v-for="location in packagedPrograms" class="item parent">
                                    <div class="tree-title">
                                        <i class="fa-solid fa-location-dot"></i> {{location.name}}
                                    </div>
                                    <section v-for="packageProgram in location.package_programs" class="item child">
                                        <div class="tree-title">
                                            <i class="fa-solid fa-bars-progress"></i> {{packageProgram.name}} <button @click.prevent="selectPackagedProgram(location, packageProgram)" class="btn btn-primary"> <i v-if="(selectedPackageProgram == packageProgram && packageLoading)" class="fa fa-spinner fa-spin"></i> Add </button>
                                        </div>
                                    </section>
                                </section>
                            </div>
                            <div v-else><p class="text-danger text-center">There are no items to display</p></div>
                        </div>
                    </div>
                </div>
                </div>
            </div>

        <program-summary />

      </div>
    </div>

    <div class="wizard-controls">
      <ul class="">
        <li>
          <a @click="goBack()" class="btn btn-dark prevBtn">
            <i class="fa-solid fa-arrow-left-long"></i>
            <span>Previous</span>
          </a>
        </li>
        <li>
            <a @click="submitProgramData()" class="btn btn-primary nextBtn">
                <span class="nextBtnText">Next </span>
                <i v-if="loading" class="fa fa-spinner fa-spin"></i>
                <i v-else class="fa-solid fa-arrow-right-long"></i>
            </a>
        </li>
      </ul>
    </div>
      <!-- Individual program -->
    <div class="modal fade" id="programModal" tabindex="-1" role="dialog" aria-labelledby="programModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="programModalLabel">{{selectedProgramName}}</h5>
                </div>
                <div class="modal-body">
                <form v-if="selectedProgram">
                    <div class="form-group">
                        <div  class="form-group">
                            <label class="form-label">Start Date<span class="required">*</span></label>
                            <v-select  label="start_date" v-model="form.start_date" :options="dates"  placeholder="-- Please Select --" >
                                <template #option="{  start_date }">
                                    {{ dateFormat(start_date) }}
                                </template>
                                <template #selected-option="{ start_date }">
                                        {{ dateFormat(start_date) }}
                                </template>
                                <template #no-options="{ search, searching, loading }">
                                    <span>No options available</span>
                                </template>
                            </v-select>
                            <p class="text-danger" v-if="errors.start_date">{{ errors.start_date }}</p>
                        </div>
                      </div>
                    <div v-if="form.start_date !== null">
                      <div class="form-group">
                          <label for="message-text" class="col-form-label">Length (weeks)<span class="required">*</span></label>
                          <v-select label="label" v-model="form.length" :options="getLengthList()" :reduce="option => option.value"   placeholder="-- Please Select --" >
                              <template #no-options="{ search, searching, loading }">
                                  <span>No options available</span>
                              </template>
                          </v-select>
                          <p class="text-danger" v-if="errors.length">{{ errors.length }}</p>
                      </div>
                      <div class="form-group">
                          <label class="col-form-label">End Date</label>
                          <i class="fa fa-spinner fa-spin" v-if="loading" style="position: absolute;right: 30px;margin-top: 43px;"></i>
                          <input  disabled type="text" class="form-control" :value="form.end_date">
                      </div>
                      <div class="form-group" v-if="programServices.length>0">

                        <div class="col-12">
                          <div class="academic-form personal-form">
                              <h3>Services and Add-ons</h3>
                              <div class="form-group"  v-for="service in programServices">
                                <div class="form-group form-check form-switch">
                                  <input type="hidden" :name="service.name" value="0">
                                  <input
                                      class="form-check-input"
                                      type="checkbox"
                                      name="service" :id="service.name"
                                      @change="selectService(service)"
                                  >
                                  <label class="form-check-label pe-2" :for="service.name">{{service.name}}</label>
                                </div>
                              </div>
                              <p class="text-danger" v-if="errors.service">{{ errors.service }}</p>
                          </div>
                      </div>

                      </div>

                    </div>
                </form>
                </div>
                <div class="modal-footer">
                <button type="button" class="btn btn-outline-secondary" @click="closeModal()">Close</button>
                <button type="button" class="btn btn-primary application-modal-btn" :disabled="loading" @click.prevent="addProgramToList"> Save</button>
                </div>
            </div>
        </div>
    </div>

      <!-- Packaged program -->
  <div class="modal fade" id="packagedProgramModal" tabindex="-1" role="dialog" aria-labelledby="packagedProgramModalLabel" aria-hidden="true">
      <div class="modal-dialog modal-lg">
          <div class="modal-content">
              <div class="modal-header">
                  <h5 class="modal-title" id="packagedProgramModalLabel">{{selectedPackagedProgramName}}</h5>
              </div>
              <div class="modal-body">
                  <div v-if="selectedPackageProgram">
                      <p class="text-danger" v-if="general_error">{{ general_error }}</p>
                      <div v-for="(program, index) in packagePrograms">
                          <i>Course {{index+1}}</i>
                          <input  disabled type="text" class="form-control" :value="program.name">

                          <div class="form-group row mb-0 mt-3">
                              <div class="col-4">
                                  <label class="form-label pkg-program-modal-label">Start Date<span class="required">*</span></label>
                              </div>
                              <div v-if="packagePrograms[index]['selected_start_date']" class="pkg-program-modal-label col-4">
                                  <label for="form-label">Length (weeks)<span class="required">*</span></label>
                              </div>
                              <div v-if="packagePrograms[index]['selected_start_date']" class="pkg-program-modal-label col-4">
                                  <i class="fa fa-spinner fa-spin" v-if="packagePrograms[index]['loading_end_date']" style="position: absolute;right: 30px;margin-top: 43px;"></i>
                                  <label for="form-label">End Date<span class="required">*</span></label>
                              </div>
                          </div>

                          <div class="form-group row">
                              <div class="col-4">
                                  <v-select  label="start_date" v-model="packagePrograms[index].selected_start_date" :options="program.dates" :reduce="option => option.start_date"  placeholder="-- Please Select --" >
                                      <template #option="{  start_date }">
                                          {{ dateFormat(start_date) }}
                                      </template>
                                      <template #selected-option="{ start_date }">
                                          {{ dateFormat(start_date) }}
                                      </template>
                                      <template #no-options="{ search, searching, loading }">
                                          <span>No options available</span>
                                      </template>
                                  </v-select>
                                  <p class="text-danger" v-if="packagePrograms[index].selected_start_date_error">{{ packagePrograms[index].selected_start_date_error }}</p>
                              </div>

                              <div v-if="packagePrograms[index]['selected_start_date']" class="col-4">
                                  <v-select label="label" v-model="packagePrograms[index].selected_length" :options="getPackagedProgramLengthList(program)" :reduce="option => option.value"   placeholder="-- Please Select --" >
                                      <template #no-options="{ search, searching, loading }">
                                          <span>No options available</span>
                                      </template>
                                  </v-select>
                                  <p class="text-danger" v-if="packagePrograms[index].selected_length_error">{{ packagePrograms[index].selected_length_error }}</p>
                              </div>

                              <div v-if="packagePrograms[index]['selected_start_date']" class="col-4">
                                  <input  disabled type="text" class="form-control" :value="packagePrograms[index].selected_end_date">
                                  <p class="text-danger" v-if="packagePrograms[index].selected_end_date_error">{{ packagePrograms[index].selected_end_date_error }}</p>
                              </div>
                          </div>
                          <hr class="mt-3">
                      </div>
                  </div>
              </div>
              <div class="modal-footer">
                  <button type="button" class="btn btn-outline-secondary" @click="closePackagedProgramModal()">Close</button>
                  <button type="button" class="btn btn-primary application-modal-btn" :disabled="loading" @click.prevent="addPackagedProgramsToList()"> Save</button>
              </div>
          </div>
      </div>
  </div>
  </div>
</template>

<script>
  import vSelect from "vue-select";
  import moment from 'moment';
  import {HttpService} from "../../../services/HttpService";
  import { useFormStore } from '../../../stores/applicationForm';
  import ProgramSummary from "./program-summary";
  import generalHelpers from "../../../helpers/generalHelpers";
export default {

  name: "academic-details",
  setup(){
      const formStore  = useFormStore();
      const {resetApplicationState, addApplicationData, getApplicationData, getCombinedProgramArray} = formStore;
      return {resetApplicationState, addApplicationData, getApplicationData, getCombinedProgramArray};
  },

  components: {
      vSelect,
      ProgramSummary
  },
  props: ["step"],
  data() {
    return {
      loading: false,
      packageLoading: false,
      locationLoading: false,
      request: new HttpService(),
      locations:[],
      packagePrograms: [],
      selectedPackagePrograms: [],
      selectedPackageProgram: null,
      packagedPrograms:[],
      selectedProgram:null,
      selectedFaculty:null,
      general_error:null,
      selectedLocation:null,
      typingTimer:null,
      programServices:[],
      dates:[],
      search:'',
      errors:{
        start_date:'',
        length:'',
        end_date:'',
        service:'',
      },
      form:{
          start_date:null,
          length:null,
          end_date:null,
          services:[]

      },
      format:'DD/MM/YYYY'
    };
  },

  mounted() {
      this.loadFaculties();
      this.loadPackagedPrograms();
      let self = this;
      $('#programModal').on('hidden.bs.modal', function (e) {
        self.clearModal();
      });
  },
  methods: {
      goBack() {
        this.$emit("prevStep");
      },
      selectService(service){
        let index = this.form.services.findIndex(item => item.id === service.id);
        if (index !== -1) {
            this.form.services.splice(index, 1);
        }else{
          this.form.services.push(service);
        }
      },
      dateFormat(date){
          return moment(date).format(this.format);
      },

      AreProgramsEmpty(){
          let programs = this.getApplicationData('programs');
          return programs.length === 0;
      },

      getLengthList(){
        let list = [];
        let min = 0;
        let max = 0;
        if(this.selectedProgram){
          if(this.selectedProgram.length_restriction_enabled === 1 && this.selectedProgram.min_length === this.selectedProgram.max_length){
              min = this.selectedProgram.min_length;
              max = this.selectedProgram.max_length;
          } else if(this.selectedProgram.length_restriction_enabled === 1 && this.selectedProgram.min_length != this.selectedProgram.max_length){
              min = this.selectedProgram.min_length;
              max = this.selectedProgram.max_length;
          } else if(this.selectedProgram.length_restriction_enabled === 0 && this.form.start_date && this.form.start_date.weeks!=null){
              min = this.form.start_date.weeks;
              max = this.form.start_date.weeks;
          }
          else {
            let detail = this.getApplicationData('personal_details');
            let visaDetail = detail.personalDetail.visa_applying_for;
            min = 1
            max = visaDetail.max_weeks;
          }

          for(let i =min; i<= max; i++ ){
            list.push({
              label:i,
              value:i
            });
           }
        }
          return list;
      },
      getPackagedProgramLengthList(program){
        let list = [];
        let min = 0;
        let max = 0;
        if(program){
          if(program.length_restriction_enabled === 1 && program.min_length === program.max_length){
              min = program.min_length;
              max = program.max_length;
          } else if(program.length_restriction_enabled === 1 && program.min_length != program.max_length){
              min = program.min_length;
              max = program.max_length;
          } else if(program.length_restriction_enabled === 0 && this.form.start_date && this.form.start_date.weeks!=null){
              min = this.form.start_date.weeks;
              max = this.form.start_date.weeks;
          }
          else {
            let detail = this.getApplicationData('personal_details');
            let visaDetail = detail.personalDetail.visa_applying_for;
            min = 1
            max = visaDetail.max_weeks;
          }

          for(let i =min; i<= max; i++ ){
            list.push({
              label:i,
              value:i
            });
           }
        }
          return list;
      },
      selectProgram(location,faculty,program){
          this.selectedProgram = program;
          this.selectedFaculty = faculty;
          this.selectedLocation = location;
          this.programServices = this.selectedProgram.optional_services;
          this.loadStartDates();
          $('#programModal').modal('show');
      },
      async selectPackagedProgram(location, programPackage) {
          this.packageLoading = true
          this.selectedPackageProgram = programPackage;

          let programs = this.getApplicationData('programs')
          for( const program of programs){
              if(program.package && (program.package.id == this.selectedPackageProgram.id)){
                  generalHelpers.showToast('This packaged course is already in the application. Remove it to add it again.', false);
                  this.packageLoading = false
                  return false;
              }
          }

          this.packagePrograms = [];
          for (const programElement of programPackage.programs) {
              programElement['dates'] = await this.loadStartDatesForPackagedProgram(programElement);
              programElement['location'] = location;
              this.packagePrograms.push(programElement);
          }
          $('#packagedProgramModal').modal('show');
          this.packageLoading = false
      },
      closePackagedProgramModal(){
          this.general_error = null;
          for (const location of this.packagedPrograms) {
              if (location.package_programs) {
                  for (const packageProgram of location.package_programs) {
                      for (const program of packageProgram.programs) {
                          program.selected_start_date = null;
                          program.selected_length = null;
                          program.selected_end_date = null;
                          program.selected_start_date_error = null;
                          program.selected_length_error = null;
                          program.selected_end_date_error = null;
                      }
                  }
              }
          }
          $('#packagedProgramModal').modal('hide');
      },
      closeModal(){
          this.clearModal();
          $('#programModal').modal('hide');
      },
      loadFaculties(){
          let self = this;
          let application = this.getApplicationData();
          this.locationLoading = true;
          return this.request.get(route('applications.programs',application.applicationId),{search:this.search})
          .then(function (response) {

              if(response.success){
                  self.locations = response.data;
                  if(self.search){
                    setTimeout(()=> $('.expandAll').click(), self.locationLoading = false, 500)
                  } else {
                    self.locationLoading = false
                  }
              }
          }).catch(function (err) {
              self.locationLoading = false;
              if(err.status == 500){
                  generalHelpers.showToast("Something went wrong", false);
              }
          });
      },
      loadPackagedPrograms(){
          let self = this;
          let application = this.getApplicationData();
          this.locationLoading = true;
          return this.request.get(route('applications.packaged.programs',application.applicationId))
          .then(function (response) {

              if(response.success){
                  self.packagedPrograms = response.data;
              }
          }).catch(function (err) {
              self.locationLoading = false;
              if(err.status == 500){
                  generalHelpers.showToast("Something went wrong", false);
              }
          });
      },
      loadStartDates(){
          let self = this;
          let url = route('applications.program.get-calendar-dates',this.selectedProgram.id);
          this.request.get(url,{faculty_id:this.selectedFaculty.id}).then(function (response) {
              if(response.success){
                  self.dates = response.dates;
              }
          }).catch(function (err) {
              self.locationLoading = false;
              if(err.status == 500){
                  generalHelpers.showToast("Something went wrong", false);
              }
          });
      },
      async loadStartDatesForPackagedProgram(program) {
          let self = this;
          let dates = [];
          let url = route('applications.program.get-calendar-dates', program.id);
          await this.request.get(url, {faculty_id: program.pivot.faculty_id}).then(function (response) {
              if (response.success) {
                  dates = response.dates;
              }
          }).catch(function (err) {
              self.locationLoading = false;
              if(err.status == 500){
                  generalHelpers.showToast("Something went wrong", false);
              }
          });

          return dates;
      },
      nextStep() {
          this.$emit("nextStep");
      },
      calculateEndDate(){
          let self = this;
          this.form.end_date = null;
          if(this.form.start_date === null || (this.form.length === null || this.form.length === ''))
              return;

          let url = route('applications.calculate-end-date');

          this.loading = true;
          this.request.get(url,{program_id:this.selectedProgram.id,faculty_id:this.selectedFaculty.ebecas_id, start_date:this.form.start_date.start_date,length: this.form.length }).then(function (response) {
              if(response.success){
                  self.form.end_date = response.data.formattedDate;
              }
              self.loading = false;
          }).catch(function (err) {
              self.loading = false;
              if(err.status == 500){
                  generalHelpers.showToast("Something went wrong", false);
              }
          });
      },
      clearModal(){
          this.form.start_date =null;
          this.form.length = null;
          this.form.end_date = null;
          this.selectedProgram = null;
          this.selectedFaculty = null;
          this.selectedLocation = null;
          this.programServices = [];
          this.form.services=[];
          this.form.dates = [];
      },

      clearErrors(){
        this.errors.start_date = '';
        this.errors.length = '';
        this.errors.end_date = '';
        this.errors.service='';
      },

      async isValidProgram() {
          this.clearErrors();
          let isValid = true;

          if (this.form.start_date === null) {
              isValid = false;
              this.errors.start_date = "Please select the start date";
          }

          if (this.form.length === null) {
              isValid = false;
              this.errors.length = "Please select the length";
          }

          if (this.form.end_date === null) {
              isValid = false;
              this.errors.end_date = "The end date needs a valid length and start date to be calculated";
          }

          if (await this.checkProgramOverlap()) {
              isValid = false;
              this.errors.start_date = "These dates are overlapping with other programs";
          }

          if (await this.checkCoursesDuration()) {
              isValid = false;
              this.errors.length = "This length exceeds the time allowed by the selected visa";
          }

          if (await this.checkCourseBreak()) {
              isValid = false;
              this.errors.start_date = "These dates will create a break with other courses longer than the maximum allowed: 8 weeks";
          }

          return isValid;
      },

      async checkCourseBreak(){
         let check = false;
          let testObj = {start_date: this.form.start_date.start_date, end_date:moment(this.form.end_date,this.format).format('YYYY-MM-DD')};

        let programList = [...this.getApplicationData('programs')];
        if (programList.length === 0) {
                return false;
        }

          let lastIndvProgram = programList[programList.length - 1];

         if (lastIndvProgram) {
             let end1 = moment(lastIndvProgram.end_date);
             end1.add(3, 'days');
             let start2 = moment(testObj.start_date);
             let weeks = start2.diff(end1, 'weeks');
             if (weeks > 8) {
                 check = true;
             }
         }

        return check;
      },
      async checkCourseBreakBetweenPackage(){
         let check = false;
         let firstPkg =  this.packagePrograms[0]
          let testObj = {start_date: firstPkg.selected_start_date, end_date:moment(firstPkg.selected_end_date,this.format).format('YYYY-MM-DD')};

        let programList = [...this.getApplicationData('programs')];
        if (programList.length === 0) {
                return false;
        }

          let lastIndvProgram = programList[programList.length - 1];

         if (lastIndvProgram) {
             let end1 = moment(lastIndvProgram.end_date);
             end1.add(3, 'days');
             let start2 = moment(testObj.start_date);
             let weeks = start2.diff(end1, 'weeks');
             if (weeks > 8) {
                 check = true;
             }
         }

        return check;
      },
      async checkProgramOverlap(type='individual') {
          let check = false;
          let programList = [...this.getApplicationData('programs')];
          if(programList.length===0){
              return false;
          }

          let testObj = {};
          if(type==='individual'){
            testObj = {start_date: this.form.start_date.start_date, end_date:moment(this.form.end_date,this.format).format('YYYY-MM-DD')};
          } else {
            let length = this.packagePrograms.length;
            testObj = {start_date: this.packagePrograms[0].selected_start_date, end_date:moment(this.packagePrograms[length-1].selected_end_date,this.format).format('YYYY-MM-DD')};
          }

          let finalArr = this.getCombinedProgramArray(programList);
          finalArr.push(testObj);
          programList = this.sortArray(finalArr);

          for(let i=0; i<programList.length - 1; i++){
              let start2 = moment(programList[i+1].start_date);
              let start1 = moment(programList[i].start_date);
              let end1 = moment(programList[i].end_date);
              if(start2.isSameOrAfter(start1) && start2.isSameOrBefore(end1)){
                  check = true;
              }
          }
          return check;

      },

      async checkIndividualProgramOverlap(program){
          let check = false;
          let programList = [...await generalHelpers.getProgramByType(this.getApplicationData('programs'), 'individual')];
          if(programList.length===0){
            return false;
          }

          let testObj = {start_date: program.selected_start_date, end_date:moment(program.selected_end_date,this.format).format('YYYY-MM-DD')};
          programList.push(testObj);
          programList = this.sortArray(programList);
          for(let i=0; i<programList.length - 1; i++){
            let start2 = moment(programList[i+1].start_date);
            let start1 = moment(programList[i].start_date);
            let end1 = moment(programList[i].end_date);
            if(start2.isSameOrAfter(start1) && start2.isSameOrBefore(end1)){
              check = true;
            }
          }
          return check;
      },
      async checkPackagedProgramOverlap(program){
          let check = false;
          // checking with the current open modal programs
          for (const programObj of this.packagePrograms) {
              if (programObj.id != program.id){
                  let start1 = moment(program.selected_start_date, ['DD/MM/YYYY', 'YYYY/MM/DD']);
                  let end1 = moment(program.selected_end_date, ['DD/MM/YYYY', 'YYYY/MM/DD']);
                  let start2 = moment(programObj.selected_start_date, ['DD/MM/YYYY', 'YYYY/MM/DD']);
                  if(start2.isSameOrAfter(start1) && start2.isSameOrBefore(end1)){
                      check = true;
                  }
              }
          }

          let programList = [...await generalHelpers.getProgramByType(this.getApplicationData('programs'), 'package')];
          if(programList.length===0){
            return check;
          }
          for (let listProgram of programList) {
              listProgram = this.sortArray(programList);
              for (let i = 0; i < listProgram.length; i++) {
                  let start2 = moment(program.selected_start_date, ['DD/MM/YYYY', 'YYYY/MM/DD']);
                  let start1 = moment(listProgram[i].start_date, ['DD/MM/YYYY', 'YYYY/MM/DD']);
                  let end1 = moment(listProgram[i].end_date, ['DD/MM/YYYY', 'YYYY/MM/DD']);
                  if (start2.isSameOrAfter(start1) && start2.isSameOrBefore(end1)) {
                      check = true;
                  }
              }
          }
          return check;
      },
      async checkIndividualCourseBreak(){
          let check = false;
          let programList = [...await generalHelpers.getProgramByType(this.getApplicationData('programs'), 'individual')];
          if(programList.length===0){
              return false;
          }

          const packageFirst = this.packagePrograms[0];
          const indvProgramLast = programList[programList.length - 1]

          let end1 = moment(indvProgramLast.end_date, ['DD/MM/YYYY', 'YYYY/MM/DD']);
          end1.add(3,'days');
          let start2 = moment(packageFirst.selected_start_date, ['DD/MM/YYYY', 'YYYY/MM/DD']);
          let weeks = start2.diff(end1,'weeks');
          if(weeks > 8){
              check = true;
          }
          return check;
      },
      checkPackageCourseBreak(program, key){
          let check = false;

          if (this.packagePrograms[parseInt(key-1)] !== undefined) {
              let gapLimit = this.selectedPackageProgram.gap_limit;
              let startDate = moment(program.selected_start_date, ['DD/MM/YYYY', 'YYYY/MM/DD']);
              let endDate = moment(this.packagePrograms[parseInt(key-1)].selected_end_date, ['DD/MM/YYYY', 'YYYY/MM/DD']);

              let weeks = startDate.diff(endDate, 'weeks');
              if (weeks > gapLimit){
                  check = true;
              }
          }

          return check;
      },
      async checkIndividualCoursesDuration(program){
          let check = false;
          let programList = await generalHelpers.getProgramByType(this.getApplicationData('programs'), 'individual');
          let programLength = programList.reduce((accumulator, object) => {
              return accumulator + object.length;
          }, 0);
          programLength = programLength + program.selected_length;
          let personalDetail = this.getApplicationData('personal_details');
          let visaWeeks = personalDetail.hasOwnProperty('visa_applying_for') ?  personalDetail.visa_applying_for.max_weeks : 0;

          if(programLength > visaWeeks)
              check = true;

          return check;
      },
      async checkPackagedCoursesDuration(program){
          let check = false;

          let personalDetail = this.getApplicationData('personal_details');
          let visaWeeks = personalDetail.hasOwnProperty('visa_applying_for') ?  personalDetail.visa_applying_for.max_weeks : 0;

          let programLength = parseInt(program.selected_length);
          for (const programObj of this.packagePrograms) {
              programLength += programObj.selected_length;
          }

          if(programLength > visaWeeks) {
              check = true;
          }

          let programList = [...await generalHelpers.getProgramByType(this.getApplicationData('programs'), 'package')];
          if(programList.length===0){
              return check;
          }
          for (let listProgram of programList) {
              programLength += listProgram.length;
          }

          if(programLength > visaWeeks) {
              check = true;
          }

          return check;
      },

      async checkCoursesDuration(){
        let check = false;
        let programList = await generalHelpers.getProgramByType(this.getApplicationData('programs'), 'individual');
        let programLength = programList.reduce((accumulator, object) => {
                    return accumulator + object.length;
                  }, 0);
        programLength = programLength + this.form.length;
        let personalDetail = this.getApplicationData('personal_details');
        let visaWeeks = personalDetail.hasOwnProperty('visa_applying_for') ?  personalDetail.visa_applying_for.max_weeks : 0;

        // getting lengths from packaged programs
          let packagedProgramList = [...await generalHelpers.getProgramByType(this.getApplicationData('programs'), 'package')];
          if(packagedProgramList.length===0){
              check = false;
          }

          for (const packagedProgram of packagedProgramList) {
                  programLength+= packagedProgram.length;
          }

        if(programLength > visaWeeks)
          check = true;

        return check;
      },

      sortArray(list){
          let sortedArray = list.sort((a, b) => {
              if (Date.parse(a.start_date) > Date.parse(b.start_date)) {
                  return 1
              } else if (Date.parse(a.start_date) < Date.parse(b.start_date)) {
                  return -1
              } else {
                  return 0
              }
          });
          return sortedArray;
      },
      sortPackageArray(list){
          let sortedArray = list.sort((a, b) => {
              if (Date.parse(a.selected_start_date) > Date.parse(b.selected_start_date)) {
                  return 1
              } else if (Date.parse(a.selected_start_date) < Date.parse(b.selected_start_date)) {
                  return -1
              } else {
                  return 0
              }
          });
          return sortedArray;
      },
      getFirstProgram(){
        let programs  = this.getApplicationData('programs');
        return programs[0];
      },

      async addPackagedProgramsToList(){

          if(! await this.isValidPackagedProgram()){
              return;
          }

          await this.addPackagedProgramListData();
      },
      async addPackagedProgramListData() {
          let packageProgramData = {};
          let packageDetail = {
              id: this.selectedPackageProgram.id,
              name: this.selectedPackageProgram.name,
          }
          packageProgramData['programs'] = [];
          for (const program of this.packagePrograms) {
              let programFaculty = null;
              for (const faculty of program.faculties){
                  if (faculty.id == program.pivot.faculty_id){
                      programFaculty = faculty
                  }
              }
              let programData = {
                  program: program.name,
                  program_id: program.id,
                  faculty_id: program.pivot.faculty_id,
                  faculty: programFaculty?.name,
                  start_date: program.selected_start_date,
                  location: program.location.name,
                  end_date: moment(program.selected_end_date, this.format).format('YYYY-MM-DD'),
                  length: program.selected_length,
                  package: packageDetail
              }
              await this.addApplicationData('programs', programData);
          }
          this.closePackagedProgramModal();
      },
      async isValidPackagedProgram(){
          this.general_error = null;
          let check = true;
          let package_check = true;
          for (const key in this.packagePrograms) {
              let program = this.packagePrograms[key]
              // start date
              program.selected_start_date_error = null;
              if (!program.selected_start_date){
                  program.selected_start_date_error = "Please select the start date";
                  check = false;
              }
              // length
              program.selected_length_error = null;
              if (!program.selected_length){
                  program.selected_length_error = "Please select the length";
                  check = false;
              }
              // end date
              program.selected_end_date_error = null;
              if (!program.selected_end_date){
                  program.selected_end_date_error = "The end date needs a valid length and start date to be calculated";
                  check = false;
              }
              // overlapping with individual programs
              if(await this.checkIndividualProgramOverlap(program)){
                  program.selected_start_date_error = "These dates are overlapping with other programs";
                  check = false;
                  package_check = false;
              }
              // overlapping with packaged programs
              if(await this.checkPackagedProgramOverlap(program)){
                  program.selected_start_date_error = "These dates are overlapping with other programs";
                  check = false;
                  package_check = false;
              }
              // check course duration with individual programs
              if(await this.checkIndividualCoursesDuration(program)){
                  program.selected_start_date_error = "This length exceeds the time allowed by the selected visa";
                  check = false;
              }
              // check course duration with packaged programs
              if(await this.checkPackagedCoursesDuration(program)){
                  program.selected_start_date_error = "This length exceeds the time allowed by the selected visa";
                  check = false;
              }
              // course break defined in the package
              if (this.checkPackageCourseBreak(program, key)){
                  program.selected_start_date_error = "These dates will create a break longer than defined in package";
                  check = false;
              }
          }

          if(package_check){
            if (await this.checkProgramOverlap('package')) {
                check = false;
              this.general_error = "These dates are overlapping within package programs";
            }
          }


          // course break check with individual programs
          if(await this.checkIndividualCourseBreak() || await this.checkCourseBreakBetweenPackage()){
              this.general_error = "These dates will create a break with other courses longer than the maximum allowed: 8 weeks";
              check = false;
          }

          return check;
      },
      async addProgramToList(){
        let self = this;
        if(!await this.isValidProgram()){
          return;
        }
        if(!this.isValidServices()){
          return;
        }

        let firstProgram = this.getFirstProgram();

        if(typeof firstProgram !== 'undefined' && firstProgram.start_date > this.form.start_date.start_date){
          Swal.fire({
                    customClass: {
                        confirmButton: 'btn btn-info text-white px-3',
                        cancelButton: 'btn btn-outline-secondary px-3 mx-3',
                    },
                    buttonsStyling: false,
                    reverseButtons: true,
                    title: 'You are about to add a new first course...',
                    text: "If you have already selected accommodation or airport transfer items, you will need to add them again.",
                    icon: 'warning',
                    showCancelButton: true,
                }).then((result) => {
                    if (result.isConfirmed) {
                      self.addListData();
                    }
                });
        }else{
          this.addListData();
        }
      },

      addListData(){
        let programData = {
          program : this.selectedProgram.name,
          program_id: this.selectedProgram.id,
          location:this.selectedLocation.name,
          faculty_ebecas_id: this.selectedFaculty.ebecas_id,
          faculty_id: this.selectedFaculty.id,
          faculty: this.selectedFaculty.name,
          start_date:this.form.start_date.start_date,// this.dateFormat(this.form.start_date.start_date),
          end_date:moment(this.form.end_date,this.format).format('YYYY-MM-DD'),
          length:this.form.length,
          package: false
        }
        this.addApplicationData('programs',programData);
        for(let i in this.form.services){
          this.addApplicationData('program_services',{
                program_id: this.selectedProgram.id,
                faculty_ebecas_id: this.selectedFaculty.ebecas_id,
                faculty_id: this.selectedFaculty.id,
                name:this.form.services[i].name,
                program:this.selectedProgram.name,
                service_id:this.form.services[i].id,
                service:this.form.services[i].name,
                mandatory:this.form.services[i].pivot.mandatory,
                type:this.form.services[i].type,
                program_start_date:this.form.start_date.start_date,
            });
        }
        this.closeModal();
      },

      isValidServices(){
        let self = this;
        this.clearErrors();
        let isValid = true;
        let formServices = this.form.services;
        let servicesList = [...this.getApplicationData('program_services')];
        if(servicesList.length===0){
          return true;
        }

        for(let i=0; i<formServices.length;i++){
          let serviceItem = formServices[i];
          if(serviceItem.type === 'application'){
            let key = servicesList.findIndex(service => service.service_id === serviceItem.id);
            if(key !== -1){
              isValid = false;
              self.errors.service = serviceItem.name+' service already added';
            }
          }

          if(serviceItem.type === 'course'){
            let key = servicesList.findIndex(service => service.service_id === serviceItem.id && service.program_id === serviceItem.pivot.program_id);
            if(key !== -1){
              isValid = false;
              self.errors.service = serviceItem.name+' service cannot repeat in same program..';
            }
          }
          servicesList.push({service_id: serviceItem.id, program_id:serviceItem.pivot.program_id})
        }
        return isValid;
      },

      submitProgramData(){
        if(this.loading){
          return;
        }

        if(this.AreProgramsEmpty()){
          generalHelpers.showToast("Please select at least one program to continue", false);
          return;
        }

        let self = this;
        this.loading = true;
        let application = this.getApplicationData('personal_details');
        let formData = this.getFormData();
        this.request.post(route('applications.program.store', application.application_id), formData)
            .then(function (response) {
                self.loading = false;
                if(response.success){
                    if(response.clearState)
                        self.resetApplicationState(false);
                    self.$emit('nextStep')
                }else{
                    generalHelpers.showToast(response.message,response.success);
                }
            }).catch(function (err) {
            self.loading = false;
            generalHelpers.showToast('Something went wrong',false);
        });
      },
      getFormData(){
        return {
          programs: this.getApplicationData('programs'),
          services: this.getApplicationData('program_services')
        }
      },
      calculatePackagedProgramEndDate(packageProgram){
          let self = this;
          packageProgram.selected_end_date = null;
          if(packageProgram.selected_start_date === null || (packageProgram.selected_length === null || packageProgram.selected_length === ''))
              return;

          let url = route('applications.calculate-end-date');
          let facultyId = null
          for (const packageProgramElement of packageProgram.faculties) {
              if (packageProgramElement.location_id === packageProgram.location.id){
                  facultyId = packageProgramElement.ebecas_id;
              }
          }

          packageProgram.loading_end_date = true;
          this.request.get(url,{program_id:packageProgram.id,faculty_id:facultyId, start_date:packageProgram.selected_start_date,length: packageProgram.selected_length }).then(function (response) {
              if(response.success){
                  packageProgram.selected_end_date = response.data.formattedDate;
                  packageProgram.selected_end_date_error = null;
                  packageProgram.selected_start_date_error = null;
                  packageProgram.selected_length_error = null;
                  packageProgram.selected_faculty_id = facultyId;
              }
              packageProgram.loading_end_date = false;
          }).catch(function (err) {
              packageProgram.loading_end_date = false;
              if(err.status == 500){
                  generalHelpers.showToast("Something went wrong", false);
              }
          });
      },
      resetPackageProgramByKey(key){
          this.packagePrograms[key].selected_start_date = null;
          this.packagePrograms[key].selected_end_date = null;
          this.packagePrograms[key].selected_length = null;
          this.packagePrograms[key].selected_start_date_errors = null;
          this.packagePrograms[key].selected_end_date_errors = null;
          this.packagePrograms[key].selected_lenght_errors = null;
      }
  },
    computed: {
        sectionId() {
            return "step-" + this.step;
        },
        selectedProgramName(){
            if(this.selectedProgram){
                return this.selectedProgram.name;
            }
            return '';
        },
        selectedPackagedProgramName(){
            if(this.selectedPackageProgram){
                return this.selectedPackageProgram.name;
            }
            return '';
        },
        services(){
            return this.getApplicationData('program_services');
        },
        // used to capture the change in program array start_date
        selectedPackagedProgramStartDate() {
            var rec = [];
            var id = this.packagePrograms.map(form => rec[form.id]=form.selected_start_date);
            return rec;
        },
        // used to capture the change in program array length
        selectedPackagedProgramLength() {
            var rec = [];
            var id = this.packagePrograms.map(form => rec[form.id]=form.selected_length);
            return rec;
        }
    },
  watch: {
      selectedPackagedProgramStartDate(newValue, oldValue) {
          for (const programId in newValue) {
              if (newValue[programId]){
                  for (const packageProgram of this.packagePrograms) {
                      if(packageProgram.id == programId && (newValue[programId] !== oldValue[programId])){
                          packageProgram.selected_length = null;
                          packageProgram.selected_end_date = null;
                      }
                  }
              }
          }

          // getting the key of updated programs
          let keyChanged = null
          for (const programId in newValue) {
             if(newValue[programId] != oldValue[programId]){
                 for (const packagedProgramKey in this.packagePrograms) {
                     if (programId == this.packagePrograms[packagedProgramKey].id){
                         keyChanged = packagedProgramKey;
                     }
                 }
             }
          }
          // resetting the form ahead
          if (keyChanged){
              for (const packagedProgramKey in this.packagePrograms) {
                  if(packagedProgramKey > keyChanged){
                      this.resetPackageProgramByKey(packagedProgramKey);
                  }
              }
          }

      },
      selectedPackagedProgramLength(newValue, oldValue) {
          for (const programId in newValue) {
              if (newValue[programId]){
                  for (const packageProgram of this.packagePrograms) {
                      if(packageProgram.id == programId && (newValue[programId] !== oldValue[programId])){
                          this.calculatePackagedProgramEndDate(packageProgram)
                      }
                  }
              }
          }

          // getting the key of updated programs
          let keyChanged = null
          for (const programId in newValue) {
              if(newValue[programId] != oldValue[programId]){
                  for (const packagedProgramKey in this.packagePrograms) {
                      if (programId == this.packagePrograms[packagedProgramKey].id){
                          keyChanged = packagedProgramKey;
                      }
                  }
              }
          }
          // resetting the form ahead
          if (keyChanged){
              for (const packagedProgramKey in this.packagePrograms) {
                  if(packagedProgramKey > keyChanged){
                      this.resetPackageProgramByKey(packagedProgramKey);
                  }
              }
          }
      },
      'form.start_date' : function (value){
          if(value !== null){
              if(this.selectedProgram.length_restriction_enabled === 1 && this.selectedProgram.min_length === this.selectedProgram.max_length){
                this.form.length = this.selectedProgram.max_length;
              }else if(this.selectedProgram.length_restriction_enabled === 0 && (value.weeks !== null && value.weeks !== '')){
                    this.form.length = value.weeks;
              }
              else {
                this.form.length = null;
              }
          }
          this.clearErrors();
          this.calculateEndDate();
      },
      'form.length' : function (value){
          if(value !== null && value !== '')
              this.clearErrors();
              this.calculateEndDate();
      },
      search: function(value){
        clearTimeout(this.typingTimer);
        this.typingTimer = setTimeout(()=> this.loadFaculties(), 500);
      }
  }
};
</script>
