<template>
  <div :id="sectionId" class="active">
    <div class="academic-form personal-form">
      <h3><i class="fa-solid fa-book-open"></i> Accommodation Details</h3>
      <div class="academic-row">
        <div class="academic-col academic-tree">
          <div class="form-group d-none">
            <label class="form-label">First Name<span class="required">*</span></label>
            <input type="text" class="form-control" placeholder="First Name" />
          </div>
          <div class="tree-outer">
            <div class="">
              <div class="expand-all-outer style-2">
                <a href="javascript:;" class="expandAll"> Expand All </a>
                <a href="javascript:;" class="collapseAll"> Collapse All </a>
              </div>
            </div>
            <div class="academicTree">
              <!-- First Tree -->
              <section v-for="category in accommodations" class="item parent">
                <div class="tree-title">
                  <i class="fa-solid fa-location-dot"></i> {{category.name}}
                </div>
                <section v-for="accommodation in category.accommodations" class="item child">
                  <div class="tree-title">
                    <i class="fa-solid fa-bars-progress"></i> {{accommodation.name}} <button
                      @click.prevent="selectAccommodation(category,accommodation)" class="btn btn-primary">Add </button>
                  </div>
                </section>
              </section>

              <!-- Second Tree -->
            </div>
          </div>
        </div>

        <accommodation-summary />

      </div>
    </div>

    <div class="wizard-controls">
      <ul class="">
        <li>
          <a @click="goBack()" class="btn btn-dark prevBtn">
            <i class="fa-solid fa-arrow-left-long"></i>
            <span>Previous</span>
          </a>
        </li>
        <li>
          <a @click="submitAccommodationData()" class="btn btn-primary nextBtn">
                <span class="nextBtnText">Next </span>
                <i v-if="loading" class="fa fa-spinner fa-spin"></i>
                <i v-else class="fa-solid fa-arrow-right-long"></i>
            </a>
        </li>
      </ul>
    </div>
    <div class="modal fade" id="accommodationModal" tabindex="-1" role="dialog"
      aria-labelledby="accommodationModalLabel" aria-hidden="true">
      <div class="modal-dialog modal-lg">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title" id="accommodationModalLabel">{{selectedAccommodationName}}</h5>
          </div>
          <div class="modal-body">
            <form v-if="selectedAccommodation">
              <div class="form-group">
                <div class="form-group">
                  <label class="form-label">Start Date<span class="required">*</span></label>

                    <Datepicker utc="preserve" v-model="form.start_date" :minDate="getMinDate()" placeholder="dd/mm/yyyy" :format="format"
                    autoApply :enableTimePicker="false"></Datepicker>

                  <p class="text-danger" v-if="errors.start_date">{{ errors.start_date }}</p>
                </div>
              </div>
              <div class="row" v-if="form.start_date !== null">

                <div class="form-group col-6">
                  <label for="message-text" class="col-form-label">Weeks<span class="required">*</span></label>
                  <v-select label="label" v-model="form.weeks" :options="getWeekOptions()"
                    :reduce="option => option.value" placeholder="-- Please Select --">
                    <template #no-options="{ search, searching, loading }">
                      <span>No options available</span>
                    </template>
                  </v-select>
                </div>
                <div class="form-group col-6">
                  <label for="message-text" class="col-form-label">Days<span class="required">*</span></label>
                  <v-select label="label" v-model="form.days" :options="getDaysOptions()"
                    :reduce="option => option.value" placeholder="-- Please Select --">
                    <template #no-options="{ search, searching, loading }">
                      <span>No options available</span>
                    </template>
                  </v-select>
                </div>
                <div class="form-group">
                  <label class="col-form-label">End Date</label>
                  <i class="fa fa-spinner fa-spin" v-if="loading"
                    style="position: absolute;right: 30px;margin-top: 43px;"></i>
                  <input disabled type="text" class="form-control" :value="form.end_date">
                </div>
                <div class="form-group" v-if="selectedAccommodation.optional_services.length > 0">

                  <div class="col-12">
                    <div class="academic-form personal-form">
                        <h3>Services</h3>
                        <div class="form-group"  v-for="service in selectedAccommodation.optional_services">
                          <div class="form-group form-check form-switch">
                            <input type="hidden" :name="service.name" value="0">
                            <input
                                class="form-check-input"
                                type="checkbox"
                                name="service" :id="service.name"
                                @change="selectService(service)"
                            >
                            <label class="form-check-label pe-2" :for="service.name">{{service.name}}</label>
                          </div>
                        </div>
                        <p class="text-danger" v-if="errors.service">{{ errors.service }}</p>
                    </div>
                  </div>
                </div>

                <div class="form-group" v-if="selectedAccommodation.optional_addons.length > 0">
                  <div class="col-12">
                    <div class="academic-form personal-form">
                        <h3>Add-ons</h3>
                        <div class="form-group"  v-for="addon in selectedAccommodation.optional_addons">
                          <div class="form-group form-check form-switch">
                            <input type="hidden" :name="addon.name" value="0">
                            <input
                                class="form-check-input"
                                type="checkbox"
                                name="addon" :id="addon.name"
                                @change="selectAddon(addon)"
                            >
                            <label class="form-check-label pe-2" :for="addon.name">{{addon.name}}</label>
                          </div>
                        </div>
                        <p class="text-danger" v-if="errors.service">{{ errors.addons }}</p>
                    </div>
                  </div>
                </div>

              </div>
            </form>
          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-outline-secondary" @click="closeModal()">Close</button>
            <button type="button" v-if="showModalBtn" class="btn btn-primary application-modal-btn" :disabled="loading"
              @click.prevent="addAccommodation()"> Save</button>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
  import vSelect from "vue-select";
  import moment from 'moment';
  import { HttpService } from "../../../services/HttpService";
  import { useFormStore } from '../../../stores/applicationForm';
  import '@vuepic/vue-datepicker/dist/main.css'
  import Datepicker from '@vuepic/vue-datepicker';
  import AccommodationSummary from "./accommodation-summary";
  import generalHelpers from "../../../helpers/generalHelpers";

  export default {

    name: "academic-details",
    setup() {
      const formStore = useFormStore();
      const {resetInsurance,addApplicationData, getApplicationData } = formStore;
      return {resetInsurance,addApplicationData, getApplicationData };
    },

    components: {
      vSelect,
      Datepicker,
      AccommodationSummary
    },
    props: ["step"],
    data() {
      return {
        loading: false,
        locationLoading: false,
        request: new HttpService(),
        accommodations: [],
        selectedAccommodation: null,
        selectedCategory: null,
        errors: {
          start_date: '',
          weeks: '',
          days: '',
          end_date: '',
          service:'',
          addons:''

        },
        form: {
          start_date: null,
          weeks: null,
          days: 0,
          end_date: null,
          services:[],
          addons:[],
        },
        format: 'dd/MM/yyyy',
        momentFormat: 'DD/MM/YYYY'
      };
    },

    mounted() {
      this.loadAccommodations();
      let self = this;
      $('#accommodationModal').on('hidden.bs.modal', function (e) {
        self.clearModal();
      });
    },
    computed: {
      sectionId() {
        return "step-" + this.step;
      },

      selectedAccommodationName() {
        if (this.selectedAccommodation) {
          return this.selectedAccommodation.name;
        }
        return '';
      },

      showModalBtn() {
        if (this.form.start_date !== null && this.form.weeks !== null && this.form.days !== null) {
          return true;
        }
        return false;
      }
    },

    methods: {
      getWeekOptions() {
        let list = [];
        let minLength = 1;
        let maxLength = 100;
        if (this.selectedAccommodation !== null && this.selectedAccommodation.length_restriction_enabled === 1) {
          minLength = this.selectedAccommodation.min_length ? this.selectedAccommodation.min_length : minLength;
          maxLength = this.selectedAccommodation.max_length ? this.selectedAccommodation.max_length : maxLength;
        }
        for (let i = minLength; i <= maxLength; i++) {
          list.push({
            label: i,
            value: i
          });
        }
        return list;
      },
      getDaysOptions() {
        let list = [];
        let minLength = 0;
        let maxLength = 6;
        for (let i = minLength; i <= maxLength; i++) {
          list.push({
            label: i,
            value: i
          });
        }
        return list;
      },
      goBack() {
        this.$emit("prevStep");
      },

      dateFormat(date) {
        return moment(date).format(this.format);
      },


      selectAccommodation(category, accommodation) {
        this.selectedCategory = category;
        this.selectedAccommodation = accommodation;
        $('#accommodationModal').modal('show');
      },
      closeModal() {
        this.clearModal();
        $('#accommodationModal').modal('hide');
      },
      loadAccommodations() {
        let self = this;
        let application = this.getApplicationData();
        this.locationLoading = true;
        return this.request.get(route('applications.accommodations', application.applicationId))
          .then(function (response) {
            self.locationLoading = false;
            if (response.success) {
              self.accommodations = response.data;
            }
          }).catch(function (err) {
            self.locationLoading = false;
            if(err.status == 500){
                generalHelpers.showToast("something went wrong", false);
            }
          });
      },

      calculateEndDate() {
        this.form.end_date = null;
        if (this.form.start_date === null || this.form.weeks === null || this.form.days === null) {
          return;
        }
        let date = moment(this.form.start_date);
        let end = date.utc().add(this.form.weeks, 'weeks');
        this.form.end_date = end.add(this.form.days, 'days').format(this.momentFormat);
      },
      sortArray(list){
          let sortedArray = list.sort((a, b) => {
              if (Date.parse(a.start_date) > Date.parse(b.start_date)) {
                  return 1
              } else if (Date.parse(a.start_date) < Date.parse(b.start_date)) {
                  return -1
              } else {
                  return 0
              }
          });
          return sortedArray;
      },

      getMinDate(){
        let program = this.getFirstProgram();
        let start  = moment(program.start_date).subtract(7,'days').format('YYYY-MM-DD');
        if(start < moment().format('YYYY-MM-DD')){
          return new Date();
        }
        return new Date(start);
      },

      getFirstProgram(){
        let programs  = this.getApplicationData('programs');
        return programs[0];
      },

      getFirstAccommodation(){
        let accommodationData  = this.getApplicationData('accommodations');
        if(accommodationData.length > 0){
          return accommodationData[0];
        }
        return null;

      },

      addAccommodation() {
        let self = this;
        if(!this.isValidAccommodation()){
          return ;
        }

        if(!this.isValidServices()){
          return;
        }

        let firstAccommodation = this.getFirstAccommodation();
        if(firstAccommodation!==null){
          if(moment(firstAccommodation.start_date).isSameOrAfter(moment(this.form.start_date))){
              Swal.fire({
                  customClass: {
                      confirmButton: 'btn btn-info text-white px-3',
                      cancelButton: 'btn btn-outline-secondary px-3 mx-3',
                  },
                  buttonsStyling: false,
                  reverseButtons: true,
                  title: 'You are about to update the first accommodation item...',
                  text: "If you have already selected insurance, you will need to add it again.",
                  icon: 'warning',
                  showCancelButton: true,
              }).then((result) => {
                  if (result.isConfirmed) {
                    self.addListData();
                  }
              });
          } else {
            self.addListData();
          }

        }else{
          this.addListData();
        }
      },

      addListData(){
        let firstProgram = this.getFirstProgram();
        let data = {
          accommodation: this.selectedAccommodation.name,
          accommodation_id: this.selectedAccommodation.id,
          accommodation_category: this.selectedCategory.name,
          start_date: moment(this.form.start_date).utc().format('YYYY-MM-DD'),
          end_date: moment(this.form.end_date, this.momentFormat).format('YYYY-MM-DD'),
          days: this.form.days,
          weeks: this.form.weeks,
          faculty_id: firstProgram.faculty_id
        }
        this.addApplicationData('accommodations', data);
        for(let i in this.form.services){
          this.addApplicationData('accommodation_services',{
                accommodation_id: this.selectedAccommodation.id,
                accommodation: this.selectedAccommodation.name,
                service_id:this.form.services[i].id,
                name:this.form.services[i].name,
                type:this.form.services[i].type,
                mandatory:this.form.services[i].pivot.mandatory,
                accommodation_start_date:moment(this.form.start_date).utc().format('YYYY-MM-DD'),
                faculty_id: firstProgram.faculty_id
            });
        }
        for(let i in this.form.addons){
          this.addApplicationData('accommodation_addons',{
                accommodation_id: this.selectedAccommodation.id,
                accommodation: this.selectedAccommodation.name,
                addon_id:this.form.addons[i].id,
                name:this.form.addons[i].name,
                faculty_id: firstProgram.faculty_id,
                mandatory:this.form.addons[i].pivot.mandatory,
                accommodation_start_date:moment(this.form.start_date).utc().format('YYYY-MM-DD')
            });
        }
        this.closeModal();
      },


      submitAccommodationData(){
        if(this.loading){
          return;
        }

        let self = this;
        this.loading = true;
        let application = this.getApplicationData('personal_details');
        let formData = this.getFormData();
        this.request.post(route('applications.accommodation.store', application.application_id), formData)
            .then(function (response) {
                self.loading = false;
                if(response.success){
                    if(response.clearState)
                      self.resetInsurance();
                    self.$emit('nextStep')
                }else{
                    generalHelpers.showToast(response.message,response.success);
                }
            }).catch(function (err) {
            self.loading = false;
            generalHelpers.showToast('Something went wrong',false);
        });
      },
      getFormData(){
        return {
          accommodations: this.getApplicationData('accommodations'),
          services: this.getApplicationData('accommodation_services'),
          addons: this.getApplicationData('accommodation_addons'),
        }
      },

      areAccommodationsEmpty(){
          let accommodations = this.getApplicationData('accommodations');
          return accommodations.length === 0;
      },

      isValidAccommodation(){
        this.clearErrors();
        let isValid = true;

        if(this.form.start_date===null){
          isValid = false;
          this.errors.start_date = "Please select the start date";
        }

        if(this.form.weeks===null){
          isValid = false;
          this.errors.weeks = "Please select the number of weeks";
        }

        if(this.form.end_date===null){
          isValid = false;
          this.errors.end_date = "Please enter valid values for the length";
        }

        if(this.checkAccommodationOverlap()){
            isValid = false;
            this.errors.start_date = "These dates are overlapping with another accommodation";
        }
        return isValid;
      },

      isValidServices(){
        let self = this;
        this.clearErrors();
        let isValid = true;
        let formServices = this.form.services;
        let servicesList = [...this.getApplicationData('accommodation_services')];
        if(servicesList.length===0){
          return true;
        }

        for(let i=0; i<formServices.length;i++){
          let serviceItem = formServices[i];
          if(serviceItem.type === 'application'){
            let key = servicesList.findIndex(service => service.service_id === serviceItem.id);
            if(key !== -1){
              isValid = false;
              self.errors.service = serviceItem.name+' service already added';
            }
          }

          if(serviceItem.type === 'product'){
            let key = servicesList.findIndex(service => service.service_id === serviceItem.id && service.accommodation_id === serviceItem.pivot.accommodation_id);
            if(key !== -1){
              isValid = false;
              self.errors.service = serviceItem.name+' service cannot repeat in same accommodation..';
            }
          }
          servicesList.push({service_id: serviceItem.id, program_id:serviceItem.pivot.program_id})
        }
        return isValid;
      },


      checkAccommodationOverlap(){
          let check = false;
          let accommodationList = [...this.getApplicationData('accommodations')];
          if(accommodationList.length===0){
            return false;
          }

          let testObj = {start_date: moment(this.form.start_date).format('YYYY-MM-DD'), end_date:moment(this.form.end_date,this.momentFormat).format('YYYY-MM-DD')};
          accommodationList.push(testObj);
          accommodationList = this.sortArray(accommodationList);
          for(let i=0; i<accommodationList.length - 1; i++){
            let start2 = moment(accommodationList[i+1].start_date);
            let start1 = moment(accommodationList[i].start_date);
            let end1 = moment(accommodationList[i].end_date);
            if(start2.isSameOrAfter(start1) && start2.isSameOrBefore(end1)){
              check = true;
            }
          }
          return check;
      },

      selectService(service){
        let index = this.form.services.findIndex(item => item.id === service.id);
        if (index !== -1) {
            this.form.services.splice(index, 1);
        }else{
          this.form.services.push(service);
        }
      },
      selectAddon(addon){
        let index = this.form.addons.findIndex(item => item.id === addon.id);
        if (index !== -1) {
            this.form.addons.splice(index, 1);
        }else{
          this.form.addons.push(addon);
        }
      },


      nextStep() {
        this.$emit("nextStep");
      },

      clearModal() {
        this.form.start_date = null;
        this.form.weeks = null;
        this.form.days = 0;
        this.form.end_date = null;
        this.form.services = [];
        this.form.addons = [];
        this.clearErrors();
      },

      clearErrors() {
        this.errors.start_date = '';
        this.errors.weeks = '';
        this.errors.end_date = '';
        this.errors.days = '';
        this.errors.service = '';
        this.errors.addons = '';
      },

    },
    watch: {
      'form.start_date': function (value) {
        this.calculateEndDate();
      },
      'form.weeks': function (value) {
        this.calculateEndDate();
      },
      'form.days': function (value) {
        this.calculateEndDate();
      }
    }
  };
</script>
