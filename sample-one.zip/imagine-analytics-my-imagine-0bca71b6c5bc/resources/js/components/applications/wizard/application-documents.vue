<template>
  <div>
    <h3>Documents</h3>

    <div v-if="documents.length > 0">
        <table  class="table table-bordered">
          <thead>
            <tr>
              <th scope="col">Type</th>
              <th scope="col">Name</th>
            </tr>
          </thead>
          <tbody>
            <tr v-for="(item,key) in documents">
              <td>{{getApplicationType(item)}}</td>
              <td>{{item.name}}    <a href="javascript:;" @click="deleteDocument(item,key)" class="d-block float-end"><i v-if="loading && deleteIndex === key" class="fa fa-spin fa-spinner"></i>  <i v-else class="fa fa-times text-danger" title="Delete document" :disabled="loading && deleteIndex === key" ></i></a></td>
            </tr>
          </tbody>
        </table>
    </div>
    <div v-else>
      <p class="text-center fw-bold mt-2 mb-2">No documents available..</p>
      <br/>
    </div>
    <div v-if="validationErrors">
      <p class="text-danger"  v-for="error in validationErrors"> <i class="fa fa-exclamation-triangle"></i> <small >{{error}}</small></p>
    </div>

    <div class="d-grid gap-2 mb-4">
      <button class="btn btn-outline-secondary" data-bs-toggle="modal" data-bs-target="#documentModal"> <i
          class="fa-solid fa-plus"></i> Add Document</button>
    </div>

    <div class="modal fade" id="documentModal" tabindex="-1" aria-labelledby="documentModalLabel" aria-hidden="true">
      <div class="modal-dialog">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title" id="documentModalLabel">Add Document</h5>
            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
          </div>
          <div class="modal-body">

              <div class="alert alert-primary" role="alert">
                  <b>Allowed file extensions:</b> jpeg, png, jpg, pdf <br>
                  <b>Document size limit:</b> 10 Mb each file
              </div>

            <div class="form-group">
              <label class="form-label">Document Type<span class="required">*</span></label>
              <vSelect label="label" v-model="form.type" :options="documentTypesArray"
                :reduce="option => option.value" placeholder="-- Please Select --">
                <template #no-options="{ search, searching, loading }">
                  <span>No options available</span>
                </template>
              </vSelect>
              <p class="text-danger" v-if="errors.type">{{ errors.type }}</p>
            </div>
            <div class="form-group">
              <label>Choose Document</label>
              <input type="file" ref="document" class="form-control" @change="chooseFile">
              <p class="text-danger" v-if="errors.document">{{ errors.document }}</p>
            </div>
          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
            <button type="button" class="btn btn-primary application-modal-btn" @click="addDocument" :disabled="loading"> <i
                class="fa fa-spinner fa-spin" v-if="loading"></i>  Add</button>
          </div>
        </div>
      </div>
    </div>
  </div>
      <!-- </div> -->
      <!-- </div> -->
</template>
<script>
  import vSelect from "vue-select";

  import moment from "moment";
  import { useFormStore } from "../../../stores/applicationForm";
  import { HttpService } from "../../../services/HttpService";
  import generalHelpers from "../../../helpers/generalHelpers";

  export default {
    name: "application-documents",
    props: ['documentTypes','errorList'],
    setup() {
      const formStore = useFormStore();
      const {
        getApplicationData,
        removeTransportation,
        removeTransportationService,
        removeTransportationAddon,
        clearTransportationState,
        removeDocument,
        addApplicationData,
      } = formStore;
      return {
        getApplicationData,
        removeTransportation,
        removeTransportationService,
        removeTransportationAddon,
        clearTransportationState,
        removeDocument,
        addApplicationData
      };
    },
    components: {
      vSelect
    },
    data() {
      return {
        loading: false,
        deleteIndex:null,
        request: new HttpService(),
        form: {
          type: null,
          name:null,
          document: null,
        },
        errors: {
          type: null,
          document: null,
        },
        validationErrors:[]
      };
    },

    mounted() {
      let self = this;
      $('#documentModal').on('hidden.bs.modal', function (e) {
        self.clearModal();
      });
    },
    computed: {
      documentTypesArray() {
        let keys = Object.keys(this.documentTypes);
        let items = [];
        for (let i in keys) {
          let key = keys[i];
          let item = this.documentTypes[key];
          items.push({
            value: keys[i],
            label: item.label,
          });
        }
        return items;
      },
      documents(){
        return this.getApplicationData('documents');
      }
    },
    methods: {
      getApplicationType(document){
        if ( document.type === 'passport' ){
            return this.documentTypes[document.type]['label'];
        }
        let type  = document.type.replace('_',' ');
        return   type.charAt(0).toUpperCase() + type.slice(1);
      },
      chooseFile(e) {
        if (e.target.files.length > 0){
          this.form.document = e.target.files[0];
          this.form.name = this.form.document.name;
        }
      },
      addDocument() {
        if (!this.validateForm()) {
          return;
        }
        let data = {
          type: this.form.type,
          name:this.form.name,
          document: this.form.document,
        }
        this.addApplicationData('documents', data);
        $('#documentModal').modal('hide');

      },
      deleteDocument(item,index) {
        let self = this;
        Swal.fire({
          customClass: {
            confirmButton: 'btn btn-info text-white px-3',
            cancelButton: 'btn btn-outline-secondary px-3 mx-3',
          },
          buttonsStyling: false,
          reverseButtons: true,
          title: 'Are you sure?',
          text: "You are about to delete this item!",
          icon: 'warning',
          showCancelButton: true,
        }).then((result) => {
          if (result.isConfirmed) {
            if(typeof item.id !== 'undefined'){
              self.deleteDocumentFromS3(item,index);
            }else{
              let key = this.getApplicationData('documents').indexOf(item);
              self.removeDocument(key);
              generalHelpers.showToast("Document Removed", true);
            }
          }
        });
      },

      deleteDocumentFromS3(item,index){
        let self = this;
        this.loading = true;
        this.deleteIndex = index;
        return this.request.delete(route('applications.document.delete', item.id))
        .then(function (response) {
            self.loading = false;
            if(response.success){
              let key = self.getApplicationData('documents').indexOf(item);
              self.removeDocument(key);
              generalHelpers.showToast("Document deleted successfully", true);
            }else{
              generalHelpers.showToast("Something went wrong", false);
            }
            self.deleteIndex = null;
        }).catch(function (err) {
            self.deleteIndex = null;
            self.loading = false;
            generalHelpers.showToast("Something went wrong", false);
            if(err.status == 500){
                generalHelpers.showToast("Something went wrong", false);
            }
        });
      },

      validateForm() {
        let validate = true;
        if (this.form.type === null) {
          validate = false;
          this.errors.type = 'This field is required';
        } else {
          this.errors.type = '';
        }
        if (this.form.document === null) {
          validate = false;
          this.errors.document = 'Please choose a document';
        } else {
          this.errors.document = '';
        }
        return validate;
      },
      clearModal() {
        this.form.document = null;
        this.form.type = null;
        this.errors.document = null;
        this.errors.type = null;
        this.$refs.document.value = null;
      }
    },
    watch: {
      errorList(value){
        this.validationErrors = value;
      }
    }
  };
</script>
