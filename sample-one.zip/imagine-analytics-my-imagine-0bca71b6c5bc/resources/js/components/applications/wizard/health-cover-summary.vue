<template>

        <div class="academic-col academic-items">
            <h3><i class="fa-solid fa-bars-progress"></i> Your Health Cover Summary</h3>
            <div class="products" >
              <div class="product-list" v-if="insurances.length > 0">
                <div class="product-item" v-for="(insurance,key) in insurances">
                  <h6 class="text-capitalize">{{insurance.insurance_name}}</h6>
                  <p class="address">{{insurance.faculty_name}}</p>
                  <p class="dates"><span>{{insurance.start_date}}</span> to <span>{{insurance.end_date}}</span></p>
                  <p class="duration">Policy Length: {{insurance.duration}} month(s)</p>
                  <a href="javascript:;" @click.prevent="removeItem(key)" class="remove-products">
                    <i class="fas fa-times"></i>
                  </a>
                </div>
              </div>
              <div v-else>
                 <p class="text-center mt-3">No items selected</p>
              </div>
            </div>
          </div>

</template>
<script>

    import { useFormStore } from '../../../stores/applicationForm';
    export default {
        name: "health-cover-summary",

        setup(){
            const formStore  = useFormStore();
            const {getApplicationData,removeInsurance } = formStore;
            return {getApplicationData,removeInsurance };
        },

        data() {
            return {
                loading:false,
            };
        },

        mounted() {

        },
        computed :{
            insurances(){
                return this.getApplicationData('insurances');
            }
        },
        methods: {
            removeItem(index){
                let self = this;
                Swal.fire({
                    customClass: {
                        confirmButton: 'btn btn-info text-white px-3',
                        cancelButton: 'btn btn-outline-secondary px-3 mx-3',
                    },
                    buttonsStyling: false,
                    reverseButtons:true,
                    title: 'Are you sure?',
                    text: "You are about to delete this item!",
                    icon: 'warning',
                    showCancelButton: true,
                }).then((result) => {
                    if (result.isConfirmed) {
                        self.removeInsurance(index);
                    }
                });
            }
        }

    }
</script>
