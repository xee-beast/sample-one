<template>
    <div class="academic-col academic-items">
        <!-- accommodation start -->
        <h3><i class="fa-solid fa-bars-progress"></i> Your Accommodations Summary</h3>
        <div class="products">
            <div class="product-list" v-if="accommodations.length > 0">
                <div class="product-item" v-for="(accommodation,key) in accommodations">
                    <h6>{{accommodation.accommodation}}</h6>
                    <p class="address">{{accommodation.accommodation_category}}</p>
                    <p class="dates"><span>{{formattedDate(accommodation.start_date)}}</span> to
                        <span>{{formattedDate(accommodation.end_date)}}</span></p>
                    <p class="duration">{{accommodation.weeks}} week(s) | {{accommodation.days}} day(s)</p>
                    <a href="javascript:;" @click.prevent="removeAccommodation(key,accommodation)"
                        class="remove-product">
                        <i class="fas fa-times"></i>
                    </a>
                    <div class="sub-products" v-if="accommodationServices(accommodation).length > 0">
                        <div class="product-title">Additional Services</div>
                        <div class="product-list">
                            <div class="product-list" v-if="accommodationServices(accommodation).length > 0">
                                <div class="product-item" v-for="(service,key) in accommodationServices(accommodation)">
                                    <h6>{{service.name}}</h6>
                                    <a href="javascript:;" @click.prevent="removeItem(service,'service')"
                                        class="remove-service">
                                        <i class="fas fa-times"></i>
                                    </a>
                                </div>
                            </div>
                            <div v-else>
                                <p class="text-center mt-3">No items selected</p>
                            </div>
                        </div>
                    </div>
                    <div class="sub-products" v-if="addons(accommodation).length > 0">
                        <div class="product-title">Add-ons</div>
                        <div class="product-list">
                            <div class="product-list" v-if="addons(accommodation).length > 0">
                                <div class="product-item" v-for="(addon,key) in addons(accommodation)">
                                    <h6>{{addon.name}}</h6>
                                    <a href="javascript:;" @click.prevent="removeItem(addon,'addon')" class="remove-addon">
                                        <i class="fas fa-times"></i>
                                    </a>
                                </div>
                            </div>
                            <div v-else>
                                <p class="text-center mt-3">No items selected</p>
                            </div>
                        </div>
                    </div>

                    <div v-if="calculateBreak(key,accommodation) !== ''">
                        <hr />
                        <p class="text-center">{{calculateBreak(key,accommodation)}} break</p>
                    </div>
                </div>
            </div>
            <div v-else>
                <p class="text-center mt-3">No items selected</p>
            </div>
        </div>
        <!-- accommodation end -->
        <div class="products" v-if="services.length > 0">
            <div class="product-title">Additional Services</div>
            <div class="product-list">
                <div class="product-list" v-if="services.length > 0">
                    <div class="product-item" v-for="(service,key) in services">
                        <h6>{{service.name}}</h6>
                        <!-- <p class="address">{{service.accommodation}}</p> -->
                        <a href="javascript:;" @click.prevent="removeItem(service,'service')" class="remove-service">
                            <i class="fas fa-times"></i>
                        </a>
                    </div>
                </div>
                <div v-else>
                    <p class="text-center mt-3">No item selected.</p>
                </div>
            </div>
        </div>
    </div>

</template>
<script>

    import moment from 'moment';
    import { useFormStore } from '../../../stores/applicationForm';
    export default {
        name: "accommodation-summary",

        setup() {
            const formStore = useFormStore();
            const { getApplicationData, removeAccommodation, removeAccommodationService, removeAccommodationAddon } = formStore;
            return { getApplicationData, removeAccommodation, removeAccommodationService, removeAccommodationAddon };
        },

        data() {
            return {
                loading: false,
            };
        },

        mounted() {

        },
        computed: {
            accommodations() {
                return this.getApplicationData('accommodations');
            },
            services() {
                let services = this.getApplicationData('accommodation_services');
                let list = services.filter((service) => {
                    return service.type === 'application';
                });
                return list;
            },
        },
        methods: {
            addons(accommodation) {
                let addons =  this.getApplicationData('accommodation_addons');
                let list = addons.filter((addon) => {
                    return addon.accommodation_start_date === accommodation.start_date;
                });
                return list;
            },
            accommodationServices(accommodation){
                let services = this.getApplicationData('accommodation_services');
                let list = services.filter((service) => {
                    return service.accommodation_start_date === accommodation.start_date && service.type !== 'application';
                });
                return list;
            },

            calculateBreak(key, accommodation) {
                let AccommodationLength = key + 1;
                if (this.accommodations.length !== 1 && this.accommodations.length > AccommodationLength) {
                    let nextItem = this.accommodations[AccommodationLength];
                    let nextStart = moment(nextItem.start_date);
                    let currentEnd = moment(accommodation.end_date);
                    let weeks = nextStart.diff(currentEnd, 'week');
                    if (weeks === 0)
                        return '';
                    return weeks + ' week(s)';
                }
                return '';
            },
            removeAccommodation(index, accommodation) {
                let message = 'You are about to delete this item!';
                if(index === 0){
                    message = 'If you have already selected insurance, you will need to add it again.';
                }

                let self = this;
                Swal.fire({
                    customClass: {
                        confirmButton: 'btn btn-info text-white px-3',
                        cancelButton: 'btn btn-outline-secondary px-3 mx-3',
                    },
                    buttonsStyling: false,
                    reverseButtons: true,
                    title: 'Are you sure?',
                    text: message,
                    icon: 'warning',
                    showCancelButton: true,
                }).then((result) => {
                    if (result.isConfirmed) {
                        self.removeAccommodation(index);
                        self.removeAttachedItems(accommodation);
                    }
                });
            },
            removeAttachedItems(accommodation) {
                let allServices = this.getApplicationData('accommodation_services');
                let attachedServices = allServices.filter((service) => {
                    return service.accommodation_start_date == accommodation.start_date && service.accommodation_id == accommodation.accommodation_id;
                });
                if (attachedServices.length > 0) {
                    for (let i in attachedServices) {
                        let index = allServices.indexOf(attachedServices[i]);
                        this.removeAccommodationService(index);
                    }
                }

                let addons =  this.getApplicationData('accommodation_addons');
                let attachedAddons = addons.filter((addon) => {
                    return addon.accommodation_start_date == accommodation.start_date && addon.accommodation_id == accommodation.accommodation_id;
                });

                if (attachedAddons.length > 0) {
                    for (let i in attachedAddons) {
                        let index = addons.indexOf(attachedAddons[i]);
                        this.removeAccommodationAddon(index);
                    }
                }
            },
            removeItem(item, type = 'service') {
                let self = this;
                Swal.fire({
                    customClass: {
                        confirmButton: 'btn btn-info text-white px-3',
                        cancelButton: 'btn btn-outline-secondary px-3 mx-3',
                    },
                    buttonsStyling: false,
                    reverseButtons: true,
                    title: 'Are you sure?',
                    text: "You are about to delete this service!",
                    icon: 'warning',
                    showCancelButton: true,
                }).then((result) => {
                    if (result.isConfirmed) {
                        if (type === 'service'){
                            let services = this.getApplicationData('accommodation_services');
                            let index = services.indexOf(item);
                            self.removeAccommodationService(index);
                        }
                        else{
                            let addons =  this.getApplicationData('accommodation_addons');
                            let index = addons.indexOf(item);
                            self.removeAccommodationAddon(index);
                        }
                    }
                });
            },
            formattedDate(date) {
                return moment(date).format('DD/MM/YYYY');
            }

        }

    }
</script>

