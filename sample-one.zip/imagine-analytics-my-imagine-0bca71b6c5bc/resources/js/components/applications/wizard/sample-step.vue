<template>

    <div :id='sectionId' class="active">
        <div class="security-form">

            <h3><i class="fa-solid fa-circle-user"></i> Sample Step</h3>
        </div>

        <div class="wizard-controls">
            <ul class="">
                <li>
                    <a @click="goBack()" class="btn btn-dark prevBtn">
                        <i class="fa-solid fa-arrow-left-long"></i>
                        <span>Previous</span>
                    </a>
                </li>
                <li>
                    <a @click="nextStep()" class="btn btn-primary nextBtn">
                        <span class="nextBtnText">Next </span>
                        <i v-if="loading" class="fa fa-spinner fa-spin"></i>
                        <i v-else class="fa-solid fa-arrow-right-long"></i>
                    </a>
                </li>
            </ul>
        </div>

    </div>

</template>
<script>
    export default {
        name: "security-details",
        props:['step'],
        data() {
            return {
                loading:false,
            };
        },

        mounted() {

        },
        computed :{
            sectionId(){
                return 'step-'+this.step;
            },
        },
        methods: {
            nextStep(){
                this.$emit('nextStep');
            },
            goBack(){
                this.$emit('prevStep');
            },
        }

    }
</script>
