<template>

    <div class="card-body p-4">
        <div class="wizard-title ">
            <div class="wizard-title-left">
                <div v-if="application">
                    <span>Application # {{application.id}}</span>
                    <h5>{{fullName}}</h5>
                    <div v-if="application.student_id" class="span-student-id">Student Id: {{application.student_number}}</div>
                </div>
                <div v-else>
                    <span>{{ applicationNumber }}</span>
                    <h5 v-if="fullName.trim()===''">New Application</h5>
                    <h5>{{fullName}}</h5>
                </div>
            </div>

            <div class="wizard-title-right">
                <div v-if="application">
                    <span>Status</span>
                    <h5>{{status[application.status]['label']}}</h5>
                </div>
                <div v-else>
                    <span>Status</span>
                    <h5>{{ status['draft']['label'] }}</h5>
                </div>

            </div>
        </div>

        <div class="wizard-steps">
            <div class="wizard-nav">
                <ul>
                    <li v-for="tab in tabs" :data-id='tab.id' :number="tab.step" :class="getActiveClass(tab)">
                        <a href="javascript:;" @click.prevent="goToStep(tab)">
                            <div><span><h6 class="text-light">{{ tab.title_break_1 }}</h6></span> <span class="small-text">{{ tab.title_break_2 }}</span></div>
                        </a>
                    </li>
                </ul>
            </div>
            <div class="wizard-progress">
                <div class="progress">
                    <div class="progress-bar progress-bar-striped bg-info" role="progressbar" :style="progressBarWidth" :aria-valuenow="progressPercentage" aria-valuemin="0" aria-valuemax="100"></div>
                </div>
            </div>

            <div class="wizard-content">

                <personal-details :countries="countries" :visas="visas" :application-detail="applicationDetail" @next-step="onNextStep"
                                :languages="languages" :user-type="userType" v-if="step === 1" :step="step"
                                  @firstNameVal="setFirstName" @lastNameVal="setLastName" @applicationNumber="setApplicationNumber"
                                  @insuranceTabCheck="insuranceTabCheck"
                />
                <academic-details v-if="step === 2" @next-step="onNextStep"  @prev-step="onPrevStep" :step="step" />
                <accommodation-details v-if="step === 3" @next-step="onNextStep"  @prev-step="onPrevStep" :step="step" />
                 <transportation-details v-if="step === 4" @next-step="onNextStep"  @prev-step="onPrevStep" :step="step" />
                <health-cover v-if="step === 5" @next-step="onNextStep" @prev-step="onPrevStep" :step="step" :insurances="insurances" :application="application" />
                <payment-methods v-if="step === 6" @next-step="onNextStep"  @prev-step="onPrevStep" :step="step" :payments="payments" />
                <application-summary v-if="step === 7" @next-step="onNextStep"  @prev-step="onPrevStep" :step="step" :document-types="documentTypes"> </application-summary>
            </div>
        </div>

    </div>

</template>

<script>
import PersonalDetails from "./personal-details";
import AccommodationDetails from "./accommodation-details";
import TransportationDetails from "./transportation-details";
import AcademicDetails from "./academic-details";
import SampleStep from "./sample-step";
import HealthCover from "./health-cover";
import { useFormStore } from '../../../stores/applicationForm';
import PaymentMethods from "./payment-methods";
import ApplicationSummary from "./application-summary";


export default {
    setup(){
        const formStore  = useFormStore();
        const {addApplicationData} = formStore;
        return {addApplicationData};
    },
    props: ['countries', 'visas', 'applicationDetail', 'languages', 'userType','application', 'status','applicationPrograms','applicationServices',
        'insurances', 'applicationInsurances', 'applicationPayments','applicationAccommodations','applicationAccommodationServices','applicationAccommodationAddons','applicationTransportations','applicationTransportationServices','applicationTransportationAddons','documentTypes','documents'],
    name: "wizard",
    components: {
        ApplicationSummary,
        HealthCover,
        SampleStep,
        AcademicDetails,
        PersonalDetails,
        PaymentMethods,
        TransportationDetails,
        AccommodationDetails
    },
    data() {
        return {
            payments: null,
            firstName:'',
            lastName:'',
            applicationNumber:'Application Form',
            insuranceTabEnabled: false,
            step:1,
            tabs:[
                {
                    id:'step-1',
                    step:'1',
                    title_break_1: 'Personal',
                    title_break_2: 'Details',
                    title:'Personal',
                }
                ,{
                    id:'step-2',
                    step:'2',
                    title_break_1: 'Academic',
                    title_break_2: 'Details',
                    title:'Academic',
                },
                {
                    id:'step-3',
                    step:'3',
                    title_break_1: 'Accommodation',
                    title_break_2: 'Details',
                    title:'Accommodation',
                },
                {
                    id:'step-4',
                    step:'4',
                    title_break_1: 'Airport Transfer',
                    title_break_2: 'Details',
                    title:'Airport Transfer',
                },
                {
                    id:'step-6',
                    step:'6',
                    title_break_1: 'Payment',
                    title_break_2: 'Methods',
                    title:'Payment Methods',
                }
                ,{
                    id:'step-7',
                    step:'7',
                    title_break_1: 'Review',
                    title_break_2: '',
                    title:'Review',
                }
            ],
        }
    },
    created() {
        this.loadDataToState();
    },
    computed: {
        progressPercentage(){
            let progress = Math.round(((this.step / this.tabs.length) * 100)) + "%";
            return progress;
        },

        progressBarWidth(){
            let progress = Math.round(((this.step / this.tabs.length) * 100)) + "%";
            let style = "width: "+progress;
            return style;
        },

        fullName(){
            return this.firstName+' '+this.lastName;
        }
    },
    methods: {
        getActiveClass(tab) {
            let className = '';
            if (parseInt(tab.step) === this.step)
                className = "active";

            if (parseInt(tab.step) < this.step)
                className = "stepClear";

            return className;
        },
        insuranceTabCheck(check) {
            if (check) {
                if ( !this.insuranceTabEnabled ) {
                    this.tabs.splice(4, 0, {
                        id: 'step-5',
                        step: '5',
                        title_break_1: 'Health',
                        title_break_2: 'Cover',
                        title: 'Health Cover',
                    });
                }
            } else {
                if ( this.insuranceTabEnabled ) {
                    this.tabs.splice(4, 1);
                }
            }
            this.insuranceTabEnabled = check;
        },
        onNextStep() {
            if (this.step <= this.tabs.length) {
                if (!this.insuranceTabEnabled && this.step == 4) {
                    this.step += 2
                    return;
                }
                this.step++;
            }
        },
        onPrevStep() {
            if (this.step > 1) {
                if (!this.insuranceTabEnabled && this.step == 6) {
                    this.step -= 2
                    return;
                }
                this.step--;
            }
        },
        setFirstName(val) {
            this.firstName = val;
        },
        setLastName(val) {
            this.lastName = val;
        },
        setApplicationNumber(val) {
            this.applicationNumber = val;
        },
        goToStep(tab) {
            if (parseInt(tab.step) < parseInt(this.step)) {
                this.step = parseInt(tab.step);
            }
        },

        loadDataToState(){
            if (typeof this.applicationDetail.id !== 'undefined' && this.applicationDetail!==null) {
                this.addApplicationData('personal_details', this.applicationDetail);
            }

            if(typeof this.applicationDetail.id !== 'undefined' && this.applicationPrograms!==null){
                for(let i in this.applicationPrograms){
                    this.addApplicationData('programs', this.applicationPrograms[i]);
                }
            }

            if(typeof this.applicationDetail.id !== 'undefined' && this.applicationServices!==null){
                for(let i in this.applicationServices){
                    let service = this.applicationServices[i];
                    this.addApplicationData('program_services', service);
                }
            }

            if (this.application !== null){
                this.payments = this.application.payment
            }

            if ( this.application !== null && this.applicationPayments ){
                this.addApplicationData('payments', this.applicationPayments);
            }

            if ( this.application !== null && this.applicationInsurances !== null ){
                for(let i in this.applicationInsurances){
                    let insurance = this.applicationInsurances[i];
                    this.addApplicationData('insurances', insurance);
                }
            }

            if ( this.application !== null && this.applicationAccommodations !== null ){
                for(let i in this.applicationAccommodations){
                    let accommodation = this.applicationAccommodations[i];
                    this.addApplicationData('accommodations', accommodation);
                }
            }

            if ( this.application !== null && this.applicationAccommodationServices !== null ){
                for(let i in this.applicationAccommodationServices){
                    let service = this.applicationAccommodationServices[i];
                    this.addApplicationData('accommodation_services', service);
                }
            }
            if ( this.application !== null && this.applicationAccommodationAddons !== null ){
                for(let i in this.applicationAccommodationAddons){
                    let addon = this.applicationAccommodationAddons[i];
                    this.addApplicationData('accommodation_addons', addon);
                }
            }

            if ( this.application !== null && this.applicationTransportations !== null ){
                for(let i in this.applicationTransportations){
                    let transportation = this.applicationTransportations[i];
                    this.addApplicationData('transportations', transportation);
                }
            }

            if ( this.application !== null && this.applicationTransportationServices !== null ){
                for(let i in this.applicationTransportationServices){
                    let service = this.applicationTransportationServices[i];
                    this.addApplicationData('transportation_services', service);
                }
            }
            if ( this.application !== null && this.applicationTransportationAddons !== null ){
                for(let i in this.applicationTransportationAddons){
                    let addon = this.applicationTransportationAddons[i];
                    this.addApplicationData('transportation_addons', addon);
                }
            }

            if ( this.application !== null && this.documents !== null ){
                for(let i in this.documents){
                    let document = this.documents[i];
                    this.addApplicationData('documents', document);
                }
            }
        }
    }
}
</script>

<style scoped>
.wizard-title-right h5::first-letter {
    text-transform:capitalize;
}
</style>
