<template>
  <div class="academic-col academic-items">
    <!-- accommodation start -->
    <h3><i class="fa-solid fa-bars-progress"></i> Your Airport Transfer Summary</h3>
    <div class="products">
      <div class="product-list" v-if="transportations.length > 0">
        <div class="product-item" v-for="(transportation, key) in transportations">
          <h6>{{ transportation.transportation }}</h6>
          <a
            href="javascript:;"
            @click.prevent="deleteTransportation(key, transportation)"
            class="remove-product"
          >
            <i class="fas fa-times"></i>
          </a>
          <div class="sub-products" v-if="services(transportation).length > 0">
            <div class="product-title">Additional Services</div>
            <div class="product-list">
              <div class="product-list" v-if="services(transportation).length > 0">
                <div
                  class="product-item"
                  v-for="(service, key) in services(transportation)"
                >
                  <h6>{{ service.name }}</h6>
                  <a
                    href="javascript:;"
                    @click.prevent="removeItem(service, 'service')"
                    class="remove-service"
                  >
                    <i class="fas fa-times"></i>
                  </a>
                </div>
              </div>
              <div v-else>
                <p class="text-center mt-3">No items selected</p>
              </div>
            </div>
          </div>
          <div class="sub-products" v-if="addons(transportation).length > 0">
            <div class="product-title">Add-ons</div>
            <div class="product-list">
              <div class="product-list" v-if="addons(transportation).length > 0">
                <div class="product-item" v-for="(addon, key) in addons(transportation)">
                  <h6>{{ addon.name }}</h6>
                  <a
                    href="javascript:;"
                    @click.prevent="removeItem(addon, 'addon')"
                    class="remove-addon"
                  >
                    <i class="fas fa-times"></i>
                  </a>
                </div>
              </div>
              <div v-else>
                <p class="text-center mt-3">No items selected</p>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div v-else><p class="text-center mt-3">No items selected</p></div>
    </div>
  </div>
</template>
<script>
import moment from "moment";
import { useFormStore } from "../../../stores/applicationForm";
export default {
  name: "transportation-summary",

  setup() {
    const formStore = useFormStore();
    const {
      getApplicationData,
      removeTransportation,
      removeTransportationService,
      removeTransportationAddon,
      clearTransportationState,
    } = formStore;
    return {
      getApplicationData,
      removeTransportation,
      removeTransportationService,
      removeTransportationAddon,
      clearTransportationState,
    };
  },

  data() {
    return {
      loading: false,
    };
  },

  mounted() {},
  computed: {
    transportations() {
      return this.getApplicationData("transportations");
    },
  },
  methods: {
    services(transportation) {
      let services = this.getApplicationData("transportation_services");
      let list = services.filter((service) => {
        return service.transportation_id === transportation.transportation_id;
      });
      return list;
    },
    addons(transportation) {
      let addons = this.getApplicationData("transportation_addons");
      let list = addons.filter((addon) => {
        return addon.transportation_id === transportation.transportation_id;
      });
      return list;
    },
    formattedDate(date) {
      return moment(date).format("DD/MM/YYYY");
    },
    deleteTransportation(index, transportation) {
      let self = this;
      Swal.fire({
        customClass: {
          confirmButton: "btn btn-info text-white px-3",
          cancelButton: "btn btn-outline-secondary px-3 mx-3",
        },
        buttonsStyling: false,
        reverseButtons: true,
        title: "Are you sure?",
        text: "You are about to delete this product...",
        icon: "warning",
        showCancelButton: true,
      }).then((result) => {
        if (result.isConfirmed) {
          if (transportation.return === 0) {
            self.clearTransportationState();
            self.$emit("resetTransportation");
          } else {
            self.removeTransportation(index);
            self.removeAttachedItems(transportation);
            self.$emit("resetReturnTransportation");
          }
        }
      });
    },
    removeAttachedItems(transportation) {
      let allServices = this.getApplicationData("transportation_services");
      let attachedServices = allServices.filter((service) => {
        return service.transportation_id == transportation.transportation_id;
      });
      if (attachedServices.length > 0) {
        for (let i in attachedServices) {
          let index = allServices.indexOf(attachedServices[i]);
          this.removeTransportationService(index);
        }
      }

      let addons = this.getApplicationData("transportation_addons");
      let attachedAddons = addons.filter((addon) => {
        return addon.transportation_id == transportation.transportation_id;
      });

      if (attachedAddons.length > 0) {
        for (let i in attachedAddons) {
          let index = addons.indexOf(attachedAddons[i]);
          this.removeTransportationAddon(index);
        }
      }
    },
    removeItem(item, type = "service") {
      let self = this;
      Swal.fire({
        customClass: {
          confirmButton: "btn btn-info text-white px-3",
          cancelButton: "btn btn-outline-secondary px-3 mx-3",
        },
        buttonsStyling: false,
        reverseButtons: true,
        title: "Are you sure?",
        text: "You are about to delete this product...",
        icon: "warning",
        showCancelButton: true,
      }).then((result) => {
        if (result.isConfirmed) {
          if (type === "service") {
            let services = this.getApplicationData("transportation_services");
            let index = services.indexOf(item);
            self.removeTransportationService(index);
          } else {
            let addons = this.getApplicationData("transportation_addons");
            let index = addons.indexOf(item);
            self.removeTransportationAddon(index);
          }
        }
      });
    },
  },
};
</script>
