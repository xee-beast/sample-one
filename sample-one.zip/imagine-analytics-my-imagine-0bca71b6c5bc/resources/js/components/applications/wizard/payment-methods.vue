<template>

    <div :id='sectionId' class="active">
        <div class="payment-methods personal-form">
            <h3><i class="fa-solid fa-money-bill"> </i> Payment Methods</h3>
            <form v-if="have_programs">

                <div v-if="show_payment_plan" class="row">
                    <div class="col-6">
                        <div class="form-group">
                            <label>Do you need a payment plan?<span class="required">*</span></label>
                            <div class="fancy-radio">
                                <div class="radio-gorup in-row">
                                    <label v-for="option in boolean_options" >
                                        <input type="radio" name="radio" @change="paymentPlanChange()" v-model="form.payment_plan_enabled" :value="option.value"  />
                                        <span>{{option.label}}</span>
                                    </label>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="row">
                    <div class="col-6">
                        <div class="form-group">
                            <label class="form-label">How you are paying for your fees?<span class="required">*</span></label>
                            <v-select v-if="payment_methods" label="name" v-model="form.payment_method_id" :options="paymentMethods"  :reduce="option => option.id"  placeholder="-- Please Select --" >
                                <template #no-options="{ search, searching, loading }">
                                    <span>No options available</span>
                                </template>
                            </v-select>
                            <p class="text-danger" v-if="errors.payment_method_id">{{ errors.payment_method_id }}</p>
                        </div>
                    </div>
                </div>


            </form>

            <p v-else class="text-danger" >Select Programs to continue</p>

            <div class="wizard-controls">
                <ul class="">
                    <li>
                        <a @click="goBack" class="btn btn-dark prevBtn">
                            <i class="fa-solid fa-arrow-left-long"></i>
                            <span>Previous</span>
                        </a>
                    </li>
                    <li>
                        <a @click="submit()" class="btn btn-primary nextBtn">
                            <span class="nextBtnText">Next </span>
                            <i v-if="loading" class="fa fa-spinner fa-spin"></i>
                            <i v-else class="fa-solid fa-arrow-right-long"></i>
                        </a>
                    </li>
                </ul>
            </div>

        </div>
    </div>


</template>

<script>
import vSelect from "vue-select";
import {useFormStore} from "../../../stores/applicationForm";
import {HttpService} from "../../../services/HttpService";
import generalHelpers from "../../../helpers/generalHelpers";

export default {
    props: ['programs','step', 'payments'],
    // Pinia state setup to initialize state data
    setup(){
        const formStore  = useFormStore();
        const {addApplicationData, getApplicationData, getApplicationId} = formStore;
        return {addApplicationData, getApplicationData, getApplicationId};
    },
    components: {
        vSelect
    },
    name: "payment-methods",
    data() {
        return {
            request: new HttpService(),
            data: null,
            loading: false,
            application_id: null,
            boolean_options: generalHelpers.getBooleanOptions(),
            show_payment_plan: false,
            payment_methods: null,
            have_programs: true,
            payment_data: null,
            form: {
                payment_plan_enabled : false,
                payment_method_id: null,
                faculty_id: null,
            },
            errors: {}
        }
    },
    async mounted() {
        // getting application details from pinia
        this.data = await this.getApplicationData('programs');
        this.application_id = await this.getApplicationData('application_number');
        this.payment_data = await this.getApplicationData('payments');

        if ( Object.keys(this.payment_data).length ){
            this.setValues();
        }

        if ( typeof this.application_id !== 'undefined' && typeof this.data[0] !== 'undefined'){
            this.form.faculty_id = this.data[0].faculty_id;
            this.getPaymentMethodData();
        }
        if(! this.data.length) {
            this.have_programs = false;
        }
    },
    methods : {
      setValues(){
          this.form.payment_plan_enabled = this.payment_data.payment_plan_enabled? true : false;
          this.form.payment_method_id = this.payment_data.payment_method_id;
          this.form.faculty_id = this.payment_data.faculty_id;
      },
      paymentPlanChange(){
          this.form.payment_method_id = null;
      },
      getPaymentMethodData(){
          const self = this;
          return this.request.get(route('applications.payment-methods', this.application_id, this.form.faculty_id))
              .then(function (response) {
                  if(response.success){
                      if ( response.has_payment_plan === true ){
                          self.show_payment_plan = true;
                      }
                      self.payment_methods = response.payment_methods
                  }
              }).catch(function (err) {
                  if(err.status == 500){
                      generalHelpers.showToast("Something went wrong", false);
                  }
              });
      },
      async submit() {
          if (this.validateData()){
              return;
          }

          let formData = this.getFormData();

          if ( this.have_programs ) {
              if (!Object.keys(this.payment_data).length) {
                  this.makeStoreRequest(formData)
              } else {
                  this.makeUpdateRequest(formData)
              }
          }
      },
        makeStoreRequest(formData){
          let self = this;
          this.loading = true;

            this.request.post(route('applications.payment.store', this.application_id), formData)
                .then(async function (response) {
                    if (response.success) {
                        await self.addApplicationData('payments', response.data);
                        self.payment_data = self.getApplicationData('payments');
                        self.nextStep();
                    }
                }).catch(function (err) {
                    if(err.status == 500){
                        generalHelpers.showToast("Something went wrong", false);
                    }
            });
          this.loading = false;
        },
        makeUpdateRequest(formData){
          let self = this;
          this.loading = true;

            this.request.patch(route('applications.payment.update', this.application_id), formData)
                .then(async function (response) {
                    if (response.success) {
                        await self.addApplicationData('payments', response.data);
                        self.payment_data = self.getApplicationData('payments');
                        self.nextStep();
                    }
                }).catch(function (err) {
                    if(err.status == 500){
                        generalHelpers.showToast("Something went wrong", false);
                    }
            })
          this.loading = false;
        },
        getFormData(){
            let formData = this.form;
            this.form.application_id = this.application_id
            return formData;
        },
        validateData() {
            let check = false;
            let self = this;
            $.each(self.errors, function (fieldName) {
                self.errors[fieldName] = ''
            });

            if (! this.form.payment_method_id || this.form.payment_method_id === '' || typeof this.form.payment_method_id == 'undefined') {
                check = true;
                this.errors.payment_method_id = "This field is required"
            }
            return check;
        },
        nextStep() {
            this.$emit("nextStep");
        },
    },
    computed: {
        paymentMethods(){
            let methods = [];
            for ( let item in this.payment_methods) {
                if (this.form.payment_plan_enabled == this.payment_methods[item].is_payment_plan) {
                    methods.push({name: this.payment_methods[item].name, id: this.payment_methods[item].id})
                }
            }
            return methods;
        },
        sectionId(){
            return 'step-'+this.step;
        },
        goBack() {
            this.$emit("prevStep");
        },
    },
}
</script>

<style scoped>

</style>
