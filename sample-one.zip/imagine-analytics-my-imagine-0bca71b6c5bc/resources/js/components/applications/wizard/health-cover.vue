<template>

    <div :id='sectionId' class="active">
        <div class="academic-form personal-form">
            <h3><i class="fa-solid fa-hospital"></i> Overseas Student Health Cover (OSHC)</h3>

            <div class="academic-row">
                <div class="academic-col academic-tree">
                    <div class="tree-outer">
                        <div class="academicTree">
                            <section v-for="insurance in insurances"  class="item">
                                <div class="tree-title text-capitalize">
                                    <i class="fa-solid fa-bars-progress"></i> {{insurance.type}} <button @click.prevent="selectInsurance(insurance)" class="btn btn-primary">Add </button>
                                </div>
                            </section>
                        </div>
                    </div>
                </div>

                <health-cover-summary />

            </div>
        </div>

        <div class="wizard-controls">
            <ul class="">
                <li>
                    <a @click="goBack" class="btn btn-dark prevBtn">
                        <i class="fa-solid fa-arrow-left-long"></i>
                        <span>Previous</span>
                    </a>
                </li>
                <li>
                    <a @click="submit()" class="btn btn-primary nextBtn">
                        <span class="nextBtnText">Next </span>
                        <i v-if="loading" class="fa fa-spinner fa-spin"></i>
                        <i v-else class="fa-solid fa-arrow-right-long"></i>
                    </a>
                </li>
            </ul>
        </div>


<!--   MODAL     -->
        <div class="modal fade" id="insuranceModal" tabindex="-1" role="dialog" aria-labelledby="insuranceModalLabel" aria-hidden="true">
            <div class="modal-dialog modal-lg">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title text-capitalize" id="insuranceModalLabel">Insurance Type: {{selectedInsuranceName}}</h5>
                    </div>
                    <div class="modal-body">
                        <form>
                            <div class="form-group">
                                <div class="form-group">
                                    <label class="col-form-label">Start Date<span class="required">*</span></label>
                                    <Datepicker v-model="form.start_date"
                                                :minDate="new Date()"
                                                placeholder="dd/mm/yyyy"
                                                :format="format"
                                                autoApply
                                                :enableTimePicker="false"
                                                :disabled="!start_date_from_course"
                                                utc="preserve"
                                    ></Datepicker>
                                    <p class="text-danger" v-if="errors.start_date">{{ errors.start_date }}</p>
                                    <p v-else-if="start_date_from_course" class="text-end"><small>This is {{ date_info }}</small></p>
                                </div>
                                <div class="form-group">
                                    <label class="col-form-label">End Date</label>
                                    <i class="fa fa-spinner fa-spin" v-if="loading" style="position: absolute;right: 30px;margin-top: 43px;"></i>
                                    <input  disabled type="text" class="form-control" :value="form.end_date">
                                </div>
                                <div class="form-group">
                                    <label class="col-form-label">Duration (Months)</label>
                                    <i class="fa fa-spinner fa-spin" v-if="loading" style="position: absolute;right: 30px;margin-top: 43px;"></i>
                                    <input  disabled type="text" class="form-control" :value="form.duration">
                                </div>
                            </div>
                        </form>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" @click="closeModal()">Close</button>
                        <button type="button" class="btn btn-primary application-modal-btn" :disabled="modalSaveBtn" @click.prevent="saveDetail"> Save</button>
                    </div>
                </div>
            </div>
        </div>
    </div>

</template>
<script>
    import {HttpService} from "../../../services/HttpService";
    import moment from 'moment';
    import Datepicker from "@vuepic/vue-datepicker";
    import vSelect from "vue-select";
    import {useFormStore} from "../../../stores/applicationForm";
    import HealthCoverSummary from "./health-cover-summary";
    import generalHelpers from "../../../helpers/generalHelpers";
    export default {
        setup(){
            const formStore  = useFormStore();
            const {addApplicationData, getApplicationData} = formStore;
            return {addApplicationData, getApplicationData};
        },
        name: "health-cover",
        props:['step', 'insurances', 'application'],
        components: {
            HealthCoverSummary,
            vSelect,
            Datepicker
        },
        data() {
            return {
                loading:false,
                request: new HttpService(),
                selectedInsuranceName: null,
                programs: null,
                accommodations: null,
                courseStartDate: null,
                courseEndDate: null,
                application_id: null,
                start_date_from_course: true,
                date_info: null,
                form: {
                  insurance_id: null,
                  faculty_id: null,
                  faculty_name: null,
                  start_date: null,
                  end_date: null,
                  duration: null,
                },
                errors:{},
                // datepicker
                format: "dd/MM/yyyy"
            };
        },

        async mounted() {
            this.application_id = await this.getApplicationData('application_number');
            this.programs = await this.getApplicationData('programs');
            this.accommodations = await this.getApplicationData('accommodations');
            if (this.programs.length) {
                this.form.faculty_id = this.programs[0].faculty_id;
                this.form.faculty_name = this.programs[0].faculty;
                var dates = await this.getDates();
                this.courseStartDate = dates.start_date;
                this.courseEndDate = dates.end_date;
            }
        },
        methods: {
            // submits the form
            async submit() {
                let self = this;

                let formData = await this.getFormData();
                this.makeRequest(formData);
            },
            async getDates(){
                return {
                    'start_date': this.programs[0].start_date,
                    'end_date': this.programs[this.programs.length - 1].end_date,
                }
            },
            makeRequest(formData){
                let self = this;
                this.loading = true;
                this.request.patch(route('applications.insurance', this.application_id), formData)
                    .then(function (response) {
                        self.loading = false;
                        self.$emit('nextStep')
                    }).catch(function (err) {
                        if(err.status == 500){
                            generalHelpers.showToast("Something went wrong", false);
                        }
                });
            },
            async selectInsurance(insurance) {
                if (this.courseStartDate) {
                    this.selectedInsuranceName = insurance.type;
                    this.form.insurance_id = insurance.id;
                    if (this.start_date_from_course) {
                        this.form.start_date = moment(this.courseStartDate, ['DD/MM/YYYY', 'YYYY-MM-DD']).subtract('1', 'week').format('YYYY-MM-DD').toString();
                    }else {
                        this.form.start_date = moment(this.courseStartDate, ['DD/MM/YYYY', 'YYYY-MM-DD']).format('YYYY-MM-DD').toString();
                    }
                    $('#insuranceModal').modal('show');
                }
            },
            calculateEndDate(){
              var startDate = moment(this.form.start_date, ['DD/MM/YYYY', 'YYYY-MM-DD']);
              var endDate = moment(this.courseEndDate, ['DD/MM/YYYY', 'YYYY-MM-DD']);

              if ( endDate.diff(startDate, 'months', true) <= 10){
                    this.form.end_date = endDate.add(1, 'month').format('DD/MM/YYYY');
              }else {
                  if ( (endDate.month() +1) <= 10 ){ // month() is zero-indexed
                      this.form.end_date = endDate.add('2', 'month').format('DD/MM/YYYY');
                  }else{
                      var year = endDate.add('1', 'year').format('YYYY');
                      this.form.end_date = '15/03/'+year;
                  }
              }
                startDate = moment(startDate);
                endDate = moment(this.form.end_date, ['DD/MM/YYYY', 'YYYY-MM-DD']);
                this.form.duration = Math.ceil(endDate.diff(startDate, 'months', true));
                this.form.end_date = startDate.add(this.form.duration, 'months').format('DD/MM/YYYY');
            },
            saveDetail(){
                let data = {
                    insurance_id: this.form.insurance_id,
                    faculty_id: this.form.faculty_id,
                    faculty_name: this.form.faculty_name,
                    insurance_name: this.selectedInsuranceName,
                    start_date: moment(this.form.start_date, ['DD/MM/YYYY', 'YYYY-MM-DD']).format('DD/MM/YYYY'),
                    end_date: moment(this.form.end_date, ['DD/MM/YYYY', 'YYYY-MM-DD']).format('DD/MM/YYYY'),
                    duration:this.form.duration,
                }
                this.addApplicationData('insurances',data);
                this.closeModal();
            },
            async getFormData() {
                const formRec = [];
                const insurances = await this.getApplicationData('insurances');
                insurances.map(insurance => {
                    formRec.push({
                        'insurance_id': insurance.insurance_id,
                        'faculty_id': insurance.faculty_id,
                        'application_id': this.application_id,
                        'duration': insurance.duration,
                        'start_date': moment(insurance.start_date, 'DD/MM/YYYY').format('DD-MM-YYYY'),
                        'end_date': moment(insurance.end_date, 'DD/MM/YYYY').format('DD-MM-YYYY'),
                    });
                });
                return formRec;
            },
            closeModal(){
                this.clearModal();
                $('#insuranceModal').modal('hide');
            },
            nextStep(){
                this.$emit('nextStep');
            },
            clearModal(){
                this.form.start_date = null;
                this.form.end_date = null;
                this.form.duration = null;
                this.form.insurance_id = null;
            },
        },
        computed :{
            sectionId(){
                return 'step-'+this.step;
            },
            goBack(){
                this.$emit('prevStep');
            },
            modalSaveBtn(){
                if (this.loading || this.errors.start_date || ! this.form.start_date){
                    return true;
                }
                return false;
            }
        },
        watch: {
            'form.start_date': function (value) {

                if(!value){
                    this.form.end_date = null;
                    this.form.duration = null;
                    return false;
                }

                this.errors.start_date = null;
                this.date_info = null;
                var date = moment(value, ['DD/MM/YYYY', 'YYYY-MM-DD']);
                var courseDate = moment(this.courseStartDate, ['DD/MM/YYYY', 'YYYY-MM-DD']);
                if ( date.isSameOrAfter(courseDate) && this.start_date_from_course ){
                    this.errors.start_date = "The cover start date cannot be after your first course commencement date ("+courseDate.format('DD/MM/YYYY')+")";
                }else {
                    var days = courseDate.diff(date, 'days');
                    this.date_info = days + " day(s) before the start of the first program";
                }
                this.calculateEndDate();
            }
        }
    }
</script>

<style>
.vdp-datepicker__calendar{
    position: fixed !important;
}
</style>
