<template>
	<div :id="sectionId" class="active">
		<div class="academic-form personal-form">
			<h3><i class="fa-solid fa-book-open pe-3"></i>Airport Transfer Details</h3>
			<div class="academic-row">
				<div  class="academic-col academic-tree">
					<p v-if="transportationLoading" class="text-center mt-3"><i class="fa fa-2x fa-spinner fa-spin"></i></p>
					<div v-else>
						<div v-if="showTransportation">
							<div class="form-group d-none">
								<label class="form-label">First Name<span class="required">*</span></label>
								<input type="text" class="form-control" placeholder="First Name" />
							</div>
							<div class="tree-outer">
								<div class="academicTree">
									<!-- First Tree -->

									<section v-for="transportation in transportationList" class="item child">
										<div class="tree-title">
											<i class="fa-solid fa-bars-progress"></i> {{transportation.name}}<button
												@click.prevent="selectTransportation(transportation)"
												class="btn btn-primary">Add </button>
										</div>
									</section>

									<!-- Second Tree -->
								</div>
							</div>
						</div>
						<div v-else>
							<p class="text-center">You have selected all your airport transfer products, please continue..</p>
						</div>
					</div>
				</div>

				<transportation-summary @reset-transportation="resetTransportation()" @reset-return-transportation="loadReturnTransportation()"/>

			</div>
		</div>

		<div class="wizard-controls">
			<ul class="">
				<li>
					<a @click="goBack()" class="btn btn-dark prevBtn">
						<i class="fa-solid fa-arrow-left-long"></i>
						<span>Previous</span>
					</a>
				</li>
				<li>
					<a @click="submitTransportation()" class="btn btn-primary nextBtn">
						<span class="nextBtnText">Next </span>
						<i v-if="loading" class="fa fa-spinner fa-spin"></i>
						<i v-else class="fa-solid fa-arrow-right-long"></i>
					</a>
				</li>
			</ul>
		</div>

		<div class="modal fade" id="transportationModal" tabindex="-1" role="dialog"
			aria-labelledby="transportationModalLabel" aria-hidden="true">
			<div class="modal-dialog modal-lg">
				<div class="modal-content">
					<div class="modal-header">
						<h5 class="modal-title" id="transportationModalLabel">{{selectedTransportationName}}</h5>
					</div>
					<div class="modal-body">
						<div class="form-group" v-if="selectedTransportation && selectedTransportation.optional_services.length > 0">
							<div class="col-12">
							  <div class="academic-form personal-form">
								  <h3>Services</h3>
								  <div class="form-group"  v-for="service in selectedTransportation.optional_services">
									<div class="form-group form-check form-switch">
									  <input type="hidden" :name="service.name" value="0">
									  <input
										  class="form-check-input"
										  type="checkbox"
										  name="service" :id="service.name"
										  @change="selectService(service)"
									  >
									  <label class="form-check-label pe-2" :for="service.name">{{service.name}}</label>
									</div>
								  </div>
								  <p class="text-danger" v-if="errors.service">{{ errors.service }}</p>
							  </div>
							</div>
						  </div>

						  <div class="form-group" v-if="selectedTransportation && selectedTransportation.optional_addons.length > 0">
							<div class="col-12">
							  <div class="academic-form personal-form">
								  <h3>Add-ons</h3>
								  <div class="form-group"  v-for="addon in selectedTransportation.optional_addons">
									<div class="form-group form-check form-switch">
									  <input type="hidden" :name="addon.name" value="0">
									  <input
										  class="form-check-input"
										  type="checkbox"
										  name="addon" :id="addon.name"
										  @change="selectAddon(addon)"
									  >
									  <label class="form-check-label pe-2" :for="addon.name">{{addon.name}}</label>
									</div>
								  </div>
								  <p class="text-danger" v-if="errors.service">{{ errors.addons }}</p>
							  </div>
							</div>
						  </div>
					</div>
					<div class="modal-footer">
						<button type="button" class="btn btn-secondary" @click="closeModal()">Close</button>
						<button type="button" class="btn btn-primary application-modal-btn" @click="addTransportation()" :disabled="loading"> Save</button>
					</div>
				</div>
			</div>
		</div>
	</div>
</template>

<script>
	import vSelect from "vue-select";
	import moment from 'moment';
	import { HttpService } from "../../../services/HttpService";
	import { useFormStore } from '../../../stores/applicationForm';
	import '@vuepic/vue-datepicker/dist/main.css'
	import Datepicker from '@vuepic/vue-datepicker';
	import TransportationSummary from "./transportation-summary";
	import generalHelpers from "../../../helpers/generalHelpers";

	export default {

		name: "academic-details",
		setup() {
			const formStore = useFormStore();
			const { addApplicationData, getApplicationData } = formStore;
			return { addApplicationData, getApplicationData };
		},

		components: {
			vSelect,
			Datepicker,
			TransportationSummary
		},
		props: ["step"],
		data() {
			return {
				loading: false,
				transportationLoading: false,
				request: new HttpService(),
				transportationList: [],
				selectedTransportation: null,
				format: 'dd/MM/yyyy',
				momentFormat: 'DD/MM/YYYY',
				errors: {
					service:'',
					addons:''
				},
				form: {
					services:[],
					addons:[],
				},
			};
		},

		mounted() {
			this.loadTransportation();
		},
		computed: {
			sectionId() {
				return "step-" + this.step;
			},

			selectedTransportationName() {
				if (this.selectedTransportation) {
					return this.selectedTransportation.name;
				}
				return '';
			},

			getFirstProgram(){
				let programs  = this.getApplicationData('programs');
				return programs[0];
			},
			showTransportation(){
				let transportations  = this.getApplicationData('transportations');
				let hasReturn = transportations.filter((transportation) => {
                    return transportation.return === 1;
                });
				let notHasReturn = transportations.filter((transportation) => {
                    return transportation.return === 0;
                });
				if(hasReturn.length ===1 && notHasReturn.length === 1){
					return false;
				}
				//this.loadTransportation();
				return true;
			}

		},

		methods: {
			resetTransportation(){
				this.loadTransportation();
			},
			loadReturnTransportation(){
				this.loadTransportation(1);
			},
			goBack() {
				this.$emit("prevStep");
			},

			dateFormat(date) {
				return moment(date).format(this.format);
			},

			selectTransportation(transportation) {
				this.selectedTransportation = transportation;
				if(transportation.optional_services.length > 0 || transportation.optional_addons.length > 0){
					$('#transportationModal').modal('show');
				}else{
					this.addTransportation();
				}
			},
			addTransportation(){
				let firstProgram = this.getFirstProgram;
				let data = {
					transportation: this.selectedTransportation.name,
					transportation_id: this.selectedTransportation.id,
					faculty_id: firstProgram.faculty_id,
					return:this.selectedTransportation.return
				}
				this.addApplicationData('transportations', data);
				for(let i in this.form.services){
					this.addApplicationData('transportation_services',{
						transportation: this.selectedTransportation.name,
						transportation_id: this.selectedTransportation.id,
						service_id:this.form.services[i].id,
						name:this.form.services[i].name,
						type:this.form.services[i].type,
                        mandatory:this.form.services[i].pivot.mandatory,
						faculty_id: firstProgram.faculty_id
					});
				}
				for(let i in this.form.addons){
				this.addApplicationData('transportation_addons',{
						transportation: this.selectedTransportation.name,
						transportation_id: this.selectedTransportation.id,
						addon_id:this.form.addons[i].id,
                        mandatory:this.form.addons[i].pivot.mandatory,
						name:this.form.addons[i].name,
						faculty_id: firstProgram.faculty_id
					});
				}
				this.closeModal();
				this.toggleTree();
			},
			toggleTree(){
				let transportations =  this.getApplicationData('transportations');
				let notHasReturn = false;
				let hasReturn = false;
				if(transportations.length === 1 && transportations[0].return === 0){
					this.loadTransportation(1);
				}
			},

			selectService(service){
				let index = this.form.services.findIndex(item => item.id === service.id);
				if (index !== -1) {
					this.form.services.splice(index, 1);
				}else{
				this.form.services.push(service);
				}
			},
			selectAddon(addon){
				let index = this.form.addons.findIndex(item => item.id === addon.id);
				if (index !== -1) {
					this.form.addons.splice(index, 1);
				}else{
				this.form.addons.push(addon);
				}
			},

			closeModal() {
				this.clearModal();
				$('#transportationModal').modal('hide');
			},
			clearModal(){
				this.form.services = [];
				this.form.addons = [];
				this.selectedTransportation = null;
			},
			loadTransportation(returnType = 0) {
				let self = this;
				let application = this.getApplicationData();
				let firstProgram = this.getFirstProgram;
				let transportations  = this.getApplicationData('transportations');
				if(transportations.length === 1  && transportations[0].return === 0){
					returnType = 1;
				}

				this.transportationLoading = true;

				return this.request.get(route('applications.transportation', application.applicationId),{
					faculty_id:firstProgram.faculty_id,
					return: returnType
				})
					.then(function (response) {
						self.transportationLoading = false;
						if (response.success) {
							self.transportationList = response.data;
						}
					}).catch(function (err) {
						self.transportationLoading = false;
                        if(err.status == 500){
                            generalHelpers.showToast("Something went wrong", false);
                        }
					});
			},

			submitTransportation(){
				let self = this;
				if(this.loading){
					return;
				}
				this.loading = true;
				let application = this.getApplicationData('personal_details');
				let formData = this.getFormData();
				this.request.post(route('applications.transportation.store', application.application_id), formData)
					.then(function (response) {
						self.loading = false;
						if(response.success){
							self.$emit('nextStep')
						}else{
							generalHelpers.showToast(response.message,response.success);
						}
					}).catch(function (err) {
					self.loading = false;
					generalHelpers.showToast('Something went wrong',false);
				});
			},
			getFormData(){
				return {
					transportations: this.getApplicationData('transportations'),
					services: this.getApplicationData('transportation_services'),
					addons: this.getApplicationData('transportation_addons'),
				}
			},
			nextStep() {
				this.$emit("nextStep");
			},

		},
	};
</script>
