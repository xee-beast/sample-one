<template>
    <div :id='sectionId' class="active">
        <div class="personal-form">

            <h3><i class="fa-solid fa-circle-user"></i> Personal Details</h3>
            <form>

                <div class="row">
                    <div class="col-md-6">
                        <div class="form-group">
                            <label>Salutation<span class="required">*</span></label>
                            <div class="fancy-radio">
                                <div class="radio-group in-row">
                                    <label v-for="salutation in salutations" >
                                        <input type="radio" name="radio" v-model="form.salutation" :value="salutation.label"  />
                                        <span>{{salutation.label}}</span>
                                    </label>
                                </div>
                            </div>
                            <p class="text-danger" v-if="errors.salutation">{{ errors.salutation }}</p>
                            <input v-if="form.salutation === 'Other'" v-model="form.other_salutation" type="text" class="form-control" required placeholder="salutation" >
                                                                <p class="text-danger" v-if="errors.other_salutation">{{ errors.other_salutation }}</p>
                        </div>
                    </div>

                    <div class="col-md-6">
                        <div class="form-group">
                            <label>Gender<span class="required">*</span></label>
                            <div class="fancy-radio">
                                <div class="radio-gorup in-row">
                                    <label v-for="gender in genders">
                                        <input type="radio" name="gender" v-model="form.gender" :value="gender.label" />
                                        <span>{{ gender.label }}</span>
                                    </label>
                                </div>
                            </div>
                            <p class="text-danger" v-if="errors.gender">{{ errors.gender }}</p>
                        </div>
                    </div>


                    <div class="col-md-4">
                        <div class="form-group">
                            <label class="form-label">First Name<span class="required">*</span></label>
                            <input v-model="form.first_name" type="text" class="form-control" placeholder="First Name">
                                            <p class="text-danger" v-if="errors.first_name">{{ errors.first_name }}</p>
                        </div>
                    </div>

                    <div class="col-md-4">
                        <div class="form-group">
                            <label class="form-label">Middle Name</label>
                            <input v-model="form.middle_name" type="text" class="form-control" placeholder="Last Name">
                                            <p class="text-danger" v-if="errors.middle_name">{{ errors.middle_name }}</p>
                        </div>
                    </div>

                    <div class="col-md-4">
                        <div class="form-group">
                            <label class="form-label">Last Name<span class="required">*</span></label>
                            <input v-model="form.last_name" type="text" class="form-control" placeholder="Last Name">
                                            <p class="text-danger" v-if="errors.last_name">{{ errors.last_name }}</p>
                        </div>
                    </div>

                    <div class="col-md-6">
                        <div class="form-group">
                            <label class="form-label">E-mail address<span class="required">*</span></label>
                            <input v-model="form.email" type="email" class="form-control" placeholder="E-mail">
                                            <p class="text-danger" v-if="errors.email">{{ errors.email }}</p>
                        </div>
                    </div>

                    <div class="col-md-6">
                        <div class="form-group">
                            <label class="form-label">Mobile Phone Number<span class="required">*</span></label>
                            <input v-model="form.mobile" type="text" class="form-control" placeholder="Phone Number">
                        </div>
                    </div>

                    <div class="col-md-12">
                        <div class="form-group mb-1">
                            <div class="fancy-radio">
                                <div class="radio-group in-row">
                                    <label>
                                        <input :value="form.marketing_consent" :checked="form.marketing_consent" v-model="form.marketing_consent" type="checkbox" name="gender" />
                                        <span>{{ consentString }}</span>
                                    </label>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="col-md-3">
                        <div class="form-group">
                            <label class="form-label">
                                Date of Birth
                                <span class="required">*</span> &nbsp;
                                <span v-if="dobDisabled" @click="enableField('dob')" class="text-muted text-end" role="button">
                                    <small>Click here to modify this field</small>
                                </span>
                            </label>
                            <Datepicker v-model="form.dob"
                                        placeholder="dd/mm/yyyy"
                                        textInput
                                        autoApply
                                        :format="format"
                                        :closeOnAutoApply="true"
                                        :disabled="dobDisabled"
                                        :enableTimePicker="false"
                                        required
                                        utc="preserve"
                            ></Datepicker>
                                            <p class="text-danger" v-if="errors.dob">{{ errors.dob }}</p>
                        </div>
                    </div>

                    <div class="col-md-3">
                        <div class="form-group">
                            <label class="form-label">Nationality/Citizenship<span class="required">*</span></label>
                            <v-select  label="name" v-model="form.country" :options="countries"  :reduce="option => option.id"  placeholder="-- Please Select --" >
                                <template #no-options="{ search, searching, loading }">
                                    <span>No options available</span>
                                </template>
                            </v-select>
                                            <p class="text-danger" v-if="errors.country">{{ errors.country }}</p>
                        </div>
                    </div>

                    <div class="col-md-3">
                        <div class="form-group">
                            <label class="form-label">Country of Birth<span class="required">*</span></label>
                            <v-select  label="name" v-model="form.country_of_birth" :options="countries"  :reduce="option => option.id"  placeholder="-- Please Select --" >
                                <template #no-options="{ search, searching, loading }">
                                    <span>No options available</span>
                                </template>
                            </v-select>
                                            <p class="text-danger" v-if="errors.country_of_birth">{{ errors.country_of_birth }}</p>
                        </div>
                    </div>

                    <div class="col-md-3">
                        <div class="form-group">
                            <label class="form-label">First Language<span class="required">*</span></label>
                            <v-select  label="name" v-model="form.language" :options="languages"  :reduce="option => option.id"  placeholder="-- Please Select --" >
                                <template #no-options="{ search, searching, loading }">
                                    <span>No options available</span>
                                </template>
                            </v-select>
                                            <p class="text-danger" v-if="errors.language">{{ errors.language }}</p>
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-md-3">
                            <div class="form-group">
                                <label class="form-label">Passport Number<span class="required">*</span></label>
                                <input v-model="form.passport_number" type="text" class="form-control datepicker" placeholder="Passport Number">
                                <p class="text-danger" v-if="errors.passport_number">{{ errors.passport_number }}</p>
                            </div>
                        </div>
                    </div>

                    <div class="col-md-12">
                        <div class="form-group">
                            <label class="form-label">Current Occupation</label>
                            <input v-model="form.occupation" type="text" class="form-control datepicker" placeholder="Occupation">
                        </div>
                    </div>

                    <div class="col-md-6">
                        <div class="form-group">
                            <label class="form-label">Are you living in Australia?<span class="required">*</span></label>
                            <v-select  label="label" v-model="form.living_in_australia" :options="selectDropbox"  :reduce="option => option.value" placeholder="--Select--" >
                                <template #no-options="{ search, searching, loading }">
                                    <span>No options available</span>
                                </template>
                            </v-select>
                                            <p class="text-danger" v-if="errors.living_in_australia">{{ errors.living_in_australia }}</p>
                        </div>
                    </div>

                    <div class="col-md-6">
                        <div class="form-group">
                            <label class="form-label">Are you an Australian resident?<span class="required">*</span></label>
                            <v-select  label="label" v-model="form.australian_resident" :options="selectDropbox"  :reduce="option => option.value" placeholder="--Select--" >
                                <template #no-options="{ search, searching, loading }">
                                    <span>No options available</span>
                                </template>
                            </v-select>
                            <p class="text-danger" v-if="errors.australian_resident">{{ errors.australian_resident }}</p>
                        </div>
                    </div>

                </div>


                <h3><i class="fa-solid fa-circle-user"></i> Australian Visa Details</h3>
                <form>

                    <div class="row">

                        <div class="col-md-6">
                            <div class="form-group">
                                <label class="form-label">Do you currently hold an Australian visa?<span class="required">*</span></label>
                                <v-select  label="label" v-model="form.has_australian_visa" :options="selectDropbox"  :reduce="option => option.value" placeholder="--Select--" >
                                    <template #no-options="{ search, searching, loading }">
                                        <span>No options available</span>
                                    </template>
                                </v-select>
                                <p class="text-danger" v-if="errors.has_australian_visa">{{ errors.has_australian_visa }}</p>
                            </div>
                        </div>

                        <div class="col-md-3">
                            <div v-if="form.has_australian_visa == true" class="form-group">
                                <label class="form-label">Please indicate visa type<span class="required">*</span></label>
                                <v-select  label="name" v-model="form.current_visa_type" :options="visas"  :reduce="option => option.id"  placeholder="-- Please Select --" >
                                    <template #no-options="{ search, searching, loading }">
                                        <span>No options available</span>
                                    </template>
                                </v-select>
                                                <p class="text-danger" v-if="errors.visa_type">{{ errors.visa_type }}</p>
                            </div>
                        </div>

                        <div class="col-md-3">
                            <div v-if="form.has_australian_visa == true" class="form-group">
                                <label class="form-label">Current Visa expiry date<span class="required">*</span></label>
                                <Datepicker utc="preserve" v-model="form.current_visa_expiry" placeholder="dd/mm/yyyy" textInput autoApply :format="format" :closeOnAutoApply="true" :enableTimePicker="false" required></Datepicker>
                                                <p class="text-danger" v-if="errors.current_visa_expiry">{{ errors.current_visa_expiry }}</p>
                            </div>
                        </div>

                        <div class="col-md-6">
                            <div class="form-group">
                                <label class="form-label">Have you ever held a student visa for Australia?<span class="required">*</span></label>
                                <v-select  label="label" v-model="form.has_had_student_visa" :options="selectDropbox"  :reduce="option => option.value"  placeholder="-- Please Select --" >
                                    <template #no-options="{ search, searching, loading }">
                                        <span>No options available</span>
                                    </template>
                                </v-select>
                                <p class="text-danger" v-if="errors.has_had_student_visa">{{ errors.has_had_student_visa }}</p>
                            </div>
                        </div>
                        <div class="col-md-6"></div>

                        <div class="col-md-6">
                            <div class="form-group">
                                <label class="form-label">Which visa are you applying?<span class="required">*</span> &nbsp;<span v-if="visaDisabled" @click="enableField('visa')" class="text-muted" role="button">
                                    <small>Click here to modify this field</small>
                                </span></label>
                                <v-select  label="name" v-model="form.visa_applying_for" :options="visas" :disabled="visaDisabled" :reduce="option => option.id"  placeholder="-- Please Select --" >
                                    <template #no-options="{ search, searching, loading }">
                                        <span>No options available</span>
                                    </template>
                                </v-select>
                                                <p class="text-danger" v-if="errors.visa_applying_for">{{ errors.visa_applying_for }}</p>
                            </div>
                        </div>

                        <div class="col-md-6">
                            <div class="form-group">
                                <label class="form-label">Will you be lodging your visa application in Australia?<span class="required">*</span></label>
                                <v-select  label="label" v-model="form.visa_application_australia" :options="selectDropbox"  :reduce="option => option.value" placeholder="--Select--" >
                                    <template #no-options="{ search, searching, loading }">
                                        <span>No options available</span>
                                    </template>
                                </v-select>
                                <p class="text-danger" v-if="errors.visa_application_australia">{{ errors.visa_application_australia }}</p>
                            </div>
                        </div>


                        <div class="col-md-6">
                            <div v-if="form.visa_application_australia == false" class="form-group">
                                <label class="form-label">Which country will you lodge the visa application?<span class="required">*</span></label>
                                <v-select  label="name" v-model="form.visa_application_location" :options="countries"  :reduce="option => option.id"  placeholder="-- Please Select --" >
                                    <template #no-options="{ search, searching, loading }">
                                        <span>No options available</span>
                                    </template>
                                </v-select>
                                                <p class="text-danger" v-if="errors.visa_application_location">{{ errors.visa_application_location }}</p>
                            </div>
                        </div>

                    </div>
                </form>

                <h3><i class="fa-solid fa-circle-user"></i> Current Residence Address</h3>
                <form>

                    <div class="row">

                        <div class="col-md-12">
                            <div class="form-group">
                                <label class="form-label">Address Line 1<span class="required">*</span></label>
                                <input v-model="form.current_residence_address_line_1" type="text" class="form-control datepicker" placeholder="Line 1">
                                <p class="text-danger" v-if="errors.current_residence_address_line_1">{{ errors.current_residence_address_line_1 }}</p>
                            </div>
                        </div>

                        <div class="col-md-12">
                            <div class="form-group">
                                <label class="form-label">Address Line 2</label>
                                <input v-model="form.current_residence_address_line_2" type="text" class="form-control datepicker" placeholder="Line 2">
                            </div>
                        </div>

                        <div class="col-md-12">
                            <div class="form-group">
                                <label class="form-label">Address Line 3</label>
                                <input v-model="form.current_residence_address_line_3" type="text" class="form-control datepicker" placeholder="Line 3">
                            </div>
                        </div>

                        <div class="col-md-3">
                            <div class="form-group">
                                <label class="form-label">City<span class="required">*</span></label>
                                <input v-model="form.current_residence_address_city" type="text" class="form-control datepicker" placeholder="City">
                                <p class="text-danger" v-if="errors.current_residence_address_city">{{ errors.current_residence_address_city }}</p>
                            </div>
                        </div>

                        <div class="col-md-3">
                            <div class="form-group">
                                <label class="form-label">State</label>
                                <input v-model="form.current_residence_address_state" type="text" class="form-control datepicker" placeholder="State">
                            </div>
                        </div>

                        <div class="col-md-3">
                            <div class="form-group">
                                <label class="form-label">Postcode<span class="required">*</span></label>
                                <input v-model="form.current_residence_address_postcode" type="text" class="form-control datepicker" placeholder="Postcode">
                                <p class="text-danger" v-if="errors.current_residence_address_postcode">{{ errors.current_residence_address_postcode }}</p>
                            </div>
                        </div>

                        <div class="col-md-3">
                            <div class="form-group">
                                <label class="form-label">Country<span class="required">*</span></label>
                                <v-select  label="name" v-model="form.current_residence_address_country" :options="countries"  :reduce="option => option.id"  placeholder="-- Please Select --" >
                                    <template #no-options="{ search, searching, loading }">
                                        <span>No options available</span>
                                    </template>
                                </v-select>
                                                <p class="text-danger" v-if="errors.current_residence_address_country">{{ errors.current_residence_address_country }}</p>
                            </div>
                        </div>

                    </div>
                </form>


                <h3><i class="fa-solid fa-circle-user"></i> Next of KIN</h3>
                <form>

                    <div class="row">

                        <div class="col-md-12">
                            <div class="form-group">
                                <label class="form-label">Contact Full Name<span class="required">*</span></label>
                                <input v-model="form.next_of_kin_full_name" type="text" class="form-control datepicker" placeholder="Full name">
                                                <p class="text-danger" v-if="errors.next_of_kin_full_name">{{ errors.next_of_kin_full_name }}</p>
                            </div>
                        </div>

                        <div class="col-md-6">
                            <div class="form-group">
                                <label class="form-label">Contact’s E-mail<span class="required">*</span></label>
                                <input v-model="form.next_of_kin_email" type="text" class="form-control datepicker" placeholder="Email">
                                                <p class="text-danger" v-if="errors.next_of_kin_email">{{ errors.next_of_kin_email }}</p>
                            </div>
                        </div>

                        <div class="col-md-6">
                            <div class="form-group">
                                <label class="form-label">Contact’s Telephone<span class="required">*</span></label>
                                <input v-model="form.next_of_kin_phone" type="text" class="form-control datepicker" placeholder="Telephone">
                                                <p class="text-danger" v-if="errors.next_of_kin_phone">{{ errors.next_of_kin_phone }}</p>
                            </div>
                        </div>

                        <div class="col-md-12">
                            <div class="form-group">
                                <label class="form-label">Contact’s Relationship<span class="required">*</span></label>
                                <input v-model="form.next_of_kin_relationship" type="text" class="form-control datepicker" placeholder="Relationship">
                                                <p class="text-danger" v-if="errors.next_of_kin_relationship">{{ errors.next_of_kin_relationship }}</p>
                            </div>
                        </div>

                    </div>
                </form>

                <span v-if="userType !== 'agent'">
                    <h3><i class="fa-solid fa-circle-user"></i> Agent Details</h3>
                    <form>

                        <div class="row">

                            <div class="col-md-6">
                                <div class="form-group">
                                    <label class="form-label">Are you receiving advice from an education agent?<span class="required">*</span></label>
                                    <v-select  label="label" v-model="form.agent_assistance" :options="selectDropbox"  :reduce="option => option.value" >
                                        <template #no-options="{ search, searching, loading }">
                                            <span>No options available</span>
                                        </template>
                                    </v-select>
                                    <p class="text-danger" v-if="errors.agent_assistance">{{ errors.agent_assistance }}</p>
                                </div>
                            </div>

                            <div class="col-md-6">
                                <div v-if="form.agent_assistance == true" class="form-group">
                                    <label class="form-label">What is the name of the agent?<span class="required">*</span></label>
                                    <input v-model="form.agent_name" type="text" class="form-control datepicker" placeholder="Name">
                                    <p class="text-danger" v-if="errors.agent_name">{{ errors.agent_name }}</p>
                                </div>
                            </div>

                        </div>
                    </form>
                </span>

            </form>
        </div>
        <div class="wizard-controls">
            <ul class="">
                <li>
                    <a @click="submit()" class="btn btn-primary nextBtn" :disabled="loading">
                        <span class="nextBtnText">Next </span>
                        <i v-if="loading" class="fa fa-spinner fa-spin"></i>
                        <i v-else class="fa-solid fa-arrow-right-long"></i>
                    </a>
                </li>
            </ul>
        </div>
    </div>

</template>

<script>
import vSelect from "vue-select";
import Datepicker from "@vuepic/vue-datepicker";
import {HttpService} from "../../../services/HttpService";
import { useFormStore } from '../../../stores/applicationForm';
import moment from 'moment';
import generalHelpers from "../../../helpers/generalHelpers";
export default {

    // Pinia state setup to initialize state data
    setup(){
        const formStore  = useFormStore();
        const {resetApplicationState,addApplicationData, getApplicationData} = formStore;
        return {resetApplicationState, addApplicationData, getApplicationData};
    },

    props:['countries', 'visas', 'applicationDetail', 'languages', 'userType','step'],
    name: "personal-details",
    components: {
        vSelect,
        Datepicker
    },
    data() {
        var self = this;
        return {
            data: null,
            loading:false,
            dobDisabled:false,
            visaDisabled:false,
            request: new HttpService(),
            form: {
                // form values
                salutation: null,
                gender: null,
                other_salutation: null,
                first_name: null,
                middle_name: null,
                last_name: null,
                email: null,
                mobile: null,
                marketing_consent: false,
                dob: null,
                passport_number: null,
                country: null,
                country_of_birth: null,
                language: null,
                occupation: null,
                living_in_australia: null,
                australian_resident: null,
                has_australian_visa:null,
                current_visa_type:null,
                current_visa_expiry:null,
                has_had_student_visa:null,
                visa_applying_for:null,
                visa_application_australia:null,
                visa_application_location:null,
                current_residence_address_line_1:null,
                current_residence_address_line_2:null,
                current_residence_address_line_3:null,
                current_residence_address_state:null,
                current_residence_address_city:null,
                current_residence_address_postcode:null,
                current_residence_address_country:null,
                next_of_kin_full_name:null,
                next_of_kin_phone:null,
                next_of_kin_email:null,
                next_of_kin_relationship:null,
                agent_assistance:0,
                agent_name:null,
            },
            errors: {

            },
            salutations:[
                {
                    label:'Miss',
                },
                {
                    label:'Mrs',
                },
                {
                    label:'Ms',
                },
                {
                    label:'Mr',
                },
                {
                    label:'Other',
                }
            ],
            genders:[
                {
                    label:'Male',
                },
                {
                    label:'Female',
                },
                {
                    label:'Other',
                }
            ],
            selectDropbox:[
                {
                    label:'Yes',
                    value:1
                },
                {
                    label:'No',
                    value:0
                }
            ],
            // datepicker
            format: "dd/MM/yyyy"
        }
    },
    mounted() {

        // getting application details from pinia

        this.data = this.getApplicationData('personal_details');
        if (typeof this.data.id !== 'undefined') {
            this.dobDisabled = true;
            this.visaDisabled = true;
            this.setValues();
        }
    },
    methods: {

        enableField(field = 'dob'){
            if(field === 'dob' && this.dobDisabled === false){
                return false;
            }

            if(field === 'visa' && this.visaDisabled === false){
                return false;
            }

            let self = this;
            Swal.fire({
                customClass: {
                    confirmButton: 'btn btn-info text-white px-3',
                    cancelButton: 'btn btn-outline-secondary px-3 mx-3',
                },
                buttonsStyling: false,
                reverseButtons: true,
                title: 'Are you sure?',
                text: "Modifying this field will reset  the data for the next steps.",
                icon: 'warning',
                showCancelButton: true,
            }).then((result) => {
                if (result.isConfirmed) {
                    if(field === 'dob')
                        this.dobDisabled = false;
                    else
                        this.visaDisabled = false;
                }
            });
        },

        async submit() {
            let self = this;
            if(this.loading){
                return;
            }

            if(this.validateData()){
                this.showToast("There are errors on the form! Please update and try again", false);
                return;
            }

            let formData = this.getFormData();
            if(typeof this.data.id !== 'undefined'){
                this.makeUpdateRequest(formData);
            }else{
                this.makeCreateRequest(formData);
            }
        },
        getFormData(){
            let formData = this.form;
            return formData;
        },
        // update request
        makeUpdateRequest(formData){
            let self = this;
            this.loading = true;
            this.request.patch(route('applications.personal-details.update', this.data.application_id), formData)
                .then(function (response) {
                    self.loading = false;
                    if(response.success){
                        if(response.clearState)
                            self.resetApplicationState();

                        response.data.visa_applying_for = response.data.visa_applying_for.id
                        self.addApplicationData('personal_details', response.data);
                        self.$emit('nextStep');
                    }else{
                        generalHelpers.showToast(response.message,response.success);
                    }
                }).catch(function (err) {
                self.loading = false;
                if(typeof err.data.errors !== 'undefined'){
                    self.showErrors(err.data.errors);
                    generalHelpers.showToast("There are errors on the form! Please update and try again!", false);
                }
                if(err.status == 500){
                    generalHelpers.showToast("Something went wrong", false);
                }
            });
        },
        // create request
        makeCreateRequest(formData){
            let self = this;
            this.loading = true;
            return this.request.post(route('applications.personal-details.store'), formData,{})
                .then(function (response) {
                    self.loading = false;
                    if(response.success){
                        self.addApplicationData('personal_details', response.data)
                        self.$emit('applicationNumber', `Application ${response.data.application_id}`)
                        self.$emit('nextStep')
                    }else{
                        generalHelpers.showToast(response.message,response.success);
                    }
                }).catch(function (err) {
                    self.loading = false;
                    if(typeof err.data.errors !== 'undefined'){
                        self.showErrors(err.data.errors);
                        generalHelpers.showToast("There are errors on the form! Please update and try again", false);
                    }
                    if(err.status == 500){
                        generalHelpers.showToast("Something went wrong", false);
                    }
                });
        },
        // show validation errors from backend
        showErrors(errors){
            for (var key in errors) {
                this.errors[key] = errors[key][0];
            }
            this.serviceErrors = true;
            this.addonErrors = true;
        },
        // show toaster
        showToast(message, isSuccess) {
            new bs5.Toast({
                body: message,
                className: !isSuccess ? 'border-0 bg-danger text-white' : 'border-0 bg-success text-white',
                btnCloseWhite: true,
            }).show();
        },
        // validate form
        validateData() {
            let self = this;
            let check = false;
            let today = moment();

            $.each(self.errors, function (fieldName) {
                self.errors[fieldName] = ''
            });

            if (! this.form.salutation || this.form.salutation === '' || typeof this.form.salutation == 'undefined') {
                check = true;
                this.errors.salutation = "This field is required"
            }
            if (! this.form.gender || this.form.gender === '' || typeof this.form.gender == 'undefined') {
                check = true;
                this.errors.gender = "This field is required"
            }

            if( this.form.salutation === 'Other' &&
                (! this.form.other_salutation || this.form.other_salutation === '' || typeof this.form.other_salutation == 'undefined') ) {
                check = true;
                this.errors.other_salutation = "This field is required"
            }
            if (! this.form.first_name || this.form.first_name === '' || typeof this.form.first_name == 'undefined') {
                check = true;
                this.errors.first_name = "This field is required"
            }
            if (! this.form.passport_number || this.form.passport_number === '' || typeof this.form.passport_number == 'undefined') {
                check = true;
                this.errors.passport_number = "This field is required"
            }else {
                if ( this.form.passport_number.length < 2 || this.form.passport_number.length > 30 ){
                    check = true;
                    this.errors.passport_number = "This field should be greater than 2 and less than 30 characters long";
                }
            }
            if (! this.form.last_name || this.form.last_name === '' || typeof this.form.last_name == 'undefined') {
                check = true;
                this.errors.last_name = "This field is required"
            }
            if (! this.form.email || this.form.email === '' || typeof this.form.email == 'undefined') {
                check = true;
                this.errors.email = "This field is required"
            }

            if(this.form.email){
                if(!this.isValidEmail(this.form.email)){
                    check = true;
                    this.errors.email = "Enter a valid email address"
                }
            }

            if (! this.form.dob || this.form.dob === '' || typeof this.form.dob == 'undefined') {
                check = true;
                this.errors.dob = "This field is required"
            }

            if (! this.form.country || this.form.country === '' || typeof this.form.country == 'undefined') {
                check = true;
                this.errors.country = "This field is required"
            }
            if (! this.form.country_of_birth || this.form.country_of_birth === '' || typeof this.form.country_of_birth == 'undefined') {
                check = true;
                this.errors.country_of_birth = "This field is required"
            }
            if (! this.form.language || this.form.language === '' || typeof this.form.language == 'undefined') {
                check = true;
                this.errors.language = "This field is required"
            }
            if (this.form.living_in_australia === null || this.form.living_in_australia === '' || typeof this.form.living_in_australia == 'undefined') {
                check = true;
                this.errors.living_in_australia = "This field is required"
            }
            if (this.form.australian_resident === null || this.form.australian_resident === '' || typeof this.form.australian_resident == 'undefined') {
                check = true;
                this.errors.australian_resident = "This field is required"
            }
            if (this.form.has_had_student_visa === null || this.form.has_had_student_visa === '' || typeof this.form.has_had_student_visa == 'undefined') {
                check = true;
                this.errors.has_had_student_visa = "This field is required"
            }
            if (this.form.has_australian_visa === null || this.form.has_australian_visa === '' || typeof this.form.has_australian_visa == 'undefined') {
                check = true;
                this.errors.has_australian_visa = "This field is required"
            }else {
                if ( this.form.has_australian_visa === 1 && ( ! this.form.current_visa_type || this.form.current_visa_type === '' || typeof this.form.current_visa_type == 'undefined' ) ){
                    check = true;
                    this.errors.visa_type = "This field is required"
                }
                if ( this.form.has_australian_visa === 1 && ( ! this.form.current_visa_expiry || this.form.current_visa_expiry === '' || typeof this.form.current_visa_expiry == 'undefined' ) ){
                    check = true;
                    this.errors.current_visa_expiry = "This field is required"
                }
            }
            if (! this.form.visa_applying_for || this.form.visa_applying_for === '' || typeof this.form.visa_applying_for == 'undefined') {
                check = true;
                this.errors.visa_applying_for = "This field is required"
            }
            if (this.form.visa_application_australia === null || this.form.visa_application_australia === '' || typeof this.form.visa_application_australia == 'undefined') {
                check = true;
                this.errors.visa_application_australia = "This field is required"
            }else {
                if ( this.form.visa_application_australia === 0 && ( ! this.form.visa_application_location || this.form.visa_application_location === '' || typeof this.form.visa_application_location == 'undefined' ) ){
                    check = true;
                    this.errors.visa_application_location = "This field is required"
                }
            }
            if (! this.form.current_residence_address_line_1 || this.form.current_residence_address_line_1 === '' || typeof this.form.current_residence_address_line_1 == 'undefined') {
                check = true;
                this.errors.current_residence_address_line_1 = "This field is required"
            }
            if (! this.form.current_residence_address_city || this.form.current_residence_address_city === '' || typeof this.form.current_residence_address_city == 'undefined') {
                check = true;
                this.errors.current_residence_address_city = "This field is required"
            }
            if (! this.form.current_residence_address_postcode || this.form.current_residence_address_postcode === '' || typeof this.form.current_residence_address_postcode == 'undefined') {
                check = true;
                this.errors.current_residence_address_postcode = "This field is required"
            }
            if (! this.form.current_residence_address_country || this.form.current_residence_address_country === '' || typeof this.form.current_residence_address_country == 'undefined') {
                check = true;
                this.errors.current_residence_address_country = "This field is required"
            }
            if (! this.form.next_of_kin_full_name || this.form.next_of_kin_full_name === '' || typeof this.form.next_of_kin_full_name == 'undefined') {
                check = true;
                this.errors.next_of_kin_full_name = "This field is required"
            }
            if (! this.form.next_of_kin_email || this.form.next_of_kin_email === '' || typeof this.form.next_of_kin_email == 'undefined') {
                check = true;
                this.errors.next_of_kin_email = "This field is required"
            }

            if(this.form.next_of_kin_email){
                if(!this.isValidEmail(this.form.next_of_kin_email)){
                    check = true;
                    this.errors.next_of_kin_email = "Email format not correct"
                }
            }

            if (! this.form.next_of_kin_phone || this.form.next_of_kin_phone === '' || typeof this.form.next_of_kin_phone == 'undefined') {
                check = true;
                this.errors.next_of_kin_phone = "This field is required"
            }
            if (! this.form.next_of_kin_relationship || this.form.next_of_kin_relationship === '' || typeof this.form.next_of_kin_relationship == 'undefined') {
                check = true;
                this.errors.next_of_kin_relationship = "This field is required"
            }
            if ( this.form.agent_assistance === '' || typeof this.form.agent_assistance == 'undefined') {
                check = true;
                this.errors.agent_assistance = "This field is required"
            }else {
                if ( this.form.agent_assistance === 1 && (! this.form.agent_name || this.form.agent_name === '' || typeof this.form.agent_name == 'undefined') ) {
                    check = true;
                    this.errors.agent_name = "This field is required"
                }
            }

            return check;
        },
        setValues(){
            this.form.salutation = this.data.salutation;
            this.form.other_salutation = this.data.other_salutation;
            this.form.gender = this.data.gender;
            this.form.first_name = this.data.first_name;
            this.form.middle_name = this.data.middle_name;
            this.form.last_name = this.data.last_name;
            this.form.email = this.data.email;
            this.form.mobile = this.data.mobile;
            this.form.marketing_consent = this.data.marketing_consent;
            this.form.dob = this.data.dob;
            this.form.passport_number = this.data.passport_number;
            this.form.country = this.data.country;
            this.form.country_of_birth = this.data.country_of_birth;
            this.form.language = this.data.language;
            this.form.occupation = this.data.occupation;
            this.form.living_in_australia = this.data.living_in_australia;
            this.form.australian_resident = this.data.australian_resident;
            this.form.has_australian_visa = this.data.has_australian_visa;
            this.form.current_visa_type = this.data.current_visa_type;
            this.form.current_visa_expiry = this.data.current_visa_expiry;
            this.form.has_had_student_visa = this.data.has_had_student_visa;
            this.form.visa_applying_for = this.data.visa_applying_for;
            this.form.visa_application_australia = this.data.visa_application_australia;
            this.form.visa_application_location = this.data.visa_application_location;
            this.form.current_residence_address_line_1 = this.data.current_residence_address_line_1;
            this.form.current_residence_address_line_2 = this.data.current_residence_address_line_2;
            this.form.current_residence_address_line_3 = this.data.current_residence_address_line_3;
            this.form.current_residence_address_state = this.data.current_residence_address_state;
            this.form.current_residence_address_city = this.data.current_residence_address_city;
            this.form.current_residence_address_postcode = this.data.current_residence_address_postcode;
            this.form.current_residence_address_country = this.data.current_residence_address_country;
            this.form.next_of_kin_full_name = this.data.next_of_kin_full_name;
            this.form.next_of_kin_phone = this.data.next_of_kin_phone;
            this.form.next_of_kin_email = this.data.next_of_kin_email;
            this.form.next_of_kin_relationship = this.data.next_of_kin_relationship;
            this.form.agent_assistance = this.data.agent_assistance;
            this.form.agent_name = this.data.agent_name;
        },

        isValidEmail(email){
            return email.match(
                /^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/
            );
        }
    },
    watch : {
        'form.first_name':function(newVal,oldVal){
            this.$emit('firstNameVal', newVal)
        },

        'form.last_name':function(newVal,oldVal){
            this.$emit('lastNameVal', newVal)
        },

        'form.visa_applying_for':function(newVal,oldVal){
            this.visas.map( visa => {
                if (visa.id === newVal){
                    this.$emit('insuranceTabCheck', visa.is_student == 1)
                }
            })
        }
    },
    computed: {
        sectionId(){
            return 'step-'+this.step;
        },
        consentString() {
            return "I do not give permission for Imagine Education Australia to contact me by e-mail or SMS for marketing purposes"
        }
    },
}
</script>

