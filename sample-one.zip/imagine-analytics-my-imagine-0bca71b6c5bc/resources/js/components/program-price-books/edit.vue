<template>

    <div v-if="form.expired"  class="alert alert-warning d-flex align-items-center" role="alert">
        <div>
            This pricebook has expired. Update the expiry date to any date in the future to make it available.
        </div>
    </div>

    <form>
        <div class="mt-2">
            <div class="form-group form-check form-switch">
                <input type="hidden" name="enabled" value="0">
                <input v-model="form.enabled" class="form-check-input" id="enabled" type="checkbox" >
                <label class="form-check-label" for="enabled">Active</label>
            </div>
        </div>

        <!--   Name Field     -->
        <div class="col-12 form-group required mt-3">
            <label class="form-label">Name</label>
            <input placeholder="Name" v-model="form.name" type="text" class="form-control" required >
            <p class="text-danger" v-if="errors.name">{{ errors.name }}</p>
        </div>

        <!--    Description  Field  -->
        <div class="col-12 form-group mt-3">
            <label class="form-label">Description</label>
            <textarea class="form-control" maxlength="255" id="description" name="description" rows="3" placeholder="Description" v-model="form.description"></textarea>
        </div>


        <!--    Category Field   -->
        <div class="col-12 form-group required mt-2">
            <label class="form-label">Category</label>
            <v-select  label="name" v-model="form.program_price_book_category_id" :options="categories" :reduce="option => option.id" placeholder="Choose Category...">
                <template #no-options="{ search, searching, loading }">
                    <span>No options available</span>
                </template>
            </v-select>
            <p class="text-danger" v-if="errors.category">{{ errors.category }}</p>
        </div>

        <!--    Expiry date  Field  -->
        <div class="col-12 form-group required mt-3">
            <label class="form-label">Expiry Date</label>
            <Datepicker utc="preserve" v-model="form.expiry_date" placeholder="dd/mm/yyyy" textInput autoApply :format="format" :closeOnAutoApply="true" :enableTimePicker="false" required></Datepicker>
            <p class="text-danger" v-if="errors.expiry_date">{{ errors.expiry_date }}</p>
        </div>

        <!--   Date rows header    -->
        <div class="row mt-4 justify-content-center">
            <div class="col-3">
                <label class="form-label">Min</label>
            </div>
            <div class="col-3">
                <label class="form-label">Max</label>
            </div>
            <div class="col-3">
                <label class="form-label">Fee ($)</label>
            </div>
            <div class="col-1">
                <label class="form-label">Action</label>
            </div>
        </div>
        <!--   Date rows data    -->
        <div v-for="(rate,index) in rates" :key="rate.id">
            <input type="hidden" :value="rate.id">
            <div class="row mt-2 justify-content-center">
                <div class="col-3">
                    <input v-model="rate.min" class="form-control" placeholder="Min" type="number" required/>
                    <span class="text-danger" v-if="errorText(rate,'min_error')">{{errorText(rate,'min_error')}}</span>
                </div>
                <div class="col-3">
                    <input v-model="rate.max" class="form-control" placeholder="Max" type="number" required/>
                    <span class="text-danger" v-if="errorText(rate,'max_error')">{{errorText(rate,'max_error')}}</span>
                </div>
                <div class="col-3">
                    <input v-model="rate.price" class="form-control" placeholder="Price" type="number" required min="0" oninput="validity.valid||(value='');" />
                    <span class="text-danger" v-if="errorText(rate,'price_error')">{{errorText(rate,'price_error')}}</span>
                </div>
                <div class="col-1">
                    <button @click="removeDateFields(rate.id, index)" class="btn btn-sm btn-outline-danger" type="button"><i class="fa fa-close"></i></button>
                </div>
            </div>
        </div>

        <!--   add new row     -->
        <div class="row mt-4">
            <div class="row">
                <div class="col-2 offset-1">
                    <button @click="addDateFields" type="button" class="btn btn-outline-success"><i class="fa fa-plus"></i> Add new</button>
                </div>
            </div>
        </div>
        <hr>
        <div class="row mt-5">
            <div class="d-flex justify-content-between">
                <a v-if="showBackBtn" :href="backUrl" class="btn btn-outline-secondary">
                    <i data-feather="arrow-left"></i>
                    Back
                </a>
                <a v-else :href="cancelUrl" class="btn btn-outline-secondary">
                    <!-- <i data-feather="arrow-left"></i> -->
                    Cancel
                </a>
                <button @click="submit" type="button" class="btn btn-primary" :disabled="loading"><i class="fa fa-spinner fa-spin" v-if="loading"></i>{{ formBtnText }}</button>
            </div>
        </div>

    </form>
</template>

<script>
import vSelect from "vue-select";
import 'bs5-toast'
import Datepicker from '@vuepic/vue-datepicker';
import '@vuepic/vue-datepicker/dist/main.css'
import {HttpService} from "../../services/HttpService";
import moment from "moment";
export default {
    props: [
        'priceBook',
        'priceBookRates',
        'categories'
    ],
    components: {
        vSelect,
        Datepicker
    },
    data() {
        return {
            request: new HttpService(),
            loading:false,
            selectCategory: null,
            rates: [],
            deletedFees: [],
            form :{
                name:'',
                expiry_date:'',
                expired : false,
                enabled : false,
                description: '',
                program_price_book_category_id:null,
            },
            errors:{
                name:'',
                category:'',
                expiry_date:'',
                program_price_book_category_id:'',
            },
            // datepicker
            format: "dd/MM/yyyy"
        }
    },
    mounted() {

        if(typeof this.priceBook !== 'undefined'){
            this.setValues();
        }

        if(typeof this.priceBookRates !== 'undefined'){
            this.rates = this.priceBookRates;
        }

    },
    methods: {
        // add new date field row
        addDateFields(){
            let fields = {
                max: null,
                min: null,
                price: null,
            };

            this.rates.push(fields)
        },
        // remove date field row
        removeDateFields(id, index){
            if ( id )
                this.deletedFees.push(id)

            this.rates.splice(index, 1)
        },
        // displays error
        errorText(rate,key){
            if(rate[key] !== ''){
                return rate[key];
            }
            return '';
        },
        // submits the form
        async submit() {
            let self = this;

            if(this.validateData()){
                return;
            }

            let formData = this.getFormData();
            if(typeof this.priceBook !== 'undefined'){
                this.makeUpdateRequest(formData);
            }else{
                this.makeCreateRequest(formData);
            }
        },
        getFormData(){
            let formData = this.form;
            formData['rates'] = this.rates;
            formData['delete_fees'] = this.deletedFees;
            return formData;
        },
        // update request
        makeUpdateRequest(formData){
            let self = this;
            this.loading = true;
            this.request.patch(route('staff.settings.fees.programs.pricebooks.update', this.priceBook.id), formData)
                .then(function (response) {
                    self.loading = false;
                    if(response.success){
                        window.location.href= response.redirect_route;
                    }else{
                        self.showToast(response.message,response.success);
                    }
                }).catch(function (err) {
                    self.loading = false;
                    if(typeof err.data.errors !== 'undefined'){
                        self.showErrors(err.data.errors);
                    }
                });
        },
        // create request
        makeCreateRequest(formData){
            return this.request.post(route('staff.settings.fees.programs.pricebooks.store'), formData,{})
                .then(function (response) {
                    self.loading = false;
                    if(response.success){
                        window.location.href= response.redirect_route;
                    }else{
                        self.showToast(response.message,response.success);
                    }
                }).catch(function (err) {
                    self.loading = false;
                    if(typeof err.data.errors !== 'undefined'){
                        self.showErrors(err.data.errors);
                    }
                });
        },
        // show validation errors from backend
        showErrors(errors){
            for (var key in errors) {
                this.errors[key] = errors[key][0];
            }
        },
        // show toaster
        showToast(message, isSuccess) {
            new bs5.Toast({
                body: message,
                className: !isSuccess ? 'border-0 bg-danger text-white' : 'border-0 bg-success text-white',
                btnCloseWhite: true,
            }).show();
        },
        // validate form
        validateData(){
            let self = this;
            let check = false;

            if (this.form.name === '' ){
                check = true;
                this.errors.name = "This field is required"
            }else{
                this.errors.name = ''
            }
            if ( ! this.form.program_price_book_category_id || this.form.program_price_book_category_id === '' ){
                check = true;
                this.errors.category = "This field is required"
            }else{
                this.errors.category = ''
            }
            if ( this.form.expiry_date  === '' ){
                check = true;
                this.errors.expiry_date = "This field is required"
            }else{
                this.errors.expiry_date = ''
            }
            // validating rates
            for(let index in this.rates) {
                let item = JSON.parse(JSON.stringify(this.rates[index]));

                if ( !item.max || typeof item.max == 'undefined' || item.max === ''){
                    check = true;
                    Object.assign(this.rates[index], {max_error: 'This field is required'});
                }else{
                    this.rates[index]['max_error'] = '';
                }

                if ( !item.min || typeof item.min == 'undefined' || item.min === ''){
                    check = true;
                    Object.assign(this.rates[index], {min_error: 'This field is required'});
                }else{
                    this.rates[index]['min_error'] = '';
                }

                if ( !item.price || typeof item.price == 'undefined' || item.price === ''){
                    check = true;
                    Object.assign(this.rates[index], {price_error: 'This field is required'});
                }else{
                    this.rates[index]['price_error'] = '';
                }
            }
            return check;
        },
        // update priceBook status
        isStatusCheck(value){
            this.priceBook.enabled = value
        },

        setValues(){
            this.form.name  = this.priceBook.name;
            this.form.expiry_date  = this.priceBook.expiry_date;
            this.form.enabled  = this.priceBook.enabled == 1 ? true: false;
            this.form.description  =  this.priceBook.description;
            this.form.expired  =  this.priceBook.expired;
            this.form.program_price_book_category_id  = this.priceBook.program_price_book_category_id;
        }
    },
    computed: {
        formBtnText(){
            if(typeof this.priceBook !== 'undefined'){
                return 'Update';
            }
            return 'Create';
        },
        showBackBtn(){
            return typeof this.priceBook === 'undefined';
        },
        backUrl(){
            return route('staff.settings.fees.programs.pricebooks.index');
        },
        cancelUrl(){
            return route('staff.settings.fees.programs.pricebooks.index');
        },
    }
}
</script>
