<template>
    <div class="mt-4">
        <div class="filter-datatable">
            <div class="row filter-dropdown">
                <div class="col-3">
                    <v-select  label="name" v-model="filter.category"
                                :options="categories"
                                :change="reloadDataTable()"
                                :reduce="option => option.id" placeholder="Filter by Category">
                        <template #no-options="{ search, searching, loading }">
                            <span>No options available</span>
                        </template>
                    </v-select>
                </div>
                <div class="col-3">
                    <v-select  label="label" v-model="filter.enabled"
                                :options="enabledOptions"
                                :change="reloadDataTable()"
                                :reduce="option => option.value" placeholder="Filter by Status">
                        <template #no-options="{ search, searching, loading }">
                            <span>No options available</span>
                        </template>
                    </v-select>
                </div>
                <div class="col-3">
                    <v-select  label="label" v-model="filter.expired"
                        :options="expiryFilter"
                        :change="reloadDataTable()"
                        :reduce="option => option.value" placeholder="Filter by Expiry">
                        <template #no-options="{ search, searching, loading }">
                            <span>No options available</span>
                        </template>
                    </v-select>
                </div>
            </div>
            <table class="table table-bordered table-striped" id="price-book-table">
                <thead>
                <tr>
                    <th scope="col" >Name</th>
                    <th scope="col" class="text-center">Description</th>
                    <th scope="col" >Category</th>
                    <th scope="col" >Expired</th>
                    <th scope="col" >Expiry Date</th>
                    <th scope="col" >Status</th>
                    <th scope="col" >Action</th>
                </tr>
                </thead>
                <tbody></tbody>
            </table>
        </div>
    </div>
</template>

<script>
    import 'datatables.net-dt/js/dataTables.dataTables';
    import 'datatables.net-dt/css/jquery.dataTables.min.css';
    import 'datatables.net-dt/js/dataTables.dataTables';
    import 'datatables.net-dt/css/jquery.dataTables.min.css';
    import {HttpService} from "../../services/HttpService";
    import vSelect from "vue-select";
    export default {
        props:['categories'],
        components: {
            vSelect
        },
        data() {
            var self = this;
            return {
                request: new HttpService(),
                datatable: null,
                enabledOptions:[
                    {
                        label:'--All--',
                        value:''
                    },
                    {
                        label:'Active',
                        value:1
                    },
                    {
                        label:'Inactive',
                        value:0
                    }

                ],
                expiryFilter:[
                    {
                        label:'--All--',
                        value:''
                    },
                    {
                        label:'Yes',
                        value:1
                    },
                    {
                        label:'No',
                        value:0
                    }

                ],
                selected: null,
                filter:{
                    enabled:null,
                    expired:null,
                    category:null
                }
            }
        },
        async mounted() {
            await this.setDataTable();

        },
        computed : {
        },
        methods: {
            async setDataTable(){
                let self = this;
                this.datatable = await $('#price-book-table').DataTable( {
                    // f - indicate search-bar
                    // <tlip> - t(sign to move to bottom)| l(chaining input)| i(summary info)| p(pagination)
                    dom: 'f <tilp>',
                    processing: true,
                    serverSide: true,
                    ordering: true,
                    responsive: true,
                    ajax: {
                        url: route('staff.settings.fees.programs.pricebooks.list'),
                        data: function ( d ) {
                            d.category = self.filter.category,
                            d.enabled =  self.filter.enabled,
                            d.expired = self.filter.expired
                        },
                    },
                    columns: [
                        {data: 'name', name: 'name', orderable: true},
                        {data: 'description', name: 'description', class: 'pre-wrap', orderable: false},
                        {data: 'category', name: 'category',orderable: true},
                        {data: 'expired', name: 'expired',orderable: false},
                        {data: 'expiry_date', name: 'expiry_date',orderable: false},
                        {data: 'enabled', name: 'enabled',orderable: false},
                        {data:   null,
                            render : function ( data, type, full, meta ) {
                                return `<a class="text-end small clone-price-book cursor-pointer" >
                                            <i class="fa fa-clone"> </i>
                                        </a>`
                            }
                        }
                    ]
                });

                $('tbody', this.$refs.table).on( 'click', '.clone-price-book', function(){
                    const cell = self.datatable.cell( $(this).closest("td") );
                    self.clonePriceBook(cell.data())
                });
            },
            reloadDataTable(){
                if ( this.datatable ) {
                    this.datatable.draw();
                }
            },
            clonePriceBook(data){
                let self = this;
                Swal.fire({
                    customClass: {
                        confirmButton: 'btn btn-info text-white px-3',
                        cancelButton: 'btn btn-outline-secondary px-3 mx-3',
                    },
                    confirmButtonText: "Confirm",
                    cancelButtonText: "Cancel",
                    buttonsStyling: false,
                    reverseButtons:true,
                    title: 'Are you sure?',
                    text: "Are you sure you want to clone this price book?",
                    icon: 'warning',
                    showCancelButton: true,
                }).then((result) => {
                    if (result.isConfirmed) {
                        this.sendClonePriceBookRequest(data.id)
                    }
                });
            },
            sendClonePriceBookRequest(id){
                let self = this;
                    return this.request.post(route('staff.settings.fees.programs.pricebooks.clone', id))
                        .then(async function (response) {
                            if (response.success){
                                self.reloadDataTable();
                                self.showToast('Price Book cloned successfully!',true)
                            }
                        }).catch(function (err) {
                    });
            },
            showToast(message, isSuccess) {
                new bs5.Toast({
                    body: message,
                    className: !isSuccess ? 'border-0 bg-danger text-white' : 'border-0 bg-success text-white',
                    btnCloseWhite: true,
                }).show();
            },
        }
    }
</script>

