<template>
    <div class="mt-4">
        <table class="table table-bordered table-striped" id="accommodation-service">
            <thead>
            <tr>
                <th scope="col" >Name</th>
                <th scope="col" >Fee</th>
                <th scope="col" >Type</th>
                <th scope="col" >Taxable</th>
                <th scope="col" >Status</th>
            </tr>
            </thead>
            <tbody></tbody>
        </table>
    </div>
</template>

<script>
import 'datatables.net-dt/js/dataTables.dataTables';
import 'datatables.net-dt/css/jquery.dataTables.min.css';
export default {
    components: {
    },
    data() {
        var self = this;
        return {
            datatable:null
        }
    },
    mounted() {
        this.setDataTable();

    },
    computed : {
    },
    methods: {
        setDataTable(){
            this.datatable = $('#accommodation-service').DataTable( {
                // f - indicate search-bar
                // <tlip> - t(sign to move to bottom)| l(chaining input)| i(summary info)| p(pagination)
                dom: 'f <tilp>',
                processing: true,
                serverSide: true,
                ordering: true,
                responsive: true,
                ajax: route('staff.settings.fees.accommodation.fee-services.list'),
                columns: [
                    {data: 'name', name: 'name', orderable: true},
                    {data: 'fee', name: 'fee'},
                    {data: 'type', name: 'type'},
                    {data: 'taxable', name: 'taxable'},
                    {data: 'enabled', name: 'enabled'},
                ]
            });
        }
    }
}
</script>
