<template>
    <form>

        <div class="mt-2">
            <div class="form-group form-check form-switch">
                <input type="hidden" name="enabled" value="0">
                <input @click="isStatusCheck(!form.enabled)" class="form-check-input" type="checkbox" :checked="!!form.enabled">
                <label class="form-check-label">Active</label>
            </div>
        </div>

        <!--    Name        -->
        <div class="col-12 form-group required mt-3">
            <label class="form-label">Name</label>
            <input v-model="form.name" type="text" class="form-control" required >
            <p class="text-danger" v-if="errors.name">{{ errors.name }}</p>
        </div>
        <!--    Description            -->
        <div class="col-12 form-group mt-2">
            <label class="form-label">Description</label>
            <textarea v-model="form.description" class="form-control" maxlength="255" id="description" name="description" rows="3" placeholder="">{{form.description}}</textarea>
        </div>

        <!--    Surcharge type            -->
        <div class="col-12 form-group required mt-2">
            <label class="form-label">Service Type</label>
            <v-select :loading="serviceTypes.length <= 0"
                      v-model="form.type"
                      :options="serviceTypesFilter"
                      :reduce="option => option.value"
                      append-to-body
                      placeholder="Select Service Type"
            >
            </v-select>
            <p class="text-danger" v-if="errors.type">{{ errors.type }}</p>
        </div>

        <!--    Taxable            -->
        <div class="col-12 form-group mt-2">
            <label class="form-check-label">Taxable</label>
            <div class="form-group form-check form-switch">
                <input type="hidden" name="enabled" value="0">
                <input @click="isTaxableCheck(!form.taxable)" class="form-check-input" type="checkbox" :checked="form.taxable">
            </div>
        </div>

        <!--    Fee            -->
        <div class="col-12 form-group required mt-2">
            <label class="form-label">{{ feeLabel }}</label>
            <div class="input-group">
                <div class="input-group-text">$</div>
                <input v-model="form.fee" type="number" class="form-control" required min="0" oninput="validity.valid||(value='');">
            </div>
            <p class="text-danger" v-if="errors.fee">{{ errors.fee }}</p>
        </div>

        <!--    Daily Fee            -->
        <div v-if="form.type === 'unit'" class="col-12 form-group required mt-2">
            <label class="form-label">Default Daily Fee</label>
            <div class="input-group">
                <div class="input-group-text">$</div>
                <input v-model="form.daily_fee" type="number" class="form-control" required min="0" oninput="validity.valid||(value='');">
            </div>
            <p class="text-danger" v-if="errors.daily_fee">{{ errors.daily_fee }}</p>
        </div>


        <div class="row mt-5">
            <div class="d-flex justify-content-between">
                <a v-if="showBackBtn" :href="backUrl" class="btn btn-outline-secondary">
                    <i data-feather="arrow-left"></i>
                    Back
                </a>
                <a v-else :href="cancelUrl" class="btn btn-outline-secondary">
                    <!-- <i data-feather="arrow-left"></i> -->
                    Cancel
                </a>
                <button @click="submit" type="button" class="btn btn-primary" :disabled="loading"><i class="fa fa-spinner fa-spin" v-if="loading"></i>{{ formBtnText }}</button>
            </div>
        </div>

    </form>
</template>

<script>
import vSelect from "vue-select";
import 'bs5-toast'
import {HttpService} from "../../services/HttpService";

export default {
    props: [
        'service',
        'serviceTypes',
    ],
    components: {
        vSelect,
    },
    data() {
        return {
            request: new HttpService(),
            loading:false,
            form: {
                name: null,
                description: null,
                type: null,
                taxable: false,
                fee: null,
                daily_fee: null,
                enabled: false,
            },
            errors:{
                name:'',
                type:'',
                fee:'',
                daily_fee:'',
            },
        }
    },
    mounted() {
        if(this.service.id){
            this.setFormValues()
        }
    },
    methods: {
        setFormValues(){
            this.form.name = this.service.name
            this.form.description = this.service.description
            this.form.fee = this.service.fee
            this.form.daily_fee = this.service.daily_fee
            this.form.type = this.service.type
            this.form.taxable = this.service.taxable
            this.form.enabled = this.service.enabled
        },
        // submits the form
        async submit() {
            let self = this;

            if(this.validateData()){
                return;
            }
            this.loading = true;
            let formData = this.getFormData();
            // update request
            if ( this.service.id ) {
                this.makeUpdateRequest(formData).then((response) => {
                    self.loading = false;
                    if (response.success === false) {
                        self.showToast(response.message, false)
                    } else {
                        window.location.href= response.redirect_route;
                    }
                }).catch(function (error) {
                    $.each(error.data.errors, function ( fieldName, msg ){
                        if ( self.errors.hasOwnProperty(fieldName) ) {
                            self.errors[fieldName] = msg[0];
                        }else{
                            self.showToast(error.data.message, false)
                        }
                        self.loading = false;
                    });
                });
            }else {
                // create request
                this.makeCreateRequest(formData).then((response) => {
                    self.loading = false;
                    if (response.success === false) {
                        self.showToast(response.message, false)
                    } else {
                        window.location.href= response.redirect_route;
                    }
                }).catch(function (error) {
                    $.each(error.data.errors, function ( fieldName, msg ){
                        if ( self.errors.hasOwnProperty(fieldName) ) {
                            self.errors[fieldName] = msg[0];
                        }else{
                            self.showToast(error.data.message, false)
                        }
                        self.loading = false;
                    });
                });
            }
        },
        // update request
        makeUpdateRequest(formData){
            return this.request.patch(route('staff.settings.fees.accommodation.fee-services.update', this.service.id), formData,{})
        },
        // create request
        makeCreateRequest(formData){
            return this.request.post(route('staff.settings.fees.accommodation.fee-services.store'), formData,{})
        },
        // get form data
        getFormData(){
            return {
                'name': this.form.name,
                'description': this.form.description,
                'type': this.form.type,
                'taxable': this.form.taxable,
                'fee': parseFloat(this.form.fee).toFixed(2),
                'enabled': this.form.enabled,
                'daily_fee': this.form.daily_fee,
            };
        },
        // show toaster
        showToast(message, isSuccess) {
            new bs5.Toast({
                body: message,
                className: !isSuccess ? 'border-0 bg-danger text-white' : 'border-0 bg-success text-white',
                btnCloseWhite: true,
            }).show();
        },
        // validates form
        validateData(){
            let self = this;
            let check = false;

            $.each( self.errors, function (fieldName) {self.errors[fieldName] = '';});

            if ( ! this.form.name || typeof this.form.name == 'undefined' || this.form.name === '' ){
                check = true;
                this.errors.name = "This field is required"
            }
            if ( ! this.form.type || typeof this.form.type == 'undefined' || this.form.type === '' ){
                check = true;
                this.errors.type = "This field is required"
            }else {
                // if type is unit then daily fee is required
                if (this.form.type === 'unit') {
                    if (!this.form.daily_fee || typeof this.form.daily_fee == 'undefined' || this.form.daily_fee === '') {
                        check = true;
                        this.errors.daily_fee = "This field is required"
                    }
                }
            }

            if ( typeof this.form.fee == 'undefined' || this.form.fee === '' || this.form.fee===null ){
                check = true;
                this.errors.fee = "This field is required"
            }

            return check;
        },
        // update taxable checkbox
        isTaxableCheck(value){
            this.form.taxable = value
        },
        // update program service status
        isStatusCheck(value){
            this.form.enabled = value
        },
    },
    watch: {
        'form.type' : {
            handler: function (newVal, oldVal) {
                if( oldVal && newVal !== oldVal ){
                    this.form.daily_fee = null;
                    this.errors.daily_fee = '';
                }
            },
            deep: true
        }
    },
    computed: {
        formBtnText(){
            if(typeof this.service.id !== 'undefined'){
                return 'Update';
            }
            return 'Create';
        },
        showBackBtn(){
            return typeof this.service === 'undefined';
        },
        backUrl(){
            return route('staff.settings.fees.accommodation.fee-services.index');
        },
        cancelUrl(){
            return route('staff.settings.fees.accommodation.fee-services.index');
        },
        feeLabel(){
            if ( this.form.type === 'unit' ){
                return 'Default Weekly Fee'
            }
            return 'Default Fee'
        },
        serviceTypesFilter(){
            let types = [];
            for ( let item in this.serviceTypes) {
                types.push({label:this.serviceTypes[item].label, value:this.serviceTypes[item].key})
            }
            return types;
        }
    }
}
</script>
