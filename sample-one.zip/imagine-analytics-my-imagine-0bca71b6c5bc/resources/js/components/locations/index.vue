<template>
    <div class="mt-4">
        <table class="table table-bordered table-striped" id="location-table">
            <thead>
            <tr>
                <th scope="col" >Name</th>
                <th scope="col" >Status</th>
                <th scope="col" >eBECAS Id</th>
            </tr>
            </thead>
            <tbody></tbody>
        </table>
    </div>
</template>

<script>
    import 'datatables.net-dt/js/dataTables.dataTables';
    import 'datatables.net-dt/css/jquery.dataTables.min.css';
    export default {
        components: {
        },
        data() {
            var self = this;
            return {
                datatable:null
            }
        },
        mounted() {
            this.setDataTable();
        },
        computed : {
        },
        methods: {
            setDataTable(){
                this.datatable = $('#location-table').DataTable( {
                    // f - indicate search-bar
                    // <tlip> - t(sign to move to bottom)| l(chaining input)| i(summary info)| p(pagination)
                    dom: 'f <tilp>',
                    processing: true,
                    serverSide: true,
                    ordering: true,
                    responsive: true,
                    ajax: route('staff.settings.locations.list'),
                    columns: [
                        {data: 'name', name: 'name', orderable: true},
                        {data: 'enabled', name: 'enabled', orderable: false},
                        {data: 'ebecas_id', name: 'ebecas_id', orderable: false},
                    ]
                });
            }
        }
    }
</script>

