<template>
    <div class="mt-4">
        <table class="table table-bordered table-striped" id="accommodation-addon-table">
            <thead>
            <tr>
                <th scope="col" >Name</th>
                <th scope="col" >Weekly Fee</th>
                <th scope="col" >Taxable</th>
                <th scope="col" >Status</th>
            </tr>
            </thead>
            <tbody></tbody>
        </table>
    </div>
</template>

<script>
    import 'datatables.net-dt/js/dataTables.dataTables';
    import 'datatables.net-dt/css/jquery.dataTables.min.css';
    import 'datatables.net-dt/js/dataTables.dataTables';
    import 'datatables.net-dt/css/jquery.dataTables.min.css';
    import vSelect from "vue-select";
    export default {
        props:['categories'],
        components: {
            vSelect
        },
        data() {
            var self = this;
            return {
                datatable: null,
            }
        },
        mounted() {
            this.setDataTable();

        },
        computed : {
        },
        methods: {
            setDataTable(){
                let self = this;
                this.datatable = $('#accommodation-addon-table').DataTable( {
                    dom: 'f <tilp>',
                    processing: true,
                    serverSide: true,
                    ordering: true,
                    responsive: true,
                    ajax: {
                        url: route('staff.settings.fees.accommodation.fee-addons.list'),
                    },
                    columns: [
                        {data: 'name', name: 'name', orderable: true},
                        {data: 'weekly_fee', name: 'weekly_fee',orderable: false},
                        {data: 'taxable', name: 'taxable',orderable: false},
                        {data: 'enabled', name: 'enabled',orderable: false},
                    ]
                });
            },
        }
    }
</script>

