<template>
    <form>

        <div class="mt-2">
            <div class="form-group form-check form-switch">
                <input type="hidden" name="enabled" value="0">
                <input @click="isStatusCheck(!form.enabled)" class="form-check-input" type="checkbox" :checked="!!form.enabled">
                <label class="form-check-label">Active</label>
            </div>
        </div>

            <!--    Name        -->
        <div class="col-12 form-group required mt-3">
                <label class="form-label">Name</label>
                <input v-model="form.name" type="text" class="form-control" required >
                <p class="text-danger" v-if="errors.name">{{ errors.name }}</p>
        </div>
            <!--    Description            -->
        <div class="col-12 form-group mt-2">
                <label class="form-label">Description</label>
                <textarea v-model="form.description" class="form-control" maxlength="255" id="description" name="description" rows="3" placeholder="">{{form.description}}</textarea>
        </div>

            <!--    Taxable            -->
        <div class="col-12 form-group mt-2">
            <label class="form-check-label">Taxable</label>
            <div class="form-group form-check form-switch">
                <input type="hidden" name="enabled" value="0">
                <input @click="isTaxableCheck(!form.taxable)" class="form-check-input" type="checkbox" :checked="form.taxable">
            </div>
        </div>

            <!--    weekly fee            -->
        <div class="col-12 form-group required mt-2">
            <label class="form-label">Daily fee</label>
            <div class="input-group">
                <div class="input-group-text">$</div>
                <input v-model="form.daily_fee" type="number" class="form-control" required min="0" oninput="validity.valid||(value='');">
            </div>
            <p class="text-danger" v-if="errors.daily_fee">{{ errors.daily_fee }}</p>
        </div>

        <!--    daily fee            -->
        <div class="col-12 form-group required mt-2">
            <label class="form-label">Weekly fee</label>
            <div class="input-group">
                <div class="input-group-text">$</div>
                <input v-model="form.weekly_fee" type="number" class="form-control" required min="0" oninput="validity.valid||(value='');">
            </div>
            <p class="text-danger" v-if="errors.weekly_fee">{{ errors.weekly_fee }}</p>
        </div>


        <div class="row mt-5">
            <div class="d-flex justify-content-between">
                <a v-if="showBackBtn" :href="backUrl" class="btn btn-outline-secondary">
                    <i data-feather="arrow-left"></i>
                    Back
                </a>
                <a v-else :href="cancelUrl" class="btn btn-outline-secondary">
                    <!-- <i data-feather="arrow-left"></i> -->
                    Cancel
                </a>
                <button @click="submit" type="button" class="btn btn-primary" :disabled="loading"><i class="fa fa-spinner fa-spin" v-if="loading"></i>{{ formBtnText }}</button>
            </div>
        </div>

    </form>
</template>

<script>
    import 'bs5-toast'
    import {HttpService} from "../../services/HttpService";
    export default {
        props: [
            'addon',
        ],
        components: {
        },
        data() {
            return {
                request: new HttpService(),
                loading:false,
                form: {
                    name: null,
                    description: null,
                    taxable: false,
                    weekly_fee: null,
                    daily_fee: null,
                    enabled: false,
                },
                errors:{
                    name:'',
                    weekly_fee:'',
                    daily_fee:'',
                },
            }
        },
        mounted() {
            if(this.addon.id){
                this.setFormValues()
            }
        },
        methods: {
            setFormValues(){
                this.form.name = this.addon.name
                this.form.description = this.addon.description
                this.form.weekly_fee = this.addon.weekly_fee
                this.form.daily_fee = this.addon.daily_fee
                this.form.taxable = this.addon.taxable
                this.form.enabled = this.addon.enabled
            },
            // submits the form
            async submit() {
                let self = this;

                if(this.validateData()){
                    return;
                }
                this.loading = true;
                let formData = this.getFormData();
                // update request
                if ( this.addon.id ) {
                    this.makeUpdateRequest(formData).then((response) => {
                        self.loading = false;
                        if (response.success === false) {
                            self.showToast(response.message, false)
                        } else {
                            window.location.href= response.redirect_route;
                        }
                    }).catch(function (error) {
                        $.each(error.data.errors, function ( fieldName, msg ){
                            if ( self.errors.hasOwnProperty(fieldName) ) {
                                self.errors[fieldName] = msg[0];
                            }else{
                                self.showToast(error.data.message, false)
                            }
                            self.loading = false;
                        });
                    });
                }else {
                    // create request
                    this.makeCreateRequest(formData).then((response) => {
                        self.loading = false;
                        if (response.success === false) {
                            self.showToast(response.message, false)
                        } else {
                            window.location.href= response.redirect_route;
                        }
                    }).catch(function (error) {
                        $.each(error.data.errors, function ( fieldName, msg ){
                            if ( self.errors.hasOwnProperty(fieldName) ) {
                                self.errors[fieldName] = msg[0];
                            }else{
                                self.showToast(error.data.message, false)
                            }
                            self.loading = false;
                        });
                    });
                }
            },
            // update request
            makeUpdateRequest(formData){
                return this.request.patch(route('staff.settings.fees.accommodation.fee-addons.update', this.addon.id), formData,{})
            },
            // create request
            makeCreateRequest(formData){
                return this.request.post(route('staff.settings.fees.accommodation.fee-addons.store'), formData,{})
            },
            // get form data
            getFormData(){
                return {
                    'name': this.form.name,
                    'description': this.form.description,
                    'taxable': this.form.taxable,
                    'weekly_fee': parseFloat(this.form.weekly_fee).toFixed(2),
                    'daily_fee': parseFloat(this.form.daily_fee).toFixed(2),
                    'enabled': this.form.enabled,
                };
            },
            // show toaster
            showToast(message, isSuccess) {
                new bs5.Toast({
                    body: message,
                    className: !isSuccess ? 'border-0 bg-danger text-white' : 'border-0 bg-success text-white',
                    btnCloseWhite: true,
                }).show();
            },
            // validates form
            validateData(){
                let self = this;
                let check = false;

                $.each( self.errors, function (fieldName) {self.errors[fieldName] = ''});

                if ( ! this.form.name || typeof this.form.name == 'undefined' || this.form.name === '' ){
                    check = true;
                    this.errors.name = "This field is required"
                }else{
                    this.errors.name = ''
                }
                if ( ! this.form.weekly_fee || typeof this.form.weekly_fee == 'undefined' || this.form.weekly_fee === '' ){
                    check = true;
                    this.errors.weekly_fee = "This field is required"
                }else{
                    this.errors.weekly_fee = ''
                }
                if ( ! this.form.daily_fee || typeof this.form.daily_fee == 'undefined' || this.form.daily_fee === '' ){
                    check = true;
                    this.errors.daily_fee = "This field is required"
                }else{
                    this.errors.daily_fee = ''
                }

                return check;
            },
            // update taxable checkbox
            isTaxableCheck(value){
                this.form.taxable = value
            },
            // update payment method status
            isStatusCheck(value){
                this.form.enabled = value
            },
        },
        computed: {
            formBtnText(){
                if(typeof this.addon.id !== 'undefined'){
                    return 'Update';
                }
                return 'Create';
            },
            showBackBtn(){
                return typeof this.addon === 'undefined';
            },
            backUrl(){
                return route('staff.settings.fees.accommodation.fee-addons.index');
            },
            cancelUrl(){
                return route('staff.settings.fees.accommodation.fee-addons.index');
            },
        }
    }
</script>

