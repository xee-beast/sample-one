import PackagedPrograms from "./components/packaged-programs";

require('./bootstrap');

window.route = require('./route');

import { createApp } from 'vue';
import { createPinia } from 'pinia';

const app = createApp({});

app.use(createPinia())

import SideBar from "./components/layouts/sidebar/SideBar";
import SubMenu from "./components/layouts/sidebar/SubMenu";

import UserForm from "./components/users/form";
app.component('user-form',UserForm);

app.component('sidebar',SideBar);
app.component('sub-menu',SubMenu);

import RegisterForm from "./components/auth/register";
app.component('register-form',RegisterForm);

import RolePermission from "./components/role_permission/permissions";
app.component('role-permissions',RolePermission);

import RolesIndex from "./components/roles/index";
app.component('roles-index',RolesIndex);

import UserIndex from "./components/users/index";
app.component('users-index',UserIndex);

import AgentShowIndex from "./components/agents/show-listing";
app.component('agent-show-index',AgentShowIndex);

import CalendarCategoriesIndex from "./components/calendar-categories/index";
app.component('calender-index',CalendarCategoriesIndex);

import AgentsIndex from "./components/agents/index";
app.component('agents-index',AgentsIndex);

import RegionIndex from "./components/regions/index"
app.component('region-index', RegionIndex)

import RegionEdit from "./components/regions/edit"
app.component('region-edit', RegionEdit)

import CountryIndex from "./components/countries/index"
app.component('country-index', CountryIndex)

import VisaIndex from "./components/visa/index"
app.component('visa-index', VisaIndex)

import PriceBookCategory from "./components/program-price-books-categories/index"
app.component('price-book-category-index', PriceBookCategory)

import PriceBook from "./components/program-price-books/index"
app.component('price-books-index', PriceBook)

import PriceBookEdit from "./components/program-price-books/edit"
app.component('price-books-edit', PriceBookEdit)

import AccommodationPriceBook from "./components/accommodation-price-books/index"
app.component('accommodation-price-books-index', AccommodationPriceBook)

import AccommodationPriceBookEdit from "./components/accommodation-price-books/edit"
app.component('accommodation-price-books-edit', AccommodationPriceBookEdit)
import CalendarDateIndex from "./components/calendars/index"
app.component('calendar-date-index', CalendarDateIndex)

import CalendarDateEdit from "./components/calendars/edit"
app.component('calendar-date-edit', CalendarDateEdit)

import InsuranceIndex from "./components/insurances/edit"
app.component('insurance-edit', InsuranceIndex)

import AccommodationPriceBookCategory from "./components/accommodation-price-books-categories/index"
app.component('accommodation-price-book-category-index', AccommodationPriceBookCategory)

import PaymentMethod from "./components/payment-methods/index"
app.component('payment-method-index', PaymentMethod)

import PaymentMethodEdit from "./components/payment-methods/edit"
app.component('payment-method-edit', PaymentMethodEdit)

import AccommodationServiceIndex from "./components/accommodation-fee-services/index"
app.component('accommodation-service-index', AccommodationServiceIndex)

import AccommodationServiceEdit from "./components/accommodation-fee-services/edit"
app.component('accommodation-service-edit', AccommodationServiceEdit)

import AccommodationFeeAddonIndex from "./components/accommodation-fee-addons/index"
app.component('accommodation-fee-addon-index', AccommodationFeeAddonIndex)

import AccommodationFeeAddonEdit from "./components/accommodation-fee-addons/edit"
app.component('accommodation-fee-addon-edit', AccommodationFeeAddonEdit)

import LocationIndex from "./components/locations/index"
app.component('location-index', LocationIndex)

import ProgramServiceIndex from "./components/program-fee-services/index"
app.component('program-service-index', ProgramServiceIndex)

import ProgramServiceEdit from "./components/program-fee-services/edit"
app.component('program-service-edit', ProgramServiceEdit)

import programIndex from "./components/programs/index"
app.component('program-index', programIndex)

import programForm from "./components/programs/edit"
app.component('program-form', programForm)

import accommodationIndex from "./components/accommodations/index"
app.component('accommodation-index', accommodationIndex)

import accommodationForm from "./components/accommodations/edit"
app.component('accommodation-form', accommodationForm)

import AccommodationCategoryIndex from "./components/accommodation-categories/index"
app.component('accommodation-category-index', AccommodationCategoryIndex)

import AccommodationCategoryEdit from "./components/accommodation-categories/edit"
app.component('accommodation-category-edit', AccommodationCategoryEdit)

import TransportationIndex from "./components/transportation/index"
app.component('transportation-index', TransportationIndex)

import TransportationEdit from "./components/transportation/edit"
app.component('transportation-edit', TransportationEdit)

import TransportationFeeServiceIndex from "./components/transportation-fee-services/index"
app.component('transportation-fee-service-index', TransportationFeeServiceIndex)

import TransportationFeeServiceEdit from "./components/transportation-fee-services/edit"
app.component('transportation-fee-service-edit', TransportationFeeServiceEdit)

import TransportationFeeAddonIndex from "./components/transportation-fee-addons/index"
app.component('transportation-fee-addon-index', TransportationFeeAddonIndex)

import TransportationFeeAddonEdit from "./components/transportation-fee-addons/edit"
app.component('transportation-fee-addon-edit', TransportationFeeAddonEdit)

import FacultyIndex from "./components/faculties/index"
app.component('faculty-index', FacultyIndex)

import FacultyEdit from "./components/faculties/edit"
app.component('faculty-edit', FacultyEdit)

import FacultyProgram from "./components/faculties/program"
app.component('faculty-program', FacultyProgram)

import PackagedProgramIndex from "./components/packaged-programs/index"
app.component('packaged-program-index', PackagedProgramIndex)

import PackagedProgramEdit from "./components/packaged-programs/edit"
app.component('packaged-program-edit', PackagedProgramEdit)

import FacultyTransportation from "./components/faculties/transportation"
app.component('faculty-transportation', FacultyTransportation)

import FacultyAccommodation from "./components/faculties/accommodation"
app.component('faculty-accommodation', FacultyAccommodation)

import FacultyInsurance from "./components/faculties/insurance"
app.component('faculty-insurance', FacultyInsurance)

import FacultyPaymentMethod from "./components/faculties/payment-method"
app.component('faculty-payment-method', FacultyPaymentMethod)

import ApplicationIndex from "./components/applications/index"
app.component('application-index', ApplicationIndex)

import ApplicationWizard from "./components/applications/wizard/wizard"
app.component('application-wizard', ApplicationWizard)

import ApplicationTrackingSummary from "./components/applications/tracking/summary"
app.component('application-tracking-summary', ApplicationTrackingSummary)

import ApplicationTrackingDetail from "./components/applications/tracking/detail"
app.component('application-tracking-detail', ApplicationTrackingDetail)

import ApplicationTimeline from "./components/applications/tracking/timeline"
app.component('application-tracking-activity', ApplicationTimeline)

import ApplicationTrackingHeader from "./components/applications/tracking/header"
app.component('application-tracking-header', ApplicationTrackingHeader)

import ApplicationTrackingDocuments from "./components/applications/tracking/documents"
app.component('application-tracking-documents', ApplicationTrackingDocuments)

import ApplicationOffer from "./components/applications/tracking/offer"
app.component('application-tracking-offer', ApplicationOffer)

import LanguageIndex from "./components/languages/index"
app.component('language-index', LanguageIndex)

import LanguageEdit from "./components/languages/edit"
app.component('language-edit', LanguageEdit)

import GeneralSettingUsers from "./components/general-settings/users"
app.component('general-setting-users', GeneralSettingUsers)

import GeneralSettingApplicationForm from "./components/general-settings/application-form"
app.component('general-setting-application-form', GeneralSettingApplicationForm)

import SpecialOfferCategoryIndex from "./components/special-offers-categories/index"
app.component('special-offer-category-index', SpecialOfferCategoryIndex)

import SpecialOfferCategoryEdit from "./components/special-offers-categories/edit"
app.component('special-offer-category-edit', SpecialOfferCategoryEdit)

import SpecialOfferIndex from "./components/special-offers/index"
app.component('special-offer-index', SpecialOfferIndex)

import SpecialOfferEdit from "./components/special-offers/edit"
app.component('special-offer-edit', SpecialOfferEdit)

import LetterOfOfferSectionIndex from "./components/letter-of-offer/section/index"
app.component('letter-of-offer-section-index', LetterOfOfferSectionIndex)

import LetterOfOfferSectionEdit from "./components/letter-of-offer/section/edit"
app.component('letter-of-offer-section-edit', LetterOfOfferSectionEdit)

import LetterOfOfferTemplateIndex from "./components/letter-of-offer/template/index"
app.component('letter-of-offer-template-index', LetterOfOfferTemplateIndex)

import LetterOfOfferTemplateEdit from "./components/letter-of-offer/template/edit"
app.component('letter-of-offer-template-edit', LetterOfOfferTemplateEdit)

app.mount('#app');
